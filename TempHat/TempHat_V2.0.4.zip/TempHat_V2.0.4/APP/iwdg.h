#ifndef __IWDG_H
#define __IWDG_H

#include "configure.h"

void iwdg_init(void);
void iwdg_feed(void);

#endif