#ifndef __FAN_H
#define __FAN_H

#include "configure.h"

void fan_init(void);
void fan_on(void);
void fan_off(void);

#endif