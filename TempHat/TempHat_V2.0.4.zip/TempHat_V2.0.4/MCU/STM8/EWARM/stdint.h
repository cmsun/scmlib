#ifndef __STDINT_H
#define __STDINT_H

#include "stm8s.h"

#endif