#ifndef __STDBOOL_H
#define __STDBOOL_H

#include "stm8s.h"

#define true    TRUE
#define false   FALSE

#endif