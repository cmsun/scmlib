#ifndef _LED_H_
#define _LED_H_

#include "hc32_ddl.h"

void led_init(void);
void led_set(uint32_t Hz, float duty);
void led_loop_task(void);

#endif