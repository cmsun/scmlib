#ifndef _WDT_H_
#define _WDT_H_

void wdt_init(void);
void wdt_loop_task(void);

#endif