#ifndef _UTILITY_H_
#define _UTILITY_H_

#include <stdint.h>
#include <stdbool.h>
//#include "ff.h"

#define PI                  (3.141592653589793)

#define min(x, y)           ((x)<(y)?(x):(y))
#define max(x, y)           ((x)>(y)?(x):(y))
#define range(x, min, max)  ((x)<(min)?(min):((x)>(max)?(max):(x))) //���Ʒ�Χ min <= x <= max;
#define count(array)        (sizeof(array)/sizeof(array[0]))        //�������Ա����
    
#define errlocal()          __FILE__, __LINE__, ""
void errdebug(const char *file, uint16_t line, const char *fmt, ...);

uint16_t htons(uint16_t host);
uint32_t htonl(uint32_t host);
uint64_t htonll(uint64_t host);
uint16_t ntohs(uint16_t net);
uint32_t ntohl(uint32_t net);
uint64_t ntohll(uint64_t net);

typedef struct SmoothFilter_TypeDef
{
    float *buff;
    uint8_t SMOOTH_FILTER_CNT;
    int index;
    float sum;
    bool is_full;
} SmoothFilter_TypeDef;

void smooth_filter_init(SmoothFilter_TypeDef *filter, float *buff, uint8_t cnt);
float smooth_filter(SmoothFilter_TypeDef *filter, float value);

//FRESULT f_deldir(const TCHAR *path);

uint16_t checksum_crc16(const uint8_t *data, uint16_t len);
uint16_t checksum_xor(const uint8_t *data, uint16_t len);

#endif