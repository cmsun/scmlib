/**
 *******************************************************************************
 * @file  main.c
 * @brief Main program template.
 @verbatim
   Change Logs:
   Date             Author          Notes
   2020-06-30        CDT         First version
 @endverbatim
 *******************************************************************************
 * Copyright (C) 2020, Huada Semiconductor Co., Ltd. All rights reserved.
 *
 * This software component is licensed by HDSC under BSD 3-Clause license
 * (the "License"); You may not use this file except in compliance with the
 * License. You may obtain a copy of the License at:
 *                    opensource.org/licenses/BSD-3-Clause
 */
/*******************************************************************************
 * Include files
 ******************************************************************************/
#include "hc32_ddl.h"

#include "wdt.h"
#include "led.h"
#include "radar.h"
#include "utility.h"
#include "uart_utility.h"
#include "modbus_slave.h"

/*******************************************************************************
 * Local type definitions ('typedef')
 ******************************************************************************/

/*******************************************************************************
 * Local pre-processor symbols/macros ('#define')
 ******************************************************************************/

/*******************************************************************************
 * Global variable definitions (declared in header file with 'extern')
 ******************************************************************************/

/*******************************************************************************
 * Local function prototypes ('static')
 ******************************************************************************/

/*******************************************************************************
 * Local variable definitions ('static')
 ******************************************************************************/
 /**
 * @brief ICG parameters configuration
 */
 /* The ICG area is filled with F by default, HRC = 16MHZ,
    Please modify this value as required */
#if defined ( __GNUC__ ) && !defined (__CC_ARM) /* GNU Compiler */
const uint32_t u32ICG[] __attribute__((section(".icg_sec"))) =
#elif defined (__CC_ARM)
const uint32_t u32ICG[] __attribute__((at(0x400))) =
#elif defined (__ICCARM__)
__root const uint32_t u32ICG[] @ 0x400 =
#else
#error "unsupported compiler!!"
#endif
{
    /* ICG 0~ 3 */
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
    /* ICG 4~ 7 */
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
    0xFFFFFFFFUL,
};

static void System_Config(void)
{
    stc_clk_sysclk_cfg_t    stcSysClkCfg;
    stc_clk_xtal_cfg_t      stcXtalCfg;
    stc_clk_mpll_cfg_t      stcMpllCfg;
    stc_sram_config_t       stcSramConfig;
    
    MEM_ZERO_STRUCT(stcSysClkCfg);
    MEM_ZERO_STRUCT(stcXtalCfg);
    MEM_ZERO_STRUCT(stcMpllCfg);
    MEM_ZERO_STRUCT(stcSramConfig);
    
    /* Set bus clk div. */
    stcSysClkCfg.enHclkDiv = ClkSysclkDiv1;
    stcSysClkCfg.enExclkDiv = ClkSysclkDiv2;
    stcSysClkCfg.enPclk0Div = ClkSysclkDiv1;
    stcSysClkCfg.enPclk1Div = ClkSysclkDiv2;//200MHz/2=100MHz
    stcSysClkCfg.enPclk2Div = ClkSysclkDiv4;
    stcSysClkCfg.enPclk3Div = ClkSysclkDiv4;
    stcSysClkCfg.enPclk4Div = ClkSysclkDiv2;
    CLK_SysClkConfig(&stcSysClkCfg);
   
    /* Config Xtal and Enable Xtal */
    /*
    ClkXtalModeOsc:     ��������<��Դ����>
    ClkXtalModeExtClk:  �ⲿʱ��Դ<��Դ����>
    */
    stcXtalCfg.enMode = ClkXtalModeExtClk;
    stcXtalCfg.enDrv = ClkXtalHighDrv;
    stcXtalCfg.enFastStartup = Enable;
    CLK_XtalConfig(&stcXtalCfg);
    CLK_XtalCmd(Enable);
    
    /* ���ʱ��Դʹ���ڲ����� */
    //CLK_HrcCmd(Enable);
    
    /* sram init include read/write wait cycle setting */
    stcSramConfig.u8SramIdx = Sram12Idx | Sram3Idx | SramHsIdx | SramRetIdx;
    stcSramConfig.enSramRC = SramCycle2;
    stcSramConfig.enSramWC = SramCycle2;
    stcSramConfig.enSramEccMode = EccMode3;
    stcSramConfig.enSramEccOp = SramNmi;
    stcSramConfig.enSramPyOp = SramNmi;
    SRAM_Init(&stcSramConfig);
    
    /* flash read wait cycle setting */
    EFM_Unlock();
    EFM_SetLatency(EFM_LATENCY_5);
    EFM_Lock();
    
    /* MPLL config (XTAL / pllmDiv * plln / PllpDiv = 200M). 
                    24MHz / 3 *  50  /  2  = 200MHz
       MPLL config (HRC / pllmDiv * plln / PllpDiv = 200M). 
                    16MHz / 2 *  50  /  2  = 200MHz
    */
    stcMpllCfg.pllmDiv = 3ul;
    stcMpllCfg.plln    = 50ul;
    stcMpllCfg.PllpDiv = 2ul;
    stcMpllCfg.PllqDiv = 2ul;
    stcMpllCfg.PllrDiv = 2ul;
    CLK_SetPllSource(ClkPllSrcXTAL); /* ѡ��ʱ��ԴΪ�ⲿ����(Ҫ����XTAL_VALUE����Ϊ24000000) */
    CLK_MpllConfig(&stcMpllCfg);
    
    /* Enable MPLL. */
    CLK_MpllCmd(Enable);
    /* Wait MPLL ready. */
    while(Set != CLK_GetFlagStatus(ClkFlagMPLLRdy))
    {
        ;
    }
    
    /* Switch driver ability */
    PWC_HS2HP();
    /* Switch system clock source to MPLL. */
    CLK_SetSysClkSource(CLKSysSrcMPLL);
}

void SysTick_IrqHandler(void)
{
    SysTick_IncTick();
}

/*******************************************************************************
 * Function implementation - global ('extern') and local ('static')
 ******************************************************************************/

/**
 * @brief  Main function of template project
 * @param  None
 * @retval int32_t return value, if needed
 */
int32_t main(void)
{   
    System_Config();
    SysTick_Init(1000u);
    led_init();
    uart_init();
    radar_modbus_init();
    modbus_slave_init();
    wdt_init();
    
    /* add your code here */
    while(1)
    {
        if(radar_front_left_distance() == 0xffff
            || radar_front_right_distance() == 0xffff
            || radar_rear_left_distance() == 0xffff
            || radar_rear_right_distance() == 0xffff)
        {
            led_set(1, 0.1f);
        }
        else
        {
            led_set(10, 0.1f);
        }
        
        uart_rx_timeout_loop_check(hRS485_1);
        uart_rx_timeout_loop_check(hRS485_2);
        uart_rx_timeout_loop_check(hRS485_3);
        
        radar_loop_task();
        modbus_slave_loop_task();
        led_loop_task();
        wdt_loop_task();
    }
}

/*******************************************************************************
 * EOF (not truncated)
 ******************************************************************************/
