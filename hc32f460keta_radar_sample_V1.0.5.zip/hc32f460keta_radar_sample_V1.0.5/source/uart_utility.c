#include <stdio.h>
#include <string.h>
#include "uart_utility.h"
#include "utility.h"

#define UART1_RX_BUFF_LENGTH 32
#define UART1_TX_BUFF_LENGTH 32
#define UART2_RX_BUFF_LENGTH 32
#define UART2_TX_BUFF_LENGTH 32
#define UART3_RX_BUFF_LENGTH 32
#define UART3_TX_BUFF_LENGTH 32

struct UartDataStruct_TypeDef_ {
    M4_USART_TypeDef *UARTx;
    M4_DMA_TypeDef *DMAx;
    en_dma_channel_t dma_ch_rx;
    en_dma_channel_t dma_ch_tx;
    en_event_src_t dma_event_trigger_rx;
    en_event_src_t dma_event_trigger_tx;
    en_port_t rs485_de_port;
    uint16_t rs485_de_pin;
    M4_TMR0_TypeDef *TMR0x;
    en_tim0_channel_t tim0_channelx;
    bool busy;
    //UART数据接收相关属性和方法
    const uint16_t RX_BUFF_SIZE;
    const uint32_t RX_TIMEOUT;
    uint8_t *rx_buff;
    uint16_t rx_count;
    uint32_t rx_timeout;
    __IO bool rx_complete;
    //UART数据发送相关属性和方法
    const uint16_t TX_BUFF_SIZE;
    uint8_t *tx_buff;
};

uint8_t uart1rxbuff[UART1_RX_BUFF_LENGTH] = {0};
uint8_t uart1txbuff[UART1_TX_BUFF_LENGTH] = {0};
UartDataStruct_TypeDef UART1DataStruct = {
    .UARTx = M4_USART1,
    .DMAx = M4_DMA1,
    .dma_ch_rx = DmaCh0,
    .dma_ch_tx = DmaCh1,
    .dma_event_trigger_rx = EVT_USART1_RI,
    .dma_event_trigger_tx = EVT_USART1_TI,
    .TMR0x = M4_TMR01,
    .tim0_channelx = Tim0_ChannelA,
    .rs485_de_port = PortC,
    .rs485_de_pin = Pin09,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart1rxbuff),
    .RX_TIMEOUT = 3,
    .rx_buff = uart1rxbuff,
    .rx_count = 0,
    .rx_timeout = 0,
    .rx_complete = false,
    .TX_BUFF_SIZE = sizeof(uart1txbuff),
    .tx_buff = uart1txbuff,
};

uint8_t uart2rxbuff[UART2_RX_BUFF_LENGTH] = {0};
uint8_t uart2txbuff[UART2_TX_BUFF_LENGTH] = {0};
UartDataStruct_TypeDef UART2DataStruct = {
    .UARTx = M4_USART2,
    .DMAx = M4_DMA1,
    .dma_ch_rx = DmaCh2,
    .dma_ch_tx = DmaCh3,
    .dma_event_trigger_rx = EVT_USART2_RI,
    .dma_event_trigger_tx = EVT_USART2_TI,
    .TMR0x = M4_TMR01,
    .tim0_channelx = Tim0_ChannelB,
    .rs485_de_port = PortA,
    .rs485_de_pin = Pin10,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart2rxbuff),
    .RX_TIMEOUT = 3,
    .rx_buff = uart2rxbuff,
    .rx_count = 0,
    .rx_timeout = 0,
    .rx_complete = false,
    .TX_BUFF_SIZE = sizeof(uart2txbuff),
    .tx_buff = uart2txbuff,
};

uint8_t uart3rxbuff[UART3_RX_BUFF_LENGTH] = {0};
uint8_t uart3txbuff[UART3_TX_BUFF_LENGTH] = {0};
UartDataStruct_TypeDef UART3DataStruct = {
    .UARTx = M4_USART3,
    .DMAx = M4_DMA2,
    .dma_event_trigger_rx = EVT_USART3_RI,
    .dma_event_trigger_tx = EVT_USART3_TI,
    .dma_ch_rx = DmaCh0,
    .dma_ch_tx = DmaCh1,
    .TMR0x = M4_TMR02,
    .tim0_channelx = Tim0_ChannelA,
    .rs485_de_port = PortB,
    .rs485_de_pin = Pin12,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart3rxbuff),
    .RX_TIMEOUT = 3,
    .rx_buff = uart3rxbuff,
    .rx_count = 0,
    .rx_timeout = 0,
    .rx_complete = false,
    .TX_BUFF_SIZE = sizeof(uart3txbuff),
    .tx_buff = uart3txbuff,
};

UartDataStruct_TypeDef *hRS485_1 = &UART1DataStruct;
UartDataStruct_TypeDef *hRS485_2 = &UART2DataStruct;
UartDataStruct_TypeDef *hRS485_3 = &UART3DataStruct;

//当485在接收数据时不能发送数据，否则接收到的数据就不完整。
//当使用DMA发送数据时必须等待发送完成才能再发送一下次数据。
bool uart_busy(UartDataStruct_TypeDef *uds)
{
    return uds->busy;
}

void uart_rx_timeout_loop_check(UartDataStruct_TypeDef *uds)
{
    if(!uds->rx_complete
        && uds->rx_count > 0
        && SysTick_GetTick() - uds->rx_timeout >= uds->RX_TIMEOUT)
    {
        uds->rx_complete = true;
        
        USART_FuncCmd(uds->UARTx, UsartRx, Disable);
        USART_FuncCmd(uds->UARTx, UsartRxInt, Disable);
        USART_FuncCmd(uds->UARTx, UsartTimeOut, Disable);
        USART_FuncCmd(uds->UARTx, UsartTimeOutInt, Disable);
    }
}

bool uart_rx_successful(UartDataStruct_TypeDef *uds)
{
    return uds->rx_complete;
}

uint8_t *uart_rx_data(UartDataStruct_TypeDef *uds)
{
    return uds->rx_complete ? uds->rx_buff : NULL;
}

uint16_t uart_rx_data_len(UartDataStruct_TypeDef *uds)
{  
    return uds->rx_complete ? uds->rx_count : 0;
}

void uart_rx_clear(UartDataStruct_TypeDef *uds)
{
    uds->rx_count = 0;
    uds->rx_complete = false;
    
    memset(uds->rx_buff, 0, uds->RX_BUFF_SIZE);
    
    //DMA_SetDesAddress(uds->DMAx, uds->dma_ch_rx, (uint32_t)(uds->rx_buff));
    //重新设置接收地址后接收最大数量会被随机改变，必须重新设置接收的最大数量
    //DMA_SetDesRptSize(uds->DMAx, uds->dma_ch_rx, uds->RX_BUFF_SIZE);

    USART_FuncCmd(uds->UARTx, UsartRx, Enable);
    USART_FuncCmd(uds->UARTx, UsartRxInt, Enable);
//    USART_FuncCmd(uds->UARTx, UsartTimeOut, Enable);
//    USART_FuncCmd(uds->UARTx, UsartTimeOutInt, Enable);
}

//不建议使用这个函数读取数据，因为单片机内存少，没有必要复制一份数据后再处理。
//读数据的方式应该为：uart_rx_successful()来判断是否有数据，然后用uart_rx_data()
//来读取数据所在内存，再用uart_rx_data_len()来读取数据大小。数据处理完后调用
//uart_rx_clear()来清除接收缓存的数据，否则不会接收新数据。
uint16_t uart_read(UartDataStruct_TypeDef *uds, uint8_t *buff, uint16_t size)
{
    uint16_t cnt = 0;
    if(uart_rx_successful(uds))
    {
        cnt = uart_rx_data_len(uds);
        cnt = (cnt < size ? cnt : size);
        memcpy(buff, uart_rx_data(uds), cnt);
        uart_rx_clear(uds);
    }
    return cnt;
}

void uart_send_poll(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len)
{
    rs485_de_write(uds);
    for(uint16_t i = 0; i < len; ++i)
    {
        while(Reset == USART_GetStatus(uds->UARTx, UsartTxEmpty))
            ;
        USART_SendData(uds->UARTx, data[i]);
    }
    //如果不等待最后一个字符发送完成就把485变成读状态，则最后一个字符会丢失。
    while(Reset == USART_GetStatus(uds->UARTx, UsartTxComplete))
        ;
    rs485_de_read(uds);
}

void uart_send_dma(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len)
{
    uint16_t cnt = min(uds->TX_BUFF_SIZE, len);
    if(!uds->busy)
    {
        uds->busy = true;
        
        rs485_de_write(uds);

        memcpy(uds->tx_buff, data, cnt);
        DMA_SetSrcAddress(uds->DMAx, uds->dma_ch_tx, (uint32_t)(uds->tx_buff));
        DMA_SetTransferCnt(uds->DMAx, uds->dma_ch_tx, cnt);
        DMA_ChannelCmd(uds->DMAx, uds->dma_ch_tx, Enable);
        
        USART_FuncCmd(uds->UARTx, UsartTx, Enable);
        USART_FuncCmd(uds->UARTx, UsartTxCmpltInt, Enable);
    }
}

void rs485_de_read(UartDataStruct_TypeDef *uds)
{
    PORT_ResetBits(uds->rs485_de_port, uds->rs485_de_pin);
}

void rs485_de_write(UartDataStruct_TypeDef *uds)
{
    PORT_SetBits(uds->rs485_de_port, uds->rs485_de_pin);
}

static void UsartErrIrqCallback_Common(UartDataStruct_TypeDef *uds)
{
    if (Set == USART_GetStatus(uds->UARTx, UsartFrameErr))
    {
        USART_ClearStatus(uds->UARTx, UsartFrameErr);
    }
    else
    {
    }

    if (Set == USART_GetStatus(uds->UARTx, UsartParityErr))
    {
        USART_ClearStatus(uds->UARTx, UsartParityErr);
    }
    else
    {
    }

    if (Set == USART_GetStatus(uds->UARTx, UsartOverrunErr))
    {
        USART_ClearStatus(uds->UARTx, UsartOverrunErr);
    }
    else
    {
    }
}

static void Usart1ErrIrqCallback(void)
{
    UsartErrIrqCallback_Common(hRS485_1);
}

static void Usart2ErrIrqCallback(void)
{
    UsartErrIrqCallback_Common(hRS485_2);
}

static void Usart3ErrIrqCallback(void)
{
    UsartErrIrqCallback_Common(hRS485_3);
}

static void UsartRxIrqCallback_Common(UartDataStruct_TypeDef *uds)
{
    uint8_t byte = USART_RecData(uds->UARTx);
    if(uds->rx_count < uds->RX_BUFF_SIZE)
    {
        uds->rx_buff[uds->rx_count++] = byte;
        uds->rx_timeout = SysTick_GetTick();
    }
}

static void Usart1RxIrqCallback(void)
{
    UsartRxIrqCallback_Common(hRS485_1);
}

static void Usart2RxIrqCallback(void)
{
    UsartRxIrqCallback_Common(hRS485_2);
}

static void Usart3RxIrqCallback(void)
{
    UsartRxIrqCallback_Common(hRS485_3);
}

static void UsartTimeoutIrqCallback_Common(UartDataStruct_TypeDef *uds)
{   
    uds->rx_complete = true;
    uds->rx_count = DMA_GetDesAddr(uds->DMAx, uds->dma_ch_rx) - (uint32_t)(uds->rx_buff);
    
    TIMER0_Cmd(uds->TMR0x, uds->tim0_channelx, Disable);
    USART_ClearStatus(uds->UARTx, UsartRxTimeOut);
    
    USART_FuncCmd(uds->UARTx, UsartRx, Disable);
    USART_FuncCmd(uds->UARTx, UsartRxInt, Disable);
    USART_FuncCmd(uds->UARTx, UsartTimeOut, Disable);
    USART_FuncCmd(uds->UARTx, UsartTimeOutInt, Disable);
}

static void Usart1TimeoutIrqCallback(void)
{
    UsartTimeoutIrqCallback_Common(hRS485_1);
}

static void Usart2TimeoutIrqCallback(void)
{
    UsartTimeoutIrqCallback_Common(hRS485_2);
}

static void Usart3TimeoutIrqCallback(void)
{
    UsartTimeoutIrqCallback_Common(hRS485_3);
}

static void UsartTxCmpltIrqCallback_Common(UartDataStruct_TypeDef *uds)
{   
    uds->busy = false;
    rs485_de_read(uds);
    DMA_ChannelCmd(uds->DMAx, uds->dma_ch_tx, Disable);
    DMA_ClearIrqFlag(uds->DMAx, uds->dma_ch_tx, TrnCpltIrq);
    USART_FuncCmd(uds->UARTx, UsartTx, Disable);
    USART_FuncCmd(uds->UARTx, UsartTxCmpltInt, Disable);
}

static void Usart1TxCmpltIrqCallback(void)
{
    UsartTxCmpltIrqCallback_Common(hRS485_1);
}

static void Usart2TxCmpltIrqCallback(void)
{
    UsartTxCmpltIrqCallback_Common(hRS485_2);
}

static void Usart3TxCmpltIrqCallback(void)
{
    UsartTxCmpltIrqCallback_Common(hRS485_3);
}
    
static void uart1_init(void) /*有2个接口*/
{
    stc_usart_uart_init_t   stcInitCfg;
    stc_irq_regi_conf_t     stcIrqRegiCfg;    
    
    PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_USART1, Enable);
        
    stcInitCfg.enClkDiv     = UsartClkDiv_64;
    stcInitCfg.enClkMode    = UsartIntClkCkNoOutput;
    stcInitCfg.enDataLength = UsartDataBits8;
    stcInitCfg.enDetectMode = UsartStartBitFallEdge;
    stcInitCfg.enHwFlow     = UsartRtsEnable;
    stcInitCfg.enParity     = UsartParityNone;
    stcInitCfg.enSampleMode = UsartSampleBit8;
    stcInitCfg.enStopBit    = UsartOneStopBit;
    stcInitCfg.enDirection  = UsartDataLsbFirst;
    
    PORT_SetFunc(RS485_1_Rx_PORT, RS485_1_Rx_PIN, Func_Usart1_Rx, Disable);
    PORT_SetFunc(RS485_1_Tx_PORT, RS485_1_Tx_PIN, Func_Usart1_Tx, Disable);
    
    USART_UART_Init(M4_USART1, &stcInitCfg);
    USART_SetBaudrate(M4_USART1, 9600);
    
    /* Set USART Rx Error IRQ */
    stcIrqRegiCfg.enIRQn = Int000_IRQn;
    stcIrqRegiCfg.pfnCallback = Usart1ErrIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART1_EI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /* Set USART Rx IRQ */
    stcIrqRegiCfg.enIRQn = Int001_IRQn;
    stcIrqRegiCfg.pfnCallback = Usart1RxIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART1_RI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Rx Timeout IRQ*/
//    stcIrqRegiCfg.enIRQn = Int002_IRQn;
//    stcIrqRegiCfg.pfnCallback = Usart1TimeoutIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART1_RTO;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Tx Complete IRQ*/
//    stcIrqRegiCfg.enIRQn = Int003_IRQn;
//    stcIrqRegiCfg.pfnCallback = Usart1TxCmpltIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART1_TCI;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
  
    USART_FuncCmd(M4_USART1, UsartTx, Enable);
    USART_FuncCmd(M4_USART1, UsartRx, Enable);
    USART_FuncCmd(M4_USART1, UsartRxInt, Enable);
//    USART_FuncCmd(M4_USART1, UsartTimeOut, Enable);
//    USART_FuncCmd(M4_USART1, UsartTimeOutInt, Enable);
}

static void uart2_init(void) /*有3个接口*/
{
    stc_usart_uart_init_t   stcInitCfg;
    stc_irq_regi_conf_t     stcIrqRegiCfg;
    
    PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_USART2, Enable);
           
    stcInitCfg.enClkDiv     = UsartClkDiv_64;
    stcInitCfg.enClkMode    = UsartIntClkCkNoOutput;
    stcInitCfg.enDataLength = UsartDataBits8;
    stcInitCfg.enDetectMode = UsartStartBitFallEdge;
    stcInitCfg.enHwFlow     = UsartRtsEnable;
    stcInitCfg.enParity     = UsartParityNone;
    stcInitCfg.enSampleMode = UsartSampleBit16;
    stcInitCfg.enStopBit    = UsartOneStopBit;
    stcInitCfg.enDirection  = UsartDataLsbFirst;
    
    PORT_SetFunc(RS485_2_Rx_PORT, RS485_2_Rx_PIN, Func_Usart2_Rx, Disable);
    PORT_SetFunc(RS485_2_Tx_PORT, RS485_2_Tx_PIN, Func_Usart2_Tx, Disable);
    
    USART_UART_Init(M4_USART2, &stcInitCfg);
    USART_SetBaudrate(M4_USART2, 9600);
    
    /* Set USART Rx Error IRQ */
    stcIrqRegiCfg.enIRQn = Int004_IRQn;
    stcIrqRegiCfg.pfnCallback = Usart2ErrIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART2_EI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /* Set USART Rx IRQ */
    stcIrqRegiCfg.enIRQn = Int005_IRQn;
    stcIrqRegiCfg.pfnCallback = Usart2RxIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART2_RI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Rx Timeout IRQ*/
//    stcIrqRegiCfg.enIRQn = Int006_IRQn;
//    stcIrqRegiCfg.pfnCallback = Usart2TimeoutIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART2_RTO;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Tx Complete IRQ*/
//    stcIrqRegiCfg.enIRQn = Int007_IRQn;
//    stcIrqRegiCfg.pfnCallback = Usart2TxCmpltIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART2_TCI;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    USART_FuncCmd(M4_USART2, UsartTx, Enable);
    USART_FuncCmd(M4_USART2, UsartRx, Enable);
    USART_FuncCmd(M4_USART2, UsartRxInt, Enable);
//    USART_FuncCmd(M4_USART2, UsartTimeOut, Enable);
//    USART_FuncCmd(M4_USART2, UsartTimeOutInt, Enable);
}

static void uart3_init(void) /*有1个接口*/
{
    stc_usart_uart_init_t   stcInitCfg;
    stc_irq_regi_conf_t     stcIrqRegiCfg;
    
    PWC_Fcg1PeriphClockCmd(PWC_FCG1_PERIPH_USART3, Enable);
        
    stcInitCfg.enClkDiv     = UsartClkDiv_64;
    stcInitCfg.enClkMode    = UsartIntClkCkNoOutput;
    stcInitCfg.enDataLength = UsartDataBits8;
    stcInitCfg.enDetectMode = UsartStartBitFallEdge;
    stcInitCfg.enHwFlow     = UsartRtsEnable;
    stcInitCfg.enParity     = UsartParityEven;
    stcInitCfg.enSampleMode = UsartSampleBit8;
    stcInitCfg.enStopBit    = UsartOneStopBit;
    stcInitCfg.enDirection  = UsartDataLsbFirst;
    
    PORT_SetFunc(RS485_3_Rx_PORT, RS485_3_Rx_PIN, Func_Usart3_Rx, Disable);
    PORT_SetFunc(RS485_3_Tx_PORT, RS485_3_Tx_PIN, Func_Usart3_Tx, Disable);
    
    USART_UART_Init(M4_USART3, &stcInitCfg);
    USART_SetBaudrate(M4_USART3, 19200);
    
    /* Set USART Rx Error IRQ */
    stcIrqRegiCfg.enIRQn = Int008_IRQn;
    stcIrqRegiCfg.pfnCallback = Usart3ErrIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART3_EI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /* Set USART Rx IRQ */
    stcIrqRegiCfg.enIRQn = Int009_IRQn;
    stcIrqRegiCfg.pfnCallback = &Usart3RxIrqCallback;
    stcIrqRegiCfg.enIntSrc = INT_USART3_RI;
    enIrqRegistration(&stcIrqRegiCfg);
    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Rx Timeout IRQ*/
//    stcIrqRegiCfg.enIRQn = Int010_IRQn;
//    stcIrqRegiCfg.pfnCallback = &Usart3TimeoutIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART3_RTO;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    /*Set USART Tx Complete IRQ*/
//    stcIrqRegiCfg.enIRQn = Int011_IRQn;
//    stcIrqRegiCfg.pfnCallback = Usart3TxCmpltIrqCallback;
//    stcIrqRegiCfg.enIntSrc = INT_USART3_TCI;
//    enIrqRegistration(&stcIrqRegiCfg);
//    NVIC_SetPriority(stcIrqRegiCfg.enIRQn, DDL_IRQ_PRIORITY_DEFAULT);
//    NVIC_ClearPendingIRQ(stcIrqRegiCfg.enIRQn);
//    NVIC_EnableIRQ(stcIrqRegiCfg.enIRQn);
    
    USART_FuncCmd(M4_USART3, UsartTx, Enable);
    USART_FuncCmd(M4_USART3, UsartRx, Enable);
    USART_FuncCmd(M4_USART3, UsartRxInt, Enable);
//    USART_FuncCmd(M4_USART3, UsartTimeOut, Enable);
//    USART_FuncCmd(M4_USART3, UsartTimeOutInt, Enable);
}

static void rs485_de_init(UartDataStruct_TypeDef *uds)
{
    stc_port_init_t stcPortInit;
    
    MEM_ZERO_STRUCT(stcPortInit);
    stcPortInit.enPinMode   = Pin_Mode_Out;
    stcPortInit.enExInt     = Disable;
    stcPortInit.enPullUp    = Enable;
    PORT_Init(uds->rs485_de_port, uds->rs485_de_pin, &stcPortInit);
    
    rs485_de_read(uds);
}

static void uart_dma_init(UartDataStruct_TypeDef *uds)
{
    stc_dma_config_t stcDmaInit;
    stc_irq_regi_conf_t stcIrqRegiCfg;

    /* Enable peripheral clock */
    PWC_Fcg0PeriphClockCmd((uds->DMAx == M4_DMA1 ? PWC_FCG0_PERIPH_DMA1 : PWC_FCG0_PERIPH_DMA2), Enable);
    /* Enable peripheral circuit trigger function. */
    PWC_Fcg0PeriphClockCmd(PWC_FCG0_PERIPH_AOS, Enable);

    /* Enable USART DMA. */
    DMA_Cmd(uds->DMAx, Enable);

    /* Initialize USART DMA Rx. */
    MEM_ZERO_STRUCT(stcDmaInit);
    stcDmaInit.u16BlockSize = 1u;
    stcDmaInit.u32SrcAddr = ((uint32_t)(&uds->UARTx->DR)+2ul);
    stcDmaInit.u32DesAddr = (uint32_t)(uds->rx_buff);
    stcDmaInit.u16DesRptSize = uds->RX_BUFF_SIZE;
    stcDmaInit.stcDmaChCfg.enDesRptEn = Enable; /* 设置成循环模式，否则接收的数据量过大的话会越界写数据导致程序崩溃。 */
    stcDmaInit.stcDmaChCfg.enSrcInc = AddressFix;
    stcDmaInit.stcDmaChCfg.enDesInc = AddressIncrease;
    stcDmaInit.stcDmaChCfg.enIntEn = Disable;
    stcDmaInit.stcDmaChCfg.enTrnWidth = Dma8Bit;
    DMA_InitChannel(uds->DMAx, uds->dma_ch_rx, &stcDmaInit);
    /* Enable the specified DMA channel. */
    DMA_ChannelCmd(uds->DMAx, uds->dma_ch_rx, Enable);
    /* Set DMA trigger source. */
    DMA_SetTriggerSrc(uds->DMAx, uds->dma_ch_rx, uds->dma_event_trigger_rx);
    
    /* Initialize USART DMA Tx. */
    MEM_ZERO_STRUCT(stcDmaInit);
    stcDmaInit.u16BlockSize = 1u;
    stcDmaInit.u32SrcAddr = (uint32_t)(uds->tx_buff);
    stcDmaInit.u32DesAddr = (uint32_t)(&uds->UARTx->DR);
    stcDmaInit.u16SrcRptSize = uds->TX_BUFF_SIZE;
    stcDmaInit.stcDmaChCfg.enSrcRptEn = Disable; /* 不设置，或者设置成Disable，否则发送的数据会相互覆盖。 */
    stcDmaInit.stcDmaChCfg.enSrcInc = AddressIncrease;
    stcDmaInit.stcDmaChCfg.enDesInc = AddressFix;
    stcDmaInit.stcDmaChCfg.enIntEn = Disable;
    stcDmaInit.stcDmaChCfg.enTrnWidth = Dma8Bit;
    DMA_InitChannel(uds->DMAx, uds->dma_ch_tx, &stcDmaInit);
    /* Enable the specified DMA channel. */
    //DMA_ChannelCmd(uds->DMAx, uds->dma_ch_tx, Enable);
    /* Set DMA trigger source. */
    DMA_SetTriggerSrc(uds->DMAx, uds->dma_ch_tx, uds->dma_event_trigger_tx);
}

static void Timer0Init(void)
{
    stc_clk_freq_t stcClkTmp;
    stc_tim0_base_init_t stcTimerCfg;
    stc_tim0_trigger_init_t StcTimer0TrigInit;

    MEM_ZERO_STRUCT(stcClkTmp);
    MEM_ZERO_STRUCT(stcTimerCfg);
    MEM_ZERO_STRUCT(StcTimer0TrigInit);

    /* Timer0 peripheral enable */
    PWC_Fcg2PeriphClockCmd(PWC_FCG2_PERIPH_TIM01 | PWC_FCG2_PERIPH_TIM02, Enable);

    /* Clear CNTAR register for channel */
    TIMER0_WriteCntReg(M4_TMR01, Tim0_ChannelA, 0u);
    TIMER0_WriteCntReg(M4_TMR01, Tim0_ChannelB, 0u);
    TIMER0_WriteCntReg(M4_TMR02, Tim0_ChannelA, 0u);

    CLK_LrcCmd(Enable);
    //使用内部32KHz的LRC震荡器为作异步时钟。32KHz/32=1KHz 则4个时钟为4ms
    stcTimerCfg.Tim0_CounterMode = Tim0_Async;
    stcTimerCfg.Tim0_AsyncClockSource = Tim0_LRC;
    stcTimerCfg.Tim0_ClockDivision = Tim0_ClkDiv32;
    stcTimerCfg.Tim0_CmpValue = (4u-1u);
    TIMER0_BaseInit(M4_TMR01, Tim0_ChannelA, &stcTimerCfg);
    //4ms超时时间：100MHz/32=3.125MHz 3125000Hz/1000=3125 3125*4=12500
    //定时器的这个通道有问题，在没有触发的时候不断计时，并且在计数值和比较值没有相等的情况下就会产生事件。导致串口2没有数据接收也不断进入接收超时中断。
    stcTimerCfg.Tim0_CounterMode = Tim0_Async;
    stcTimerCfg.Tim0_AsyncClockSource = Tim0_LRC;
    stcTimerCfg.Tim0_ClockDivision = Tim0_ClkDiv32;
    stcTimerCfg.Tim0_CmpValue = (4u-1u);
    TIMER0_BaseInit(M4_TMR01, Tim0_ChannelB, &stcTimerCfg);
    //4ms超时时间：100MHz/32=3.125MHz 3125000Hz/1000=3125 3125*4=12500
    stcTimerCfg.Tim0_CounterMode = Tim0_Sync;
    stcTimerCfg.Tim0_SyncClockSource = Tim0_Pclk1;
    stcTimerCfg.Tim0_ClockDivision = Tim0_ClkDiv32;
    stcTimerCfg.Tim0_CmpValue = (12500u-1u);
    TIMER0_BaseInit(M4_TMR02, Tim0_ChannelA, &stcTimerCfg);

    /* Clear compare flag */
    TIMER0_ClearFlag(M4_TMR01, Tim0_ChannelA);
    TIMER0_ClearFlag(M4_TMR01, Tim0_ChannelB);
    TIMER0_ClearFlag(M4_TMR02, Tim0_ChannelA);

    /* Config timer0 hardware trigger */
    /* USART1 : Timer0 Unit1 A 通道 */
    /* USART2 : Timer0 Unit1 B 通道 */
    /* USART3 : Timer0 Unit2 A 通道 */
    /* USART4 : Timer0 Unit2 B 通道 */
    StcTimer0TrigInit.Tim0_InTrigEnable = false;
    StcTimer0TrigInit.Tim0_InTrigClear = true;
    StcTimer0TrigInit.Tim0_InTrigStart = true;
    StcTimer0TrigInit.Tim0_InTrigStop = false;
    TIMER0_HardTriggerInit(M4_TMR01, Tim0_ChannelA, &StcTimer0TrigInit);
    TIMER0_HardTriggerInit(M4_TMR01, Tim0_ChannelB, &StcTimer0TrigInit);
    TIMER0_HardTriggerInit(M4_TMR02, Tim0_ChannelA, &StcTimer0TrigInit);
}

void uart_init(void)
{    
    rs485_de_init(hRS485_1);
    rs485_de_init(hRS485_2);
    rs485_de_init(hRS485_3);
    
    uart1_init();
    uart2_init();
    uart3_init();
    
    //用来产生接收超时中断
    //Timer0Init();
    //uart_dma_init(hRS485_1);
    //uart_dma_init(hRS485_2);
    //uart_dma_init(hRS485_3);
}