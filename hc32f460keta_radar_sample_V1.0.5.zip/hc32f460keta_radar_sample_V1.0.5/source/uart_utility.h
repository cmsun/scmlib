#ifndef __UART_UTILITY_H
#define __UART_UTILITY_H

#include <stdint.h>
#include <stdbool.h>
#include "hc32_ddl.h"

#define RS485_1_Rx_PORT     PortA
#define RS485_1_Rx_PIN      Pin09

#define RS485_1_Tx_PORT     PortA
#define RS485_1_Tx_PIN      Pin08

#define RS485_1_DE_PORT     PortC
#define RS485_1_DE_PIN      Pin09

#define RS485_2_Rx_PORT     PortA
#define RS485_2_Rx_PIN      Pin11

#define RS485_2_Tx_PORT     PortA
#define RS485_2_Tx_PIN      Pin12

#define RS485_2_DE_PORT     PortA
#define RS485_2_DE_PIN      Pin10

#define RS485_3_Rx_PORT     PortB
#define RS485_3_Rx_PIN      Pin14

#define RS485_3_Tx_PORT     PortB
#define RS485_3_Tx_PIN      Pin13

#define RS485_3_DE_PORT     PortB
#define RS485_3_DE_PIN      Pin12

typedef struct UartDataStruct_TypeDef_ UartDataStruct_TypeDef;

extern UartDataStruct_TypeDef *hRS485_1;
extern UartDataStruct_TypeDef *hRS485_2;
extern UartDataStruct_TypeDef *hRS485_3;

void uart_init(void);
bool uart_busy(UartDataStruct_TypeDef *uds);
void uart_rx_timeout_loop_check(UartDataStruct_TypeDef *uds);
bool uart_rx_successful(UartDataStruct_TypeDef *uds);
uint8_t *uart_rx_data(UartDataStruct_TypeDef *uds);
uint16_t uart_rx_data_len(UartDataStruct_TypeDef *uds);
void uart_rx_clear(UartDataStruct_TypeDef *uds);
uint16_t uart_read(UartDataStruct_TypeDef *uds, uint8_t *buff, uint16_t size);
void uart_send_poll(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len);
void uart_send_dma(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len);
void rs485_de_read(UartDataStruct_TypeDef *uds);
void rs485_de_write(UartDataStruct_TypeDef *uds);

#endif
