#ifndef _RADAR_H_
#define _RADAR_H_

#include <stdint.h>

void radar_modbus_init(void);
void radar_loop_task(void);
uint16_t radar_front_left_distance(void);
uint16_t radar_front_right_distance(void);
uint16_t radar_rear_left_distance(void);
uint16_t radar_rear_right_distance(void);

#endif