#ifndef _MODBUS_SLAVE_H_
#define _MODBUS_SLAVE_H_

void modbus_slave_init(void);
void modbus_slave_loop_task(void);

#endif