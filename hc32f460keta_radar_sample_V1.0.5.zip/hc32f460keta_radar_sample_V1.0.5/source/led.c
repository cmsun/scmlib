#include "led.h"

static uint32_t LedBlinkHz;
static float LedBlinkDuty;

static inline void led_on(void) {PORT_ResetBits(PortC, Pin00);}
static inline void led_off(void) {PORT_SetBits(PortC, Pin00);}
static inline void led_toggle(void) {PORT_Toggle(PortC, Pin00);}

static void led_blink(uint32_t Hz, float duty)
{
    uint32_t cur, period;
    static uint32_t last = 0;
    
    period = 1000.0f / Hz;
    cur = SysTick_GetTick();
    if(cur - last < period * duty)
    {
        led_on();
    }
    else
    {
        led_off();
        if(cur - last >= period)
        {
            led_on();
            last = cur;
        }
    }
}

void led_init(void)
{
    stc_port_init_t stcPortInit;
    
    MEM_ZERO_STRUCT(stcPortInit);
    
    stcPortInit.enPinMode = Pin_Mode_Out;
    stcPortInit.enExInt   = Enable;
    stcPortInit.enPullUp  = Enable;
    PORT_Init(PortC, Pin00, &stcPortInit);
}

void led_set(uint32_t Hz, float duty)
{
    LedBlinkHz = Hz;
    LedBlinkDuty = duty;
}

void led_loop_task(void)
{
    led_blink(LedBlinkHz, LedBlinkDuty);
}