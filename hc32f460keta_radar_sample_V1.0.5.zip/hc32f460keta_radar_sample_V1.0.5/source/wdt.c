#include "wdt.h"

#include "hc32_ddl.h"

void wdt_init(void)
{
    stc_wdt_init_t stcWdtInit;
    stc_irq_regi_conf_t stcIrqRegiConf;

    /* configure structure initialization */
    MEM_ZERO_STRUCT(stcWdtInit);
    MEM_ZERO_STRUCT(stcIrqRegiConf);

    /* WDT structure parameters configure */
    /* 50MHz/2048=24414Hz 4096/24414=0.167 ��ʱʱ��Ϊ167ms */
    stcWdtInit.enClkDiv = WdtPclk3Div2048;
    stcWdtInit.enCountCycle = WdtCountCycle4096;
    stcWdtInit.enRefreshRange = WdtRefresh0To100Pct;
    stcWdtInit.enSleepModeCountEn = Enable;
    stcWdtInit.enRequestType = WdtTriggerResetRequest;
    WDT_Init(&stcWdtInit);
    
    //���Ź���ʼ�����������ֵΪ0��Ҫˢ�¿��Ź����������Ź���������
    WDT_RefreshCounter();
}

void wdt_loop_task(void)
{
    static uint32_t period = 0;
    
    if(SysTick_GetTick() - period >= 20)
    {
        period = SysTick_GetTick();
        WDT_RefreshCounter();
    }
}