#include "modbus_slave.h"
#include "modbus.h"
#include "utility.h"
#include "uart_utility.h"
#include "radar.h"

#define MODBUS_SLAVE_UART hRS485_3

void modbus_slave_init(void)
{
    mb_init(MODBUS_RTU, 4);
}

void mb_raw_send(mbu8 *data, mbu16 length)
{
    uart_send_poll(MODBUS_SLAVE_UART, data, length);
    //uart_send_dma(MODBUS_SLAVE_UART, data, length);
}

void modbus_slave_loop_task(void)
{
    uint8_t data[32];
    uint16_t len;
    
    mbHoldReg[0] = radar_front_left_distance();
    mbHoldReg[1] = radar_front_right_distance();
    mbHoldReg[2] = radar_rear_left_distance();
    mbHoldReg[3] = radar_rear_right_distance();
    
    if(uart_rx_successful(MODBUS_SLAVE_UART))
    {
        len = uart_read(MODBUS_SLAVE_UART, data, count(data));
        for(uint16_t i = 0; i < len; ++i)
        {
            mb_receive(data[i]);
        }
        mb_timeout();
        mb_poll();
    }
}