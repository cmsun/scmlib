#include "radar.h"
#include "utility.h"
#include "uart_utility.h"

#define RADAR_FRONT_UART    hRS485_1
#define RADAR_REAR_UART     hRS485_2

#define MODBUS_CMD_LENGTH       8
#define BUS_RELEASE_DELAY       17
#define RADAR_ACK_TIMEOUT       100

typedef struct {
    uint8_t     cmd[MODBUS_CMD_LENGTH];
    uint8_t     failed_cnt;
    uint16_t    distance;
} RadarModbusStation_TypeDef;

typedef struct {
    RadarModbusStation_TypeDef  left;
    RadarModbusStation_TypeDef  right;
    RadarModbusStation_TypeDef  *object;
    bool                        wait_ack;
    uint32_t                    release_delay;//��ĳ���豸ͨ�Ž��յ����������Ժ�Ҫ���һ��ʱ���ٸ���һ���豸ͨ�ţ����������豸�޷��ж�modbus����֡�߽硣
    uint32_t                    ack_timeout;
    UartDataStruct_TypeDef      *hUART;
} RadarModbusPort_TypeDef;

RadarModbusPort_TypeDef RadarFrontPort = 
{
    .left.cmd = {0x01, 0x03, 0x01, 0x01, 0x00, 0x01, 0xD4, 0x36},
    .right.cmd = {0x02, 0x03, 0x01, 0x01, 0x00, 0x01, 0xD4, 0x05},
    .left.distance = 0xffff,
    .right.distance = 0xffff
};

RadarModbusPort_TypeDef RadarRearPort = 
{
    .left.cmd = {0x03, 0x03, 0x01, 0x01, 0x00, 0x01, 0xD5, 0xD4},
    .right.cmd = {0x04, 0x03, 0x01, 0x01, 0x00, 0x01, 0xD4, 0x63},
    .left.distance = 0xffff,
    .right.distance = 0xffff
};

void radar_modbus_init(void)
{
    RadarFrontPort.object   = &RadarFrontPort.left;
    RadarFrontPort.hUART    = RADAR_FRONT_UART;
   
    RadarRearPort.object    = &RadarRearPort.left;
    RadarRearPort.hUART     = RADAR_REAR_UART;
}

static void radar_port_task(RadarModbusPort_TypeDef *port)
{
    uint8_t data[64];
    uint16_t len;
        
    if(port->wait_ack)
    {
        if(SysTick_GetTick() - port->ack_timeout >= RADAR_ACK_TIMEOUT)
        {
            port->wait_ack = false;
            port->release_delay = SysTick_GetTick() - BUS_RELEASE_DELAY;
            port->object->distance = 0xffff;
            port->object = (port->object == &port->left ? &port->right : &port->left);
        }
    }
    else
    {
        if(SysTick_GetTick() - port->release_delay >= BUS_RELEASE_DELAY)
        {
            //uart_send_dma(port->hUART, port->object->cmd, MODBUS_CMD_LENGTH);
            uart_send_poll(port->hUART, port->object->cmd, MODBUS_CMD_LENGTH);
            port->wait_ack = true;
            port->ack_timeout = SysTick_GetTick();
        }
    }
    
    if(uart_rx_successful(port->hUART))
    {
        port->wait_ack = false;
        port->release_delay = SysTick_GetTick();
        len = uart_read(port->hUART, data, sizeof(data));
        if(data[0] == port->object->cmd[0] && checksum_crc16(data, len) == 0)
        {
            port->object->failed_cnt = 0;
            port->object->distance = data[3]<<8 | data[4];
            port->object = (port->object == &port->left ? &port->right : &port->left);
        }
        else
        {
            if(++port->object->failed_cnt >= 3)
            {
                port->object->failed_cnt = 0;
                port->object->distance = 0xffff;
                port->object = (port->object == &port->left ? &port->right : &port->left);
            }
        }
    }
}

void radar_loop_task(void)
{
    radar_port_task(&RadarFrontPort);
    radar_port_task(&RadarRearPort);
}

uint16_t radar_front_left_distance(void) { return RadarFrontPort.left.distance;}
uint16_t radar_front_right_distance(void) { return RadarFrontPort.right.distance;}
uint16_t radar_rear_left_distance(void) { return RadarRearPort.left.distance;}
uint16_t radar_rear_right_distance(void) { return RadarRearPort.right.distance;}