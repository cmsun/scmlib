
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'HC32F460KETA' 
 * Target:  'HC32F460KETA_Debug' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "HC32F460KETA.h"


#endif /* RTE_COMPONENTS_H */
