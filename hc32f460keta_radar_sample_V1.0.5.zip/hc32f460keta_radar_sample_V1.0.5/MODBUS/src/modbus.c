/*
********************************************************************************
*                              COPYRIGHT NOTICE
*                             Copyright (c) 2016
*                             All rights reserved
*
*  @fileName       : modbus.c
*  @author         : scm 351721714@qq.com
*  @create         : 2018/12/20 10:44:17
********************************************************************************
*/

#include "mbconfig.h"
#include "modbus.h"
#include "mbrtu.h"
#include "mbascii.h"

mbObject_t  mbObject;

/*
 * modbus通信协议中规定：一个逻辑线圈或者一个继电器或者一个数字量输入占用一个位。
 * modbus通信协议中规定：所有的寄存器（保持型寄存器和模拟量输入寄存器）都是双字节的。
 */
#if MB_COIL_COUNT > 0
mbu8 mbCoil [(MB_COIL_COUNT+7)/8] = {0};            //线圈和继电器(一个位对应一个逻辑线圈)
#endif

#if MB_DISINPUT_COUNT > 0
mbu8 mbDisInput [(MB_DISINPUT_COUNT+7)/8] = {0};    //Discrete Input 离散输入量(一个位对应一个离散输入量)
#endif

#if MB_HOLDREG_COUNT > 0
mbu16 mbHoldReg [MB_HOLDREG_COUNT] = {0};           //保持型寄存器
#endif

#if MB_INPUTREG_COUNT > 0
mbu16 InputReg[MB_INPUTREG_COUNT] = {0};            //输入寄存器
#endif

void mb_init(MODBUS_TYPE type, uint8_t station)
{
    //设置modbus地址
    mbObject.station = station;
    
    //设定modbus的工作模式是 RTU 还是 ASCII
    if(type == MODBUS_RTU)
    {
        mbObject.frame =                 	mbObject.RxBuff;
        mbObject.frameLength =           	0;
        mbObject.sendBuff =              	mbObject.TxBuff;
        mbObject.buffCapacity =          	MB_SEND_BUFFER_LENGTH;
        mbObject.chksumLength =          	2;

        mbObject.mb_func_receive =			mb_rtu_receive;
        mbObject.mb_func_send =				mb_raw_send;
        mbObject.mb_func_timeout =			mb_rtu_timeout;
        mbObject.mb_func_poll =				mb_rtu_poll;
        mbObject.mb_func_append_checksum =	mb_rtu_append_CRC;
    }
    else if(type == MODBUS_ASCII)
    {
        mbObject.frame =                 	mbObject.RxBuff;
        mbObject.frameLength =           	0;
        mbObject.sendBuff =              	mbObject.TxBuff;
        mbObject.buffCapacity =          	(MB_SEND_BUFFER_LENGTH-3)/2;
        mbObject.chksumLength =          	1;

        mbObject.mb_func_receive =			mb_ascii_receive;
        mbObject.mb_func_send =				mb_ascii_send;
        mbObject.mb_func_timeout =			mb_ascii_timeout;
        mbObject.mb_func_poll =				mb_ascii_poll;
        mbObject.mb_func_append_checksum =	mb_ascii_append_LRC;         	
    }
}

void mb_clear_receive_buff(void)
{
    mbObject.RxCount = 0;
}

void mb_timeout(void)
{
    mbObject.mb_func_timeout();
}

void mb_receive(mbu8 data)
{
    mbObject.mb_func_receive(data);
}

void mb_poll(void)
{
    mbObject.mb_func_poll();
}

__weak void mb_raw_send(mbu8 *data, mbu16 length)
{
    
}

__weak void mb_enable_timer(void)
{

}

__weak void mb_disable_timer(void)
{

}
