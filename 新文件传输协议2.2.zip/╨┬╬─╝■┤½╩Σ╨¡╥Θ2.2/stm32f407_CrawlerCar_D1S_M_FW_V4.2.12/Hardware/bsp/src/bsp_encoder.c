/**
*****************************************************************************
* @��  ���� bsp_encoder.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� ����������������
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_encoder.h"

//Ӳ������
#include "hardware.h"

//�궨��
#define ENCODER_TIM_PERIOD  (uint16_t)0xFFFF
#define ENCODER_MAX_COUNT   (uint16_t)10000
#define ENCODER_COUNT_RESET (uint16_t)0
#define ICx_FILTER          (uint16_t)6



/*
******************************************************************************
*	�� �� ��: Encoder_gpioInit
*	����˵��: ������IO��ʼ��
*	��    ��: encoderNum�����������
*	�� �� ֵ: ��
******************************************************************************
*/
void Encoder_gpioInit(ENCODER_NUM_ENUM encoderNum)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    switch(encoderNum)
    {
        case ENCODER_1ST:
        {
            GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
            GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
            GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
            GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;
            GPIO_Init(GPIOB,&GPIO_InitStructure);      
            GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_TIM4);
            GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_TIM4);
        }break;
        case ENCODER_2ND:
        {
            GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
            GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
            GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
            GPIO_InitStructure.GPIO_Speed  =GPIO_Speed_100MHz;
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10 | GPIO_Pin_11;
            GPIO_Init(GPIOH,&GPIO_InitStructure);
            GPIO_PinAFConfig(GPIOH,GPIO_PinSource10,GPIO_AF_TIM5);
            GPIO_PinAFConfig(GPIOH,GPIO_PinSource11,GPIO_AF_TIM5);
        }break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Encoder_nvicInit
*	����˵��: Encoder�ж�����
*	��    ��: encoderNum:encoder���
*	�� �� ֵ: ��
******************************************************************************
*/
void Encoder_nvicInit(ENCODER_NUM_ENUM encoderNum)
{
    NVIC_InitTypeDef NVIC_InitStructure;

    switch(encoderNum)
    {
        case ENCODER_1ST:{
            NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;
            NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
            NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
            NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
            NVIC_Init(&NVIC_InitStructure);                      
        }break;
        case ENCODER_2ND:{
            NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;
            NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
            NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
            NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
            NVIC_Init(&NVIC_InitStructure); 
        }break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Encoder_init
*	����˵��: ��������ʼ��
*	��    ��: encoderNum�����������
*	�� �� ֵ: ��
******************************************************************************
*/
void Encoder_init(ENCODER_NUM_ENUM encoderNum)
{
    
    TIM_TimeBaseInitTypeDef		TIM_TimeBaseInitStruct;
    TIM_ICInitTypeDef 			TIM_ICInitStruct;    

    Encoder_gpioInit(encoderNum);
    Encoder_nvicInit(encoderNum);

    switch(encoderNum)
    {
        case ENCODER_1ST:
        {
            RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

            TIM_DeInit(TIM4);
            
            TIM_TimeBaseStructInit(&TIM_TimeBaseInitStruct);
            TIM_TimeBaseInitStruct.TIM_Prescaler = 0;
            TIM_TimeBaseInitStruct.TIM_Period =  ENCODER_TIM_PERIOD - 1;
            TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
            TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
            TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStruct); 
            
            TIM_EncoderInterfaceConfig(TIM4,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);

            TIM_ICStructInit(&TIM_ICInitStruct);
            TIM_ICInitStruct.TIM_ICFilter = ICx_FILTER;
            TIM_ICInit(TIM4,&TIM_ICInitStruct);
            
            TIM_ClearFlag(TIM4,TIM_FLAG_Update);
            TIM_ITConfig(TIM4,TIM_IT_Update,ENABLE);
            
            TIM_SetCounter(TIM4,ENCODER_COUNT_RESET);
            TIM_Cmd(TIM4,ENABLE);
        }break;
        case ENCODER_2ND:
        {
            RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);

            TIM_DeInit(TIM5);
            
            TIM_TimeBaseStructInit(&TIM_TimeBaseInitStruct);
            TIM_TimeBaseInitStruct.TIM_Prescaler = 0;
            TIM_TimeBaseInitStruct.TIM_Period =  ENCODER_TIM_PERIOD - 1;
            TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
            TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
            TIM_TimeBaseInit(TIM5, &TIM_TimeBaseInitStruct); 
            
            TIM_EncoderInterfaceConfig(TIM5,TIM_EncoderMode_TI12,TIM_ICPolarity_Rising,TIM_ICPolarity_Rising);

            TIM_ICStructInit(&TIM_ICInitStruct);
            TIM_ICInitStruct.TIM_ICFilter = ICx_FILTER;
            TIM_ICInit(TIM5,&TIM_ICInitStruct);
            
            TIM_ClearFlag(TIM5,TIM_FLAG_Update);
            TIM_ITConfig(TIM5,TIM_IT_Update,ENABLE);
            
            TIM_SetCounter(TIM5,ENCODER_COUNT_RESET);
            TIM_Cmd(TIM5,ENABLE);
        }break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Encoder_getValue
*	����˵��: ��ȡ��������ֵ
*	��    ��: encoderNum����������� pValue��������ֵ
*	�� �� ֵ: ��
******************************************************************************
*/
void Encoder_getValue(ENCODER_NUM_ENUM encoderNum, int32_t *pValue)
{
    switch(encoderNum)
    {
        case ENCODER_1ST:
        {
            static  uint32_t   lastCount = 0;
            uint32_t  curCount = TIM4->CNT;
            int32_t   dAngle = (int32_t)(curCount - lastCount);

            if(dAngle >  ENCODER_MAX_COUNT){
                dAngle -= ENCODER_TIM_PERIOD;
            }else if(dAngle < -ENCODER_MAX_COUNT){
                dAngle += ENCODER_TIM_PERIOD;
            }

            lastCount = curCount;
            *pValue =  dAngle;
        }break;
        case ENCODER_2ND:
        {
            static  uint32_t   lastCount = 0;
            uint32_t  curCount = TIM5->CNT;
            int32_t   dAngle = (int32_t)(curCount - lastCount);

            if(dAngle >  ENCODER_MAX_COUNT){
                dAngle -= ENCODER_TIM_PERIOD;
            }else if(dAngle < -ENCODER_MAX_COUNT){
                dAngle += ENCODER_TIM_PERIOD;
            }
            
            lastCount = curCount;
            *pValue =  dAngle;   
        }break;
        default:break;
    }
}
