/**
*****************************************************************************
* @��  ���� bsp_max31865.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� max31865�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_max31865.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//�궨��
#define MAX31865_SPI         HSPI3

#define MAX31865_DUMMPLY     0xFF

#define REG_CONFIG                  (uint8_t)0x00
#define REG_RTD_MSB                 (uint8_t)0x01
#define REG_RTD_LSB                 (uint8_t)0x02
#define REG_HIGH_FAULT_THR_MSB      (uint8_t)0x03
#define REG_HIGH_FAULT_THR_LSB      (uint8_t)0x04
#define REG_LOW_FAULT_THR_MSB       (uint8_t)0x05
#define REG_LOW_FAULT_THR_LSB       (uint8_t)0x06
#define REG_FAULT_STATUS            (uint8_t)0x07
#define WR(reg)                     (uint8_t)((reg)|0x80)


#ifdef MAX31865_CS_INDEPENDENT
    #define MAX31865_1ST_CS_H()  GPIO_WriteBit(GPIOA, GPIO_Pin_15, Bit_SET)
    #define MAX31865_1ST_CS_L()  GPIO_WriteBit(GPIOA, GPIO_Pin_15, Bit_RESET)
    #define MAX31865_2ND_CS_H()  GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_SET)
    #define MAX31865_2ND_CS_L()  GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_RESET)
#else
    #define MAX31865_1ST_CS_H()  GPIOx_chipSelect(SEL_MAX31865_1ST, DISELECTED)
    #define MAX31865_1ST_CS_L()  GPIOx_chipSelect(SEL_MAX31865_1ST, SELECTED)
    #define MAX31865_2ND_CS_H()  GPIOx_chipSelect(SEL_MAX31865_2ND, DISELECTED)
    #define MAX31865_2ND_CS_L()  GPIOx_chipSelect(SEL_MAX31865_2ND, ELECTED)
#endif

//��̬����
static CONFIG_REGISTER_UNION configRegValue[2] =
{
    {
		.confRegister.bit0_FilterSelect = 0x01, //60Hz
		.confRegister.bit1_FaultStaus = 0x01, //not auto-clear
		.confRegister.bit2_3_FaultDetection = 0x00, //No action
		.confRegister.bit4_WireSelect = 0x01, //3-wire
		.confRegister.bit5_OneShout = 0x00,  //no 1-shot
		.confRegister.bit6_ConverMode = 0x01, //Auto conver
		.confRegister.bit7_VolBias = 0x01, //ON
    },
    {
		.confRegister.bit0_FilterSelect = 0x01, //60Hz
		.confRegister.bit1_FaultStaus = 0x01, //not auto-clear
		.confRegister.bit2_3_FaultDetection = 0x00, //No action
		.confRegister.bit4_WireSelect = 0x01, //3-wire
		.confRegister.bit5_OneShout = 0x00,  //no 1-shot
		.confRegister.bit6_ConverMode = 0x01, //Auto conver
		.confRegister.bit7_VolBias = 0x01, //ON
    }
};

//ȫ�ֱ���
MAX31865_STRUCT max31865Struct;



/*
******************************************************************************
*	�� �� ��: MAX31865_gpioInit
*	����˵��: LM95071���ƹ̳ܽ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void MAX31865_gpioInit(MAX31865_NUM_ENUM max31865Num)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;

    switch(max31865Num){
        case MAX31865_1ST:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
            GPIO_Init(GPIOA, &GPIO_InitStructure);
        break;
        case MAX31865_2ND:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
            GPIO_Init(GPIOC, &GPIO_InitStructure);
        break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Max31865_paramInit
*	����˵��: MAX31865������ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Max31865_paramInit(MAX31865_NUM_ENUM max31865Num)
{
    uint16_t configRegWrite[8] = {0x00};
	
	configRegWrite[0] = WR(REG_CONFIG);
	configRegWrite[1] = configRegValue[max31865Num].confRegisterFlag;
	configRegWrite[2] = (uint8_t)0x00;
	configRegWrite[3] = (uint8_t)0x00;
	configRegWrite[4] = (uint8_t)0xFF;
	configRegWrite[5] = (uint8_t)0xFE;
	configRegWrite[6] = (uint8_t)0x00;
	configRegWrite[7] = (uint8_t)0x01;

    switch(max31865Num){
        case MAX31865_1ST:
            MAX31865_1ST_CS_L();
            for(uint8_t i = 0; i < 8; i++ )
                SPIx_readWriteByte(MAX31865_SPI,configRegWrite[i]);
            MAX31865_1ST_CS_H();
        break;
        case MAX31865_2ND:
            MAX31865_2ND_CS_L();
            for(uint8_t i = 0; i < 8; i++ )
                SPIx_readWriteByte(MAX31865_SPI,configRegWrite[i]);
            MAX31865_2ND_CS_H();
        break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Max31865_getAllRegValue
*	����˵��: MAX31865��ȡ��������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Max31865_getAllRegValue(MAX31865_NUM_ENUM max31865Num, VARIABLE_INFO_STRUCT *pVarInfo)
{
    uint16_t  wDataWord[9] = {0x00};
    uint16_t  rDataWord[9] = {0x00};
	
	wDataWord[0] = REG_CONFIG;
	wDataWord[1] = REG_RTD_MSB;
	wDataWord[2] = REG_RTD_LSB;
	wDataWord[3] = REG_HIGH_FAULT_THR_MSB;
	wDataWord[4] = REG_HIGH_FAULT_THR_LSB;
	wDataWord[5] = REG_LOW_FAULT_THR_MSB;
	wDataWord[6] = REG_LOW_FAULT_THR_LSB;
	wDataWord[7] = REG_FAULT_STATUS;
   
    switch(max31865Num)
    {
        case MAX31865_1ST:{
            MAX31865_1ST_CS_L();
            for(uint8_t i = 0; i < 9; i++ )
                rDataWord[i] = SPIx_readWriteByte(MAX31865_SPI, wDataWord[i]);
            MAX31865_1ST_CS_H();
        }break;
        case MAX31865_2ND:{
            MAX31865_2ND_CS_L();
            for(uint8_t i = 0; i < 9; i++ )
                rDataWord[i] = SPIx_readWriteByte(MAX31865_SPI, wDataWord[i]);
            MAX31865_2ND_CS_H();
        }break;
        default:break;
    }

	pVarInfo->ConfReg.confRegisterFlag = (uint8_t)rDataWord[0];
	pVarInfo->CurTmpAdcVal = ((rDataWord[2] <<8)|(rDataWord[3]))>>1 ;
	pVarInfo->HFT_val = (rDataWord[4] << 8)|(rDataWord[5]) ;
	pVarInfo->LFT_val = (rDataWord[6] << 8)|(rDataWord[7]) ;
	pVarInfo->RtdSta = rDataWord[8];
}

/*
******************************************************************************
*	�� �� ��: Max31865_init
*	����˵��: MAX31865��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Max31865_init(void)
{
#ifdef MAX31865_CS_INDEPENDENT
    MAX31865_gpioInit(MAX31865_1ST);
    MAX31865_gpioInit(MAX31865_2ND);
#endif
    SPIx_init(MAX31865_SPI);
    Max31865_paramInit(MAX31865_1ST);
    Max31865_paramInit(MAX31865_2ND);
}

/*
******************************************************************************
*	�� �� ��: Max31865_reset
*	����˵��: MAX31865��λָ�����оƬ
*	��    ��: lm95071Num:���������
*	�� �� ֵ: ��
******************************************************************************
*/
void Max31865_reset(MAX31865_NUM_ENUM max31865Num)
{
    Max31865_paramInit(max31865Num);
}

/*
******************************************************************************
*	�� �� ��: Max31865_getValue
*	����˵��: MAX31865��ȡָ���¶ȴ�������ֵ
*	��    ��: lm95071Num:��������� pVaild���Ƿ���Ч pValue������ֵ
*	�� �� ֵ: ��
******************************************************************************
*/
void Max31865_getValue(MAX31865_NUM_ENUM max31865Num, MAX31865_VALUE_STATE *pVaild, float *pValue)
{
    Max31865_getAllRegValue(max31865Num,&max31865Struct.Max31865Info[max31865Num].VarInfo);

	if((max31865Struct.Max31865Info[max31865Num].VarInfo.RtdSta != 0)){
        *pVaild = MAX31865_VALUE_INVAILD;
	}else{
        *pVaild = MAX31865_VALUE_VAILD;
    }

    max31865Struct.Max31865Info[max31865Num].sensorValue =\
        (((float)max31865Struct.Max31865Info[max31865Num].VarInfo.CurTmpAdcVal /32) - 256);

    *pValue = max31865Struct.Max31865Info[max31865Num].sensorValue;
}
