/**
*****************************************************************************
* @��  ���� bsp_led.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� LED�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08: ��ʼ�汾
*   2018/09/17: ���ӿ��Ź�
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_led.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"



/*
******************************************************************************
*	�� �� ��: Led_init
*	����˵��: LED��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Led_init(void)
{
	GPIO_InitTypeDef gpioInitStrcut;
	
	gpioInitStrcut.GPIO_Mode = GPIO_Mode_OUT;
    gpioInitStrcut.GPIO_PuPd = GPIO_PuPd_UP;
	gpioInitStrcut.GPIO_Speed = GPIO_Speed_50MHz;
    
    gpioInitStrcut.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_3;
	GPIO_Init(GPIOD, &gpioInitStrcut);
	
	gpioInitStrcut.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_Init(GPIOE, &gpioInitStrcut);

    Led_setState(LED_0, LED_OFF);
    Led_setState(LED_1, LED_OFF);
    Led_setState(LED_2, LED_OFF);
    Led_setState(WDI_3, LED_OFF);

    Led_setState(LED_4, LED_OFF);
}

/*
******************************************************************************
*	�� �� ��: Led_set
*	����˵��: LED����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Led_setState(LED_NUM_ENUM ledNum, LED_STATE_ENUM ledState)
{
    switch(ledNum)
    {
        case LED_0:
            GPIO_WriteBit(GPIOD, GPIO_Pin_4, ledState != LED_ON ? Bit_SET : Bit_RESET);
        break;
        case LED_1:
            GPIO_WriteBit(GPIOD, GPIO_Pin_3, ledState != LED_ON ? Bit_SET : Bit_RESET);
        break;     
        case LED_2:
            GPIO_WriteBit(GPIOE, GPIO_Pin_1, ledState != LED_ON ? Bit_SET : Bit_RESET);
        break;
        case WDI_3:
            GPIO_WriteBit(GPIOE, GPIO_Pin_0, ledState != LED_ON ? Bit_SET : Bit_RESET);
        break;
        case LED_4:
            GPIOx_setExtOutSingle(EXT_OUT7 , ledState != LED_ON ? BIT_RESET : BIT_SET);
        break;
        case LED_ALL:
            GPIO_WriteBit(GPIOD, GPIO_Pin_4, ledState != LED_ON ? Bit_SET : Bit_RESET);
            GPIO_WriteBit(GPIOD, GPIO_Pin_3, ledState != LED_ON ? Bit_SET : Bit_RESET);
            GPIO_WriteBit(GPIOE, GPIO_Pin_1, ledState != LED_ON ? Bit_SET : Bit_RESET);
            GPIO_WriteBit(GPIOE, GPIO_Pin_0, ledState != LED_ON ? Bit_SET : Bit_RESET);
        break;
        default:break;
    }

}

/*
******************************************************************************
*	�� �� ��: Led_setToggle
*	����˵��: LED״̬�л�
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Led_setToggle(LED_NUM_ENUM ledNum)
{
    switch(ledNum)
    {
        case LED_0:
            GPIO_ToggleBits(GPIOD, GPIO_Pin_4);
        break;
        case LED_1:
            GPIO_ToggleBits(GPIOD, GPIO_Pin_3);
        break;     
        case LED_2:
            GPIO_ToggleBits(GPIOE, GPIO_Pin_1);
        break;
        case WDI_3:
            GPIO_ToggleBits(GPIOE, GPIO_Pin_0);
        break;
        case LED_ALL:
            GPIO_ToggleBits(GPIOD, GPIO_Pin_4);
            GPIO_ToggleBits(GPIOD, GPIO_Pin_3);
            GPIO_ToggleBits(GPIOE, GPIO_Pin_1);
            GPIO_ToggleBits(GPIOE, GPIO_Pin_0);
        break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Led_Blink
*	����˵��: LED��˸,100ms period
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Led_setBlink(LED_NUM_ENUM ledNum, LED_BLINK_ENUM ledBlink)
{  
#define LED_PERIID_TIME       20    // period 2.0s  
#define LED_LIGHTING_TIME     1     // lighting last time  
#define LED_CYCLE_TIME        1     // one times
      
    static int32_t sLedCycleTime = LED_PERIID_TIME;  
    static int32_t sCnt = LED_LIGHTING_TIME * LED_CYCLE_TIME * 2;      
  
    if(sLedCycleTime > 0){  
        sLedCycleTime --;  
        if(sCnt > 0){  
            if(sCnt % (LED_LIGHTING_TIME * 2) == 0){  
                Led_setState(ledNum, LED_ON);
            }else{  
                Led_setState(ledNum, LED_OFF);
            }  
            sCnt --;  
        }else{  
            Led_setState(ledNum, LED_OFF);
        }  
    }else{  
        sLedCycleTime = LED_PERIID_TIME;  
        sCnt = LED_LIGHTING_TIME * ledBlink * 2;  
        Led_setState(ledNum, LED_OFF);
    }  
}

/*
******************************************************************************
*	�� �� ��: Led_setBreathing
*	����˵��: LED��˸,10us period
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Led_setBreathing(LED_NUM_ENUM ledNum, uint8_t percent)
{
#define PERIID_TIME     100
    static int32_t sLedCycleTime = PERIID_TIME;  

    if(sLedCycleTime > 0){
        sLedCycleTime --;
        if(sLedCycleTime >= percent)
            Led_setState(ledNum, LED_OFF);
        else
            Led_setState(ledNum, LED_ON);
    }else{
        Led_setState(ledNum, LED_OFF);
        sLedCycleTime = PERIID_TIME;
    }
}

