/**
*****************************************************************************
* @��  ���� bsp_hmc5883l.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 24-Sep-2019
* @��  ���� HMC5883L�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2019/09/24����ʼ�汾
*
******************************************************************************
**/

//����ͷ�ļ�
#include "bsp_hmc5883l.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
//#define EXTER_IO_UPDATE  /* �жϹ̸ܽ������� */

//��̬����
static const uint8_t DevId[3]={'H','4','3'};

static const int16_t counts_per_milligauss[8] ={  
    1370,  //+-0.88Ga
    1090,  //+-1.3Ga
    820,   //+-1.9Ga
    660,   //+-2.5Ga
    440,   //+-4.0Ga
    390,   //+-4.7Ga
    330,   //+-5.6Ga
    230	   //+-8.1Ga
};

//��̬����
static int32_t  isNewReach = 0;

//ȫ�ֱ���
HMC5883L_RAW_INFO       Hmc5883lRawInfo;
HMC5883L_REAL_INFO      Hmc5883lRealInfo;
HMC5883L_CALIB_INFO     Hmc5883lCalibInfo;

float x_scale,y_scale,z_scale;


/*
******************************************************************************
*	�� �� ��: Hmc5883l_intIsr
*	����˵��: Hmc5883l�жϹܽ��жϺ���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_intIsr(void)
{
    isNewReach += 1;
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_gpioInit
*	����˵��: Hmc5883l���ƹ̳ܽ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_gpioInit(void)
{
#ifdef EXTER_IO_TRIG
    GPIOx_setPinMode(PA5);
#endif
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_readReg
*	����˵��: Hmc5883l��ȡ�Ĵ���ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
uint8_t Hmc5883l_readReg(uint8_t _ucRegAddr, uint8_t _ucDataLen, uint8_t* pData)
{
    return I2Cx_readReg(HI2C1, HMC58X3_ADDR, _ucRegAddr, _ucDataLen, pData);
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_writeReg
*	����˵��: Hmc5883lд��Ĵ���ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
uint8_t Hmc5883l_writeReg(uint8_t _ucRegAddr, uint8_t _ucDataLen, uint8_t* pData)
{
    return I2Cx_writeReg(HI2C1, HMC58X3_ADDR, _ucRegAddr, _ucDataLen, pData);
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_readId
*	����˵��: Hmc5883l��ȡоƬID
*	��    ��: ��
*	�� �� ֵ: 0: ���� -1���쳣
******************************************************************************
*/
int8_t Hmc5883l_readId(void)
{
	uint8_t tId[3] = {0};
    uint8_t tRetryCnt = 0;
    
    do{                                                                     //��Ҫ���Լ���,����ͨ�ųɹ�
        Hmc5883l_readReg(HMC58X3_R_IDA, 3, tId);
        if(0 == memcmp(DevId, tId, 3))
            break;
    }while(tRetryCnt++ < 5);

    if(tRetryCnt > 5){                                                     //�������5����ʧ�ܣ������������
        return -1;
    }else{
        return 0;
    }
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_getRawInfo
*	����˵��: Hmc5883l��ȡԭʼֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
bool Hmc5883l_getRawInfo(HMC5883L_RAW_INFO *pInfo) 
{
    uint8_t vbuff[6] = {0}; 
#ifdef EXTER_IO_TRIG
    if(isNewReach > 0){
        isNewReach -= 1;
#else
    if(1){
#endif
        if(0 == Hmc5883l_readReg(HMC58X3_R_XM, 6, vbuff)){
            pInfo->Magn[X_Axis] = (int16_t)vbuff[0] << 8 | vbuff[1];
            pInfo->Magn[Z_Axis] = (int16_t)vbuff[2] << 8 | vbuff[3];
            pInfo->Magn[Y_Axis] = (int16_t)vbuff[4] << 8 | vbuff[5];
            Hmc5883lRawInfo = *pInfo;
            return true;
        }else{
            return false;
        }
    }else{
        return false;
    }
   
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_getRealInfo
*	����˵��: Hmc5883l ��ȡУ����Ĵ�����ADCֵ
*	��    ��: pArry �������ָ��	
*	�� �� ֵ: ��
******************************************************************************
*/
bool Hmc5883l_getRealInfo(HMC5883L_REAL_INFO *pInfo)
{
    HMC5883L_RAW_INFO uRawInfo;
    if(false == Hmc5883l_getRawInfo(&uRawInfo)){
        return false;
    }
    
    uRawInfo.Magn[X_Axis] = (float)uRawInfo.Magn[X_Axis]/x_scale;
    uRawInfo.Magn[Y_Axis] = (float)uRawInfo.Magn[Y_Axis]/y_scale;
    uRawInfo.Magn[Z_Axis] = (float)uRawInfo.Magn[Z_Axis]/z_scale;
    
    if(Hmc5883lCalibInfo.startFlag == 1){
		if(Hmc5883lCalibInfo.Min[X_Axis] > uRawInfo.Magn[X_Axis]) 
            Hmc5883lCalibInfo.Min[X_Axis] = uRawInfo.Magn[X_Axis];
		if(Hmc5883lCalibInfo.Min[Y_Axis] > uRawInfo.Magn[Y_Axis]) 
            Hmc5883lCalibInfo.Min[Y_Axis] = uRawInfo.Magn[Y_Axis];
		if(Hmc5883lCalibInfo.Min[Z_Axis] > uRawInfo.Magn[Z_Axis]) 
            Hmc5883lCalibInfo.Min[Z_Axis] = uRawInfo.Magn[Z_Axis];
        
		if(Hmc5883lCalibInfo.Max[X_Axis] < uRawInfo.Magn[X_Axis]) 
            Hmc5883lCalibInfo.Max[X_Axis] = uRawInfo.Magn[X_Axis];
		if(Hmc5883lCalibInfo.Max[Y_Axis] < uRawInfo.Magn[Y_Axis]) 
            Hmc5883lCalibInfo.Max[Y_Axis] = uRawInfo.Magn[Y_Axis];
		if(Hmc5883lCalibInfo.Max[Z_Axis] < uRawInfo.Magn[Z_Axis]) 
            Hmc5883lCalibInfo.Max[Z_Axis] = uRawInfo.Magn[Z_Axis];
	}
    
    Hmc5883lRealInfo.Magn[X_Axis] = (float)(uRawInfo.Magn[X_Axis] - ((Hmc5883lCalibInfo.Max[X_Axis] + Hmc5883lCalibInfo.Min[X_Axis]) / 2));
    Hmc5883lRealInfo.Magn[Y_Axis] = (float)(uRawInfo.Magn[Y_Axis] - ((Hmc5883lCalibInfo.Max[Y_Axis] + Hmc5883lCalibInfo.Min[Y_Axis]) / 2));
    Hmc5883lRealInfo.Magn[Z_Axis] = (float)(uRawInfo.Magn[Z_Axis] - ((Hmc5883lCalibInfo.Max[Z_Axis] + Hmc5883lCalibInfo.Min[Z_Axis]) / 2));

    Hmc5883lRealInfo.Amuzith = atan2(Hmc5883lRealInfo.Magn[Y_Axis],Hmc5883lRealInfo.Magn[X_Axis]) * (180.0f / 3.14159265f);
    
    *pInfo = Hmc5883lRealInfo;
    
    return true;
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_setGain
*	����˵��: Hmc5883l ���� 5883L������
*	��    ��: gain Ŀ������ 0-7
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_setGain(uint8_t gain) 
{ 
    if(gain > 7)
        return;

    uint8_t tRegValue = (gain << 5);
    Hmc5883l_writeReg(HMC58X3_R_CONFB, 1, &tRegValue);
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_setGain
*	����˵��: Hmc5883l ���� 5883L�� �����������
*	��    ��: ���������     ����ֵ
            0 -> 0.75Hz  |   1 -> 1.5Hz
            2 -> 3Hz     |   3 -> 7.5Hz
            4 -> 15Hz    |   5 -> 30Hz
            6 -> 75Hz  
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_setFsr(uint8_t fsr) 
{
    if(fsr > 6)
        return;

    uint8_t tRegValue = (fsr << 2);
    Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegValue);
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_setMode
*	����˵��: Hmc5883l���ò�����ʹ��������״̬
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_setMode(uint8_t mode)
{
    if(mode > 2)
        return;

    uint8_t tRegValue = mode;
    Hmc5883l_writeReg(HMC58X3_R_MODE, 1, &tRegValue);

    Delay_mSec(1);  //��ʱ�ȴ�������Ч
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_setUp
*	����˵��: Hmc5883l���ò�����ʹ��������״̬
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_setUp(uint8_t setmode)
{
    if(setmode)
        Hmc5883l_setMode(0);

    x_scale = 1.0; // get actual values
    y_scale = 1.0;
    z_scale = 1.0;

    uint8_t tRegValue;

    tRegValue = 0x70;
    Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegValue); // 8 samples averaged, 75Hz frequency, no artificial bias.
    tRegValue = 0xA0;
    Hmc5883l_writeReg(HMC58X3_R_CONFB, 1, &tRegValue);
    tRegValue = 0x00;
    Hmc5883l_writeReg(HMC58X3_R_MODE, 1, &tRegValue);
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_getOffset
*	����˵��: Hmc5883l��ȡƫ��ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_getOffset(void)
{
    HMC_OFFSET_UNION uHmcOffset;
    ParamInfoStruct.hmcOffsetStruct.read(&uHmcOffset);

    Hmc5883lCalibInfo.Max[X_Axis] = uHmcOffset.Struct.Max[X_Axis];
    Hmc5883lCalibInfo.Max[Y_Axis] = uHmcOffset.Struct.Max[Y_Axis];
    Hmc5883lCalibInfo.Max[Z_Axis] = uHmcOffset.Struct.Max[Z_Axis];

    Hmc5883lCalibInfo.Min[X_Axis] = uHmcOffset.Struct.Min[X_Axis];
    Hmc5883lCalibInfo.Min[Y_Axis] = uHmcOffset.Struct.Min[Y_Axis];
    Hmc5883lCalibInfo.Min[Z_Axis] = uHmcOffset.Struct.Min[Z_Axis];
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_startCalib
*	����˵��: Hmc5883l ��������Ʊ궨
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_startCalib(void)
{
	Hmc5883lCalibInfo.startFlag = 1;  //��ʼ�궨

    Hmc5883lCalibInfo.Max[X_Axis] = 0;
    Hmc5883lCalibInfo.Max[Y_Axis] = 0;
    Hmc5883lCalibInfo.Max[Z_Axis] = 0;

    Hmc5883lCalibInfo.Min[X_Axis] = 0;
    Hmc5883lCalibInfo.Min[Y_Axis] = 0;
    Hmc5883lCalibInfo.Min[Z_Axis] = 0;
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_saveCalib
*	����˵��: Hmc5883l ��������Ʊ궨ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_saveCalib(void)
{
    HMC_OFFSET_UNION uHmcOffset;

    uHmcOffset.Struct.Max[X_Axis] = Hmc5883lCalibInfo.Max[X_Axis];
    uHmcOffset.Struct.Max[Y_Axis] = Hmc5883lCalibInfo.Max[Y_Axis];
    uHmcOffset.Struct.Max[Z_Axis] = Hmc5883lCalibInfo.Max[Z_Axis];

    uHmcOffset.Struct.Min[X_Axis] = Hmc5883lCalibInfo.Min[X_Axis];
    uHmcOffset.Struct.Min[Y_Axis] = Hmc5883lCalibInfo.Min[Y_Axis];
    uHmcOffset.Struct.Min[Z_Axis] = Hmc5883lCalibInfo.Min[Z_Axis];

    ParamInfoStruct.hmcOffsetStruct.write(uHmcOffset);

    Hmc5883lCalibInfo.startFlag = 0;  //�����궨
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_calibrate
*	����˵��: Hmc5883l ʹ���ڲ��Ĵų��������ı궨
*	��    ��: gain  ���� 0-7
			  n_samples �������� 
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_calibrate(uint8_t gain, uint32_t n_samples) 
{
    int16_t xyz[3];                 // 16 bit integer values for each axis.
    int32_t xyz_total[3] = {0,0,0}; // 32 bit totals so they won't overflow.
    uint8_t bret = 1;               // Function return value.  Will return false if the wrong identifier is returned, saturation is detected or response is out of range to self test bias.
    int32_t low_limit, high_limit;  
	uint8_t vbuff[6];
    uint8_t tRegVal;

    if ((8 > gain) && (0 < n_samples)) // Notice this allows gain setting of 7 which the data sheet warns against.
    { 
        /*
            Use the positive bias current to impose a known field on each axis.
            This field depends on the device and the axis.
        */
        tRegVal = 0x10 + HMC_POS_BIAS;
        Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegVal); // Reg A DOR=0x10 + MS1,MS0 set to pos bias
        /*
            Note that the  very first measurement after a gain change maintains the same gain as the previous setting. 
            The new gain setting is effective from the second measurement and on.
        */
        Hmc5883l_setGain(gain);                      
        Hmc5883l_setMode(1);                         // Change to single measurement mode.
        // Get the raw values and ignore since this reading may use previous gain.
        Hmc5883l_readReg(HMC58X3_R_XM, 6, vbuff);

        xyz[0]=((int16_t)vbuff[0] << 8) | vbuff[1];
        xyz[1]=((int16_t)vbuff[4] << 8) | vbuff[5];
        xyz[2]=((int16_t)vbuff[2] << 8) | vbuff[3];
         
        for (uint16_t i = 0; i < n_samples; i++) 
        { 
            Hmc5883l_setMode(1);
            Hmc5883l_readReg(HMC58X3_R_XM, 6, vbuff);
            xyz[0]=((int16_t)vbuff[0] << 8) | vbuff[1];
            xyz[1]=((int16_t)vbuff[4] << 8) | vbuff[5];
            xyz[2]=((int16_t)vbuff[2] << 8) | vbuff[3];
            /*
                Since the measurements are noisy, they should be averaged rather than taking the max.
            */
            xyz_total[0]+=xyz[0];
            xyz_total[1]+=xyz[1];
            xyz_total[2]+=xyz[2];
            /*
                Detect saturation.
            */
            if (-(1<<12) >= MIN(xyz[0],MIN(xyz[1],xyz[2])))
            {
                //Hmc5883l Self test saturated. Increase range.
                bret=0;
                break;  // Breaks out of the for loop.  No sense in continuing if we saturated.
            }
        }
        /*
            Apply the negative bias. (Same gain)
        */
        tRegVal = 0x10 + HMC_NEG_BIAS;
        Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegVal); // Reg A DOR=0x010 + MS1,MS0 set to negative bias.
        for (uint16_t i = 0; i < n_samples; i++) 
        { 
            Hmc5883l_setMode(1);
            // Get the raw values and ignore since this reading may use previous gain.
            Hmc5883l_readReg(HMC58X3_R_XM, 6, vbuff);
            xyz[0] = ((int16_t)vbuff[0] << 8) | vbuff[1];
            xyz[1] = ((int16_t)vbuff[4] << 8) | vbuff[5];
            xyz[2] = ((int16_t)vbuff[2] << 8) | vbuff[3];
            /*
                Since the measurements are noisy, they should be averaged.
            */
            xyz_total[0] -= xyz[0];
            xyz_total[1] -= xyz[1];
            xyz_total[2] -= xyz[2];
            /*
                Detect saturation.
            */
            if (-(1<<12) >= MIN(xyz[0],MIN(xyz[1],xyz[2])))
            {
                //Hmc5883l Self test saturated. Increase range.
                bret=0;
                break;  // Breaks out of the for loop.  No sense in continuing if we saturated.
            }
        }
        /*
            Compare the values against the expected self test bias gauss.
            Notice, the same limits are applied to all axis.
        */
        low_limit = SELF_TEST_LOW_LIMIT * counts_per_milligauss[gain] * 2 * n_samples;
        high_limit = SELF_TEST_HIGH_LIMIT * counts_per_milligauss[gain] * 2 * n_samples;

        if ((bret) && 
            (low_limit <= xyz_total[0]) && (high_limit >= xyz_total[0]) &&
            (low_limit <= xyz_total[1]) && (high_limit >= xyz_total[1]) &&
            (low_limit <= xyz_total[2]) && (high_limit >= xyz_total[2]) )
        {   /*
                Successful calibration.
                Normalize the scale factors so all axis return the same range of values for the bias field.
                Factor of 2 is from summation of total of n_samples from both positive and negative bias.
            */
            x_scale = (counts_per_milligauss[gain] * (HMC58X3_X_SELF_TEST_GAUSS*2)) / (xyz_total[0]/n_samples);
            y_scale = (counts_per_milligauss[gain] * (HMC58X3_Y_SELF_TEST_GAUSS*2)) / (xyz_total[1]/n_samples);
            z_scale = (counts_per_milligauss[gain] * (HMC58X3_Z_SELF_TEST_GAUSS*2)) / (xyz_total[2]/n_samples);
        }
        else
        {
            //Hmc5883l Self test out of range.
            bret = 0;
        }
        tRegVal = 0x10;
        Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegVal); // set RegA/DOR back to default. 
    }
    else
    {  
        //Hmc5883l Bad parameters.
        bret = 0;
    }
    
    tRegVal = 0x10;
	Hmc5883l_writeReg(HMC58X3_R_CONFA, 1, &tRegVal); // set RegA/DOR back to default
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_init
*	����˵��: Hmc5883l��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_init(void)
{
    Hmc5883l_gpioInit();												    //��ʼ���ܽ�
    
    I2Cx_initNum(HI2C1);                                                    //��ʼ��ͨ�ſ�

    if(0 != Hmc5883l_readId()){                                             //ȷ��ͨ���Ƿ�����
        return;
    }

    Hmc5883l_setUp(0);
    // Don't set mode yet, we'll do that later on.
    // Calibrate HMC using self test, not recommended to change the gain after calibration.
    // Single mode conversion was used in calibration, now set continuous mode
    Hmc5883l_calibrate(1, 32); //�Լ�� �궨
    Hmc5883l_setMode(0);
    Hmc5883l_setFsr(5);  //30hz ������

    Hmc5883l_getOffset(); //��ȡ�궨ֵ

#ifdef EXTER_IO_UPDATE
    EXITx.begin(PA5,Hmc5883l_intIsr,EXTI_FALLING);                          //�����жϳ���
#endif
}

/*
******************************************************************************
*	�� �� ��: Hmc5883l_getLastRaw
*	����˵��: Hmc5883l��ȡ����ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Hmc5883l_getLastValue(HMC5883L_RAW_INFO *pInfo)
{
    pInfo->Magn[X_Axis] = (int16_t)Hmc5883lRealInfo.Magn[X_Axis];
    pInfo->Magn[Y_Axis] = (int16_t)Hmc5883lRealInfo.Magn[Y_Axis];
    pInfo->Magn[Z_Axis] = (int16_t)Hmc5883lRealInfo.Magn[Z_Axis];
}
