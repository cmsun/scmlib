/**
*****************************************************************************
* @��  ���� bsp_ad7478.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� AD7478����������
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_ad7478.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//�궨��
#define AD7478_SPI          HSPI3

#define AD7478_DUMMPLY      0x00

#ifdef  AD7478_CS_INDEPENDENT
    #define AD7478_CS_H()  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_SET)
    #define AD7478_CS_L()  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_RESET)
#else
    #define AD7478_CS_H()  GPIOx_chipSelect(SEL_AD7478, DISELECTED)
    #define AD7478_CS_L()  GPIOx_chipSelect(SEL_AD7478, SELECTED)
#endif


#define REFERENCE_VOLTAGE    (float)5.16
#define PRESSURE_RESISTANCE  (float)11.0

//��̬����
static  uint8_t deviceBitsNumber = 8;



/*
******************************************************************************
*	�� �� ��: Ad7478_gpioInit
*	����˵��: Ad7478 ��ʼ��gpio��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad7478_gpioInit(void)
{

	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

}

/*
******************************************************************************
*	�� �� ��: Ad7478_getRegValue
*	����˵��: Ad7478��ȡ�Ĵ���ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad7478_getRegValue(uint16_t *pRegValue)
{

    uint16_t convResult = 0,tRegValue[2] = {0};

    SPIx_setParam(AD7478_SPI, MODE_1ST, SPEED_NORMAL);
    
	AD7478_CS_L();
    //GPIOx_adu1402Select(SELECTED);
    tRegValue[0] = SPIx_readWriteByte(HSPI3, AD7478_DUMMPLY);
    tRegValue[1] = SPIx_readWriteByte(HSPI3, AD7478_DUMMPLY);
	//GPIOx_adu1402Select(DISELECTED);
    AD7478_CS_H();
    
    SPIx_setParam(AD7478_SPI, MODE_4TH, SPEED_NORMAL);
	
	switch(deviceBitsNumber){
		case 8:
			convResult = (((uint16_t)(tRegValue[0] & 0x0F)) << 8) +
						 (tRegValue[1] & 0xF0);
			convResult = convResult >> 4;
			break;
		case 10:
			convResult = (((uint16_t)(tRegValue[0] & 0x0F)) << 8) +
						 (tRegValue[1] & 0xFC);
			convResult = convResult >> 4;
			break;
		case 12:
			convResult = (((uint16_t)(tRegValue[0] & 0x0F)) << 8) +
						 (tRegValue[1] & 0xFF);
			convResult = convResult >> 4;
			break;
		default: // 16 bits
			convResult = (((uint16_t)(tRegValue[0] & 0xFF)) << 8) +
						 tRegValue[1];
			break;		
	}
	
	*pRegValue = convResult;

}

/*
******************************************************************************
*	�� �� ��: Ad7478_getRegValue
*	����˵��: Ad7478��ȡ�Ĵ���ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad7478_convertToVolt(uint16_t regValue,float vRef,float *pVolt)
{
	*pVolt = (regValue) * vRef / (1 << deviceBitsNumber);
}

/*
******************************************************************************
*	�� �� ��: Ad7478_init
*	����˵��: Ad7478��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad7478_init(void)
{
    Ad7478_gpioInit();
	AD7478_CS_H();

    SPIx_init(AD7478_SPI);
}

/*
******************************************************************************
*	�� �� ��: Ad7478_getValue
*	����˵��: Ad7478��ȡֵ
*	��    ��: ad7478Vaild:������Ч ;pValue:���ص�ѹֵmV
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad7478_getValue(AD7478_VALUE_STATE *ad7478Vaild, int32_t *pValue)
{
    float voltage = 0;
    uint16_t adcValue = 0;
    
    Ad7478_getRegValue(&adcValue);
    Ad7478_convertToVolt(adcValue,REFERENCE_VOLTAGE,&voltage);
	voltage *= PRESSURE_RESISTANCE;

    if((voltage < (float)0.0)||(voltage > (float)40.0)){
        *ad7478Vaild = AD7478_VALUE_INVAILD;
        *pValue = voltage * 1000;
    }else{
        *ad7478Vaild = AD7478_VALUE_VAILD;
        *pValue = voltage * 1000;
    }
	
}
