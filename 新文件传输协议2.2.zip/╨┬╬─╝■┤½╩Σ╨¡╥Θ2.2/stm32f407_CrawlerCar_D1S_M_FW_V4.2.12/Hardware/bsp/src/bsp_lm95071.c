/**
*****************************************************************************
* @��  ���� bsp_lm95071.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� lm95071�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_lm95071.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//�궨��
#define LM95071_SPI         HSPI3

#define LM95071_DUMMPLY     0xFF

#ifdef LM95071_CS_INDEPENDENT
    #define LM95071_1ST_CS_H()  GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_SET)
    #define LM95071_1ST_CS_L()  GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_RESET)
    #define LM95071_2ND_CS_H()  GPIO_WriteBit(GPIOC, GPIO_Pin_1, Bit_SET)
    #define LM95071_2ND_CS_L()  GPIO_WriteBit(GPIOC, GPIO_Pin_1, Bit_RESET)
#else
    #define LM95071_1ST_CS_H()  GPIOx_chipSelect(SEL_LM95071_1ST, DISELECTED)
    #define LM95071_1ST_CS_L()  GPIOx_chipSelect(SEL_LM95071_1ST, SELECTED)
    #define LM95071_2ND_CS_H()  GPIOx_chipSelect(SEL_LM95071_2ND, DISELECTED)
    #define LM95071_2ND_CS_L()  GPIOx_chipSelect(SEL_LM95071_2ND, SELECTED)
#endif



/*
******************************************************************************
*	�� �� ��: lm95071_gpioInit
*	����˵��: LM95071���ƹ̳ܽ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Lm95071_gpioInit(LM95071_NUM_ENUM lm95071Num)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;

    switch(lm95071Num){
        case LM95071_1ST:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
            GPIO_Init(GPIOB, &GPIO_InitStructure);
        break;
        case LM95071_2ND:
            GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1;
            GPIO_Init(GPIOC, &GPIO_InitStructure);
        break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: Lm95071_init
*	����˵��: LM95071��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Lm95071_init(void)
{
#ifdef LM95071_CS_INDEPENDENT
    Lm95071_gpioInit(LM95071_1ST);
    Lm95071_gpioInit(LM95071_2ND);
#endif
    SPIx_init(LM95071_SPI);
}

/*
******************************************************************************
*	�� �� ��: Lm95071_getValue
*	����˵��: LM95071��ȡָ���¶ȴ�������ֵ
*	��    ��: lm95071Num:��������� pVaild���Ƿ���Ч pValue������ֵ
*	�� �� ֵ: ��
******************************************************************************
*/
void Lm95071_getValue(LM95071_NUM_ENUM lm95071Num, LM95071_VALUE_STATE *pVaild, float *pValue)
{
    uint16_t tReadBuff[2]={0};
    uint16_t tTempShort = 0;
    float    tTemperature = 0.0;

    switch(lm95071Num)
    {
        case LM95071_1ST:{
            LM95071_1ST_CS_L();
            tReadBuff[0] = SPIx_readWriteByte(LM95071_SPI,LM95071_DUMMPLY);
            tReadBuff[1] = SPIx_readWriteByte(LM95071_SPI,LM95071_DUMMPLY);
            LM95071_1ST_CS_H();

            tTempShort = (tReadBuff[0] << 8) | tReadBuff[1] ;
            tTemperature =  (tTempShort >> 2) * (float)0.03125;
            if((tTemperature > 120) || (tTemperature < -40)){
                *pVaild = LM95071_VALUE_INVAILD;
                *pValue = 0.0;
            }else{
                *pVaild = LM95071_VALUE_VAILD;
                *pValue = tTemperature;
            }
        }break;

        case LM95071_2ND:{
            LM95071_2ND_CS_L();
            tReadBuff[0] = SPIx_readWriteByte(LM95071_SPI,LM95071_DUMMPLY);
            tReadBuff[1] = SPIx_readWriteByte(LM95071_SPI,LM95071_DUMMPLY);
            LM95071_2ND_CS_H();

            tTempShort = (tReadBuff[0] << 8) | tReadBuff[1] ;
            tTemperature =  (tTempShort >> 2) * (float)0.03125;
            if((tTemperature > 120) || (tTemperature < -40)){
                *pVaild = LM95071_VALUE_INVAILD;
                *pValue = 0.0;
            }else{
                *pVaild = LM95071_VALUE_VAILD;
                *pValue = tTemperature;
            }
        }break;

        default:break;
    }
}
