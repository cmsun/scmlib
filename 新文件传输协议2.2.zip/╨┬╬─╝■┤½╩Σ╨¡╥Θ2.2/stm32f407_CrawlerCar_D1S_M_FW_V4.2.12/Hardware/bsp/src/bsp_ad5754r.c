/**
*****************************************************************************
* @��  ���� bsp_ad5754r.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� AD5754R����������
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "bsp_ad5754r.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//�궨��
#define AD5754R_SPI          HSPI2
#define AD5754R_DUMMPLY      0xFF

#define AD5754R_CS_GPIO_PORT    GPIOI
#define AD5754R_CS_GPIO_PIN     GPIO_Pin_0
#define AD5754R_CS_GPIO_RCC     RCC_AHB1Periph_GPIOI

#define AD5754R_LDAC_GPIO_PORT  GPIOI
#define AD5754R_LDAC_GPIO_PIN   GPIO_Pin_4
#define AD5754R_LDAC_GPIO_RCC   RCC_AHB1Periph_GPIOI

#define AD5754R_CLR_GPIO_PORT   GPIOI
#define AD5754R_CLR_GPIO_PIN    GPIO_Pin_5
#define AD5754R_CLR_GPIO_RCC    RCC_AHB1Periph_GPIOI

#define AD5754R_BIN_GPIO_PORT   GPIOI  //do not fit ,connect to GND
#define AD5754R_BIN_GPIO_PIN    GPIO_Pin_8
#define AD5754R_BIN_GPIO_RCC    RCC_AHB1Periph_GPIOI 
	 	 
#define AD5754R_LDAC_LOW()       GPIO_ResetBits(AD5754R_LDAC_GPIO_PORT, AD5754R_LDAC_GPIO_PIN)
#define AD5754R_LDAC_HIGH()      GPIO_SetBits  (AD5754R_LDAC_GPIO_PORT, AD5754R_LDAC_GPIO_PIN)
#define AD5754R_CLR_LOW()        GPIO_ResetBits(AD5754R_CLR_GPIO_PORT, AD5754R_CLR_GPIO_PIN)
#define AD5754R_CLR_HIGH()       GPIO_SetBits  (AD5754R_CLR_GPIO_PORT, AD5754R_CLR_GPIO_PIN)
#define AD5754R_BIN_LOW()        GPIO_ResetBits(AD5754R_BIN_GPIO_PORT, AD5754R_BIN_GPIO_PIN)
#define AD5754R_BIN_HIGH()       GPIO_SetBits  (AD5754R_BIN_GPIO_PORT, AD5754R_BIN_GPIO_PIN)
#define AD5754R_CS_LOW()         GPIO_ResetBits(AD5754R_CS_GPIO_PORT, AD5754R_CS_GPIO_PIN)
#define AD5754R_CS_HIGH()        GPIO_SetBits  (AD5754R_CS_GPIO_PORT, AD5754R_CS_GPIO_PIN)


//��̬����
static void Ad5754r_setRegisterValue(uint8_t regBits,uint8_t adrBits,uint16_t regValue);
static void Ad5754r_setPower(DAC_CHANNEL_ENUM dacChannel,uint8_t onOff);
static void Ad5754r_loadDac(DAC_CHANNEL_ENUM dacChannel,uint16_t dacValue);
static void Ad5754r_rangeSelect(DAC_CHANNEL_ENUM dacChannel,uint8_t outputRange);
static void Ad5754r_controlFunction(uint8_t option,uint8_t bitValue);
static int16_t Ad5754r_mVtoHexValue(uint8_t outputRange, int16_t dacValue);
static int16_t Ad5754r_getRegisterValue(uint8_t regBits,uint8_t adrBits);




/*
******************************************************************************
*	�� �� ��: Ad5754r_gpioInit
*	����˵��: Ad5754r ��ʼ��gpio��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_gpioInit(void)
{
	GPIO_InitTypeDef gpio_init_struct;
		
	gpio_init_struct.GPIO_Mode = GPIO_Mode_OUT;
	gpio_init_struct.GPIO_OType = GPIO_OType_PP;  
	gpio_init_struct.GPIO_PuPd = GPIO_PuPd_UP;
	gpio_init_struct.GPIO_Speed = GPIO_Speed_50MHz;
	
	gpio_init_struct.GPIO_Pin = AD5754R_CS_GPIO_PIN;
	GPIO_Init(AD5754R_CS_GPIO_PORT, &gpio_init_struct);
	
	gpio_init_struct.GPIO_PuPd = GPIO_PuPd_UP;
	gpio_init_struct.GPIO_Pin = AD5754R_LDAC_GPIO_PIN;
	GPIO_Init(AD5754R_LDAC_GPIO_PORT, &gpio_init_struct);
	
	gpio_init_struct.GPIO_Pin = AD5754R_CLR_GPIO_PIN;
	GPIO_Init(AD5754R_CLR_GPIO_PORT, &gpio_init_struct);
	
	gpio_init_struct.GPIO_Pin = AD5754R_BIN_GPIO_PIN;
	GPIO_Init(AD5754R_BIN_GPIO_PORT, &gpio_init_struct);

	AD5754R_LDAC_LOW();
	AD5754R_CLR_HIGH();
	AD5754R_BIN_HIGH();
	AD5754R_CS_HIGH();

    Delay_mSec(10);
}

/*
******************************************************************************
*	�� �� ��: Ad5754r_init
*	����˵��: Ad5754r ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_init(void)
{
    Ad5754r_gpioInit();

	SPIx_setParam(AD5754R_SPI, MODE_1ST, SPEED_HIGH);

    Ad5754r_setPower(AD5754R_DAC_ALL, 0x01);
	Ad5754r_rangeSelect(AD5754R_DAC_ALL, AD5754R_DAC_ALL_RANGE);
    Ad5754r_loadDac(AD5754R_DAC_ALL, (uint16_t)0x0000);

}

/*
******************************************************************************
*	�� �� ��: Ad5754r_setChannelValue
*	����˵��: Ad5754r ����DACͨ����ֵ
*	��    ��: dacChannel��ֵ�Ƿ���Ч dacValue:ͨ����ѹ(mV)
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_setChannelValue(DAC_CHANNEL_ENUM dacChannel,int16_t dacValue)
{
	uint16_t dacSetValue = 0x0000;
	
	switch(dacChannel)
	{
		case AD5754R_DAC_A:
			dacSetValue = Ad5754r_mVtoHexValue(AD5754R_DAC_A_RANGE, dacValue);
			Ad5754r_loadDac(AD5754R_DAC_A, dacSetValue);
			break;
		case AD5754R_DAC_B:
			dacSetValue = Ad5754r_mVtoHexValue(AD5754R_DAC_B_RANGE, dacValue);
			Ad5754r_loadDac(AD5754R_DAC_B, dacSetValue);
			break;
		case AD5754R_DAC_C:
			dacSetValue = Ad5754r_mVtoHexValue(AD5754R_DAC_C_RANGE, dacValue);
			Ad5754r_loadDac(AD5754R_DAC_C, dacSetValue);
			break;
		case AD5754R_DAC_D:
			dacSetValue = Ad5754r_mVtoHexValue(AD5754R_DAC_D_RANGE, dacValue);
			Ad5754r_loadDac(AD5754R_DAC_D, dacSetValue);
			break;
        case AD5754R_DAC_ALL:
            dacSetValue = Ad5754r_mVtoHexValue(AD5754R_DAC_ALL_RANGE, dacValue);
            Ad5754r_loadDac(AD5754R_DAC_ALL, dacSetValue);
			break;
		default: break;
	}

}

/*
******************************************************************************
*	�� �� ��: Ad5754r_setRegisterValue
*	����˵��: Ad5754r ���üĴ���ֵ
*	��    ��: regBits:�Ĵ�����ַλ adrBits:ͨ��λ regValue:�Ĵ���ֵ
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_setRegisterValue(uint8_t regBits,uint8_t adrBits,uint16_t regValue)
{
    AD5754R_CS_LOW();
    SPIx_readWriteByte(AD5754R_SPI, (regBits << 3) + adrBits);
    SPIx_readWriteByte(AD5754R_SPI, (regValue & 0xFF00) >> 8);
    SPIx_readWriteByte(AD5754R_SPI, (regValue & 0x00FF));
    AD5754R_CS_HIGH();
}

/*
******************************************************************************
*	�� �� ��: Ad5754r_getRegisterValue
*	����˵��: Ad5754r ��ȡ�Ĵ���ֵ
*	��    ��: regBits:�Ĵ�����ַλ adrBits:ͨ��λ 
*	�� �� ֵ: registerValue:�Ĵ���ֵ
******************************************************************************
*/
int16_t Ad5754r_getRegisterValue(uint8_t regBits,uint8_t adrBits)							  
{
	uint16_t registerWord[3]   = {0};
	int16_t data              = 0;

    AD5754R_CS_LOW();
    SPIx_readWriteByte(AD5754R_SPI, (1 << 7) + (regBits << 3) + adrBits);
    SPIx_readWriteByte(AD5754R_SPI, AD5754R_DUMMPLY);
    SPIx_readWriteByte(AD5754R_SPI, AD5754R_DUMMPLY);
    AD5754R_CS_HIGH();

    AD5754R_CS_LOW();
    registerWord[0] = SPIx_readWriteByte(AD5754R_SPI, AD5754R_DUMMPLY);
    registerWord[1] = SPIx_readWriteByte(AD5754R_SPI, AD5754R_DUMMPLY);
    registerWord[2] = SPIx_readWriteByte(AD5754R_SPI, AD5754R_DUMMPLY);
    AD5754R_CS_HIGH();

	data = (registerWord[1] << 8) + registerWord[2];

	return(data);
}

/*
******************************************************************************
*	�� �� ��: Ad5754r_setPower
*	����˵��: Ad5754r ����ĳ��DACͨ��
*	��    ��: dacChannel: �Ǹ�ͨ�� onOff:�����
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_setPower(DAC_CHANNEL_ENUM dacChannel,uint8_t onOff)
{
	uint16_t oldPowerCtl = 0;
	uint16_t newPowerCtl = 0;
    uint8_t  tmpDacChannel = dacChannel;

	if(dacChannel == AD5754R_DAC_ALL){
		tmpDacChannel = 0x0F;
	}else{
		tmpDacChannel = (1 << dacChannel);   
	}

	oldPowerCtl = Ad5754r_getRegisterValue(AD5754R_REG_POWER_CONTROL,0x00);
	newPowerCtl = oldPowerCtl & ~tmpDacChannel;
	newPowerCtl = newPowerCtl | (onOff * tmpDacChannel);
	Ad5754r_setRegisterValue(AD5754R_REG_POWER_CONTROL,0x00,newPowerCtl);
}

/*
******************************************************************************
*	�� �� ��: Ad5754r_loadDac
*	����˵��: Ad5754r д���ݵ�DACͨ���ļĴ���
*	��    ��: dacChannel: �Ǹ�ͨ�� dacValue:ֵ
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_loadDac(DAC_CHANNEL_ENUM dacChannel,uint16_t dacValue)
{
    uint16_t regDacValue = dacValue <<  4;
	Ad5754r_setRegisterValue(AD5754R_REG_DAC, (uint8_t)dacChannel, regDacValue);
}

/*
******************************************************************************
*	�� �� ��: Ad5754r_rangeSelect
*	����˵��: Ad5754r ����ĳ��ͨ����DAC�����Χ
*	��    ��: dacChannel: �Ǹ�ͨ�� outputRange:��Χ
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_rangeSelect(DAC_CHANNEL_ENUM dacChannel,uint8_t outputRange)
{
	uint16_t registerData = 0;

	registerData |= outputRange; 
	Ad5754r_setRegisterValue(AD5754R_REG_RANGE_SELECT,(uint8_t)dacChannel,
                             registerData);

}

/*
******************************************************************************
*	�� �� ��: Ad5754r_controlFunction
*	����˵��: Ad5754r ��
*	��    ��: option: control function selected
*             bitValue: 
*
*	�� �� ֵ: ��
******************************************************************************
*/
void Ad5754r_controlFunction(uint8_t option,uint8_t bitValue)
{

	uint8_t adrBits  = option & 0xF0;
	uint8_t dataBits = option & 0X0F;
	uint16_t oldControl = 0;
	uint16_t newControl = 0;

	if(adrBits == 0x01){
		oldControl = Ad5754r_getRegisterValue(AD5754R_REG_CONTROL,0x01); 
		newControl = oldControl & ~(dataBits); 
		newControl = newControl | (bitValue * dataBits);
	}

	Ad5754r_setRegisterValue(AD5754R_REG_CONTROL,adrBits,newControl);

}

/*
******************************************************************************
*	�� �� ��: Ad5754r_readAlertBit
*	����˵��: Ad5754r ��ȡоƬ�쳣ֵ
*	��    ��: ��
*	�� �� ֵ: �쳣ֵ
*   ��    ע�� Example: 0x01 - TSD is set
*                      0x05 - OCa and TSD are set
*                      0x3C - OCd, OCc, OCb, OCa are set.    
******************************************************************************
*/
uint8_t Ad5754r_readAlertBit(void)
{

	uint16_t powerCtlStatus = 0; 

	powerCtlStatus = Ad5754r_getRegisterValue(AD5754R_REG_POWER_CONTROL, 0x00);
	powerCtlStatus = (powerCtlStatus >> 5);
	powerCtlStatus &= 0x003F;	// Only bits 5 to 0 are required.

	return ((uint8_t) powerCtlStatus);

}

/*
******************************************************************************
*	�� �� ��: Ad5754r_mVtoHexValue
*	����˵��: Ad5754r ���������Χ��DACֵ�����Ҫ���뵽�Ĵ�����ֵ
*	��    ��: outputRange: �����Χ
*             dacValue: dacֵ
*	�� �� ֵ: 16��ֵֹ
******************************************************************************
*/
int16_t Ad5754r_mVtoHexValue(uint8_t outputRange, int16_t dacValue)
{
    
	int32_t retrunVal = 0;

	if(outputRange == AD5754R_BIPOLAR_10_RANGE){
		retrunVal = dacValue * 2048;
        retrunVal = retrunVal/ 10000;
	}else if(outputRange == AD5754R_BIPOLAR_5_RANGE){
		retrunVal = dacValue * 2048; 
        retrunVal = retrunVal/ 5000;
	}else if(outputRange == AD5754R_UNIPOLAR_10_RANGE){
		retrunVal = dacValue * 4096;
        retrunVal = retrunVal/ 10000;
	}else if(outputRange == AD5754R_UNIPOLAR_5_RANGE){
		retrunVal = dacValue * 4096;
        retrunVal = retrunVal/ 5000;
	}
    
    retrunVal = (int32_t)retrunVal & 0x0000FFFF;

	return (int16_t)retrunVal;

}
