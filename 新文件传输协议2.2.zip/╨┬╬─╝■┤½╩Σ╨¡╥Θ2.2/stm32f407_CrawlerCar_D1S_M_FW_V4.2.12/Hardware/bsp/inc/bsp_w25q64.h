/**
*****************************************************************************
* @��  ���� bsp_w25q64.h
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 16-June-2018
* @��  ���� w25q64�����ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/07/16����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _BSP_W25Q64_H_
#define _BSP_W25Q64_H_

#ifdef __cplusplus
 extern "C" {
#endif 

//C��
#include <stdint.h>

//�궨��
#define FLASH_WIP_FLAG           0x01  /*!< Write In Progress (WIP) flag */

#define FLASH_DUMMY_BYTE         0x00

#define FLASH_W25Q16             0xEF4015
#define FLASH_W25Q32             0xEF4016
#define FLASH_W25Q64             0xEF4017
#define FLASH_W25Q128            0xEF4018

#define FLASH_PAGE_SIZE          (256)
#define FLASH_SECTOR_SIZE        (FLASH_PAGE_SIZE * 16)
#define FLASH_BLOCK_SIZE         (FLASH_SECTOR_SIZE * 16)

//����ṹ��     
typedef struct {
    uint8_t     flash_cmd_rd_id;      /* Read flash id ���� */
    uint32_t    flash_id;             /* Flash id */  
    int8_t      *flash_desc;          /* Flash ���� */  
    uint8_t     flash_cmd_write;      /* Page program ���� */
    uint8_t     flash_cmd_wr_en;      /* Write enable ���� */  
    uint8_t     flash_cmd_read;       /* Read from Memory ���� */
    uint8_t     flash_cmd_rd_sr;      /* Read Status Register ����  */
    uint8_t     flash_cmd_se;         /* Sector Erase ���� */
    uint8_t     flash_cmd_be;         /* Block Erase ���� */
    uint8_t     flash_cmd_ce;         /* Chip Erase ���� */
    uint16_t    flash_cy_pagesize;    /* оƬҳ��С */
    uint32_t    flash_cy_sectorsize;  /* оƬ������С */
    uint32_t    flash_cy_blocksize;   /* оƬ���С */
    uint64_t    flash_cy_totalsize;   /* оƬ������ */
}spi_flash_cmd_t;

typedef struct{
    uint32_t volatile spi_flash_index;
    uint8_t volatile spi_flash_found;   
}spi_flash_t;

//�ӿں���
spi_flash_t *ltk_spi_flash_get_info(void);
uint8_t W25qxx_autoWritePage(int32_t write_addr, uint8_t* buffer, int32_t num_byte_to_write);
void W25qxx_eraseOneSector(int32_t flash_addr);
void W25qxx_eraseSector(int32_t flash_addr, int32_t num_byte_to_write);
void W25qxx_writeBuffer(uint8_t* buffer, int32_t write_addr, int32_t num_byte_to_write);
void W25qxx_readBuffer(uint8_t* buffer, int32_t read_addr, int32_t num_byte_to_read);
void W25qxx_eraseChip(void);
void W25qxx_idCheck(void);
void W25qxx_init(void);

#ifdef __cplusplus
}
#endif

#endif
