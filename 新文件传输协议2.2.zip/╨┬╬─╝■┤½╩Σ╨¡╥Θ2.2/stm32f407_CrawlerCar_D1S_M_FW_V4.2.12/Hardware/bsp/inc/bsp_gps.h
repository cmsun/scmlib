/**
*****************************************************************************
* @��  ���� bsp_gps.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 12-June-2018
* @��  ���� GPSģ�������ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/07/12����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _BSP_GPS_H_
#define _BSP_GPS_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <string.h>
#include <stdbool.h>


//����ö��
typedef enum{
	GPS_DISCONNECT = 0,
	GPS_CONNECTED
}GPS_CONNECT_ENUM;

typedef enum{
	GPS_INVALID = 0,
	GPS_FIX,
	GPS_DIFFERENTTIAL,
	GPS_SENSITIVE,
    GPS_FIXED_SOLUTION,
    GPS_FLOAT_SOLUTION
}GPS_QUALITY_ENUM;

typedef enum{
    HDOP_INVALID = 0,
    HDOP_VALID
}GPS_HDOP_STATE;

typedef enum{
    AZIMUTH_INVALID = 0,
    AZIMUTH_VALID
}GPS_AZIMUTH_STATE;

typedef enum{
    INUSE_INVALID = 0,
    INUSE_VALID
}GPS_INUSE_ENUM;

typedef enum{
    TIME_INVALID = 0,
    TIME_VALID
}GPS_TIME_ENUM;

//����ṹ��
typedef struct{
    int32_t    year;       /**< Years since dc 0 */
    int32_t    mon;        /**< Months since January - [1,12] */
    int32_t    day;        /**< Day of the month - [1,31] */
    int32_t    hour;       /**< Hours since midnight - [0,23] */
    int32_t    min;        /**< Minutes after the hour - [0,59] */
    int32_t    sec;        /**< Seconds after the minute - [0,59] */
	int32_t    hsec;       /**< Seconds after the minute - [0,100] */
    int32_t    adj;        /**< local time dis hours - [0,24] */
}GPS_TIME_STRUCT;

typedef struct{
    double speed;
	double height;
    double azimuth;
    double latitude;
    double longitude;
    
    int32_t satliteInUse;
    int32_t satliteInView;
    
    GPS_CONNECT_ENUM    ConnectSta;
	GPS_QUALITY_ENUM    QualitySta;
    GPS_AZIMUTH_STATE   AmuzithSta;
    GPS_INUSE_ENUM      InUseSta;
    GPS_HDOP_STATE      HdopSta;
    GPS_TIME_ENUM       TimeSta;

    bool isTimeUpdate;
    bool isAmuzithUpdate;
    bool isPositionUpdate;
}GPS_INFO_STRUCT;

//�ӿں���
void Gps_init(void);
uint16_t Gps_infoAnalyse(void);
uint16_t Gps_getInfo(GPS_INFO_STRUCT *pCorInfo);
bool Gps_getDateTime(GPS_TIME_STRUCT *pTimeInfo);

//�ⲿ����
extern GPS_TIME_STRUCT GpsTimeStruct;

#ifdef _cplusplus
	}
#endif

#endif
