/**
*****************************************************************************
* @��  ���� bsp_max31865.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 11-May-2018
* @��  ���� max31865�����ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/11����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _BSP_MAX31865_H_
#define _BSP_MAX31865_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//�궨��
#define MAX31865_CS_INDEPENDENT

//ö���ض���
typedef enum {MAX31865_1ST = 0, MAX31865_2ND } MAX31865_NUM_ENUM;
typedef enum {MAX31865_VALUE_INVAILD = 0,MAX31865_VALUE_VAILD } MAX31865_VALUE_STATE;

//����������
typedef union
{
	uint8_t confRegisterFlag;
	struct
	{
		uint8_t bit0_FilterSelect:1;
		uint8_t bit1_FaultStaus:1;
		uint8_t bit2_3_FaultDetection:2;
		uint8_t bit4_WireSelect:1;
		uint8_t bit5_OneShout:1;
		uint8_t bit6_ConverMode:1;
		uint8_t bit7_VolBias:1;
	}confRegister;
}CONFIG_REGISTER_UNION;

//����ṹ��
typedef struct
{
    CONFIG_REGISTER_UNION ConfReg;              // Configuration register readout
    
	uint8_t               RtdSta;		        // RTD status - full status code
	uint16_t              HFT_val;				// High fault threshold register readout
	uint16_t              LFT_val;				// Low fault threshold register readout
	uint16_t              CurTmpAdcVal;         // Current temperature
}VARIABLE_INFO_STRUCT;

typedef struct{
    VARIABLE_INFO_STRUCT VarInfo;
    MAX31865_VALUE_STATE SensorVaild;
    float sensorValue;
}MAX31865_INFO_STRUCT;

typedef struct{
    MAX31865_INFO_STRUCT Max31865Info[2];
}MAX31865_STRUCT;

//�ӿں���
void Max31865_init(void);
void Max31865_reset(MAX31865_NUM_ENUM Max31865Num);
void Max31865_getValue(MAX31865_NUM_ENUM Max31865Num, MAX31865_VALUE_STATE *pVaild, float *pValue);


//�ⲿ����
extern MAX31865_STRUCT max31865Struct;


#ifdef _cplusplus
	}
#endif

#endif
