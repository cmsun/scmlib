/**
*****************************************************************************
* @��  ���� bsp_mpu6515.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 11-May-2018
* @��  ���� mpu6515�����ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/11����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _BSP_MPU6515_H_
#define _BSP_MPU6515_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//���ò���
#include "configure.h"
 
//�궨��
#define INV_MPU9150_WHOAMI_VALUE		0x68
#define INV_MPU9250_WHOAMI_VALUE		0x71
#define INV_MPU9255_WHOAMI_VALUE		0x73
#define INV_MPU6515_WHOAMI_VALUE		0x74
#define INV_ICM20608_WHOAMI_VALUE		0xAF

//����ṹ��
typedef struct{
	int16_t temperature;
    int16_t Gyro[MAX_Axis];
	int16_t Accel[MAX_Axis];
	int16_t Magn[MAX_Axis];
}MPU6515_RAW_STRUCT;

typedef struct{
    bool  isNewData;
	float temperature;
    float Gyro[MAX_Axis];
	float Accel[MAX_Axis];
	float Magn[MAX_Axis];
}MPU6515_INFO_STRUCT;


//�ӿں���
bool Mpu6515_init(void);
void Mpu6515_loop(void);

int8_t Mpu6515_readId(void);

void Mpu6515_restart(void);

void Mpu6515_chipReset(void);
void Mpu6515_chipStartup(void);
void Mpu6515_chipPowerOn(void);
void Mpu6515_chipPowerOff(void);

bool Mpu6515_initGyroOffset(bool ctl);
void Mpu6515_getLastRaw(MPU6515_RAW_STRUCT *pRawInfo);
bool Mpu6515_getMotionValue(MPU6515_INFO_STRUCT *pValue);

int32_t Mpu6515_i2c_readReg(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *pBuf);
int32_t Mpu6515_i2c_writeReg(uint8_t addr, uint8_t reg, uint8_t len, uint8_t *pBuf);

#ifdef _cplusplus
	}
#endif

#endif
