/**
*****************************************************************************
* @��  ���� mip_gpio.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� GPIOx�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*   2018/07/12������ D1_ctl_v1.1.pdf 
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mip_gpio.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//�궨��
#define LM95071_1ST_CS_GPIO_PORT       GPIOB
#define LM95071_1ST_CS_GPIO_PIN        GPIO_Pin_8

#define LM95071_2ND_CS_GPIO_PORT       GPIOC
#define LM95071_2ND_CS_GPIO_PIN        GPIO_Pin_1

#define MAX31865_1ST_CS_GPIO_PORT      GPIOA
#define MAX31865_1ST_CS_GPIO_PIN       GPIO_Pin_15

#define MAX31865_2ND_CS_GPIO_PORT      GPIOC
#define MAX31865_2ND_CS_GPIO_PIN       GPIO_Pin_13

#define AD7478_CS_GPIO_PORT            GPIOB
#define AD7478_CS_GPIO_PIN             GPIO_Pin_0

#define WIFI_POWER_CTL_GPIO_PORT       GPIOD
#define WIFI_POWER_CTL_GPIO_PIN        GPIO_Pin_5

#define GPS_POWER_CTL_GPIO_PORT        GPIOA
#define GPS_POWER_CTL_GPIO_PIN         GPIO_Pin_8



/* APEX GPIO PORT MAPPING
    APEXIN0  -> PE12         APEXOUT0 -> PD15
    APEXIN1  -> PE13         APEXOUT1 -> PD14
    APEXIN2  -> PE14         APEXOUT2 -> PD13
    APEXIN3  -> PE15         APEXOUT3 -> PD12
    APEXIN4  -> PE8          APEXOUT4 -> PD11
    APEXIN5  -> PE9          APEXOUT5 -> PD10
    APEXIN6  -> PE10         APEXOUT6 -> PD9
    APEXIN7  -> PE11         APEXOUT7 -> PD8
 */
 
#define APEXIN0_PORT   GPIOE
#define APEXIN0_PIN    GPIO_Pin_12
#define APEXIN1_PORT   GPIOE
#define APEXIN1_PIN    GPIO_Pin_13
#define APEXIN2_PORT   GPIOE
#define APEXIN2_PIN    GPIO_Pin_14
#define APEXIN3_PORT   GPIOE
#define APEXIN3_PIN    GPIO_Pin_15
#define APEXIN4_PORT   GPIOE
#define APEXIN4_PIN    GPIO_Pin_8
#define APEXIN5_PORT   GPIOE
#define APEXIN5_PIN    GPIO_Pin_9
#define APEXIN6_PORT   GPIOE
#define APEXIN6_PIN    GPIO_Pin_10
#define APEXIN7_PORT   GPIOE
#define APEXIN7_PIN    GPIO_Pin_11


#define APEXOUT0_PORT   GPIOD
#define APEXOUT0_PIN    GPIO_Pin_15
#define APEXOUT1_PORT   GPIOD
#define APEXOUT1_PIN    GPIO_Pin_14
#define APEXOUT2_PORT   GPIOD
#define APEXOUT2_PIN    GPIO_Pin_13
#define APEXOUT3_PORT   GPIOD
#define APEXOUT3_PIN    GPIO_Pin_12
#define APEXOUT4_PORT   GPIOD
#define APEXOUT4_PIN    GPIO_Pin_11
#define APEXOUT5_PORT   GPIOD
#define APEXOUT5_PIN    GPIO_Pin_10
#define APEXOUT6_PORT   GPIOD
#define APEXOUT6_PIN    GPIO_Pin_9
#define APEXOUT7_PORT   GPIOD
#define APEXOUT7_PIN    GPIO_Pin_8

//��̬��������
static void GPIOx_initExtIn(void);
static void GPIOx_initExtOut(void);
static void GPIOx_initChipSel(void);
static void GPIOx_initPowerCtl(void);

//ȫ�ֱ���
GPIOx_STRUCT PIN_MAP[MAX_EXIT_PIN]={
    {HGPIOD, 0, GPIO_Pin_0, GPIO_Mode_IN, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP}, /* PD0 ->INT */
	{HGPIOD, 1, GPIO_Pin_1, GPIO_Mode_IN, GPIO_Speed_50MHz, GPIO_OType_PP, GPIO_PuPd_UP}, /* PD1 ->FSYNC */
};

/*
******************************************************************************
*	�� �� ��: GPIOx_init
*	����˵��: GPIOx��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_init(void)
{  
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE);                   //ֻҪ����ʹ�õ��ⲿ�жϣ��ͱ����SYSCFGʱ��
    
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA|RCC_AHB1Periph_GPIOB        //һ�ο�������ʱ��
      |RCC_AHB1Periph_GPIOC|RCC_AHB1Periph_GPIOD|RCC_AHB1Periph_GPIOE, ENABLE);

    GPIOx_initExtIn();
    GPIOx_initExtOut();
    GPIOx_initChipSel();
    GPIOx_initPowerCtl();
    
    GPIOx_setExtOut(0x00);
    GPIOx_chipSelect(CHIP_SEL_ALL,DISELECTED);
}

/*
******************************************************************************
*	�� �� ��: GPIOx_initExtOut
*	����˵��: GPIOxͨ��IO�����ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_initExtOut(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
    GPIO_InitStructure.GPIO_Pin = APEXOUT0_PIN;
    GPIO_Init(APEXOUT0_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXOUT1_PIN;
    GPIO_Init(APEXOUT1_PORT,&GPIO_InitStructure);    

    GPIO_InitStructure.GPIO_Pin = APEXOUT2_PIN;
    GPIO_Init(APEXOUT2_PORT,&GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = APEXOUT3_PIN;
    GPIO_Init(APEXOUT3_PORT,&GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = APEXOUT4_PIN;
    GPIO_Init(APEXOUT4_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXOUT5_PIN;
    GPIO_Init(APEXOUT5_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXOUT6_PIN;
    GPIO_Init(APEXOUT6_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXOUT7_PIN;
    GPIO_Init(APEXOUT7_PORT,&GPIO_InitStructure); 
}

/*
******************************************************************************
*	�� �� ��: GPIOx_initExtIn
*	����˵��: GPIOxͨ��IO�����ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_initExtIn(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP; 
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
    GPIO_InitStructure.GPIO_Pin = APEXIN0_PIN;
    GPIO_Init(APEXIN0_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN1_PIN;
    GPIO_Init(APEXIN1_PORT,&GPIO_InitStructure);
 
    GPIO_InitStructure.GPIO_Pin = APEXIN2_PIN;
    GPIO_Init(APEXIN2_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN3_PIN;
    GPIO_Init(APEXIN3_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN4_PIN;
    GPIO_Init(APEXIN4_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN5_PIN;
    GPIO_Init(APEXIN5_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN6_PIN;
    GPIO_Init(APEXIN6_PORT,&GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = APEXIN7_PIN;
    GPIO_Init(APEXIN7_PORT,&GPIO_InitStructure);
}

/*
******************************************************************************
*	�� �� ��: GPIOx_setExtOut
*	����˵��: �źŵ�ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_setExtOut(uint16_t cIOValue)
{
    GPIO_WriteBit(APEXOUT0_PORT,  APEXOUT0_PIN,  (BitAction)(cIOValue&((uint16_t)1<<0)));
    GPIO_WriteBit(APEXOUT1_PORT,  APEXOUT1_PIN,  (BitAction)(cIOValue&((uint16_t)1<<1)));
    GPIO_WriteBit(APEXOUT2_PORT,  APEXOUT2_PIN,  (BitAction)(cIOValue&((uint16_t)1<<2)));
    GPIO_WriteBit(APEXOUT3_PORT,  APEXOUT3_PIN,  (BitAction)(cIOValue&((uint16_t)1<<3)));
    GPIO_WriteBit(APEXOUT4_PORT,  APEXOUT4_PIN,  (BitAction)(cIOValue&((uint16_t)1<<4)));
    GPIO_WriteBit(APEXOUT5_PORT,  APEXOUT5_PIN,  (BitAction)(cIOValue&((uint16_t)1<<5)));
    GPIO_WriteBit(APEXOUT6_PORT,  APEXOUT6_PIN,  (BitAction)(cIOValue&((uint16_t)1<<6)));
    GPIO_WriteBit(APEXOUT7_PORT,  APEXOUT7_PIN,  (BitAction)(cIOValue&((uint16_t)1<<7)));
}

/*
******************************************************************************
*	�� �� ��: GPIOx_setExtOutSingle
*	����˵��: ���õ���IO�ڵĵ�ƽ���
*	��    ��: ExtOutNum:IO����� BitSet:����ߵ�
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_setExtOutSingle(EXT_OUT_NUM_ENUM ExtOutNum, BIT_STATE_ENUM BitSet)
{
    switch(ExtOutNum){
        case EXT_OUT0: 
            GPIO_WriteBit(APEXOUT0_PORT,  APEXOUT0_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT1: 
            GPIO_WriteBit(APEXOUT1_PORT,  APEXOUT1_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT2: 
            GPIO_WriteBit(APEXOUT2_PORT,  APEXOUT2_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT3: 
            GPIO_WriteBit(APEXOUT3_PORT,  APEXOUT3_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT4: 
            GPIO_WriteBit(APEXOUT4_PORT,  APEXOUT4_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT5: 
            GPIO_WriteBit(APEXOUT5_PORT,  APEXOUT5_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT6: 
            GPIO_WriteBit(APEXOUT6_PORT,  APEXOUT6_PIN,  (BitAction)BitSet);
        break;
        case EXT_OUT7: 
            GPIO_WriteBit(APEXOUT7_PORT,  APEXOUT7_PIN,  (BitAction)BitSet);
        break;
        default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: GPIOx_getExtIn
*	����˵��: ��ȡ�����źŵ�ֵ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_getExtIn(uint16_t *pIOValue)
{
	uint16_t bGpioValue = 0;

	if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN0_PORT,APEXIN0_PIN)) bGpioValue|=(1<<0);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN1_PORT,APEXIN1_PIN)) bGpioValue|=(1<<1);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN2_PORT,APEXIN2_PIN)) bGpioValue|=(1<<2);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN3_PORT,APEXIN3_PIN)) bGpioValue|=(1<<3);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN4_PORT,APEXIN4_PIN)) bGpioValue|=(1<<4);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN5_PORT,APEXIN5_PIN)) bGpioValue|=(1<<5);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN6_PORT,APEXIN6_PIN)) bGpioValue|=(1<<6);
    if(Bit_SET ==  GPIO_ReadInputDataBit(APEXIN7_PORT,APEXIN7_PIN)) bGpioValue|=(1<<7);

	*pIOValue = bGpioValue;
}

/*
******************************************************************************
*	�� �� ��: GPIOx_getExtInSingle
*	����˵��: ��ȡ�����źŵ�ֵ
*	��    ��: ExtInNum:ѡ�е�����IO��
*	�� �� ֵ: ��ǰ�ӿڵ�״̬
******************************************************************************
*/
BIT_STATE_ENUM GPIOx_getExtInSingle(EXT_IN_NUM_ENUM ExtInNum)
{
    BIT_STATE_ENUM tBitSta;

    switch(ExtInNum)
    {
        case EXT_IN0:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN0_PORT,APEXIN0_PIN);
        break;
        case EXT_IN1:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN1_PORT,APEXIN1_PIN);
        break;
        case EXT_IN2:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN2_PORT,APEXIN2_PIN);
        break;
        case EXT_IN3:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN3_PORT,APEXIN3_PIN);
        break;  
        case EXT_IN4:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN4_PORT,APEXIN4_PIN);
        break;  
        case EXT_IN5:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN5_PORT,APEXIN5_PIN);
        break;  
        case EXT_IN6:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN6_PORT,APEXIN6_PIN);
        break;  
        case EXT_IN7:
            tBitSta = (BIT_STATE_ENUM)GPIO_ReadInputDataBit(APEXIN7_PORT,APEXIN7_PIN);
        break;  
        
        default:break;
    }
    
    return tBitSta;
}

/*
******************************************************************************
*	�� �� ��: GPIOx_initChipSel
*	����˵��: оƬƬѡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_initChipSel(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	
    GPIO_InitStructure.GPIO_Pin = LM95071_1ST_CS_GPIO_PIN;
    GPIO_Init(LM95071_1ST_CS_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = LM95071_2ND_CS_GPIO_PIN;
    GPIO_Init(LM95071_2ND_CS_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = MAX31865_1ST_CS_GPIO_PIN;
    GPIO_Init(MAX31865_1ST_CS_GPIO_PORT, &GPIO_InitStructure);		

    GPIO_InitStructure.GPIO_Pin = MAX31865_2ND_CS_GPIO_PIN;
    GPIO_Init(MAX31865_2ND_CS_GPIO_PORT, &GPIO_InitStructure);	

    GPIO_InitStructure.GPIO_Pin = AD7478_CS_GPIO_PIN;
    GPIO_Init(AD7478_CS_GPIO_PORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = AD7478_CS_GPIO_PIN;
    GPIO_Init(AD7478_CS_GPIO_PORT, &GPIO_InitStructure);    
}

/*
******************************************************************************
*	�� �� ��: GPIOx_chipSelect
*	����˵��: chipSel:оƬ��� bSel:��ѡ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_chipSelect(CHIP_SEL_ENUM chipSel, B_SEL bSel)
{
	switch(chipSel){
        case SEL_NONE:{
            GPIO_WriteBit(LM95071_1ST_CS_GPIO_PORT, LM95071_1ST_CS_GPIO_PIN, (BitAction)bSel);
            GPIO_WriteBit(LM95071_2ND_CS_GPIO_PORT, LM95071_2ND_CS_GPIO_PIN, (BitAction)bSel);
            GPIO_WriteBit(MAX31865_1ST_CS_GPIO_PORT, MAX31865_1ST_CS_GPIO_PIN, (BitAction)bSel);
            GPIO_WriteBit(MAX31865_2ND_CS_GPIO_PORT, MAX31865_2ND_CS_GPIO_PIN, (BitAction)bSel);
            GPIO_WriteBit(AD7478_CS_GPIO_PORT, AD7478_CS_GPIO_PIN, (BitAction)bSel);
        }break;
		case SEL_LM95071_1ST:{
			GPIO_WriteBit(LM95071_1ST_CS_GPIO_PORT, LM95071_1ST_CS_GPIO_PIN, (BitAction)!bSel);
		}break;
		case SEL_LM95071_2ND:{
			GPIO_WriteBit(LM95071_2ND_CS_GPIO_PORT, LM95071_2ND_CS_GPIO_PIN, (BitAction)!bSel);
		}break;
		case SEL_MAX31865_1ST:{
			GPIO_WriteBit(MAX31865_1ST_CS_GPIO_PORT, MAX31865_1ST_CS_GPIO_PIN, (BitAction)!bSel);
		}break;
		case SEL_MAX31865_2ND:{
			GPIO_WriteBit(MAX31865_2ND_CS_GPIO_PORT, MAX31865_2ND_CS_GPIO_PIN, (BitAction)!bSel);
		}break;
		case SEL_AD7478:{
			GPIO_WriteBit(AD7478_CS_GPIO_PORT, AD7478_CS_GPIO_PIN, (BitAction)!bSel);
		}break;
        case CHIP_SEL_ALL:{
            GPIO_WriteBit(LM95071_1ST_CS_GPIO_PORT, LM95071_1ST_CS_GPIO_PIN, (BitAction)!bSel);
            GPIO_WriteBit(LM95071_2ND_CS_GPIO_PORT, LM95071_2ND_CS_GPIO_PIN, (BitAction)!bSel);
            GPIO_WriteBit(MAX31865_1ST_CS_GPIO_PORT, MAX31865_1ST_CS_GPIO_PIN, (BitAction)!bSel);
            GPIO_WriteBit(MAX31865_2ND_CS_GPIO_PORT, MAX31865_2ND_CS_GPIO_PIN, (BitAction)!bSel);
            GPIO_WriteBit(AD7478_CS_GPIO_PORT, AD7478_CS_GPIO_PIN, (BitAction)!bSel);
        }break;
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: GPIOx_initPowerCtl
*	����˵��: ��Դ���Ƴ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_initPowerCtl(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;  
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    
    GPIO_InitStructure.GPIO_Pin = WIFI_POWER_CTL_GPIO_PIN;
    GPIO_Init(WIFI_POWER_CTL_GPIO_PORT, &GPIO_InitStructure);    

    GPIO_InitStructure.GPIO_Pin = GPS_POWER_CTL_GPIO_PIN;
    GPIO_Init(GPS_POWER_CTL_GPIO_PORT, &GPIO_InitStructure);

    GPIO_WriteBit(WIFI_POWER_CTL_GPIO_PORT, WIFI_POWER_CTL_GPIO_PIN, Bit_SET);
    GPIO_WriteBit(GPS_POWER_CTL_GPIO_PORT, GPS_POWER_CTL_GPIO_PIN, Bit_RESET);
}

/*
******************************************************************************
*	�� �� ��: GPIOx_wifiSelect
*	����˵��: bSel:��ѡ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_wifiSelect(B_SEL bSel)
{
    GPIO_WriteBit(WIFI_POWER_CTL_GPIO_PORT, WIFI_POWER_CTL_GPIO_PIN, (BitAction)bSel);
}

/*
******************************************************************************
*	�� �� ��: GPIOx_gpsSelect
*	����˵��: bSel:��ѡ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_gpsSelect(B_SEL bSel)
{
    GPIO_WriteBit(GPS_POWER_CTL_GPIO_PORT, GPS_POWER_CTL_GPIO_PIN, (BitAction)bSel);
}

/*
******************************************************************************
*	�� �� ��: GPIOx_getNum
*	����˵��: ������Ż�ȡSPIx
*	��    ��: spiNum:SPIx���,SPIx:SPI���
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_getNum(GPIO_NUM_ENUM spiNum, GPIO_TypeDef** GPIOx)
{
	switch(spiNum){														    //��ȡGPIO�ӿ�	
		case HGPIOA: *GPIOx = GPIOA; break;
        case HGPIOB: *GPIOx = GPIOB; break;
        case HGPIOC: *GPIOx = GPIOC; break;
        case HGPIOD: *GPIOx = GPIOD; break;
        case HGPIOE: *GPIOx = GPIOE; break;
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: GPIOx_setPinMode
*	����˵��: ָ��IO�ڳ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void GPIOx_setPinMode(int16_t bit)
{
	GPIO_InitTypeDef gpioInitStruct;
    GPIO_TypeDef*    GPIOx;

    if (bit >= MAX_EXIT_PIN)
        return;
    if(bit == -1)
        return;

    GPIOx_getNum(PIN_MAP[bit].gpioNum,&GPIOx);
    
	gpioInitStruct.GPIO_Pin  =  PIN_MAP[bit].gpioPin;
	gpioInitStruct.GPIO_Mode =  (GPIOMode_TypeDef)PIN_MAP[bit].gpioMode;
	gpioInitStruct.GPIO_Speed = (GPIOSpeed_TypeDef)PIN_MAP[bit].gpioSpeed;
    gpioInitStruct.GPIO_OType = (GPIOOType_TypeDef)PIN_MAP[bit].gpioOType;
    gpioInitStruct.GPIO_PuPd = (GPIOPuPd_TypeDef)PIN_MAP[bit].gpioPuPd;
	
    GPIO_Init(GPIOx, &gpioInitStruct);
}


