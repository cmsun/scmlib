/**
*****************************************************************************
* @��  ���� mip_usart.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 30-Aug-2019
* @��  ���� USART�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2019/08/30����ʼ�汾
*
*
******************************************************************************
**/

//Ӳ������
#include "mip_usart.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//���ζ���
#include "mod_queue.h"

//�궨��
#define USART1_BAUD_RATE (uint32_t)115200
#define USART2_BAUD_RATE (uint32_t)19200
#define USART3_BAUD_RATE (uint32_t)115200
#define USART4_BAUD_RATE (uint32_t)115200
#define USART5_BAUD_RATE (uint32_t)115200
#define USART6_BAUD_RATE (uint32_t)19200

#define USART1_TXBUF_SIZE   (uint16_t)1024
#define USART1_RXBUF_SIZE   (uint16_t)1024
#define USART2_TXBUF_SIZE   (uint16_t)256
#define USART2_RXBUF_SIZE   (uint16_t)256
#define USART3_TXBUF_SIZE   (uint16_t)512
#define USART3_RXBUF_SIZE   (uint16_t)512
#define USART4_TXBUF_SIZE   (uint16_t)512
#define USART4_RXBUF_SIZE   (uint16_t)512
#define USART5_TXBUF_SIZE   (uint16_t)256
#define USART5_RXBUF_SIZE   (uint16_t)256
#define USART6_TXBUF_SIZE   (uint16_t)256
#define USART6_RXBUF_SIZE   (uint16_t)256

//��̬����
static void USARTx_gpioInit(USART_NUM_ENUM usartNum);
static void USARTx_paramInit(USART_NUM_ENUM usartNum);
static void USARTx_nvicInit(USART_NUM_ENUM usartNum);
static void USARTx_buffInit(USART_NUM_ENUM usartNum);
static void USARTx_callBackInit(USART_NUM_ENUM usartNum, USARTx_CALLBACK uCallBack);
static void USARTx_getNum(USART_NUM_ENUM usartNum, USART_TypeDef** USARTx);

//��̬����
static uint8_t Usart1TxBuff[USART1_TXBUF_SIZE],Usart1RxBuff[USART1_RXBUF_SIZE];
static uint8_t Usart2TxBuff[USART2_TXBUF_SIZE],Usart2RxBuff[USART2_RXBUF_SIZE];
static uint8_t Usart3TxBuff[USART3_TXBUF_SIZE],Usart3RxBuff[USART3_RXBUF_SIZE];
static uint8_t Usart4TxBuff[USART4_TXBUF_SIZE],Usart4RxBuff[USART4_RXBUF_SIZE];
static uint8_t Usart5TxBuff[USART5_TXBUF_SIZE],Usart5RxBuff[USART5_RXBUF_SIZE];
static uint8_t Usart6TxBuff[USART6_TXBUF_SIZE],Usart6RxBuff[USART6_RXBUF_SIZE];

static uint8_t *UsartBuffPtr[MAX_HUSART][MAX_USART_TYPE] = {
    {Usart1TxBuff,Usart1RxBuff},
    {Usart2TxBuff,Usart2RxBuff},
    {Usart3TxBuff,Usart3RxBuff},
    {Usart4TxBuff,Usart4RxBuff},
    {Usart5TxBuff,Usart5RxBuff},
    {Usart6TxBuff,Usart6RxBuff},
};

static const uint16_t UsartBufSize[MAX_HUSART][MAX_USART_TYPE] = {
	{USART1_TXBUF_SIZE,USART1_RXBUF_SIZE},
    {USART2_TXBUF_SIZE,USART2_RXBUF_SIZE},
    {USART3_TXBUF_SIZE,USART3_RXBUF_SIZE},
	{USART4_TXBUF_SIZE,USART4_RXBUF_SIZE},
    {USART5_TXBUF_SIZE,USART5_RXBUF_SIZE},
    {USART6_TXBUF_SIZE,USART6_RXBUF_SIZE},
};

static Queue UsartQueue[MAX_HUSART][MAX_USART_TYPE];
static QueuePtr UsartQueuePtr[MAX_HUSART][MAX_USART_TYPE];

static USARTx_CALLBACK UsartCallBack[6];
static uint8_t FrameTail[FRAME_TAIL_LEN];

//��̬����
static const uint16_t FrameTailRaw[FRAME_TAIL_LEN] = {0x0000, 0x007f, 0x00ff}; 



/*
******************************************************************************
*	�� �� ��: DebugCallBack
*	����˵��: �����жϻص�����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
static int32_t rxCnt = 0;
void DebugCallBack_Rx(void){
 	rxCnt += 1;
}
 
static int32_t txCnt = 0;
void DebugCallBack_Tx(void){
 	txCnt += 1;
}

/*
******************************************************************************
*	�� �� ��: USARTx_init
*	����˵��: USARTx��ʼ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_init(void)
{
	for(int8_t i = 0; i < MAX_HUSART; i++){
		UsartQueuePtr[i][USART_TX_TYPE] = &UsartQueue[i][USART_TX_TYPE];
		UsartQueuePtr[i][USART_RX_TYPE] = &UsartQueue[i][USART_RX_TYPE];
	}

	for(int8_t i = 0; i < FRAME_TAIL_LEN; i++){
		FrameTail[i] = (uint8_t)FrameTailRaw[i];
	}
	
    if(!DEBUG_OFF){
        USARTx_CALLBACK DebugCallBack;
        DebugCallBack.RxCompletePtr = DebugCallBack_Rx;
        DebugCallBack.TxCompletePtr = DebugCallBack_Tx;
        USARTx_initNum(DEBUG_PORT,DebugCallBack);
    }
}

/*
******************************************************************************
*	�� �� ��: USARTx_initNum
*	����˵��: USARTx��ʼ��ָ����Ŵ���
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_initNum(USART_NUM_ENUM usartNum, USARTx_CALLBACK uCallBack)
{
	if(usartNum == HUSART_NULL)												//�������
		return;

    USARTx_buffInit(usartNum);
	USARTx_gpioInit(usartNum);
	USARTx_paramInit(usartNum);
	USARTx_nvicInit(usartNum);
	USARTx_callBackInit(usartNum,uCallBack);
}

/*
******************************************************************************
*	�� �� ��: USARTx_getNum
*	����˵��: ������Ż�ȡUSARTx
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_getNum(USART_NUM_ENUM usartNum, USART_TypeDef** USARTx)
{
	switch(usartNum){
		case HUSART1: *USARTx = USART1; break;
		case HUSART2: *USARTx = USART2; break;
		case HUSART3: *USARTx = USART3; break;
		case HUSART4: *USARTx =  UART4; break;
		case HUSART5: *USARTx =  UART5; break;
		case HUSART6: *USARTx = USART6; break;
		default:break;
    }
}

/*
******************************************************************************
*	�� �� ��: USARTx_gpioInit
*	����˵��: USARTx�ӿ����ã� //��ʼ�����̣���ʼ��->IO����������->����IO�ڣ���Ȼ����һ��0xFF���ʹ���
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_gpioInit(USART_NUM_ENUM usartNum)
{
	GPIO_InitTypeDef gpioInitStruct;

	gpioInitStruct.GPIO_Mode = GPIO_Mode_AF;
	gpioInitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;

	switch(usartNum){
		case HUSART1:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource10, GPIO_AF_USART1);

            gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_9;
			GPIO_Init(GPIOA, &gpioInitStruct);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_10;
			GPIO_Init(GPIOA, &gpioInitStruct);
			break;
		case HUSART2:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);		
				
            gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_2;
			GPIO_Init(GPIOA, &gpioInitStruct);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_3;
			GPIO_Init(GPIOA, &gpioInitStruct);
			break;
		case HUSART3:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
            GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);
            GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_10;
			GPIO_Init(GPIOB, &gpioInitStruct);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_11;
			GPIO_Init(GPIOB, &gpioInitStruct);
			break;
		case HUSART4:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);	
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource0, GPIO_AF_UART4);
            GPIO_PinAFConfig(GPIOA, GPIO_PinSource1, GPIO_AF_UART4);

            gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_0;
			GPIO_Init(GPIOA, &gpioInitStruct);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_1;
			GPIO_Init(GPIOA, &gpioInitStruct);
			break;
		case HUSART5:
			// not use
			break;
		case HUSART6:
			RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);	
			GPIO_PinAFConfig(GPIOC, GPIO_PinSource6, GPIO_AF_USART6);
			GPIO_PinAFConfig(GPIOC, GPIO_PinSource7, GPIO_AF_USART6);

            gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_6;
			GPIO_Init(GPIOC, &gpioInitStruct);
        
            gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_7;
			GPIO_Init(GPIOC, &gpioInitStruct);
			break;
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: USARTx_paramInit
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_paramInit(USART_NUM_ENUM usartNum)
{
	USART_TypeDef* USARTx;

	USART_InitTypeDef usartInitStruct;

	usartInitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;		//��Ӳ������
	usartInitStruct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;						//���պͷ���
	usartInitStruct.USART_Parity = USART_Parity_No;									//��У��
	usartInitStruct.USART_StopBits = USART_StopBits_1;								//1λֹͣλ
	usartInitStruct.USART_WordLength = USART_WordLength_8b;							//8λ����λ
	
	switch(usartNum){
		case HUSART1:
			usartInitStruct.USART_BaudRate = USART1_BAUD_RATE;
			break;	
		case HUSART2:
            usartInitStruct.USART_BaudRate = USART2_BAUD_RATE;
			usartInitStruct.USART_Parity   = USART_Parity_Even;
			usartInitStruct.USART_WordLength = USART_WordLength_9b;	            
			break;	
		case HUSART3:
			usartInitStruct.USART_BaudRate = USART3_BAUD_RATE;
			break;	
		case HUSART4:
			usartInitStruct.USART_BaudRate = USART4_BAUD_RATE;
			break;
		case HUSART5:
			usartInitStruct.USART_BaudRate = USART5_BAUD_RATE;
			break;
		case HUSART6:
            usartInitStruct.USART_BaudRate = USART6_BAUD_RATE;
			break;
		default:break;
	}

	USARTx_getNum(usartNum ,&USARTx);

	USART_Init(USARTx, &usartInitStruct);

	USART_Cmd(USARTx,ENABLE);
}

/*
******************************************************************************
*	�� �� ��: USARTx_nvicInit
*	����˵��: USARTx�ж�����
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_nvicInit(USART_NUM_ENUM usartNum)
{
	USART_TypeDef* USARTx;

	NVIC_InitTypeDef nvicInitStruct;

    USARTx_getNum(usartNum ,&USARTx);

    USART_ITConfig(USARTx, USART_IT_TC, ENABLE);
	USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
	USART_ITConfig(USARTx, USART_IT_IDLE, ENABLE);							//�����ô����жϣ����ʹ���ж�
    
    USART_ClearFlag(USARTx, USART_FLAG_TC);
    USART_ClearFlag(USARTx, USART_FLAG_TXE);                                //���жϱ��
    
	switch(usartNum)
    {
		case HUSART1:
			nvicInitStruct.NVIC_IRQChannel = USART1_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 0;
			NVIC_Init(&nvicInitStruct);
		    break;	
		case HUSART2:
			nvicInitStruct.NVIC_IRQChannel = USART2_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 1;
			NVIC_Init(&nvicInitStruct);
		    break;	
		case HUSART3:
			nvicInitStruct.NVIC_IRQChannel = USART3_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 2;
			NVIC_Init(&nvicInitStruct);
		    break;	
		case HUSART4:
			nvicInitStruct.NVIC_IRQChannel = UART4_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 3;
			NVIC_Init(&nvicInitStruct);
		    break;
		case HUSART5:
			nvicInitStruct.NVIC_IRQChannel = UART5_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 4;
			NVIC_Init(&nvicInitStruct);
		    break;
		case HUSART6:
			nvicInitStruct.NVIC_IRQChannel = USART6_IRQn;
			nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
			nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1;
			nvicInitStruct.NVIC_IRQChannelSubPriority = 5;
			NVIC_Init(&nvicInitStruct);
		    break;
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: USARTx_buffInit
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_buffInit(USART_NUM_ENUM usartNum)
{
    Queue_init(UsartQueuePtr[usartNum][USART_TX_TYPE], 
		UsartBufSize[usartNum][USART_TX_TYPE], 
		UsartBuffPtr[usartNum][USART_TX_TYPE]);
    Queue_init(UsartQueuePtr[usartNum][USART_RX_TYPE], 
		UsartBufSize[usartNum][USART_RX_TYPE], 
		UsartBuffPtr[usartNum][USART_RX_TYPE]);
}

/*
******************************************************************************
*	�� �� ��: USARTx_cleanBuff
*	����˵��: USARTx�����������
*	��    ��: usartNum:USARTx���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_cleanBuff(USART_NUM_ENUM usartNum)
{
	Queue_clear(UsartQueuePtr[usartNum][USART_TX_TYPE]);
    Queue_clear(UsartQueuePtr[usartNum][USART_RX_TYPE]);
}

/*
******************************************************************************
*	�� �� ��: USARTx_callBackInit
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���; uCallBack:�ô��ڵĻص�����
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_callBackInit(USART_NUM_ENUM usartNum, USARTx_CALLBACK uCallBack)
{
	UsartCallBack[usartNum] = uCallBack;
}

/*
******************************************************************************
*	�� �� ��: USARTx_sendBuff
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���; buff:����ָ��; Len:���ݳ���
*	�� �� ֵ: д�뵽���е����ݳ���
******************************************************************************
*/
uint16_t USARTx_sendBuff(USART_NUM_ENUM usartNum, uint8_t *pBuff, uint16_t len)
{
	USART_TypeDef* USARTx;
	USARTx_getNum(usartNum ,&USARTx);
    uint16_t tFreeBuff = Queue_getFree(UsartQueuePtr[usartNum][USART_TX_TYPE]);
    if(tFreeBuff >= len){
        Queue_write(UsartQueuePtr[usartNum][USART_TX_TYPE], pBuff, len);
        USART_ITConfig(USARTx, USART_IT_TXE, ENABLE);
        return len;
    }else{
        return 0;
    }
}

/*
******************************************************************************
*	�� �� ��: USARTx_recvBuff
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���; buff:����ָ��; Len:���ݳ���
*	�� �� ֵ: ���ж�ȡ�����ݳ���
******************************************************************************
*/
uint16_t USARTx_recvBuff(USART_NUM_ENUM usartNum, uint8_t *pBuff, uint16_t len)
{
    uint16_t outputCnt;
    outputCnt = Queue_read(UsartQueuePtr[usartNum][USART_RX_TYPE], pBuff, len);
	return outputCnt;
}

/*
******************************************************************************
*	�� �� ��: USARTx_recvFrame
*	����˵��: USARTx��������
*	��    ��: usartNum:USARTx���; buff:����ָ��; Len:���ݳ���
*	�� �� ֵ: ���ж�ȡ�����ݳ���  0:������ >0:֡���ݳ���(���������)
******************************************************************************
*/
uint16_t USARTx_recvFrame(USART_NUM_ENUM usartNum, uint8_t *pBuff, uint16_t len)
{
    uint8_t  tRxByte = 0;
    uint32_t tRxByteCnt = 0;
    uint32_t tReadCnt = 0;

	for(int16_t i = 0; i < len; i++){									//�ȱ������У�����Ƿ���֡β���
		tRxByteCnt = Queue_read(UsartQueuePtr[usartNum][USART_RX_TYPE],&tRxByte,1);
		if(tRxByteCnt == 1){
            *(pBuff + tReadCnt) = tRxByte;                              //��������
            tReadCnt += 1;
        }else{
			len = 0;													//���ٶ����ѭ��
		}

		if(tReadCnt >= FRAME_TAIL_LEN){                              	//�ж�֡������� 
			if(0 == memcmp((pBuff + (tReadCnt - FRAME_TAIL_LEN)), FrameTail, FRAME_TAIL_LEN)){
				return (tReadCnt - FRAME_TAIL_LEN);
			}
		}
	}

	return tRxByteCnt;	
}

/*
******************************************************************************
*	�� �� ��: USARTx_printf
*	����˵��: USARTx��ӡ����
*	��    ��: buff:����ָ��; Len:���ݳ���
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_printf(char *fmt,...)
{
    static uint8_t printfBuff[512] = {0};                                   //����ÿ�ζ�����ջ
    
    if(DEBUG_OFF) return;													//������Թر�ֱ�ӷ���	
    
    va_list ap;
	va_start(ap, fmt);
	vsprintf((char *)printfBuff, (char*)fmt, ap);
	va_end(ap);

	USARTx_sendBuff(DEBUG_PORT, printfBuff, strlen((char*)printfBuff));
}

/*
******************************************************************************
*	�� �� ��: USARTx_irqHandle
*	����˵��: USARTx�жϴ�������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void USARTx_irqHandle(USART_NUM_ENUM usartNum)
{
	USART_TypeDef* USARTx;
	USARTx_getNum(usartNum ,&USARTx);

    if(USART_GetITStatus(USARTx, USART_IT_TXE) != RESET){               //�����жϣ���û�����ݵ�ʱ������ USART_IT_TXE���ٴη��Ϳ� USART_IT_TXE
        uint8_t tTxByte = 0;
        if(1 == Queue_read(UsartQueuePtr[usartNum][USART_TX_TYPE],&tTxByte,1)){
            USART_SendData(USARTx,tTxByte);
        }else{
            USART_ITConfig(USARTx, USART_IT_TXE, DISABLE);				//������ɣ��������ݼĴ���Ϊ��
            USART_ClearITPendingBit(USARTx, USART_IT_TXE);
        }
    }

	if(USART_GetITStatus(USARTx, USART_IT_TC) != RESET){				//�ȴ����ͽ���,����λ�Ĵ���Ϊ��
        USART_ClearITPendingBit(USARTx, USART_IT_TC);
		if(UsartCallBack[usartNum].TxCompletePtr)
			UsartCallBack[usartNum].TxCompletePtr();
	}

	if(USART_GetITStatus(USARTx, USART_IT_RXNE) != RESET){				//�����жϣ��������ǣ��Ͷ�ȡ����
		USART_ClearITPendingBit(USARTx, USART_IT_RXNE);
        uint8_t tRxByte = USART_ReceiveData(USARTx);
        if(0 == Queue_write(UsartQueuePtr[usartNum][USART_RX_TYPE],&tRxByte,1)){
            //Queue_clear(UsartQueuePtr[usartNum][USART_RX_TYPE]);
        }
    }

	if(USART_GetITStatus(USARTx, USART_IT_IDLE) != RESET){				//�����жϣ������*USART_ReceiveData*��Ȼ����岻��
		uint8_t tRxByte = USART_ReceiveData(USARTx);
        uint8_t tFreeBytesCnt = Queue_getFree(UsartQueuePtr[usartNum][USART_RX_TYPE]);
        if(tFreeBytesCnt >= FRAME_TAIL_LEN){
            Queue_write(UsartQueuePtr[usartNum][USART_RX_TYPE],FrameTail,FRAME_TAIL_LEN);
            UsartCallBack[usartNum].RxCompletePtr();
        }else{
            Queue_clear(UsartQueuePtr[usartNum][USART_RX_TYPE]);     	//�����������������Ĺ���,�ر�Ӧ��wifi��
        }
    }
}

/*
******************************************************************************
*	�� �� ��: USARTx_IRQHandler
*	����˵��: USARTx�жϴ�������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void USART1_IRQHandler(void){
	USARTx_irqHandle(HUSART1);
}
void USART2_IRQHandler(void){
	USARTx_irqHandle(HUSART2);
}
void USART3_IRQHandler(void){
	USARTx_irqHandle(HUSART3);
}
void UART4_IRQHandler(void){
	USARTx_irqHandle(HUSART4);
}
void UART5_IRQHandler(void){
	USARTx_irqHandle(HUSART5);
}
void USART6_IRQHandler(void){
	USARTx_irqHandle(HUSART6);
}

