/**
*****************************************************************************
* @��  ���� mip_pvd.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� PVD���籣�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mip_pvd.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"



/*
******************************************************************************
*	�� �� ��: PVD_init
*	����˵��: PVD��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void PVDx_init(void)
{
	NVIC_InitTypeDef NVIC_InitStructure;
	EXTI_InitTypeDef EXTI_InitStructure;

	/* Enable PWR clock */
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR, ENABLE);
                                                
	/* Enable the PVD Interrupt */
	NVIC_InitStructure.NVIC_IRQChannel = PVD_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	   
	/* Configure EXTI Line16(PVD Output) to generate an interrupt on rising and
	  falling edges */
	EXTI_ClearITPendingBit(EXTI_Line16);
    EXTI_StructInit(&EXTI_InitStructure);
	EXTI_InitStructure.EXTI_Line = EXTI_Line16;
	EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
	EXTI_InitStructure.EXTI_LineCmd = ENABLE;
	EXTI_Init(&EXTI_InitStructure);

	/* Configure the PVD Level to 3 (PVD detection level set to 2.5V, refer to the
	   electrical characteristics of you device datasheet for more details) */
	PWR_PVDLevelConfig(PWR_PVDLevel_7); //do not test other parameter *****

	/* Enable the PVD Output */
	PWR_PVDCmd(ENABLE);
}

/*
******************************************************************************
*	�� �� ��: PVD_IRQHandler
*	����˵��: PVD�жϴ���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void PVD_IRQHandler(void)
{
    if(EXTI_GetITStatus(EXTI_Line16) != RESET)
    {
        EXTI_ClearITPendingBit(EXTI_Line16);
    }
}


