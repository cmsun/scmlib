/*
*****************************************************************************
* @��  ���� mip_i2c.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 16-June-2018
* @��  ���� I2C�������ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/07/16����ʼ�汾
*
******************************************************************************
**/
//�ο�
//https://wenku.baidu.com/view/c9ea12a5e53a580217fcfe19.html
//https://blog.csdn.net/ybhuangfugui/article/details/52175621

//�ӿ��ļ�
#include "mip_iic.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//��̬����
static void I2Cx_gpioInit(I2C_NUM_ENUM i2cNum);
static void I2Cx_paramInit(I2C_NUM_ENUM i2cNum);
static void I2Cx_getNum(I2C_NUM_ENUM i2cNum, I2C_TypeDef** I2Cx);



/*
******************************************************************************
*	�� �� ��: I2Cx_init
*	����˵��: I2Cx_��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_init(void)
{
    I2Cx_initNum(HI2C1);
}  

/*
******************************************************************************
*	�� �� ��: I2Cx_initNum
*	����˵��: I2Cx_��ʼ��
*	��    ��: i2cNum:I2Cx���
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_initNum(I2C_NUM_ENUM i2cNum)
{
    if(i2cNum == HI2C_NULL)
        return;
    
    I2Cx_gpioInit(i2cNum);
    I2Cx_paramInit(i2cNum);
    I2Cx_release(i2cNum);
}

/*
******************************************************************************
*	�� �� ��: I2Cx_gpioInit
*	����˵��: I2Cx��ʼ��
*	��    ��: i2cNum:I2Cx���
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_gpioInit(I2C_NUM_ENUM i2cNum)
{
	GPIO_InitTypeDef gpioInitStruct;

	gpioInitStruct.GPIO_Mode = GPIO_Mode_AF;
    gpioInitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	gpioInitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    
	switch(i2cNum){
		case HI2C1:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);

            GPIO_PinAFConfig(GPIOB,GPIO_PinSource6,GPIO_AF_I2C1);
            GPIO_PinAFConfig(GPIOB,GPIO_PinSource7,GPIO_AF_I2C1);
        
        	gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_6 ;
			GPIO_Init(GPIOB, &gpioInitStruct);
        
        	gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_7 ;
			GPIO_Init(GPIOB, &gpioInitStruct);
		    break;
		case HI2C2:
			RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
        
            GPIO_PinAFConfig(GPIOB,GPIO_PinSource10,GPIO_AF_I2C1);
            GPIO_PinAFConfig(GPIOB,GPIO_PinSource11,GPIO_AF_I2C1);
        
        	gpioInitStruct.GPIO_OType = GPIO_OType_PP;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_10 ;
			GPIO_Init(GPIOB, &gpioInitStruct);
        
        	gpioInitStruct.GPIO_OType = GPIO_OType_OD;
			gpioInitStruct.GPIO_Pin = GPIO_Pin_11 ;
			GPIO_Init(GPIOB, &gpioInitStruct);
		    break;
		default:break;	
	}
}

/*
******************************************************************************
*	�� �� ��: I2Cx_paramInit
*	����˵��: I2Cx��������
*	��    ��: i2cNum:I2Cx���
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_paramInit(I2C_NUM_ENUM i2cNum)
{
	I2C_InitTypeDef i2cInitStruct;
	I2C_TypeDef* I2Cx;

	I2Cx_getNum(i2cNum,&I2Cx);											//��ȡI2C�ӿ�
    I2C_DeInit(I2Cx);                                                   //�ȸ�λI2C
    
    i2cInitStruct.I2C_Mode = I2C_Mode_I2C;
    i2cInitStruct.I2C_DutyCycle = I2C_DutyCycle_2;
    i2cInitStruct.I2C_OwnAddress1 = 0x0A;
    i2cInitStruct.I2C_Ack = I2C_Ack_Enable;
    i2cInitStruct.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
    i2cInitStruct.I2C_ClockSpeed = 400000;                              //100000��100kHz 400000: 400kHz

	I2C_Init(I2Cx, &i2cInitStruct);										//����I2C_InitStruct��ָ���Ĳ�����ʼ������I2Cx�Ĵ���
    
	I2C_Cmd(I2Cx, ENABLE);
    
    //I2C_SoftwareResetCmd(I2Cx,ENABLE);
}

/*
******************************************************************************
*	�� �� ��: I2Cx_getNum
*	����˵��: ������Ż�ȡI2Cx
*	��    ��: i2cNum:I2Cx���,I2Cx:SPI���
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_getNum(I2C_NUM_ENUM i2cNum, I2C_TypeDef** I2Cx)
{
	switch(i2cNum){														//��ȡSPI�ӿ�	
		case HI2C1: *I2Cx = I2C1; break;
		case HI2C2: *I2Cx = I2C2; break;		
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: I2Cx_release
*	����˵��: �ͷ�I2C����
*	��    ��: i2cNum:I2Cx���
*	�� �� ֵ: ��
******************************************************************************
*/
void I2Cx_release(I2C_NUM_ENUM i2cNum)
{
	switch(i2cNum){														//��ȡSPI�ӿ�	
		case HI2C1:{
            for(int8_t i = 0; i < 10; i++){
                GPIO_SetBits(GPIOB, GPIO_Pin_6);
                Delay_nLoop(10);
                GPIO_ResetBits(GPIOB, GPIO_Pin_6);
                Delay_nLoop(10);
            }
            GPIO_SetBits(GPIOB, GPIO_Pin_6);
        }break;
		case HI2C2:{ 
            for(int8_t i = 0; i < 10; i++){
                GPIO_SetBits(GPIOB, GPIO_Pin_10);
                Delay_nLoop(10);
                GPIO_ResetBits(GPIOB, GPIO_Pin_10);
                Delay_nLoop(10);
            }
            GPIO_SetBits(GPIOB, GPIO_Pin_10);
        }break;
		default:break;
	}
}

/*
******************************************************************************
*	�� �� ��: I2Cx_readReg
*	����˵��: I2Cx��ȡ������ַ�Ĵ�����ֵ
*	��    ��: devAddr �豸��ַ;  regAddr �Ĵ�����ַ; dataLen ���ݳ���; pData ����ָ��
*	�� �� ֵ: ִ��״̬
******************************************************************************
*/
uint8_t I2Cx_readReg(I2C_NUM_ENUM i2cNum, uint8_t devAddr, 
                    uint8_t regAddr, uint8_t dataLen, uint8_t *pData)
{
#define WAIT_TIMEOUT (int16_t)0x1000
    int16_t waitTimeout = 0;
    uint8_t errSta = 0;

    /* �Ȼ�ȡ���ĸ�IIC */
    I2C_TypeDef *I2Cx;
    I2Cx_getNum(i2cNum,&I2Cx);

    /* �ȵ� I2C ���߿��� */
    waitTimeout = WAIT_TIMEOUT;
    while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY)){
        if((waitTimeout--) == 0){
            errSta = 1;
            goto erro_exit;
        }
    }

    /* ���� I2C ���� */
    waitTimeout = WAIT_TIMEOUT;
    I2C_GenerateSTART(I2Cx, ENABLE);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_MODE_SELECT)){                  /* EV5 */
        if((waitTimeout--) == 0){
            errSta = 2;
            goto erro_exit;
        }
    }

    /* �����豸��ַ | ����*/
    waitTimeout = WAIT_TIMEOUT;
    I2C_Send7bitAddress(I2Cx, devAddr, I2C_Direction_Transmitter);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)){    /* EV6 */
        if((waitTimeout--) == 0){
            errSta = 3;
            goto erro_exit;
        }
    }

    /* ���ͼĴ�����ַ */
    waitTimeout = WAIT_TIMEOUT;
    I2C_SendData(I2Cx, regAddr);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED)){             /* EV8 */
        if((waitTimeout--) == 0){
            errSta = 4;
            goto erro_exit;
        }
    }

    /* ���� I2C ���� */
    waitTimeout = WAIT_TIMEOUT;
    I2C_GenerateSTART(I2Cx, ENABLE);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_MODE_SELECT)){                  /* EV5 */
        if((waitTimeout--) == 0){
            errSta = 5;
            goto erro_exit;
        }
    }

    /* �����豸��ַ | ���� */
    waitTimeout = WAIT_TIMEOUT;
    I2C_Send7bitAddress(I2Cx, devAddr, I2C_Direction_Receiver);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED)){       /* EV6 */
        if((waitTimeout--) == 0){
            errSta = 6;
            goto erro_exit;
        }
    }

    /* ���ռĴ��������� */
    for(int16_t i = 0; i < (dataLen - 1); i++){
        I2C_AcknowledgeConfig(I2Cx, ENABLE);
        while(I2C_GetFlagStatus(I2Cx,I2C_FLAG_RXNE) == RESET){                  /* EV7 */
            if((waitTimeout--) == 0){
                errSta = 7;
                goto erro_exit;
            }
        }
        *pData = I2C_ReceiveData(I2Cx);
        pData++;
    }
    
    /* Ӧ��ʹ�ܹرգ�����һ��ֹͣλ */
    I2C_AcknowledgeConfig(I2Cx, DISABLE);
    I2C_GenerateSTOP(I2Cx, ENABLE);
    
    /* �ڶ�ȡ���һ������֮ǰ������ ACK = 0 ��ֹͣ���� */
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_RECEIVED)){                /* EV7 */
        if((waitTimeout--) == 0){
            errSta = 7;
            goto erro_exit;
        }
    }
    *pData = I2C_ReceiveData(I2Cx);       

erro_exit:
    return errSta;
}

/*
******************************************************************************
*	�� �� ��: I2Cx_writeReg
*	����˵��: I2Cxд��������ַ�Ĵ�����ֵ
*	��    ��: devAddr �豸��ַ;  regAddr �Ĵ�����ַ; dataLen ���ݳ���; pData ����ָ��
*	�� �� ֵ: ִ��״̬
******************************************************************************
*/
uint8_t I2Cx_writeReg(I2C_NUM_ENUM i2cNum, uint8_t devAddr, 
                    uint8_t regAddr, uint8_t dataLen, uint8_t *pData)
{
#define WAIT_TIMEOUT (int16_t)0x1000
    int16_t waitTimeout = 0;
    uint8_t errSta = 0;

    /* �Ȼ�ȡ���ĸ�IIC */
    I2C_TypeDef *I2Cx;
    I2Cx_getNum(i2cNum,&I2Cx);

    /* �ȵ� I2C ���߿��� */
    waitTimeout = WAIT_TIMEOUT;
    while(I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY)){
        if((waitTimeout--) == 0){
            errSta = 1;
            goto erro_exit;
        }
    }

    /* ���� I2C ���� */
    waitTimeout = WAIT_TIMEOUT;
    I2C_GenerateSTART(I2Cx, ENABLE);
    while(!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT)){                  /* EV5 */
        if((waitTimeout--) == 0){
            errSta = 2;
            break;
        }
    }

    /* �����豸��ַ | ���� */
    waitTimeout = WAIT_TIMEOUT;
    I2C_Send7bitAddress(I2Cx, devAddr, I2C_Direction_Transmitter);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)){    /* EV6 */
        if((waitTimeout--) == 0){
            errSta = 3;
            goto erro_exit;
        }
    }

    /* ���ͼĴ�����ַ */
    waitTimeout = WAIT_TIMEOUT;
    I2C_SendData(I2Cx, regAddr);
    while(!I2C_CheckEvent(I2C1,I2C_EVENT_MASTER_BYTE_TRANSMITTED)){             /* EV8 */
        if((waitTimeout--) == 0){
            errSta = 4;
            goto erro_exit;
        }
    }

    /* ���ͼĴ��������� */    
    for(int16_t i = 0; i < dataLen; i++){
        waitTimeout = WAIT_TIMEOUT;
        I2C_SendData(I2Cx, *(pData + i));
        if(i == (dataLen - 1)){
            while(!I2C_CheckEvent(I2Cx,I2C_EVENT_MASTER_BYTE_TRANSMITTED)){     /* EV8_2 */
                if((waitTimeout--) == 0){
                    errSta = 5;
                    goto erro_exit;
                }
            }
        }
    }

erro_exit:
    /* ʹ��ֹͣ */
    I2C_GenerateSTOP(I2Cx, ENABLE);

    return errSta;
}
