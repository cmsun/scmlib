/**
*****************************************************************************
* @��  ���� mip_exit.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� EXITx�����ļ�,Ŀǰ�����ֻ֧��16���̵ܽ��ж�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mip_exit.h"

//Ӳ��ͷ�ļ�
#include "hardware.h"

//��̬����
void EXITx_begin(uint8_t pin, voidFuncPtr handler, exti_trigger_mode mode);
void EXITx_setMode(uint8_t pin, exti_trigger_mode mode);
void EXITx_pause (uint8_t pin );
void EXITx_resume(uint8_t pin);
void EXITx_close(uint8_t pin);

//ȫ�ֱ���
EXITx_STRUCT EXITx = {
	.begin = EXITx_begin,
	.close = EXITx_close,
	.pause = EXITx_pause,
	.resume = EXITx_resume,
};

// exit �ӿں����ṹ
typedef struct exti_channel {
    void  (*handler)(void);
    uint8_t arg;
} exti_channel;

//
//=====================================================================
// exit �ӿں�����
static exti_channel exti_channels[] = {
    { .handler = NULL, .arg = 0 },  // EXTI0
    { .handler = NULL, .arg = 1 },  // EXTI1
    { .handler = NULL, .arg = 2 },  // EXTI2
    { .handler = NULL, .arg = 3 },  // EXTI3
    { .handler = NULL, .arg = 4 },  // EXTI4
    { .handler = NULL, .arg = 5 },  // EXTI5
    { .handler = NULL, .arg = 6 },  // EXTI6
    { .handler = NULL, .arg = 7 },  // EXTI7
    { .handler = NULL, .arg = 8 },  // EXTI8
    { .handler = NULL, .arg = 9 },  // EXTI9
    { .handler = NULL, .arg = 10},  // EXTI10
    { .handler = NULL, .arg = 11},  // EXTI11
    { .handler = NULL, .arg = 12},  // EXTI12
    { .handler = NULL, .arg = 13},  // EXTI13
    { .handler = NULL, .arg = 14},  // EXTI14
    { .handler = NULL, .arg = 15},  // EXTI15
};

//
//=====================================================================
// exit �жϺ���
static void dispatch_multi_extis(uint32_t start,uint32_t end) 
{
    for (uint32_t exti = start; exti <= end; exti++) {
        uint32_t exti_line = (EXTI_Line0 << exti);
        if(EXTI_GetITStatus(exti_line) != RESET){
            EXTI_ClearITPendingBit(exti_line);
            voidFuncPtr handlerFunc = exti_channels[exti].handler;
            if (!handlerFunc)   continue;
            handlerFunc();
        }
    }
}

//
//=====================================================================
// exit �жϺ���
static  void dispatch_single_exti(uint32_t exti) 
{
    uint32_t exti_line = (EXTI_Line0 << exti);
    voidFuncPtr handlerFunc = exti_channels[exti].handler;
    if(EXTI_GetITStatus(exti_line) != RESET){
        EXTI_ClearITPendingBit(exti_line);
        if (!handlerFunc)   return;
        handlerFunc();
    }
}

//
//=====================================================================
// exit �жϺ���
void EXTI0_IRQHandler(void)      {dispatch_single_exti(0);    }
void EXTI1_IRQHandler(void)      {dispatch_single_exti(1);    }
void EXTI2_IRQHandler(void)      {dispatch_single_exti(2);    }
void EXTI3_IRQHandler(void)      {dispatch_single_exti(3);    }
void EXTI4_IRQHandler(void)      {dispatch_single_exti(4);    }
void EXTI9_5_IRQHandler(void)    {dispatch_multi_extis(5,9);  }
void EXTI15_10_IRQHandler(void)  {dispatch_multi_extis(10,15);}


//=====================================================================
// ��ʼ�趨�����ж�
//=====================================================================
void EXITx_begin(uint8_t pin, voidFuncPtr handler, exti_trigger_mode mode) {

	NVIC_InitTypeDef nvicInitStruct;
    //
    //========================================
    //-- �жϺ���ֲ��
    uint8_t num = PIN_MAP[pin].gpioBit;
    exti_channels[num].handler = handler;
    //
    //========================================
    //-- �жϿ���
    nvicInitStruct.NVIC_IRQChannelCmd = ENABLE;
    nvicInitStruct.NVIC_IRQChannelSubPriority = 0;   
    if (num < 5) {
        nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 1; 
		nvicInitStruct.NVIC_IRQChannel = (EXTI0_IRQn + num);
		NVIC_Init(&nvicInitStruct);
    } else if (num < 10) {
        nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 2;     
		nvicInitStruct.NVIC_IRQChannel = EXTI9_5_IRQn;
		NVIC_Init(&nvicInitStruct);		
    } else {
        nvicInitStruct.NVIC_IRQChannelPreemptionPriority = 3;  
		nvicInitStruct.NVIC_IRQChannel = EXTI15_10_IRQn;
		NVIC_Init(&nvicInitStruct);				
    }
    //
    //========================================
    //-- �趨�����ж�ģʽ
    EXITx_setMode(pin, mode);
    //
    //====================
}
//
//=====================================================================
// �趨�����ж�ģʽ
//=====================================================================
void EXITx_setMode(uint8_t pin, exti_trigger_mode mode) {

    EXTI_InitTypeDef extiInitStruct;
    //
    //========================================
    //-- �ж���ӳ��
    //-- Ex: SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA,EXTI_PinSource0);
    SYSCFG_EXTILineConfig(PIN_MAP[pin].gpioNum, PIN_MAP[pin].gpioBit);
    //
    //========================================
    //-- ���� EXIT �ж���
    switch (mode) {
        case EXTI_RISING: 
            extiInitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
            break;
        case EXTI_FALLING:
            extiInitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
            break;
        case EXTI_RISING_FALLING:
            extiInitStruct.EXTI_Trigger = EXTI_Trigger_Rising_Falling;
            break;
        default:break;
    }
    extiInitStruct.EXTI_Line = PIN_MAP[pin].gpioPin;    //EXTI_Line0
    extiInitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
    extiInitStruct.EXTI_LineCmd = ENABLE;
    EXTI_Init(&extiInitStruct);
}
//
//=====================================================================
// ��ͣ
//=====================================================================
void EXITx_pause (uint8_t pin ) {
    EXTI->IMR &= ~(1<<PIN_MAP[pin].gpioBit);
}
//=====================================================================
// ����
//=====================================================================
void EXITx_resume(uint8_t pin) {
    EXTI->IMR |= (1<<PIN_MAP[pin].gpioBit);
}
//=====================================================================
// ��ʼ�趨�����ж�
//=====================================================================
void EXITx_close(uint8_t pin) {

    uint8_t num = PIN_MAP[pin].gpioBit;
    //
    //========================================
    //-- �жϹر�
    EXTI->IMR &= ~(1<<num);
    //========================================
    //-- �жϺ���ɾ��
    exti_channels[num].handler = NULL;
}


