/**
*****************************************************************************
* @��  ���� mip_spi.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� SPI�����ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MIP_SPI_H_
#define _MIP_SPI_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//ö���ض���
typedef enum {HSPI1 = 0, HSPI2, HSPI3} SPI_NUM_ENUM;
typedef enum {MODE_1ST = 0, MODE_2ND, MODE_3RD, MODE_4TH} SPI_MODE_ENUM;
typedef enum {SPEED_LOW = 0, SPEED_NORMAL, SPEED_HIGH, SPEED_FAST} SPI_SPEED_ENUM;

//�ӿں���
void SPIx_init(SPI_NUM_ENUM spiNum);

void SPIx_setMode(SPI_NUM_ENUM spiNum, SPI_MODE_ENUM modeNum);
void SPIx_setSpeed(SPI_NUM_ENUM spiNum, SPI_SPEED_ENUM speedEnum);
void SPIx_setParam(SPI_NUM_ENUM spiNum, SPI_MODE_ENUM modeNum, SPI_SPEED_ENUM speedEnum);

void SPIx_writeByte(SPI_NUM_ENUM spiNum, uint16_t txData);
uint16_t SPIx_readWriteByte(SPI_NUM_ENUM spiNum, uint16_t txData);

#ifdef _cplusplus
	}
#endif

#endif
