/**
*****************************************************************************
* @��  ���� mip_gpio.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� GPIO�������ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MIP_GPIO_H_
#define _MIP_GPIO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//�궨��


//����ö��
typedef enum {
    HGPIOA = 0, 
    HGPIOB, 
    HGPIOC,
    HGPIOD,
    HGPIOE
}GPIO_NUM_ENUM;
        
typedef enum{
    DISELECTED  = 0, 
    SELECTED = 1
}B_SEL;

typedef enum{
    BIT_RESET = 0,
    BIT_SET = 1
}BIT_STATE_ENUM;

typedef enum{
    EXT_IN0 = 0,EXT_IN1,EXT_IN2,EXT_IN3,
    EXT_IN4,EXT_IN5,EXT_IN6,EXT_IN7,
}EXT_IN_NUM_ENUM;

typedef enum{
    EXT_OUT0 = 0,EXT_OUT1,EXT_OUT2,EXT_OUT3,
    EXT_OUT4,EXT_OUT5,EXT_OUT6,EXT_OUT7,
}EXT_OUT_NUM_ENUM;

typedef enum{
    SEL_NONE = 0,
	SEL_LM95071_1ST,
	SEL_LM95071_2ND,    
	SEL_MAX31865_1ST,
	SEL_MAX31865_2ND,
	SEL_AD7478,
    CHIP_SEL_ALL
}CHIP_SEL_ENUM;

typedef enum {
    PD0 = 0, PD1 = 1,
    MAX_EXIT_PIN
}EXIT_PIN_ENUM;

//����ṹ��
typedef struct {
    GPIO_NUM_ENUM   gpioNum;       	/**< pin's GPIO device */
    uint32_t        gpioBit;        /**< Pin's GPIO port bit. */
    uint32_t        gpioPin;        /**< Pin's GPIO port pin. */
    uint8_t         gpioMode;       /**< Pin's GPIO port mode. */
    uint8_t         gpioSpeed;      /**< Pin's GPIO port speed. */
    uint8_t         gpioOType;      /**< Pin's GPIO port OType. */
    uint8_t         gpioPuPd;       /**< Pin's GPIO port PuPd. */
}GPIOx_STRUCT;


//�ӿں���
void GPIOx_init(void);

void GPIOx_setExtOut(uint16_t cIOValue);
void GPIOx_getExtIn(uint16_t *pIOValue);

void GPIOx_setExtOutSingle(EXT_OUT_NUM_ENUM ExtOutNum, BIT_STATE_ENUM BitSet);
BIT_STATE_ENUM GPIOx_getExtInSingle(EXT_IN_NUM_ENUM ExtInNum);

void GPIOx_adu1402Select(B_SEL bSel);

void GPIOx_gpsSelect(B_SEL bSel);
void GPIOx_wifiSelect(B_SEL bSel);

void GPIOx_chipSelect(CHIP_SEL_ENUM chipSel, B_SEL bSel);

void GPIOx_setPinMode(int16_t bit);

//ȫ�ֱ���
extern GPIOx_STRUCT PIN_MAP[MAX_EXIT_PIN];

#ifdef _cplusplus
	}
#endif

#endif
