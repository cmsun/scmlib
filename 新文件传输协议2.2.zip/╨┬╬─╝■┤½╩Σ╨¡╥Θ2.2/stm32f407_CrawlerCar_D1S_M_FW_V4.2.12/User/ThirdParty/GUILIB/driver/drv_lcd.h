/**
* Copyright (c), 2015-2025
* @file drv_lcd.h
* @brief lcd������ͷ�ļ�
* @author jdh
* @date 2015/7/28
* @verbatim 
* Ӳ������˵��
* ��·���          ��Ƭ������       LCD����
* SDI               PB15            D0    
* SCL               PB13            D1
* CS                PB12            CS
* NRST              NRST            RES
* A0                PB1             DC

* SDI               PB13            D0    
* SCL               PB15            D1
* CS                PB12            CS
* NRST              PB10            RES
* A0                PB11            DC
* @endverbatim 
*/

#ifndef _DRV_LCD_H_
#define _DRV_LCD_H_

/*********************************************************************
*                           ͷ�ļ�
**********************************************************************/

#include "stm32f10x.h"

/*********************************************************************
*                           ����
**********************************************************************/

/**
* @brief ��ʼlcd
*/

void drv_lcd_init(void);

/**
* @brief ����
* @param x:x����
* @param y:y����
* @param show:0:����ʾ,1:��ʾ
*/

void drv_lcd_draw_pixel(uint8_t x,uint8_t y,uint8_t show);

/**
* @brief ����ʾ
* @param 0:�ر�,1:��
*/

void drv_lcd_display_set(uint8_t state);

#endif
