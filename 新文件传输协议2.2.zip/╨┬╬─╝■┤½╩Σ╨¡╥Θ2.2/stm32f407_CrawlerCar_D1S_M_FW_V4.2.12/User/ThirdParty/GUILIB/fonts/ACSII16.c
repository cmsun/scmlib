/**
* Copyright (c), 2015-2025
* @file ACSII16.c
* @brief 16��ACSII�ֿ⣬��������
* @author jdh
* @date 2015/9/6
* @date 2015/9/7
* @date 2015/9/9
*/

/*********************************************************************
*							ͷ�ļ�
**********************************************************************/

#include "font.h"

/*********************************************************************
*							�궨��
**********************************************************************/
#define GUI_CONST_STORAGE const

typedef struct 
{
	uint8_t width;
	uint8_t height;
	uint8_t size;
	const uint8_t *pData;
} GUI_CHARINFO;

/*********************************************************************
*							��̬����
**********************************************************************/

/* Start of unicode area <Basic Latin> */
GUI_CONST_STORAGE unsigned char acGUI_Font16_0020[ 16] = { /* code 0020, SPACE */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0021[ 16] = { /* code 0021, EXCLAMATION MARK */
  ________,
  ________,
  ________,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ________,
  ________,
  ___X____,
  ___X____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0022[ 16] = { /* code 0022, QUOTATION MARK */
  ________,
  ___X__X_,
  __X__X__,
  __X__X__,
  _X__X___,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0023[ 16] = { /* code 0023, NUMBER SIGN */
  ________,
  ________,
  ________,
  ___X__X_,
  ___X__X_,
  ___X__X_,
  _XXXXXX_,
  __X__X__,
  __X__X__,
  __X__X__,
  _XXXXXX_,
  __X__X__,
  __X__X__,
  __X__X__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0024[ 16] = { /* code 0024, DOLLAR SIGN */
  ________,
  ________,
  ____X___,
  __XXXX__,
  _X__X_X_,
  _X__X_X_,
  _X__X___,
  __XXX___,
  ____XX__,
  ____X_X_,
  ____X_X_,
  _X__X_X_,
  _X__X_X_,
  __XXXX__,
  ____X___,
  ____X___};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0025[ 16] = { /* code 0025, PERCENT SIGN */
  ________,
  ________,
  ________,
  _X___X__,
  X_X__X__,
  X_X_X___,
  X_X_X___,
  X_XX____,
  _X_X_X__,
  ___XX_X_,
  __X_X_X_,
  __X_X_X_,
  _X__X_X_,
  _X___X__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0026[ 16] = { /* code 0026, AMPERSAND */
  ________,
  ________,
  ________,
  __XX____,
  _X__X___,
  _X__X___,
  _X__X___,
  _X_X____,
  _XX_XXX_,
  X_X__X__,
  X__X_X__,
  X__XX___,
  X___X__X,
  _XXX_XX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0027[ 16] = { /* code 0027, APOSTROPHE */
  ________,  
  ________,  
  ________,
  ____XX__,
  ___X__X_,
  ____XX__,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0028[ 16] = { /* code 0028, LEFT PARENTHESIS */
  ________,
  ______X_,
  _____X__,
  ____X___,
  ____X___,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ____X___,
  ____X___,
  _____X__,
  ______X_,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0029[ 16] = { /* code 0029, RIGHT PARENTHESIS */
  ________,
  _X______,
  __X_____,
  ___X____,
  ___X____,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ___X____,
  ___X____,
  __X_____,
  _X______,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002A[ 16] = { /* code 002A, ASTERISK */
  ________,
  ________,
  ________,
  ________,
  ___X____,
  ___X____,
  XX_X_XX_,
  __XXX___,
  __XXX___,
  XX_X_XX_,
  ___X____,
  ___X____,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002B[ 16] = { /* code 002B, PLUS SIGN */
  ________,
  ________,
  ________,
  ________,
  ________,
  ____X___,
  ____X___,
  ____X___,
  _XXXXXXX,
  ____X___,
  ____X___,
  ____X___,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002C[ 16] = { /* code 002C, COMMA */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XX_____,
  __X_____,
  __X_____,
  _X______};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002D[ 16] = { /* code 002D, HYPHEN-MINUS */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XXXXXX_,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002E[ 16] = { /* code 002E, FULL STOP */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XX_____,
  _XX_____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_002F[ 16] = { /* code 002F, SOLIDUS */
  ________,
  ________,
  ______X_,
  _____X__,
  _____X__,
  _____X__,
  ____X___,
  ____X___,
  ___X____,
  ___X____,
  ___X____,
  __X_____,
  __X_____,
  _X______,
  _X______,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0030[ 16] = { /* code 0030, DIGIT ZERO */
  ________,
  ________,
  ________,
  ___XX___,
  __X__X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  __X__X__,
  ___XX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0031[ 16] = { /* code 0031, DIGIT ONE */
  ________,
  ________,
  ________,
  ____X___,
  __XXX___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  __XXXXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0032[ 16] = { /* code 0032, DIGIT TWO */
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  _X____X_,
  ______X_,
  _____X__,
  ____X___,
  ___X____,
  __X_____,
  _X____X_,
  _XXXXXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0033[ 16] = { /* code 0033, DIGIT THREE */
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  ______X_,
  _____X__,
  ___XX___,
  _____X__,
  ______X_,
  _X____X_,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0034[ 16] = { /* code 0034, DIGIT FOUR */
  ________,
  ________,
  ________,
  _____X__,
  ____XX__,
  ____XX__,
  ___X_X__,
  __X__X__,
  __X__X__,
  _X___X__,
  _XXXXXXX,
  _____X__,
  _____X__,
  ___XXXXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0035[ 16] = { /* code 0035, DIGIT FIVE */
  ________,
  ________,
  ________,
  _XXXXXX_,
  _X______,
  _X______,
  _X______,
  _XXXX___,
  _X___X__,
  ______X_,
  ______X_,
  _X____X_,
  _X___X__,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0036[ 16] = { /* code 0036, DIGIT SIX */
  ________,
  ________,
  ________,
  ___XX___,
  __X__X__,
  _X______,
  _X______,
  _X_XXX__,
  _XX___X_,
  _X____X_,
  _X____X_,
  _X____X_,
  __X___X_,
  ___XXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0037[ 16] = { /* code 0037, DIGIT SEVEN */
  ________,
  ________,
  ________,
  _XXXXXX_,
  _X____X_,
  _____X__,
  _____X__,
  ____X___,
  ____X___,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0038[ 16] = { /* code 0038, DIGIT EIGHT */
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  _X____X_,
  __X__X__,
  ___XX___,
  __X__X__,
  _X____X_,
  _X____X_,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0039[ 16] = { /* code 0039, DIGIT NINE */
  ________,
  ________,
  ________,
  __XXX___,
  _X___X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X___XX_,
  __XXX_X_,
  ______X_,
  ______X_,
  __X__X__,
  ___XX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003A[ 16] = { /* code 003A, COLON */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ___XX___,
  ___XX___,
  ________,
  ________,
  ________,
  ________,
  ___XX___,
  ___XX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003B[ 16] = { /* code 003B, SEMICOLON */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ___X____,
  ________,
  ________,
  ________,
  ________,
  ________,
  ___X____,
  ___X____,
  ___X____};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003C[ 16] = { /* code 003C, LESS-THAN SIGN */
  ________,
  ________,
  ________,
  ______X_,
  _____X__,
  ____X___,
  ___X____,
  __X_____,
  _X______,
  __X_____,
  ___X____,
  ____X___,
  _____X__,
  ______X_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003D[ 16] = { /* code 003D, EQUALS SIGN */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XXXXXX_,
  ________,
  ________,
  _XXXXXX_,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003E[ 16] = { /* code 003E, GREATER-THAN SIGN */
  ________,
  ________,
  ________,
  _X______,
  __X_____,
  ___X____,
  ____X___,
  _____X__,
  ______X_,
  _____X__,
  ____X___,
  ___X____,
  __X_____,
  _X______,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_003F[ 16] = { /* code 003F, QUESTION MARK */
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  _XX___X_,
  _____X__,
  ____X___,
  ____X___,
  ____X___,
  ________,
  ___XX___,
  ___XX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0040[ 16] = { /* code 0040, COMMERCIAL AT */
  ________,
  ________,
  ________,
  __XXX___,
  _X___X__,
  _X_XX_X_,
  X_X_X_X_,
  X_X_X_X_,
  X_X_X_X_,
  X_X_X_X_,
  X_X_X_X_,
  _X_XXX__,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0041[ 16] = { /* code 0041, LATIN CAPITAL LETTER A */
  ________,
  ________,
  ________,
  ___X____,
  ___X____,
  ___XX___,
  __X_X___,
  __X_X___,
  __X__X__,
  __XXXX__,
  _X___X__,
  _X____X_,
  _X____X_,
  XXX__XXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0042[ 16] = { /* code 0042, LATIN CAPITAL LETTER B */
  ________,
  ________,
  ________,
  XXXXX___,
  _X___X__,
  _X___X__,
  _X___X__,
  _XXXX___,
  _X___X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X___X__,
  XXXXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0043[ 16] = { /* code 0043, LATIN CAPITAL LETTER C */
  ________,
  ________,
  ________,
  __XXXXX_,
  _X____X_,
  _X____X_,
  X_______,
  X_______,
  X_______,
  X_______,
  X_______,
  _X____X_,
  _X___X__,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0044[ 16] = { /* code 0044, LATIN CAPITAL LETTER D */
  ________,
  ________,
  ________,
  XXXXX___,
  _X___X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X___X__,
  XXXXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0045[ 16] = { /* code 0045, LATIN CAPITAL LETTER E */
  ________,
  ________,
  ________,
  XXXXXX__,
  _X____X_,
  _X__X___,
  _X__X___,
  _XXXX___,
  _X__X___,
  _X__X___,
  _X______,
  _X____X_,
  _X____X_,
  XXXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0046[ 16] = { /* code 0046, LATIN CAPITAL LETTER F */
  ________,
  ________,
  ________,
  XXXXXX__,
  _X____X_,
  _X__X___,
  _X__X___,
  _XXXX___,
  _X__X___,
  _X__X___,
  _X______,
  _X______,
  _X______,
  XXX_____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0047[ 16] = { /* code 0047, LATIN CAPITAL LETTER G */
  ________,
  ________,
  ________,
  __XXXX__,
  _X___X__,
  _X___X__,
  X_______,
  X_______,
  X_______,
  X___XXX_,
  X____X__,
  _X___X__,
  _X___X__,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0048[ 16] = { /* code 0048, LATIN CAPITAL LETTER H */
  ________,
  ________,
  ________,
  XXX__XXX,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _XXXXXX_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  XXX__XXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0049[ 16] = { /* code 0049, LATIN CAPITAL LETTER I */
  ________,
  ________,
  ________,
  _XXXXX__,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004A[ 16] = { /* code 004A, LATIN CAPITAL LETTER J */
  ________,
  ________,
  ________,
  __XXXXX_,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  X___X___,
  XXXX____};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004B[ 16] = { /* code 004B, LATIN CAPITAL LETTER K */
  ________,
  ________,
  ________,
  XXX_XXX_,
  _X___X__,
  _X__X___,
  _X_X____,
  _XXX____,
  _X_X____,
  _X__X___,
  _X__X___,
  _X___X__,
  _X___X__,
  XXX_XXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004C[ 16] = { /* code 004C, LATIN CAPITAL LETTER L */
  ________,
  ________,
  ________,
  XXX_____,
  _X______,
  _X______,
  _X______,
  _X______,
  _X______,
  _X______,
  _X______,
  _X______,
  _X____X_,
  XXXXXXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004D[ 16] = { /* code 004D, LATIN CAPITAL LETTER M */
  ________,
  ________,
  ________,
  XXX_XXX_,
  _XX_XX__,
  _XX_XX__,
  _XX_XX__,
  _XX_XX__,
  _XX_XX__,
  _X_X_X__,
  _X_X_X__,
  _X_X_X__,
  _X_X_X__,
  XX_X_XX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004E[ 16] = { /* code 004E, LATIN CAPITAL LETTER N */
  ________,
  ________,
  ________,
  XX___XXX,
  _XX___X_,
  _XX___X_,
  _X_X__X_,
  _X_X__X_,
  _X__X_X_,
  _X__X_X_,
  _X__X_X_,
  _X___XX_,
  _X___XX_,
  XXX___X_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_004F[ 16] = { /* code 004F, LATIN CAPITAL LETTER O */
  ________,
  ________,
  ________,
  __XXX___,
  _X___X__,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  _X___X__,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0050[ 16] = { /* code 0050, LATIN CAPITAL LETTER P */
  ________,
  ________,
  ________,
  XXXXXX__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _XXXXX__,
  _X______,
  _X______,
  _X______,
  _X______,
  XXX_____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0051[ 16] = { /* code 0051, LATIN CAPITAL LETTER Q */
  ________,
  ________,
  ________,
  __XXX___,
  _X___X__,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_____X_,
  X_XX__X_,
  _X__XX__,
  __XXX___,
  _____XX_,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0052[ 16] = { /* code 0052, LATIN CAPITAL LETTER R */
  ________,
  ________,
  ________,
  XXXXXX__,
  _X____X_,
  _X____X_,
  _X____X_,
  _XXXXX__,
  _X__X___,
  _X__X___,
  _X___X__,
  _X___X__,
  _X____X_,
  XXX___XX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0053[ 16] = { /* code 0053, LATIN CAPITAL LETTER S */
  ________,
  ________,
  ________,
  __XXXXX_,
  _X____X_,
  _X____X_,
  _X______,
  __X_____,
  ___XX___,
  _____X__,
  ______X_,
  _X____X_,
  _X____X_,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0054[ 16] = { /* code 0054, LATIN CAPITAL LETTER T */
  ________,
  ________,
  ________,
  XXXXXXX_,
  X__X__X_,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0055[ 16] = { /* code 0055, LATIN CAPITAL LETTER U */
  ________,
  ________,
  ________,
  XXX__XXX,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0056[ 16] = { /* code 0056, LATIN CAPITAL LETTER V */
  ________,
  ________,
  ________,
  XXX__XXX,
  _X____X_,
  _X____X_,
  _X___X__,
  __X__X__,
  __X__X__,
  __X_X___,
  __X_X___,
  ___XX___,
  ___X____,
  ___X____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0057[ 16] = { /* code 0057, LATIN CAPITAL LETTER W */
  ________,
  ________,
  ________,
  XX_X_XX_,
  _X_X_X__,
  _X_X_X__,
  _X_X_X__,
  _X_X_X__,
  _X_X_X__,
  _XX_XX__,
  __X_X___,
  __X_X___,
  __X_X___,
  __X_X___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0058[ 16] = { /* code 0058, LATIN CAPITAL LETTER X */
  ________,
  ________,
  ________,
  XXX__XXX,
  _X____X_,
  __X__X__,
  __X__X__,
  ___XX___,
  ___XX___,
  ___XX___,
  __X__X__,
  __X__X__,
  _X____X_,
  XXX__XXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0059[ 16] = { /* code 0059, LATIN CAPITAL LETTER Y */
  ________,
  ________,
  ________,
  XXX_XXX_,
  _X___X__,
  _X___X__,
  __X_X___,
  __X_X___,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  __XXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005A[ 16] = { /* code 005A, LATIN CAPITAL LETTER Z */
  ________,
  ________,
  ________,
  _XXXXXX_,
  X____X__,
  _____X__,
  ____X___,
  ____X___,
  ___X____,
  __X_____,
  __X_____,
  _X____X_,
  _X____X_,
  XXXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005B[ 16] = { /* code 005B, LEFT SQUARE BRACKET */
  ________,
  ___XXXX_,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___XXXX_,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005C[ 16] = { /* code 005C, REVERSE SOLIDUS */
  ________,
  ________,
  _X______,
  __X_____,
  __X_____,
  __X_____,
  ___X____,
  ___X____,
  ___X____,
  ____X___,
  ____X___,
  _____X__,
  _____X__,
  _____X__,
  ______X_,
  ______X_};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005D[ 16] = { /* code 005D, RIGHT SQUARE BRACKET */
  ________,
  _XXXX___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  _XXXX___,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005E[ 16] = { /* code 005E, CIRCUMFLEX ACCENT */
  ________,
  ___XX___,
  __X__X__,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_005F[ 16] = { /* code 005F, LOW LINE */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XXXXXXXX};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0060[ 16] = { /* code 0060, GRAVE ACCENT */
  ________,
  _XX_____,
  ___X____,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0061[ 16] = { /* code 0061, LATIN SMALL LETTER A */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  __XXX___,
  _X___X__,
  ____XX__,
  __XX_X__,
  _X___X__,
  _X__XX__,
  __XX_XX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0062[ 16] = { /* code 0062, LATIN SMALL LETTER B */
  ________,
  ________,
  ________,
  ________,
  XX______,
  _X______,
  _X______,
  _X_XX___,
  _XX__X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _XX__X__,
  _X_XX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0063[ 16] = { /* code 0063, LATIN SMALL LETTER C */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ___XXX__,
  __X___X_,
  _X______,
  _X______,
  _X______,
  __X___X_,
  ___XXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0064[ 16] = { /* code 0064, LATIN SMALL LETTER D */
  ________,
  ________,
  ________,
  ________,
  _____XX_,
  ______X_,
  ______X_,
  __XXXXX_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X___XX_,
  __XXX_XX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0065[ 16] = { /* code 0065, LATIN SMALL LETTER E */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  _XXXXXX_,
  _X______,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0066[ 16] = { /* code 0066, LATIN SMALL LETTER F */
  ________,
  ________,
  ________,
  ________,
  ____XX__,
  ___X__X_,
  ___X____,
  _XXXXX__,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0067[ 16] = { /* code 0067, LATIN SMALL LETTER G */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  __XXXXX_,
  _X___X__,
  _X___X__,
  __XXX___,
  _X______,
  __XXXX__,
  _X____X_,
  _X____X_,
  __XXXX__};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0068[ 16] = { /* code 0068, LATIN SMALL LETTER H */
  ________,
  ________,
  ________,
  ________,
  XX______,
  _X______,
  _X______,
  _X_XXX__,
  _XX___X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  XXX__XXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0069[ 16] = { /* code 0069, LATIN SMALL LETTER I */
  ________,
  ________,
  ________,
  __XX____,
  __XX____,
  ________,
  ________,
  _XXX____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006A[ 16] = { /* code 006A, LATIN SMALL LETTER J */
  ________,
  ________,
  ________,
  ____XX__,
  ____XX__,
  ________,
  ________,
  ___XXX__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _X___X__,
  _XXXX___};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006B[ 16] = { /* code 006B, LATIN SMALL LETTER K */
  ________,
  ________,
  ________,
  ________,
  XX______,
  _X______,
  _X______,
  _X__XXX_,
  _X__X___,
  _X_X____,
  _XXX____,
  _X__X___,
  _X___X__,
  XXX_XXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006C[ 16] = { /* code 006C, LATIN SMALL LETTER L */
  ________,
  ________,
  ________,
  ___X____,
  _XXX____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006D[ 16] = { /* code 006D, LATIN SMALL LETTER M */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XXXXXXX_,
  _X__X__X,
  _X__X__X,
  _X__X__X,
  _X__X__X,
  _X__X__X,
  XXX_XX_X,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006E[ 16] = { /* code 006E, LATIN SMALL LETTER N */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XX_XXX__,
  _XX___X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  XXX__XXX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_006F[ 16] = { /* code 006F, LATIN SMALL LETTER O */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  __XXXX__,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  __XXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0070[ 16] = { /* code 0070, LATIN SMALL LETTER P */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XX_XX___,
  _XX__X__,
  _X____X_,
  _X____X_,
  _X____X_,
  _XX__X__,
  _X_XX___,
  _X______,
  XXX_____};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0071[ 16] = { /* code 0071, LATIN SMALL LETTER Q */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ___XX_X_,
  __X__XX_,
  _X____X_,
  _X____X_,
  _X____X_,
  __X__XX_,
  ___XX_X_,
  ______X_,
  _____XXX};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0072[ 16] = { /* code 0072, LATIN SMALL LETTER R */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XXX_XXX_,
  __XX__X_,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  XXXXX___,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0073[ 16] = { /* code 0073, LATIN SMALL LETTER S */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  __XXXXX_,
  _X____X_,
  _X______,
  __XXXX__,
  ______X_,
  _X____X_,
  _XXXXX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0074[ 16] = { /* code 0074, LATIN SMALL LETTER T */
  ________,
  ________,
  ________,
  ________,
  ________,
  ___X____,
  ___X____,
  _XXXXX__,
  ___X____,
  ___X____,
  ___X____,
  ___X____,
  ___X__X_,
  ____XX__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0075[ 16] = { /* code 0075, LATIN SMALL LETTER U */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XX___XX_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X____X_,
  _X___XX_,
  __XXX_XX,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0076[ 16] = { /* code 0076, LATIN SMALL LETTER V */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XXX_XXX_,
  _X___X__,
  _X___X__,
  __X_X___,
  __X_X___,
  ___X____,
  ___X____,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0077[ 16] = { /* code 0077, LATIN SMALL LETTER W */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XX_XX_XX,
  X___X__X,
  _X__X_X_,
  _X_XX_X_,
  _X_X_X__,
  __X__X__,
  __X__X__,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0078[ 16] = { /* code 0078, LATIN SMALL LETTER X */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XXX_XX_,
  __X__X__,
  ___XX___,
  ___XX___,
  ___XX___,
  __X__X__,
  _XX_XXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_0079[ 16] = { /* code 0079, LATIN SMALL LETTER Y */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  XXX__XXX,
  _X____X_,
  __X__X__,
  __X__X__,
  ___XX___,
  ___XX___,
  ___X____,
  ___X____,
  _XX_____};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007A[ 16] = { /* code 007A, LATIN SMALL LETTER Z */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  _XXXXXX_,
  _X___X__,
  ____X___,
  ___X____,
  ___X____,
  __X___X_,
  _XXXXXX_,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007B[ 16] = { /* code 007B, LEFT CURLY BRACKET */
  ________,
  ______XX,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  ____X___,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  _____X__,
  ______XX,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007C[ 16] = { /* code 007C, VERTICAL LINE */
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___,
  ____X___};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007D[ 16] = { /* code 007D, RIGHT CURLY BRACKET */
  ________,
  XX______,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  ___X____,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  __X_____,
  XX______,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007E[ 16] = { /* code 007E, TILDE */
  __X_____,
  _X_XX_X_,
  _____X__,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE unsigned char acGUI_Font16_007F[ 16] = { /* code 007F, <control> */
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________,
  ________};

GUI_CONST_STORAGE GUI_CHARINFO GUI_Font16_CharInfo[96] = {
   {   8,   16,  8, acGUI_Font16_0020 } /* code 0020 */
  ,{   8,   16,  8, acGUI_Font16_0021 } /* code 0021 */
  ,{   8,   16,  8, acGUI_Font16_0022 } /* code 0022 */
  ,{   8,   16,  8, acGUI_Font16_0023 } /* code 0023 */
  ,{   8,   16,  8, acGUI_Font16_0024 } /* code 0024 */
  ,{   8,   16,  8, acGUI_Font16_0025 } /* code 0025 */
  ,{   8,   16,  8, acGUI_Font16_0026 } /* code 0026 */
  ,{   8,   16,  8, acGUI_Font16_0027 } /* code 0027 */
  ,{   8,   16,  8, acGUI_Font16_0028 } /* code 0028 */
  ,{   8,   16,  8, acGUI_Font16_0029 } /* code 0029 */
  ,{   8,   16,  8, acGUI_Font16_002A } /* code 002A */
  ,{   8,   16,  8, acGUI_Font16_002B } /* code 002B */
  ,{   8,   16,  8, acGUI_Font16_002C } /* code 002C */
  ,{   8,   16,  8, acGUI_Font16_002D } /* code 002D */
  ,{   8,   16,  8, acGUI_Font16_002E } /* code 002E */
  ,{   8,   16,  8, acGUI_Font16_002F } /* code 002F */
  ,{   8,   16,  8, acGUI_Font16_0030 } /* code 0030 */
  ,{   8,   16,  8, acGUI_Font16_0031 } /* code 0031 */
  ,{   8,   16,  8, acGUI_Font16_0032 } /* code 0032 */
  ,{   8,   16,  8, acGUI_Font16_0033 } /* code 0033 */
  ,{   8,   16,  8, acGUI_Font16_0034 } /* code 0034 */
  ,{   8,   16,  8, acGUI_Font16_0035 } /* code 0035 */
  ,{   8,   16,  8, acGUI_Font16_0036 } /* code 0036 */
  ,{   8,   16,  8, acGUI_Font16_0037 } /* code 0037 */
  ,{   8,   16,  8, acGUI_Font16_0038 } /* code 0038 */
  ,{   8,   16,  8, acGUI_Font16_0039 } /* code 0039 */
  ,{   8,   16,  8, acGUI_Font16_003A } /* code 003A */
  ,{   8,   16,  8, acGUI_Font16_003B } /* code 003B */
  ,{   8,   16,  8, acGUI_Font16_003C } /* code 003C */
  ,{   8,   16,  8, acGUI_Font16_003D } /* code 003D */
  ,{   8,   16,  8, acGUI_Font16_003E } /* code 003E */
  ,{   8,   16,  8, acGUI_Font16_003F } /* code 003F */
  ,{   8,   16,  8, acGUI_Font16_0040 } /* code 0040 */
  ,{   8,   16,  8, acGUI_Font16_0041 } /* code 0041 */
  ,{   8,   16,  8, acGUI_Font16_0042 } /* code 0042 */
  ,{   8,   16,  8, acGUI_Font16_0043 } /* code 0043 */
  ,{   8,   16,  8, acGUI_Font16_0044 } /* code 0044 */
  ,{   8,   16,  8, acGUI_Font16_0045 } /* code 0045 */
  ,{   8,   16,  8, acGUI_Font16_0046 } /* code 0046 */
  ,{   8,   16,  8, acGUI_Font16_0047 } /* code 0047 */
  ,{   8,   16,  8, acGUI_Font16_0048 } /* code 0048 */
  ,{   8,   16,  8, acGUI_Font16_0049 } /* code 0049 */
  ,{   8,   16,  8, acGUI_Font16_004A } /* code 004A */
  ,{   8,   16,  8, acGUI_Font16_004B } /* code 004B */
  ,{   8,   16,  8, acGUI_Font16_004C } /* code 004C */
  ,{   8,   16,  8, acGUI_Font16_004D } /* code 004D */
  ,{   8,   16,  8, acGUI_Font16_004E } /* code 004E */
  ,{   8,   16,  8, acGUI_Font16_004F } /* code 004F */
  ,{   8,   16,  8, acGUI_Font16_0050 } /* code 0050 */
  ,{   8,   16,  8, acGUI_Font16_0051 } /* code 0051 */
  ,{   8,   16,  8, acGUI_Font16_0052 } /* code 0052 */
  ,{   8,   16,  8, acGUI_Font16_0053 } /* code 0053 */
  ,{   8,   16,  8, acGUI_Font16_0054 } /* code 0054 */
  ,{   8,   16,  8, acGUI_Font16_0055 } /* code 0055 */
  ,{   8,   16,  8, acGUI_Font16_0056 } /* code 0056 */
  ,{   8,   16,  8, acGUI_Font16_0057 } /* code 0057 */
  ,{   8,   16,  8, acGUI_Font16_0058 } /* code 0058 */
  ,{   8,   16,  8, acGUI_Font16_0059 } /* code 0059 */
  ,{   8,   16,  8, acGUI_Font16_005A } /* code 005A */
  ,{   8,   16,  8, acGUI_Font16_005B } /* code 005B */
  ,{   8,   16,  8, acGUI_Font16_005C } /* code 005C */
  ,{   8,   16,  8, acGUI_Font16_005D } /* code 005D */
  ,{   8,   16,  8, acGUI_Font16_005E } /* code 005E */
  ,{   8,   16,  8, acGUI_Font16_005F } /* code 005F */
  ,{   8,   16,  8, acGUI_Font16_0060 } /* code 0060 */
  ,{   8,   16,  8, acGUI_Font16_0061 } /* code 0061 */
  ,{   8,   16,  8, acGUI_Font16_0062 } /* code 0062 */
  ,{   8,   16,  8, acGUI_Font16_0063 } /* code 0063 */
  ,{   8,   16,  8, acGUI_Font16_0064 } /* code 0064 */
  ,{   8,   16,  8, acGUI_Font16_0065 } /* code 0065 */
  ,{   8,   16,  8, acGUI_Font16_0066 } /* code 0066 */
  ,{   8,   16,  8, acGUI_Font16_0067 } /* code 0067 */
  ,{   8,   16,  8, acGUI_Font16_0068 } /* code 0068 */
  ,{   8,   16,  8, acGUI_Font16_0069 } /* code 0069 */
  ,{   8,   16,  8, acGUI_Font16_006A } /* code 006A */
  ,{   8,   16,  8, acGUI_Font16_006B } /* code 006B */
  ,{   8,   16,  8, acGUI_Font16_006C } /* code 006C */
  ,{   8,   16,  8, acGUI_Font16_006D } /* code 006D */
  ,{   8,   16,  8, acGUI_Font16_006E } /* code 006E */
  ,{   8,   16,  8, acGUI_Font16_006F } /* code 006F */
  ,{   8,   16,  8, acGUI_Font16_0070 } /* code 0070 */
  ,{   8,   16,  8, acGUI_Font16_0071 } /* code 0071 */
  ,{   8,   16,  8, acGUI_Font16_0072 } /* code 0072 */
  ,{   8,   16,  8, acGUI_Font16_0073 } /* code 0073 */
  ,{   8,   16,  8, acGUI_Font16_0074 } /* code 0074 */
  ,{   8,   16,  8, acGUI_Font16_0075 } /* code 0075 */
  ,{   8,   16,  8, acGUI_Font16_0076 } /* code 0076 */
  ,{   8,   16,  8, acGUI_Font16_0077 } /* code 0077 */
  ,{   8,   16,  8, acGUI_Font16_0078 } /* code 0078 */
  ,{   8,   16,  8, acGUI_Font16_0079 } /* code 0079 */
  ,{   8,   16,  8, acGUI_Font16_007A } /* code 007A */
  ,{   8,   16,  8, acGUI_Font16_007B } /* code 007B */
  ,{   8,   16,  8, acGUI_Font16_007C } /* code 007C */
  ,{   8,   16,  8, acGUI_Font16_007D } /* code 007D */
  ,{   8,   16,  8, acGUI_Font16_007E } /* code 007E */
  ,{   8,   16,  8, acGUI_Font16_007F } /* code 007F */
};


/*********************************************************************
*							����
**********************************************************************/

/**
* @brief �õ�����߶�
* @param font:����
* @retval �߶�
*/

uint8_t ACSII_16X16_get_height(void)
{
	return 16;
}

/**
* @brief �õ���ַ
* @param font:����
* @param ch:����ȡ���ַ�
* @param addr:���ݴ洢��ַ
* @retval ��ȡ���.0:ʧ��,1:�ɹ�
*/

uint8_t ACSII_16X16_get_address(uint16_t ch,struct _Font_Type *font_type,uint32_t *addr) 
{ 
	if((ch >= 0x20 )&&(ch <= 0x7D)){
		font_type->width  = GUI_Font16_CharInfo[ch - 0x20].width;
		font_type->height = GUI_Font16_CharInfo[ch - 0x20].height;
		font_type->size   = GUI_Font16_CharInfo[ch - 0x20].size;
		*addr = (uint32_t)GUI_Font16_CharInfo[ch - 0x20].pData;
		return 1;
	}else{
		return 0;
	}
}

