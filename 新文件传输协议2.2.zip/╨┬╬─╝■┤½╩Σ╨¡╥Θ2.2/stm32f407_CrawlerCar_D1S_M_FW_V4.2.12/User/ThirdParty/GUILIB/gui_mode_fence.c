/**
* Copyright (c), 2015-2025
* @file gui_mode_fence.c
* @brief Χ��ģʽ����ģ�����ļ�
* @author jdh
* @date 2015/11/22
* @update 2015/12/11
*/

/*********************************************************************
*							ͷ�ļ�
**********************************************************************/

#include "gui_mode_fence.h"
#include "gui.h"

/*********************************************************************
*							���ݽṹ
**********************************************************************/

/**
* @brief ����״̬
*/

struct _Key_State
{
	uint8_t ok;
	uint8_t cancel;
	uint8_t left;
	uint8_t right;
};

/*********************************************************************
*							��̬����
**********************************************************************/


/**
* @brief ��ǰ��ʾ״̬.0:δ��ʾ,1��ʾ
*/

static uint8_t State_Show = 0;

/**
* @brief �ؼ�
*/

//��������
static Widget_Text_Handle Widget_Text_Alarm_Distance;
//״̬
static Widget_Text_Handle Widget_Text_State;
//����
static Widget_Text_Handle Widget_Text_Distance;

/**
* @brief ����״̬
*/

static struct _Key_State Key_State = 
{
	.ok = 0,
	.cancel = 0,
	.left = 0,
	.right = 0
};

/**
* @brief �ӻ���Ϣ
*/

static struct _Slave_Info Slave_Info_Show;

/*********************************************************************
*							��̬����
**********************************************************************/

/**
* @brief ��������
* @retval ����״̬
*/

static int pt_run(void);

/**
* @brief ��������
*/

static void deal_key(void);

/**
* @brief ���½���
*/

static void refresh_ui(void);

/*********************************************************************
*							����
**********************************************************************/


/**
* @brief ������ʾ״̬
* @param enable:0:�ر���ʾ,1:����ʾ
*/

void gui_mode_fence_show(uint8_t enable)
{
	uint8_t distance_alarm = 0;
	char str[32] = {0};
	
	//�жϵ�ǰ״̬
	if (State_Show == enable)
	{
		return;
	}
	
	State_Show = enable;
	if (State_Show)
	{
		//����
		gui_fill_rect(0,0,LCD_WIDTH - 1,LCD_HEIGHT - 1,0);
		
		//��ʾ�����ؼ�
		//��ȡ��������
		sprintf(str,"%dm",distance_alarm);
		Widget_Text_Alarm_Distance = gui_widget_text_create(93,20,30,20,GB18030_20X20,str);
		Widget_Text_State = gui_widget_text_create(93,40,30,20,GB18030_20X20,"����");
		Widget_Text_Distance = gui_widget_text_create(0,27,87,30,GB18030_37X37B,"0.0m");
		refresh_ui();
	}
	else
	{
		gui_widget_delete(Widget_Text_Alarm_Distance);
		gui_widget_delete(Widget_Text_State);
		gui_widget_delete(Widget_Text_Distance);
	}
}

/**
* @brief �õ���ǰ����ʾ״̬
* @retval 0:�ر���ʾ,1:����ʾ
*/

uint8_t gui_mode_fence_get_show(void)
{
	return State_Show;
}

/**
* @brief ��������
* @retval ����״̬
*/

static int pt_run(void)
{
	
	if (State_Show)
	{
		//���½���
		refresh_ui();
		//��������
		deal_key();
	}
	
}

/**
* @brief ��������
*/

static void deal_key(void)
{	
	uint8_t distance_alarm = 0;
	char str[32] = {0};
	
	//if (inf_key_detect_hold(KEY_CANCEL))
    if(0)
	{
		if (Key_State.cancel == 0)
		{
			Key_State.cancel = 1;
			return;
		}
	}
	else
	{
		if (Key_State.cancel == 1)
		{
			Key_State.cancel = 0;
			return;
		}
	}
	
	if (inf_key_detect_hold(KEY_OK))
	{
		if (Key_State.ok == 0)
		{
			Key_State.ok = 1;
			
			distance_alarm = para_manage_read_distance_alarm();
			switch (distance_alarm)
			{
				case 5:
				{
					distance_alarm = 10;
					break;
				}
				case 10:
				{
					distance_alarm = 20;
					break;
				}
				case 20:
				{
					distance_alarm = 30;
					break;
				}
				case 30:
				{
					distance_alarm = 5;
					break;
				}
				default:
				{
					distance_alarm = 10;
					break;
				}
			}
			para_manage_earase_para(2);
			para_manage_save_valid(2);
			para_manage_save_distance_alarm(distance_alarm);
			sprintf(str,"%dm",distance_alarm);
			gui_widget_text_set_text(Widget_Text_Alarm_Distance,GB18030_20X20,str);
			return;
		}
	}
	else
	{
		if (Key_State.ok == 1)
		{
			Key_State.ok = 0;
			return;
		}
	}
	
	if (inf_key_detect_hold(KEY_LEFT))
	{
		if (Key_State.left == 0)
		{
			Key_State.left = 1;
			
			//����Ϊֹͣ��ģʽ
			para_manage_save_work_mode(MODE_STOPING);
			//�л���ֹͣ���Ƚ���
			gui_schedule_switch(GUI_STOP_PROGRESS);
			
			return;
		}
	}
	else
	{
		if (Key_State.left == 1)
		{
			Key_State.left = 0;
			return;
		}
	}
	
	if (inf_key_detect_hold(KEY_RIGHT))
	{
		if (Key_State.right == 0)
		{
			Key_State.right = 1;
			
			//����Ϊ����ģʽ
			para_manage_save_work_mode(MODE_SEARCH);
			//�л�������ģʽ����
			gui_schedule_switch(GUI_MODE_SEARCH);
			return;
		}
	}
	else
	{
		if (Key_State.right == 1)
		{
			Key_State.right = 0;
			return;
		}
	}
}

/**
* @brief ���½���
*/

static void refresh_ui(void)
{	
	char str[32] = {0};
	uint16_t slave_id = 0;
	struct _Slave_Info slave_info;
	
	//�ӻ�����
	if (para_manage_read_slave_num() == 0)
	{
		return;
	}
	//��ȡ�ӻ�id
	slave_id = para_manage_read_slave_id(1);
	//��ȡ�ӻ���Ϣ
	slave_info = slave_manage_read_slave(slave_id);
	
	//״̬
	if (Slave_Info_Show.state != slave_info.state)
	{
		Slave_Info_Show.state = slave_info.state;
		switch (Slave_Info_Show.state)
		{
			case 0:
			{
				gui_widget_text_set_text(Widget_Text_State,GB18030_20X20,"����");
				break;
			}
			case 1:
			{
				gui_widget_text_set_text(Widget_Text_State,GB18030_20X20,"�͵�");
				break;
			}
			case 2:
			{
				gui_widget_text_set_text(Widget_Text_State,GB18030_20X20,"����");
				break;
			}
			case 3:
			{
				gui_widget_text_set_text(Widget_Text_State,GB18030_20X20,"ʧ��");
				break;
			}
		}
	}
	
	//����
	if (Slave_Info_Show.distance != slave_info.distance)
	{
		Slave_Info_Show.distance = slave_info.distance;
		sprintf(str,"%.1fm",Slave_Info_Show.distance);
		gui_widget_text_set_text(Widget_Text_Distance,GB18030_37X37B,str);
	}
}

