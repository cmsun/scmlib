/**
  ******************************************************************************
  * �ļ�: diskio.c
  * ����: LeiTek (leitek.taobao.com)
  * �汾: V1.0.0
  * ����: ʵ�� SD disc ����
  ******************************************************************************
  *
  *                  ��Ȩ���� (C), LeiTek (leitek.taobao.com)
  *                                www.leitek.com
  *
  ******************************************************************************
  */
#include "hardware.h"

#include "diskio.h"			/* FatFs lower layer API */
#include "bsp_sdcard.h"	    /* SD���ײ����� */

#define SECTOR_SIZE		512

/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS SD_disk_initialize(void)
{
	SD_CardInfo SDCardInfo;
	SD_Error Status;

	Status = SD_Init();

	if (Status == SD_OK)
	{
		return RES_OK;
	}
	else
	{
		return STA_NODISK;
	}
}

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber (0..) */
)
{
	DSTATUS stat;

	switch (pdrv) {
	case FS_SD :
		stat = SD_disk_initialize();
		return stat;

	case FS_NAND :
		stat = STA_NOINIT;
		return stat;
	}
	return STA_NOINIT;
}



/*-----------------------------------------------------------------------*/
/* Get Disk Status                                                       */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber (0..) */
)
{
	DSTATUS stat;

	switch (pdrv)
	{
	case FS_SD :
		stat = 0;
		return stat;

	case FS_NAND :
		return stat;
	}
	return STA_NOINIT;
}

/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address (LBA) */
	UINT count		/* Number of sectors to read (1..128) */
)
{
	DRESULT res;

	switch (pdrv) {
	case FS_SD :
		{
			SD_Error Status = SD_OK;

			if (count == 1)
			{
				Status = SD_ReadBlock(buff, sector << 9 , SECTOR_SIZE);
			}
			else
			{
				Status = SD_ReadMultiBlocks(buff, sector << 9 , SECTOR_SIZE, count);
			}
			if (Status != SD_OK)
			{
				return RES_ERROR;
			}

		#ifdef SD_DMA_MODE
			/* SDIO������DMAģʽ����Ҫ������DMA�����Ƿ���� */
			Status = SD_WaitReadOperation();
			if (Status != SD_OK)
			{
				return RES_ERROR;
			}

			while(SD_GetStatus() != SD_TRANSFER_OK);
		#endif

			return RES_OK;
		}

	case FS_NAND :
		res = RES_OK;
		return res;

	}
	return RES_PARERR;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/
#if _USE_WRITE
DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber (0..) */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address (LBA) */
	UINT count			/* Number of sectors to write (1..128) */
)
{
	DRESULT res;
    
    IWDGx_feed();           //ιMCU�ڲ����Ź�
    Led_setToggle(WDI_3);   //ι�ⲿ���Ź�

	switch (pdrv) {
	case FS_SD :
		{
			SD_Error Status = SD_OK;

			if (count == 1)
			{
				Status = SD_WriteBlock((uint8_t *)buff, sector << 9 ,SECTOR_SIZE);

				if (Status != SD_OK)
				{
					return RES_ERROR;
				}

			#ifdef SD_DMA_MODE
				/* SDIO������DMAģʽ����Ҫ������DMA�����Ƿ���� */
				Status = SD_WaitReadOperation();
				if (Status != SD_OK)
				{
					return RES_ERROR;
				}
				while(SD_GetStatus() != SD_TRANSFER_OK);
			#endif
				return RES_OK;
			}
			else
			{
				/* �˴��������ʣ� �����������д count �����������1��block�޷�д�� */
				//Status = SD_WriteMultiBlocks((uint8_t *)buff, sector << 9 ,SECTOR_SIZE, count);
				Status = SD_WriteMultiBlocks((uint8_t *)buff, sector << 9 ,SECTOR_SIZE, count + 1);

				if (Status != SD_OK)
				{
					return RES_ERROR;
				}

			#ifdef SD_DMA_MODE
				/* SDIO������DMAģʽ����Ҫ������DMA�����Ƿ���� */
				Status = SD_WaitReadOperation();
				if (Status != SD_OK)
				{
					return RES_ERROR;
				}
				while(SD_GetStatus() != SD_TRANSFER_OK);
			#endif


				return RES_OK;
			}
		}


	case FS_NAND :
		res = RES_OK;
		return res;
	}
	return RES_PARERR;
}
#endif


/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

#if _USE_IOCTL
DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	DRESULT res;

	switch (pdrv) {
	case FS_SD :
        if(cmd == GET_SECTOR_COUNT)
            *(DWORD *)buff = 31250000;
		res = RES_OK;
		return res;

	case FS_NAND :
		res = RES_OK;
		return res;
	}
	return RES_PARERR;
}
#endif

#if !_FS_READONLY
/**
  * ����: �õ���ǰʱ��
  * ����: ��
  * ����: ��ǰʱ��
  */
DWORD get_fattime(void)
{
   uint32_t res;
   RTC_TIME_STRUCT rtc;

   RTCx_get(&rtc);

   /* �� 1980-1-1 ���� */
   res =  (((DWORD)rtc.year - 1980) << 25) | ((DWORD)rtc.month << 21) |
          ((DWORD)rtc.mday << 16) | (WORD)(rtc.hour << 11) |
          (WORD)(rtc.min << 5) | (WORD)(rtc.sec >> 1);

   return res;
}
#endif

/****************************** leitek.taobao.com *****************************/
