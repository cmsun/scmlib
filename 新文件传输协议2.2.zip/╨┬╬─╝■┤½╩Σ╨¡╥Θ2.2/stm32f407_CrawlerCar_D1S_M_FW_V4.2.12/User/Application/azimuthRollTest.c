#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <math.h>

#if 0

#define CIRCLE_ANGLE (int32_t)360

int main(void)
{
    static double sAmuizthByRtk = 0.0;

    double inputAzimuth = 0.0;

    for(int i = 0; i < 2000; i++){
        inputAzimuth = 359.1 - (i % 360);                                      //����Ƕ� 0 �� 360

        int32_t tRealCircle = sAmuizthByRtk / CIRCLE_ANGLE;                     //������ת�˶���Ȧ
        printf("sAmuizthByRtk = %.6f,inputAzimuth = %.6f,tRealCircle = %d\r\n",sAmuizthByRtk,inputAzimuth,tRealCircle);

        double tRealAngle = sAmuizthByRtk - (tRealCircle * CIRCLE_ANGLE);       //ʣ��Ƕ�
        if(tRealAngle < 0.0){                                                   //���Ƕ���(0.0~-360.0]��ʱ����Ҫ��tRealAngle��Ϊ[0~360),���Լ�360��ʱ����Ҫ��һȦ
            tRealAngle += CIRCLE_ANGLE;
            tRealCircle -= 1;
        }

        printf("tRealAngle = %.6f\r\n",tRealAngle);
        if((inputAzimuth - tRealAngle) > 180.0){                               //������ת�ۼƽǶ�,From -> To => To - From
            tRealCircle -= 1;
            printf("tRealCircle -= 1 = %d\r\n",tRealCircle);  
        }else if((inputAzimuth - tRealAngle) < -180.0){
            tRealCircle += 1;
            printf("tRealCircle += 1 = %d\r\n",tRealCircle);
        }
        sAmuizthByRtk = inputAzimuth + tRealCircle * CIRCLE_ANGLE;

        printf("Final: sAmuizthByRtk = %.6f\r\n",sAmuizthByRtk);

    }

}
#endif

#if 0

int main(void)
{
    double amuzithAngle = 60; //1210.0      ���ﲻӰ���������

    for(int i = 0; i < 5000; i++){
        //double inputAzimuth = 360 - i % 360;
        double inputAzimuth = i;

        double tDisAngle = amuzithAngle - inputAzimuth;  
        int32_t tCircleCnt = tDisAngle / CIRCLE_ANGLE;                  //������Ȧ
        printf("inputAzimuth = %.6f,tDisAngle = %.6f,tCircleCnt = %d\r\n",inputAzimuth,tDisAngle,tCircleCnt);

        double tDisAmuzithAngle = tDisAngle - tCircleCnt * CIRCLE_ANGLE;//������ٶȣ�-360�� ~ +360�㣩
        if(tDisAmuzithAngle > 180.0f){                                  //�������Ƕ���Ȧ��
            tCircleCnt += 1;
            tDisAmuzithAngle -= 180.0f;
            printf("tCircleCnt += 1 = %d\r\n",tCircleCnt);  
        }else if(tDisAmuzithAngle < -180.0f){
            tCircleCnt -= 1;
            tDisAmuzithAngle += 180.0f;
            printf("tCircleCnt -= 1 = %d\r\n",tCircleCnt);
        }
        double tYawOutput = amuzithAngle - tCircleCnt * CIRCLE_ANGLE;   //����Ҫ�����ƫ����

        printf("tDisAmuzithAngle = %.6f,tYawOutput = %.6f\r\n",tDisAmuzithAngle,tYawOutput);
    }
}

#endif


#if 0

/*
******************************************************************************
*	�� �� ��: PositionInfo_calcuAzimuthDis
*	����˵��: λ����Ϣ��ȡ����ǲ�ֵ
*	��    ��: formAzimuth:�����Ƕ�  toAzimuth������Ƕ�
*	�� �� ֵ: -180 ~ +180 
******************************************************************************
*/
double PositionInfo_calcuAzimuthDis(double formAzimuth, double toAzimuth)
{
    double tDisAzimuth = toAzimuth - formAzimuth;
    if(tDisAzimuth > 180.0){
        tDisAzimuth -= 360.0;
    }else if(tDisAzimuth < -180.0){
        tDisAzimuth += 360.0;
    }

    return tDisAzimuth;
}

#define COMPARE_LENTH       10
#define AZIMUTH_DISTANCE    3.0
static double sAzimuthByRtkArry[COMPARE_LENTH];//= {0.01,0.04,0.8,1.5,2.5,4.6,5.7,6.7,8.9,11.2};
static double sAzimuthByImuArry[COMPARE_LENTH]; //= {0.01,0.04,0.8,1.5,2.5,4.6,5.7,6.7,8.9,16.2};

int main(void)
{
    uint32_t sCnt = 0;

    for(uint32_t i = 0; i < 1000; i++){

        sAzimuthByRtkArry[sCnt % COMPARE_LENTH] = (i % 360);
        sAzimuthByImuArry[sCnt % COMPARE_LENTH] = ((i*3) % 360);
        printf("sAzimuthByRtkArry,sAzimuthByRtkArry[%d] = %.6f,%.6f\r\n",i,sAzimuthByRtkArry[sCnt % COMPARE_LENTH],sAzimuthByImuArry[sCnt % COMPARE_LENTH]);

        if(++sCnt >= (COMPARE_LENTH*100))   sCnt = 0;

        double sSquareAzimuthDisByRtk = 0.0,sSquareAzimuthDisByImu = 0.0;       //һ���ڲ�������,ʹ�÷���
        for(uint32_t i = 0; i < (COMPARE_LENTH-1); i++){
            double tAzimuthDisByRtk = PositionInfo_calcuAzimuthDis(sAzimuthByRtkArry[(sCnt+i) % COMPARE_LENTH],sAzimuthByRtkArry[(sCnt+i+1) % COMPARE_LENTH]);
            double tAzimuthDisByImu = PositionInfo_calcuAzimuthDis(sAzimuthByImuArry[(sCnt+i) % COMPARE_LENTH],sAzimuthByImuArry[(sCnt+i+1) % COMPARE_LENTH]);
            printf("tAzimuthDisByRtk,tAzimuthDisByImu = %.6f,%.6f\r\n",tAzimuthDisByRtk,tAzimuthDisByImu);
            sSquareAzimuthDisByRtk += fabs(tAzimuthDisByRtk);
            sSquareAzimuthDisByImu += fabs(tAzimuthDisByImu);
        }
        double tVal = fabs(sSquareAzimuthDisByRtk - sSquareAzimuthDisByImu);
        printf("tVal = %.6f\r\n",tVal);

        if(tVal > pow(AZIMUTH_DISTANCE,2)){
            printf("Something wrong!!!\r\n");
        }else{ 
            printf("Something right!!!\r\n");
        }
    }
}


#endif


#if 0


#define NMEA_PI                     (3.141592653589793)                 /**< PI value */
#define NMEA_PI180                  (NMEA_PI / 180)                     /**< PI division by 180 */
#define NMEA_EARTHRADIUS_KM         (6378)                              /**< Earth's mean radius in km */
#define NMEA_EARTHRADIUS_M          (NMEA_EARTHRADIUS_KM * 1000)        /**< Earth's mean radius in m */
#define NMEA_EARTH_SEMIMAJORAXIS_M  (6378137.0)                         /**< Earth's semi-major axis in m according WGS84 */
#define NMEA_EARTH_SEMIMAJORAXIS_KM (NMEA_EARTH_SEMIMAJORAXIS_M / 1000) /**< Earth's semi-major axis in km according WGS 84 */
#define NMEA_EARTH_FLATTENING       (1 / 298.257223563)                 /**< Earth's flattening according WGS 84 */
#define NMEA_DOP_FACTOR             (5)                                 /**< Factor for translating DOP to meters */


typedef struct{
	double latitude;
	double longitude;
}POS_POINT;

typedef struct _nmeaPOS{
    double lat;         /**< Latitude */
    double lon;         /**< Longitude */
} nmeaPOS;

double nmea_degree2radian(double val)
{ return (val * NMEA_PI180); }


double nmea_distance(
        const nmeaPOS *from_pos,    /**< From position in radians */
        const nmeaPOS *to_pos       /**< To position in radians */
        )
{
    double dist = ((double)NMEA_EARTHRADIUS_M) * acos(
        sin(to_pos->lat) * sin(from_pos->lat) +
        cos(to_pos->lat) * cos(from_pos->lat) * cos(to_pos->lon - from_pos->lon)
        );
    return dist;
}

static POS_POINT ssPosPointArry[120] = {
{113.8534248709717,22.7483363218539},
{113.8534319318155,22.7483351336386},
{113.8534389926593,22.7483339454232},
{113.8534460535030,22.7483327572079},
{113.8534460535030,22.7483327572079},
{113.8534491327537,22.7483352955764},
{113.8534492790791,22.7483377813154},
{113.8534496491105,22.7483440673140},
{113.8534492790791,22.7483377813154},
{113.8534465179033,22.7483406447774},
{113.8534371867631,22.7483411863557},
{113.8534278556229,22.7483417279340},
{113.8534210428480,22.7483421233466},
{113.8534278556229,22.7483417279340},
{113.8534247242942,22.7483392064946},
{113.8534245198992,22.7483366068248},
{113.8534272289969,22.7483337602920},
{113.8534366412500,22.7483332587500},
{113.8534460535030,22.7483327572079},
{113.8534528683899,22.7483323940693},
{113.8534460535030,22.7483327572079},
{113.8534488156497,22.7483299075744},
{113.8534486694011,22.7483274221071},
{113.8534482995231,22.7483211361008},
{113.8534486694011,22.7483274221071},
{113.8534455893944,22.7483248700096},
{113.8534360957368,22.7483253311442},
{113.8534266020792,22.7483257922788},
{113.8534197852749,22.7483261233909},
{113.8534266020792,22.7483257922788},
{113.8534238922226,22.7483286250818},
{113.8534240967002,22.7483312250251},
{113.8534272289969,22.7483337602920},
{113.8534493086378,22.7483336750025},
{113.8534567993189,22.7483332443762},
{113.8534642900000,22.7483328137500},
{113.8534717806810,22.7483323831237},
{113.8534792713621,22.7483319524974},
{113.8534827639769,22.7483299864144},
{113.8534799815396,22.7483328292760},
{113.8534801111690,22.7483353479850},
{113.8534804348001,22.7483416361606},
{113.8534801111690,22.7483353479850},
{113.8534831711635,22.7483378976842},
{113.8534927812851,22.7483374199137},
{113.8535023914067,22.7483369421431},
{113.8535120015283,22.7483364643726},
{113.8535216116499,22.7483359866021},
{113.8535284280061,22.7483356477246},
{113.8535216116499,22.7483359866021},
{113.8535243747532,22.7483331473498},
{113.8535242245182,22.7483305888420},
{113.8535211451897,22.7483280427522},
{113.8535115498865,22.7483285286677},
{113.8535019545833,22.7483290145833},
{113.8534923592801,22.7483295004988},
{113.8534827639769,22.7483299864144},
{113.8534759479923,22.7483303315826},
{113.8534827639769,22.7483299864144},
{113.8534797041391,22.7483274394113},
{113.8534795745066,22.7483249206893},
{113.8534792508697,22.7483186325141},
{113.8534795745066,22.7483249206893},
{113.8534823567789,22.7483220751268},
{113.8534919372694,22.7483215810751},
{113.8535015177599,22.7483210870234},
{113.8535110982503,22.7483205929718},
{113.8535206787408,22.7483200989201},
{113.8535274943463,22.7483197474494},
{113.8535206787408,22.7483200989201},
{113.8535237579043,22.7483226423089},
{113.8535239081362,22.7483252008038},
{113.8535211451897,22.7483280427522},
{113.8535211451897,22.7483280427522},
{113.8535127704242,22.7483288247012},
{113.8535043956587,22.7483296066503},
{113.8534960208931,22.7483303885993},
{113.8534876461276,22.7483311705483},
{113.8534792713621,22.7483319524974},
{113.8534792713621,22.7483319524974},
{113.8534717806810,22.7483323831237},
{113.8534642900000,22.7483328137499},
{113.8534567993189,22.7483332443762},
{113.8534493086378,22.7483336750025},
{113.8534291039314,22.7483421445200},
{113.8534296004771,22.7483494667844},
{113.8534300970228,22.7483567890488},
{113.8534305935686,22.7483641113133},
{113.8534305907096,22.7483752643104},
{113.8534278392050,22.7483781131970},
{113.8534281701797,22.7483833826980},
{113.8534285649199,22.7483896674181},
{113.8534281701797,22.7483833826980},
{113.8534312596079,22.7483859140605},
{113.8534408782525,22.7483853801768},
{113.8534504968970,22.7483848462930},
{113.8534601155416,22.7483843124093},
{113.8534669294672,22.7483839342017},
{113.8534601155416,22.7483843124093},
{113.8534628637008,22.7483814570262},
{113.8534625320639,22.7483762668818},
{113.8534594392904,22.7483737290228},
{113.8534498230968,22.7483742407854},
{113.8534402069032,22.7483747525479},
{113.8534305907096,22.7483752643104},
{113.8534237757921,22.7483756269923},
{113.8534305907096,22.7483752643104},
{113.8534275008450,22.7483727262946},
{113.8534271698487,22.7483674568025},
{113.8534267750822,22.7483611720838},
{113.8534271698487,22.7483674568025},
{113.8534299217494,22.7483646145744},
{113.8534395355333,22.7483641249237},
{113.8534491493171,22.7483636352730},
{113.8534587631010,22.7483631456222},
{113.8534655789691,22.7483627984754},
{113.8534587631010,22.7483631456222},
{113.8534618562705,22.7483656901398},
{113.8534621878861,22.7483708802930},
{113.8534594392904,22.7483737290228},
};

int main(void)
{
#define DISTANCE_WITH_TIME	10                                      //10  ʱ���
#define DISTANCE_METER      0.1                                     //0.1m  �����
    static POS_POINT sPosPointArry[DISTANCE_WITH_TIME] = {0};
    static nmeaPOS uFromPos,uToPos;
    static double sDistance = 0.0;
    static int32_t sCnt = 0;
    static bool isBuffFill = false;


    for(uint32_t i = 0; i < 120; i++){
        sPosPointArry[sCnt % DISTANCE_WITH_TIME] = ssPosPointArry[i];    //�����

        if(isBuffFill){
            uFromPos.lat = nmea_degree2radian(sPosPointArry[sCnt % DISTANCE_WITH_TIME].latitude);
            uFromPos.lon = nmea_degree2radian(sPosPointArry[sCnt % DISTANCE_WITH_TIME].longitude);
            uToPos.lat = nmea_degree2radian(sPosPointArry[(sCnt+1) % DISTANCE_WITH_TIME].latitude);
            uToPos.lon = nmea_degree2radian(sPosPointArry[(sCnt+1) % DISTANCE_WITH_TIME].longitude);
            sDistance = nmea_distance(&uFromPos,&uToPos);                   //��ȡ5��ʱ�䳤�Ⱦ���

            printf("sPosPointArry[sCnt %% DISTANCE_WITH_TIME] = %.13f,%.13f;sPosPointArry[(sCnt+1) %% DISTANCE_WITH_TIME] = %.13f,%.13f\r\n",
                        sPosPointArry[sCnt % DISTANCE_WITH_TIME].latitude,sPosPointArry[sCnt % DISTANCE_WITH_TIME].longitude,
                        sPosPointArry[(sCnt+1) % DISTANCE_WITH_TIME].latitude,sPosPointArry[(sCnt+1) % DISTANCE_WITH_TIME].longitude
            );
            printf("uFromPos:uToPos = %.14f,%.14f,%.14f,%.14f\r\n",uFromPos.lat,uFromPos.lon,uToPos.lat,uToPos.lon);

            printf("sCnt = %d,sDistance = %.13f\r\n",sCnt,sDistance);
            if(sDistance < DISTANCE_METER){                                 //�������С��0.1m���������ٶ�
                printf("sDistance < DISTANCE_METER\r\n");
            }
        }

        if(++sCnt >= 1000)   sCnt = 0;                                  //����ֵ��ֵֹ���

        if(sCnt >= (DISTANCE_WITH_TIME - 1)){                           //10����ֻ���9����
            if(isBuffFill == false){
                isBuffFill = true;
            }
        }
    }
}

#endif

#if 0

#define AZIMUTH_DISTANCE    3.0                                             //����3���򱨴�    
#define COMPARE_LENTH       10                                              //�ж�һ�����Ƕȱ仯��ֵ  

/*
******************************************************************************
*	�� �� ��: PositionInfo_calcuAzimuthDis
*	����˵��: λ����Ϣ��ȡ����ǲ�ֵ
*	��    ��: formAzimuth:�����Ƕ�  toAzimuth������Ƕ�
*	�� �� ֵ: -180 ~ +180 
******************************************************************************
*/
double PositionInfo_calcuAzimuthDis(double formAzimuth, double toAzimuth)
{
    double tDisAzimuth = toAzimuth - formAzimuth;
    if(tDisAzimuth > 180.0){
        tDisAzimuth -= 360.0;
    }else if(tDisAzimuth < -180.0){
        tDisAzimuth += 360.0;
    }

    return tDisAzimuth;
}

int main(void)
{
    static double sAzimuthByRtkArry[COMPARE_LENTH] = {0};
    static double sAzimuthByImuArry[COMPARE_LENTH] = {0};
    static uint16_t sCnt = 0;

    for(uint32_t i = 0; i < 100; i++){

        sAzimuthByRtkArry[sCnt % COMPARE_LENTH] = (i % 360);
        sAzimuthByImuArry[sCnt % COMPARE_LENTH] = ((2*i) % 360);
    
        static double sAzimuthDisByRtk,sAzimuthDisByImu,sAzimuthDisByRtkImu;    //һ���ڼ���ж�
        sAzimuthDisByRtk = PositionInfo_calcuAzimuthDis(sAzimuthByRtkArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByRtkArry[sCnt % COMPARE_LENTH]);
        sAzimuthDisByImu = PositionInfo_calcuAzimuthDis(sAzimuthByImuArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByImuArry[sCnt % COMPARE_LENTH]);
        printf("sAzimuthByRtkArry[(sCnt+1) %% COMPARE_LENTH] = %.6f;sAzimuthByRtkArry[(sCnt) %% COMPARE_LENTH] = %.6f\r\n",sAzimuthByRtkArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByRtkArry[(sCnt) % COMPARE_LENTH]);
        printf("sAzimuthByImuArry[(sCnt+1) %% COMPARE_LENTH] = %.6f;sAzimuthByImuArry[(sCnt) %% COMPARE_LENTH] = %.6f\r\n",sAzimuthByImuArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByImuArry[(sCnt) % COMPARE_LENTH]);

        sAzimuthDisByRtkImu = fabs(sAzimuthDisByRtk - sAzimuthDisByImu);
        printf("i = %d,sAzimuthDisByRtk:sAzimuthDisByImu:sAzimuthDisByRtkImu = %.6f,%.6f,%.6f\r\n",i,sAzimuthDisByRtk,sAzimuthDisByImu,sAzimuthDisByRtkImu);
        if(sAzimuthDisByRtkImu > AZIMUTH_DISTANCE){
            printf("Something is wrong !!!\r\n");
        }

        if(++sCnt >= (COMPARE_LENTH*1))   sCnt = 0;                           //����ֵ��ֵֹ���,ʹ��10�ı���
    }

}

#endif


#if 0

typedef struct{
    uint8_t     devAddr;
    uint8_t     cmdNumb;
    uint16_t    regAddr;
    uint16_t    regCount;
}MBH_READ_MULTI_REQ_STRUCT;

uint16_t htons(uint16_t n)
{
    return ((n & 0xff) << 8) | ((n & 0xff00) >> 8);
}

int main(void)
{
#define LENGTH sizeof(MBH_READ_MULTI_REQ_STRUCT)     
    
    MBH_READ_MULTI_REQ_STRUCT uInfo,*pInfo;
    uint8_t tBuff[LENGTH+2] = {0};

    pInfo = (MBH_READ_MULTI_REQ_STRUCT*)tBuff;

    uInfo.devAddr = 0x01;
    uInfo.cmdNumb = 0x02;
    uInfo.regAddr = 0x0103;
    uInfo.regCount = 0x0204;

    *pInfo = uInfo;
    pInfo->regAddr = htons(pInfo->regAddr);
    pInfo->regCount = htons(pInfo->regCount);

    uint16_t tCrcVal = 0xF502;                 //����У��
    tBuff[LENGTH] = (uint8_t)(tCrcVal >> 8);                            //��������
    tBuff[LENGTH+1] = (uint8_t)(tCrcVal & 0x00FF);

    for(int i = 0; i < (sizeof(MBH_READ_MULTI_REQ_STRUCT)+2); i++){
        printf("tBuff[%d] = 0x%02x\r\n",i,tBuff[i]);
    }
}

#endif

#if 0

typedef void (*voidFuncPtr)     (void);

typedef struct{
    uint8_t     devAddr;
    uint8_t     cmdNumb;
    uint8_t    regAddr;
    uint8_t    regCount;
}MBH_READ_MULTI_REQ_STRUCT;

typedef struct{
    voidFuncPtr     MbHostCbPtr;
    void*           MbHostTxDataPtr;
}MBH_MANAGE_STRUCT;

MBH_MANAGE_STRUCT sMbHostInfo;

uint8_t txBuf[20] = {"Hello word!!!\r\n"};
uint8_t txxBuf[30] = {"hhhhhhhhhHello word!!!\r\n"};

MBH_READ_MULTI_REQ_STRUCT ttx = {
    .devAddr = 'c',
    .cmdNumb = 'd',
    .regAddr = 'f',
    .regCount = 'g',
};

int main(void)
{
    sMbHostInfo.MbHostTxDataPtr = txBuf;
    printf("sMbHostInfo.MbHostTxDataPtr= %s",sMbHostInfo.MbHostTxDataPtr);
    sMbHostInfo.MbHostTxDataPtr = txxBuf;
    printf("sMbHostInfo.MbHostTxDataPtr= %s",sMbHostInfo.MbHostTxDataPtr);
    sMbHostInfo.MbHostTxDataPtr = &ttx;
    printf("sMbHostInfo.MbHostTxDataPtr= %s",sMbHostInfo.MbHostTxDataPtr);

}
#endif


#if 1

uint32_t reverseCnt = 0;
uint32_t validArry[10] = {0};

void setBit(uint32_t tNum)
{
    uint32_t tArryNum = tNum / 32;
    uint32_t tValNum = tNum % 32;
    validArry[tArryNum] |=  1 << tValNum;
}

void calcuBit(void)
{
    bool oldFlag = false;
    for(uint8_t i = 0; i < 10; i++){
        for(uint8_t j = 0; j < 32; j++){
            bool tFlag = validArry[i] & (0x00000001 <<j);
            if(tFlag != oldFlag){
                oldFlag = tFlag;
                reverseCnt += 1;
            }
        }
    }
}

int main(void)
{
    setBit(3208%320);

    calcuBit();

    printf("reverseCnt is %d\r\n", reverseCnt);
    for(uint32_t i = 0; i < 10; i++){
        printf("validArry[%d] = %08x\r\n",i,validArry[i]);
    }
}

#endif