#include<stdio.h>
#include<stdlib.h>
#include<string.h>


char *str_replaceChar(char *pBuf , char _srcByte, char _desByte)
{
    while(pBuf){
        if((*pBuf) == _srcByte){
            (*pBuf) = _desByte;
        }
        if((*pBuf) == '\0')
            break;
        pBuf++;
    }

    return pBuf;
}



int main(void)
{
    int a,b,c,d;
    char aa[3],bb[3],cc[3],dd[3];
    char txt[20] = {"| 0 | 1 | 4 | 3 |"};
    char txtA[30];
    char *rTxt;

    sscanf(txt,"| %d | %d | %d | %d |",&a,&b,&c,&d);
    sscanf(txt,"| %s | %s | %s | %s |",aa,bb,cc,dd);

    printf("txt = %s\r\n",txt);

    printf("a = %d,b = %d,c = %d,d = %d\r\n",a,b,c,d);

    printf("aa = %s,bb = %s,cc = %s,dd = %s\r\n",aa,bb,cc,dd);

    sprintf(txtA,"aa = %s,bb = %s,cc = %s,dd = %s\r\n",aa,bb,cc,dd);

    printf("txtA = %s\r\n",txtA);

    rTxt = str_replaceChar(txt,'|',',');

    printf("txt = %s\r\n",txt);

    printf("rTxt = %s\r\n",rTxt);

    printf("rTxt[0] = %d\r\n",rTxt[0]);
}