#include <stdint.h>
#include <stdio.h>
#include <math.h>

#define NMEA_PI                     (3.141592653589793)                 /**< PI value */
#define NMEA_PI180                  (NMEA_PI / 180)                     /**< PI division by 180 */

int main(void)
{
#define ARRT_LEN   180
    double angleArry[ARRT_LEN] = {0,45,90,135,180,225,270,315};
	double midArry[ARRT_LEN]={0};
    double toArry[ARRT_LEN]={0};
    double Circlelen = 100;
    double toCirclelen = 0.0;
    int32_t i =0;

    for(i = 0; i < ARRT_LEN; i++){
        angleArry[i] = (i*2.0);
        printf("angleArry[%d] = %f\r\n",i,angleArry[i]);
    }

    for(i = 0; i < ARRT_LEN; i++){
		if(angleArry[i] > 180) 
			midArry[i] = 360 - angleArry[i];
		else
			midArry[i] = angleArry[i];
        toArry[i] = midArry[i] * -1.0/9.0 + 10.0;
        toCirclelen = Circlelen * cos(toArry[i]*NMEA_PI180);
        printf("midArry[%d] = %f, toArry[%d] = %f,toCirclelen = %0.5f\r\n",i,midArry[i],i,toArry[i],toCirclelen);
    }

}
