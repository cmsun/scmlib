/**
******************************************************************************
* @��  ���� AppModuleTest.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 5-Jun-2018
* @��  ���� ģ�����������
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

//ͷ�ļ�����
#include "includes.h"



/*
******************************************************************************
*	�� �� ��: main
*	����˵��: ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#if 1

#define SECTOR_POINT_TOTAL   	7
#define CRUISE_POINT_TOTAL	    150
#define GARAGE_LINE_TOTAL		2
#define INGARAGE_POINT_TOTAL	8	
#define OUTGARAGE_POINT_TOTAL	8	

#define RETURN_ROUTER_TOTAL     2
#define RETURN_POINT_TOTAL	    20
	
static SEGMENT_AMOUNT_UNION wAmount = {
	.Struct.sectorTotal = SECTOR_POINT_TOTAL,
	.Struct.cruiseTotal = CRUISE_POINT_TOTAL,
	.Struct.garageTotal = GARAGE_LINE_TOTAL,
	.Struct.LineInfo[0].inGarageTotal = INGARAGE_POINT_TOTAL,
	.Struct.LineInfo[0].outGarageTotal = OUTGARAGE_POINT_TOTAL,
	.Struct.LineInfo[0].returnListTotal = RETURN_ROUTER_TOTAL,
	.Struct.LineInfo[0].returnTotal =  { RETURN_POINT_TOTAL,RETURN_POINT_TOTAL },
	.Struct.LineInfo[1].inGarageTotal = INGARAGE_POINT_TOTAL,
	.Struct.LineInfo[1].outGarageTotal = OUTGARAGE_POINT_TOTAL,
	.Struct.LineInfo[1].returnListTotal = RETURN_ROUTER_TOTAL,
	.Struct.LineInfo[1].returnTotal =  { RETURN_POINT_TOTAL,RETURN_POINT_TOTAL },
	.Struct.isVaild = 1,
};

#if 1	
static const SECTOR_AREA_UNION wSectorAreaArry[SECTOR_POINT_TOTAL] = {	
	{
		.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 0,
		.Struct.Point[0].longitude = 1.0,.Struct.Point[0].latitude = 2.0,
		.Struct.Point[1].longitude = 1.1,.Struct.Point[1].latitude = 2.1,
		.Struct.Point[2].longitude = 1.2,.Struct.Point[2].latitude = 2.2,
		.Struct.Point[3].longitude = 1.3,.Struct.Point[3].latitude = 2.3,
	},{
		.Struct.serNum = 1, .Struct.secNum = 1, .Struct.pointType = 0,
		.Struct.Point[0].longitude = 3.0,.Struct.Point[0].latitude = 4.0,
		.Struct.Point[1].longitude = 3.1,.Struct.Point[1].latitude = 4.1,
		.Struct.Point[2].longitude = 3.2,.Struct.Point[2].latitude = 4.2,
		.Struct.Point[3].longitude = 3.3,.Struct.Point[3].latitude = 4.3,
	},
};

static const SEGMENT_CONTENT_UNION wCruiseSegmentArry[CRUISE_POINT_TOTAL]={
	{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8535396317, .Struct.latitude = 22.74840955333},
	{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8535387700, .Struct.latitude = 22.74840075000},
	{.Struct.serNum = 2, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534931417, .Struct.latitude = 22.74840403667},

	{.Struct.serNum = 3, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534950483, .Struct.latitude = 22.74842121500},		
	{.Struct.serNum = 4, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8535409567, .Struct.latitude = 22.74841741167},
	{.Struct.serNum = 5, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534900617, .Struct.latitude = 22.74841592167},

	{.Struct.serNum = 6, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534660083, .Struct.latitude = 22.74841751833},
	{.Struct.serNum = 7, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534373217, .Struct.latitude = 22.74842113167},
	{.Struct.serNum = 8, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534396283, .Struct.latitude = 22.74841013833},

	{.Struct.serNum = 9, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534651033, .Struct.latitude = 22.74840829333},
	{.Struct.serNum = 6, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534660083, .Struct.latitude = 22.74841751833},
	{.Struct.serNum = 5, .Struct.secNum = 0, .Struct.pointType = 3, .Struct.velocity = 11, .Struct.longitude = 113.8534900617, .Struct.latitude = 22.74841592167},
};
	
static const SEGMENT_CONTENT_UNION wInGarageSegmentArry[GARAGE_LINE_TOTAL][INGARAGE_POINT_TOTAL]={
	{
		{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 1, .Struct.velocity = 10, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
		{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 1, .Struct.velocity = 10, .Struct.longitude = 113.8535524117, .Struct.latitude = 22.74840886833},	
	},{
		{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 1, .Struct.velocity = 10, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
		{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 1, .Struct.velocity = 10, .Struct.longitude = 113.8535524117, .Struct.latitude = 22.74840886833},	
	}
};

static const SEGMENT_CONTENT_UNION wOutGarageSegmentArry[GARAGE_LINE_TOTAL][OUTGARAGE_POINT_TOTAL]={
	{
		{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 2, .Struct.velocity = 10, .Struct.longitude = 113.8535524117, .Struct.latitude = 22.74840886833},
		{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 2, .Struct.velocity = 10, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
		},{	
		{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 2, .Struct.velocity = 10, .Struct.longitude = 113.8535524117, .Struct.latitude = 22.74840886833},
		{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 2, .Struct.velocity = 10, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
	}
};


static const SEGMENT_CONTENT_UNION wReturnsSegmentArry[GARAGE_LINE_TOTAL][RETURN_ROUTER_TOTAL][RETURN_POINT_TOTAL]={
	{
		{
			{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8534900617, .Struct.latitude = 22.74841592163},
			{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 2, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 3, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 4, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
		},{
			{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8534900616, .Struct.latitude = 32.74841592164},
			{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 2, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 3, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 4, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
		}
	},{
		{
			{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8534900617, .Struct.latitude = 22.74841592163},
			{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 2, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 3, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
			{.Struct.serNum = 4, .Struct.secNum = 0, .Struct.pointType = 4, .Struct.velocity = 12, .Struct.longitude = 113.8535334517, .Struct.latitude = 22.74840955333},
		},{
			{.Struct.serNum = 0, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8534900616, .Struct.latitude = 32.74841592164},
			{.Struct.serNum = 1, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 2, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 3, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
			{.Struct.serNum = 4, .Struct.secNum = 0, .Struct.pointType = 5, .Struct.velocity = 12, .Struct.longitude = 114.8535334516, .Struct.latitude = 32.74840955334},
		},
	}
};
#endif

static	SECTOR_AREA_UNION rSectorAreaArry[SECTOR_POINT_TOTAL];
static	SEGMENT_CONTENT_UNION rCruiseSegmentArry[CRUISE_POINT_TOTAL];
	
static	SEGMENT_CONTENT_UNION rInGarageSegmentArry[GARAGE_LINE_TOTAL][INGARAGE_POINT_TOTAL];
static	SEGMENT_CONTENT_UNION rOutGarageSegmentArry[GARAGE_LINE_TOTAL][OUTGARAGE_POINT_TOTAL];
static	SEGMENT_CONTENT_UNION rReturnsSegmentArry[GARAGE_LINE_TOTAL][RETURN_ROUTER_TOTAL][RETURN_POINT_TOTAL];
	
static	SEGMENT_AMOUNT_UNION  rAmount;

static	GETLIST_STATE_ENUM rSta = GETLIST_FAILED;
static  uint32_t sErrCnt = 0;

int main(void)
{
    GPIOx_init();
    Delay_init();

    M95m02dr_init();
	
	CoordinateListStruct.init();

	//CoordinateListStruct.Router.AmountProcess.setAmount(wAmount);

#if 0
	for(int i = 0; i < SECTOR_POINT_TOTAL; i++){
		CoordinateListStruct.Router.SectorProcess.setContent(i,wSectorAreaArry[i]);
		wAmount.Struct.sectorTotal = (i + 1);
	}	
	
	for(int i = 0; i < CRUISE_POINT_TOTAL; i++){
		CoordinateListStruct.Router.CruiseProcess.setContent(i,wCruiseSegmentArry[i]);
		wAmount.Struct.cruiseTotal = (i + 1);
	}

	for(int m = 0; m < GARAGE_LINE_TOTAL; m++){

		for(int i = 0; i < INGARAGE_POINT_TOTAL; i++){
			CoordinateListStruct.Router.GarageStruct.InGarageProcess.setContent(m,i,wInGarageSegmentArry[m][i]);
			wAmount.Struct.LineInfo[m].inGarageTotal = (i + 1);
		}

		for(int i = 0; i < OUTGARAGE_POINT_TOTAL; i++){
			CoordinateListStruct.Router.GarageStruct.OutGarageProcess.setContent(m,i,wOutGarageSegmentArry[m][i]);
			wAmount.Struct.LineInfo[m].outGarageTotal = (i + 1);
		}
	
		for(int j = 0; j < RETURN_ROUTER_TOTAL ; j++){
			for(int i = 0; i < RETURN_POINT_TOTAL; i++){
				CoordinateListStruct.Router.GarageStruct.ReturnsProcess.setContent(m,j,i,wReturnsSegmentArry[m][j][i]);
				wAmount.Struct.LineInfo[m].returnTotal[j] = (i + 1);
			}
			wAmount.Struct.LineInfo[m].returnListTotal = (j + 1);
		}
	}
    
    CoordinateListStruct.Router.AmountProcess.setAmount(wAmount);

#endif		
	
	rSta = CoordinateListStruct.Router.AmountProcess.getAmount(&rAmount);
	if(rSta == GETLIST_FAILED) sErrCnt += 1;
	
#if 1	
	for(int i = 0; i < rAmount.Struct.sectorTotal; i++){
		rSta = CoordinateListStruct.Router.SectorProcess.getContent(i,&rSectorAreaArry[i]);
		if(rSta == GETLIST_FAILED) sErrCnt += 1;
	}
	
	for(int i = 0; i < rAmount.Struct.cruiseTotal ; i++){
		rSta = CoordinateListStruct.Router.CruiseProcess.getContent(i,&rCruiseSegmentArry[i]);
		if(rSta == GETLIST_FAILED) sErrCnt += 1;
	}
	
	for(int m = 0; m < rAmount.Struct.garageTotal; m++){
		
		for(int i = 0; i < rAmount.Struct.LineInfo[m].inGarageTotal ; i++){
			rSta = CoordinateListStruct.Router.GarageStruct.InGarageProcess.getContent(m,i,&rInGarageSegmentArry[m][i]);
			if(rSta == GETLIST_FAILED) sErrCnt += 1;
		}

		for(int i = 0; i < rAmount.Struct.LineInfo[m].outGarageTotal ; i++){
			rSta = CoordinateListStruct.Router.GarageStruct.OutGarageProcess.getContent(m,i,&rOutGarageSegmentArry[m][i]);
			if(rSta == GETLIST_FAILED) sErrCnt += 1;
		}

		for(int j = 0; j < rAmount.Struct.LineInfo[m].returnListTotal; j++){
			for(int i = 0; i < rAmount.Struct.LineInfo[m].returnTotal[j] ; i++){
				rSta = CoordinateListStruct.Router.GarageStruct.ReturnsProcess.getContent(m,j,i,&rReturnsSegmentArry[m][j][i]);
				if(rSta == GETLIST_FAILED) sErrCnt += 1;
			}
		}
	}
#endif
		
	while(1){
        Delay_mSec(1000);
    }

}
#endif

#if 0
int main(void)
{
    LOG_CONTENT_UNION tLogContentUnion,ttLogContentUnion;
    
    tLogContentUnion.ContentStruct.dateArry[1] = 0;
    
    GPIOx_init();
    Delay_init();

    M95m02dr_init();
    
    TemperatureInfo_init();
    ParamInfoStruct.robotIdMagStruct.init();
    ParamInfoStruct.robotMileageStruct.init();
    LogSysInfoStruct.init();
    LogSysInfoStruct.ContentStruct.record(tLogContentUnion);
    LogSysInfoStruct.ContentStruct.getSerial(&ttLogContentUnion,0);

    while(1)
    {
        tLogContentUnion.ContentStruct.dateArry[1] += 1;
        LogSysInfoStruct.ContentStruct.record(tLogContentUnion);
        LogSysInfoStruct.ContentStruct.getRecent(&ttLogContentUnion,0);
        TemperatureInfo_loopReadSmooth();
        Delay_mSec(1000);
    }

}
#endif

#if 0
int main(void)
{
    GPIOx_init();
    Delay_init();
    
    BatteryInfo_init();
    
    while(1){
        BatteryInfo_loopReadSmooth();
        Delay_mSec(100);
    }
    
}
#endif


#if 0
/*
******************************************************************************
*	�� �� ��: fileConvert
*	����˵��: fatfs �ļ�ϵͳ����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void fileConvert(void)
{
	FIL file;
	FATFS fs;
	FRESULT res;
	
	uint8_t name[16] = {0};
	uint8_t logcsv[256]={0};
	uint32_t reindex = 0x00;	

	res = f_mount(&fs, "", 0);	
	if(res != FR_OK){
		PRINT_DBG("f_mount fs erro = %d\r\n",res);
	}
	
	/* �ļ��� ID_DATA_TIME */
	sprintf((char*)name,"%s.txt","file");

	/* ����һ���µ��ļ� */
	res = f_open(&file,(const TCHAR *)name,FA_READ | FA_WRITE | FA_CREATE_ALWAYS);
	if(res != FR_OK){		
		PRINT_DBG("f_open erro = %d\r\n",res);
	}
	
	/* �������� */
	sprintf((char*)logcsv,"I am jackey jiang \r\n");
	
	/* д�������ͣ���λ�� */
	res = f_write(&file,logcsv,strlen((char*)logcsv), &reindex);
	if(res != FR_OK){		
		PRINT_DBG("f_write erro = %d\r\n",res);
	}
	
	/* �رո��ļ����Ա��´�ʹ�� */
	res = f_close(&file);
	if(res != FR_OK){
		PRINT_DBG("f_close erro = %d\r\n",res);
	}
	
	/* �� SD ��ж�� */
	res = f_mount(NULL, "", 0);
	if(res != FR_OK){
		PRINT_DBG("f_mount null erro = %d\r\n",res);
	}

}

int main(void)
{
    GPIOx_init();
    
    Delay_init();
    Led_init();
    
    fileConvert();
    
    while(1)
    {
        Led_setBlink(LED_2,BLINK_ONCE);
        Delay_mSec(100);
    }
}
#endif


#if 0
/*
******************************************************************************
*	�� �� ��: convertFile
*	����˵��: ת���ļ�
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#define ZOOM (0.0001)

void convertFile(void)
{
#define FUNC(SRC_FILE,DES_FILE) do{\
	res = f_open(&mdFile,SRC_FILE,FA_READ | FA_OPEN_ALWAYS);\
	if(res != FR_OK){\
		PRINT_DBG("%s,f_open erro = %d\r\n",SRC_FILE,res);\
	}\
	res = f_open(&csvFile,DES_FILE,FA_READ | FA_WRITE | FA_CREATE_ALWAYS);\
	if(res != FR_OK){\
		PRINT_DBG("%s, f_open erro = %d\r\n",DES_FILE,res);\
	}\
    while(!f_eof(&mdFile)){\
        memset(mdBuff,0,sizeof(mdBuff));\
		f_gets(mdBuff, sizeof(mdBuff), &mdFile);\
		tScanfValue = sscanf(mdBuff, "| %u | %hu | %u | %lf | %lf | %hu |",&uSegment.serNum,&uSegment.pointType,&uSegment.secNum,\
			&uSegment.longitude,&uSegment.latitude,&uSegment.velocity);\
        if(tScanfValue <= 0)\
            continue;\
		sprintf(csvBuff,"%u,%hu,%u,%lf,%lf,%hu\r\n",uSegment.serNum,uSegment.pointType,uSegment.secNum,\
			uSegment.longitude * ZOOM,uSegment.latitude * ZOOM,uSegment.velocity);\
		res = f_write(&csvFile,csvBuff,strlen((char*)csvBuff), &reindex);\
		if(res != FR_OK){\
			PRINT_DBG("%s f_write erro = %d\r\n",DES_FILE,res);\
		}\
	}\
	res = f_close(&mdFile);\
	if(res != FR_OK){\
		PRINT_DBG("%s f_close erro = %d\r\n",SRC_FILE,res);\
	}\
	res = f_close(&csvFile);\
	if(res != FR_OK){\
		PRINT_DBG("%s f_close erro = %d\r\n",DES_FILE,res);\
	}\
}while(0);

	FIL mdFile,csvFile;
	FATFS fs;
	FRESULT res;
	
	static char mdBuff[256]={0};
	static char csvBuff[256]={0};
	uint32_t reindex = 0x00;
	int32_t tScanfValue = 0;

	SEGMENT_CONTENT_STRUCT uSegment;
	SECTOR_AREA_STRUCT uSector;

	res = f_mount(&fs, "", 0);	
	if(res != FR_OK){
		PRINT_DBG("f_mount fs erro = %d\r\n",res);
	}
	
	/* ��һ���µ��ļ� */
	res = f_open(&mdFile,"ConvSrc/Sector.md",FA_READ | FA_OPEN_ALWAYS);
	if(res != FR_OK){		
		PRINT_DBG("ConvSrc/Sector.md f_open erro = %d\r\n",res);
	}

	/* ����һ���µ��ļ� */
	res = f_open(&csvFile,"ConvDes/Sector.csv",FA_READ | FA_WRITE | FA_CREATE_ALWAYS);
	if(res != FR_OK){		
		PRINT_DBG("ConvDes/Sector.csv f_open erro = %d\r\n",res);
	}

	/* ����|�����ݻ�Ϊ��׼�ġ�,���ļ� */
    while(!f_eof(&mdFile)){
        memset(mdBuff,0,sizeof(mdBuff));
		f_gets(mdBuff, sizeof(mdBuff), &mdFile);

		tScanfValue = sscanf(mdBuff,"| %u | %hu | %u | %lf | %lf | %lf | %lf | %lf | %lf | %lf |  %lf |",
					&uSector.serNum,&uSector.pointType,&uSector.secNum,
					&uSector.Point[0].longitude,&uSector.Point[0].latitude,
					&uSector.Point[1].longitude,&uSector.Point[1].latitude,
					&uSector.Point[2].longitude,&uSector.Point[2].latitude,
					&uSector.Point[3].longitude,&uSector.Point[3].latitude);
        if(tScanfValue <= 0) 
            continue;
		
		sprintf(csvBuff,"%u,%hu,%u,%lf,%lf,%lf,%lf,%lf,%lf,%lf,%lf \r\n",
					uSector.serNum,uSector.pointType,uSector.secNum,
					uSector.Point[0].longitude * ZOOM,uSector.Point[0].latitude * ZOOM,
					uSector.Point[1].longitude * ZOOM,uSector.Point[1].latitude * ZOOM,
					uSector.Point[2].longitude * ZOOM,uSector.Point[2].latitude * ZOOM,
					uSector.Point[3].longitude * ZOOM,uSector.Point[3].latitude * ZOOM);
		
		res = f_write(&csvFile,csvBuff,strlen((char*)csvBuff), &reindex);
		if(res != FR_OK){	
			PRINT_DBG("f_write erro = %d\r\n",res);
		}
	}
	
	/* �رո��ļ����Ա��´�ʹ�� */
	res = f_close(&mdFile);
	if(res != FR_OK){
		PRINT_DBG("ConvSer/Sector.csv f_close erro = %d\r\n",res);
	}

	res = f_close(&csvFile);
	if(res != FR_OK){
		PRINT_DBG("ConvDes/Sector.csv f_close erro = %d\r\n",res);
	}
	
	FUNC("ConvSrc/InGara.md","ConvDes/InGara.csv");
	FUNC("ConvSrc/OutGara.md","ConvDes/OutGara.csv");
	FUNC("ConvSrc/Cruise.md","ConvDes/Cruise.csv");
	FUNC("ConvSrc/Return.md","ConvDes/Return.csv");

	/* �� SD ��ж�� */
	res = f_mount(NULL, "", 0);
	if(res != FR_OK){
		PRINT_DBG("f_mount null erro = %d\r\n",res);
	}
}


int main(void)
{
    GPIOx_init();
    
    Delay_init();
    Led_init();
    
    convertFile();
    
    while(1)
    {
        Led_setBlink(LED_2,BLINK_ONCE);
        Delay_mSec(100);
    }
}

#endif
