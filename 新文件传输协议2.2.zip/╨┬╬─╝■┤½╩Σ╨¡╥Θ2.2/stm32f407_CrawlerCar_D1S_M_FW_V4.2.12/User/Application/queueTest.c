#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#if 1

#include "mod_queue.h"

int main() {
	
    Queue MyQueueTest;
    QueuePtr  MyQueueTestPrt = &MyQueueTest;

    uint8_t buff[20] = {0};
    uint8_t wDigitalArry[5] = {1,2,3,4,5};
    uint8_t rDigitalArry[5] = {5,4,3,2,1};

    uint32_t tWrite = 0,tRead = 0;

    //MyQueueTest = Queue_create(6);
    MyQueueTest.payload = NULL;
    
    Queue_init(MyQueueTestPrt, 20, buff);

    tWrite = Queue_write(MyQueueTestPrt,wDigitalArry,5);

    tRead = Queue_read(MyQueueTestPrt,rDigitalArry,5);

    return 0;
}


#elif 0

#include "mod_queue.h"

int main() {
	
    QueuePtr MyQueueTest;

    uint8_t wDigitalArry[5] = {1,2,3,4,5};
    uint8_t rDigitalArry[5] = {5,4,3,2,1};

    uint32_t tWrite = 0,tRead = 0;

    MyQueueTest = Queue_create(6);

    tWrite = Queue_write(MyQueueTest,wDigitalArry,5);

    tRead = Queue_read(MyQueueTest,rDigitalArry,5);

    return 0;
}

#elif 0

#include "mod_filter.h"

int main() {
	
    FilterPtr MyFilterTest;

    float    wfDigitalArry[8];
	uint8_t  wDigitalArry[8] = {1,2,3,4,5,6,7,8};
	elem lastValue = 0;

	for(int32_t i = 0; i < 8; i++){
		*(wfDigitalArry + i) = (float)wDigitalArry[i];
	}
	
    MyFilterTest = Filter_create(5);

    lastValue = Filter_insert(MyFilterTest,wfDigitalArry,5);

    return 0;
}

#endif