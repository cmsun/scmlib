/**
******************************************************************************
* @��  ���� AppMotionTest.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� ����MPU6500��̬����������
******************************************************************************
* @�޸ļ�¼��
*   2018/09/10����ʼ�汾
*    
*
******************************************************************************
**/

//ͷ�ļ�����
#include "includes.h"



/*
******************************************************************************
*	�� �� ��: main
*	����˵��: ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#if 0

int main(void)
{
#define NUM_POINTS 3

    const char *buff[] = {
        "$GPRMC,213925.000,A,4221.1129,N,07102.9146,W,0.00,,010207,,,A*68\r\n",
        "$GPRMC,213917.199,A,4221.0510,N,07102.9549,W,0.23,175.43,010207,,,A*77\r\n",
        "$GPRMC,213916.199,A,4221.0377,N,07102.9778,W,0.00,,010207,,,A*6A\r\n",
        "$GPRMC,111609.14,A,5001.27,N,3613.06,E,11.2,0.0,261206,0.0,E*50\r\n"
    };



    nmeaPOS pos[NUM_POINTS], pos_moved[NUM_POINTS][2];
    double dist[NUM_POINTS][2];
    double azimuth[NUM_POINTS][2], azimuth_moved[NUM_POINTS];
    int result[2];
    int it = 0;

    GPIOx_init();
    RTCx_init();
    USARTx_init();

    nmeaPARSER parser;
    nmea_parser_init(&parser);

    for(it = 0; it < NUM_POINTS; ++it)
    {
        int result;
        nmeaINFO info;
        nmea_zero_INFO(&info);
        result = nmea_parse(&parser, buff[it], (int)strlen(buff[it]), &info);
        nmea_info2pos(&info, &pos[it]);
    }

    nmea_parser_destroy(&parser);

    for(it = 0; it < NUM_POINTS; ++it)
    {
        dist[it][0] = nmea_distance(&pos[0], &pos[it]);
        dist[it][1] = nmea_distance_ellipsoid(
            &pos[0], &pos[it], &azimuth[it][0], &azimuth[it][1]
            );
    }

    for(it = 0; it < NUM_POINTS; ++it)
    {
        result[0] = nmea_move_horz(&pos[0], &pos_moved[it][0], azimuth[it][0], dist[it][0]);
        result[1] = nmea_move_horz_ellipsoid(
            &pos[0], &pos_moved[it][1], azimuth[it][0], dist[it][0], &azimuth_moved[it]
            );

    }

    /* Output of results */
    PRINT_DBG("Coordinate points:\r\n");
    for(it = 0; it < NUM_POINTS; ++it)
    {
        PRINT_DBG(
            "P%d in radians: lat:%9.6lf lon:%9.6lf  \tin degree: lat:%+010.6lf?lon:%+011.6lf癨n",
            it, pos[it].lat, pos[it].lon, nmea_radian2degree(pos[it].lat), nmea_radian2degree(pos[it].lon)
            );
    }

    PRINT_DBG("\r\nCalculation results:\r\n");
    for(it = 0; it < NUM_POINTS; ++it)
    {
        PRINT_DBG("\n");
        PRINT_DBG("Distance P0 to P%d\ton spheroid:  %14.3lf m\n", it, dist[it][0]);
        PRINT_DBG("Distance P0 to P%d\ton ellipsoid: %14.3lf m\n", it, dist[it][1]);
        PRINT_DBG("Azimuth  P0 to P%d\tat start: %8.3lf\tat end: %8.3lf\n", it, nmea_radian2degree(azimuth[it][0]), nmea_radian2degree(azimuth[it][1]));
        PRINT_DBG("Move     P0 to P%d\t         \tAzimuth at end: %8.3lf\n", it, nmea_radian2degree(azimuth_moved[it]));
        PRINT_DBG("Move     P0 to P%d\ton spheroid:  %3s lat:%+010.6lf?lon:%+011.6lf\n", it, result[0] == 1 ? "OK" : "nOK", nmea_radian2degree(pos_moved[it][0].lat), nmea_radian2degree(pos_moved[it][0].lon));
        PRINT_DBG("Move     P0 to P%d\ton ellipsoid: %3s lat:%+010.6lf?lon:%+011.6lf\n", it, result[0] == 1 ? "OK" : "nOK", nmea_radian2degree(pos_moved[it][1].lat), nmea_radian2degree(pos_moved[it][1].lon));
        PRINT_DBG("Move     P0 to P%d\toriginal:         lat:%+010.6lf?lon:%+011.6lf\n", it, nmea_radian2degree(pos[it].lat), nmea_radian2degree(pos[it].lon));
    }

    return 0;
}
#endif

#if 0
int main(void)
{
    uint32_t rVal = 0;
	
    SECTOR_AREA_UNION uRefContent = {
        .Struct.Point[0].longitude = 113.9347409233,
        .Struct.Point[0].latitude = 22.55160566167,
        .Struct.Point[1].longitude = 113.9347864700,
        .Struct.Point[1].latitude = 22.55168197500,
        .Struct.Point[2].longitude = 113.9347522317,
        .Struct.Point[2].latitude = 22.55169976833,
        .Struct.Point[3].longitude = 113.9347069167,
        .Struct.Point[3].latitude = 22.55162339667,
    };
	
    SECTOR_AREA_UNION uTgtContent = {
        .Struct.Point[0].longitude = 113.9347420017,
        .Struct.Point[0].latitude = 22.55161463627,
        .Struct.Point[1].longitude = 113.9347788514, //113.9347940886
        .Struct.Point[1].latitude = 22.55167636513, //22.55168758487
        .Struct.Point[2].longitude = 113.9347511533,
        .Struct.Point[2].latitude = 22.55169079372,
        .Struct.Point[3].longitude = 113.9347145353, //113.9348584048
        .Struct.Point[3].latitude = 22.55162900655, //22.55173494342
    };

    rVal = CoordinateListStruct.areaReduce(uRefContent,&uTgtContent);

    PRINT_DBG("rVal = %d\r\n", rVal);

}
#endif

#if 0
int main(void)
{
    double tFromAzimuth = 0.0f,tToAzimuth = 0.0f;
    static double tDistance = 0.0f, tAzimuth = 0.0f,ttAzimuth = 0.0f,tAzimuthDegree = 0.0f;

    nmeaPOS uFromPos,uToPos,uDisPos,uTgtPos,finalPos;
    
    uFromPos.lat = nmea_degree2radian(22.74822374401);
    uFromPos.lon = nmea_degree2radian(113.8544876045);
    
//    uToPos.lat = nmea_degree2radian(22.7482239165);
//    uToPos.lon = nmea_degree2radian(113.8544886592);
    uToPos.lat = nmea_degree2radian(22.74822374401);
    uToPos.lon = nmea_degree2radian(113.8544876045);
        
    tDistance = nmea_distance_ellipsoid(&uFromPos, &uToPos, &tFromAzimuth, &tToAzimuth); 

    ttAzimuth = nmea_radian2degree(tFromAzimuth);                            //��תΪ�Ƕ�

    uDisPos.lat = uToPos.lat - uFromPos.lat;                                //��ȡ��������
    uDisPos.lon = uToPos.lon - uFromPos.lon;
    if(uDisPos.lat < 0){
        if(uDisPos.lon > 0) 
            ttAzimuth = 180 + ttAzimuth;
        else if(uDisPos.lon < 0) 
            ttAzimuth = -180 + ttAzimuth;
        else
            ttAzimuth = -180;                                               //[0~180) (0~-180] �������仮��
    }

    if(ttAzimuth < 0.0f){                                                   //ת��Ϊ0~359.9999��
        ttAzimuth += 360.0;
    }


    tDistance *= 0.001;
                                                                           //����ˮƽƫ��
    nmea_move_horz_ellipsoid(&uFromPos,&uTgtPos,tFromAzimuth,tDistance,&tToAzimuth);                                                                         
    //nmea_move_horz_ellipsoid(&uFromPos,&uTgtPos,nmea_degree2radian(ttAzimuth),tDistance,&tToAzimuth);        
    //nmea_move_horz(&uFromPos,&uTgtPos,ttAzimuth,tDistance);      
    
    finalPos.lat = nmea_radian2degree(uTgtPos.lat);                         //ת������
    finalPos.lon= nmea_radian2degree(uTgtPos.lon);
    
    tAzimuthDegree = nmea_radian2degree(tFromAzimuth);
    
    while(1);

}
#endif


#if 0
int main(void)
{
#define EACH_ANGLE          30.0            //�ǶȲ�
#define POINT_TOTAL         12              //12pcs
#define RTK_ADAPT_DISTANCE  (+0.11*0.001)   //110mm
    
    double tFromAzimuth[POINT_TOTAL] = {0},tToAzimuth[POINT_TOTAL] = {0};
    static double tDistance[POINT_TOTAL] = {0.0f}, tAzimuth = 0.0f,ttAzimuth[POINT_TOTAL] = {0.0f},tttAzimuth[POINT_TOTAL] = {0.0f},tAzimuthDegree = 0.0f;

    nmeaPOS uFromPos,uToPos,uDisPos,uTgtPos[POINT_TOTAL],finalPos[POINT_TOTAL];
    
    uFromPos.lat = nmea_degree2radian(22.0);
    uFromPos.lon = nmea_degree2radian(113.0);
        
    for(int8_t i = 0; i < POINT_TOTAL; i++){
        //nmea_move_horz(&uFromPos,&uTgtPos[i],EACH_ANGLE * i),RTK_ADAPT_DISTANCE);
        nmea_move_horz_ellipsoid(&uFromPos,&uTgtPos[i],nmea_degree2radian(EACH_ANGLE * i),RTK_ADAPT_DISTANCE,&tToAzimuth[i]); 
        finalPos[i].lat = nmea_radian2degree(uTgtPos[i].lat);                         //ת������
        finalPos[i].lon= nmea_radian2degree(uTgtPos[i].lon);
        ttAzimuth[i] = nmea_radian2degree(tToAzimuth[i]);                                 //��תΪ�Ƕ�
    }
    
    for(int8_t j = 0; j < POINT_TOTAL; j++){
        tDistance[j] = nmea_distance_ellipsoid(&uFromPos, &uTgtPos[j], &tFromAzimuth[j], &tToAzimuth[j]); 
        tttAzimuth[j] = nmea_radian2degree(tFromAzimuth[j]);   
    }
    
    
    //tDistance = nmea_distance_ellipsoid(&uFromPos, &uTgtPos, &tFromAzimuth, &tToAzimuth); 

    //ttAzimuth = nmea_radian2degree(tFromAzimuth);                            //��תΪ�Ƕ�

    //ttAzimuth = nmea_radian2degree(tToAzimuth);                             //��תΪ�Ƕ�
/*
    uDisPos.lat = uToPos.lat - uFromPos.lat;                                //��ȡ��������
    uDisPos.lon = uToPos.lon - uFromPos.lon;
    if(uDisPos.lat < 0){
        if(uDisPos.lon > 0) 
            ttAzimuth = 180 + ttAzimuth;
        else if(uDisPos.lon < 0) 
            ttAzimuth = -180 + ttAzimuth;
        else
            ttAzimuth = -180;                                               //[0~180) (0~-180] �������仮��
    }

    if(ttAzimuth < 0.0f){                                                   //ת��Ϊ0~359.9999��
        ttAzimuth += 360.0;
    }

*/
    //tDistance *= 0.001;
                                                                           //����ˮƽƫ��
    //nmea_move_horz_ellipsoid(&uFromPos,&uTgtPos,tFromAzimuth,tDistance,&tToAzimuth);                                                                         
    //nmea_move_horz_ellipsoid(&uFromPos,&uTgtPos,nmea_degree2radian(ttAzimuth),tDistance,&tToAzimuth);        
    //nmea_move_horz(&uFromPos,&uTgtPos,ttAzimuth,tDistance);      
    
    
    while(1);

}
#endif

#if 0
int main(void)
{
    char buff[] = {\
       "$GPRMC,173843,A,3349.896,N,11808.521,W,000.0,360.0,230108,013.4,E*69\r\n$GPGGA,111609.14,5001.27,N,3613.06,E,3,08,0.0,10.2,M,0.0,M,0.0,0000*70\r\n$GPGSV,2,1,08,01,05,005,80,02,05,050,80,03,05,095,80,04,05,140,80*7f\r\n$GPGSV,2,2,08,05,05,185,80,06,05,230,80,07,05,275,80,08,05,320,80*71\r\n$GPGSA,A,3,01,02,03,04,05,06,07,08,00,00,00,00,0.0,0.0,0.0*3a\r\n$GPRMC,111609.14,A,5001.27,N,3613.06,E,11.2,0.0,261206,0.0,E*50\r\n$GPVTG,217.5,T,208.8,M,000.00,N,000.01,K*4C\r\n"
    };

	char *ptr;
	
    nmeaINFO info;
    nmeaPARSER parser;

    nmea_zero_INFO(&info);
    nmea_parser_init(&parser);
	
	ptr = buff;
	
	if(ptr){
        nmea_parse(&parser, ptr, (int)strlen(ptr), &info);
		ptr += strlen((char*)ptr);
    }

    nmea_parser_destroy(&parser);

    return 0;
}
#endif

#if 1
int main()
{
    const char *buff[] = {
#if 1		
		
		"$GPGSV,3,1,09,02,22,264,42,03,22,042,42,04,,,38,06,51,297,42*42\r\n",
		"$GPGSV,3,2,09,09,15,131,38,17,52,015,44,23,12,093,39,28,63,165,47*7D\r\n",
		"$GPGSV,3,3,09,30,05,180,44*4F\r\n",
		"$GPGSA,A,1,3,6,17,28,,,,,,,,,1.2,0.9,0.8*3B\r\n",
		"$GPZDA,083123.00,31,05,2019,,*60\r\n",
		"$GPGGA,083123.00,2244.9002861,N,11351.2050483,E,4,09,0.9,29.284,M,-4.133,M,2.0,0000*68\r\n",
		"$GPHDT,134.407,T*30\r\n",
		"$GPGGA,083123.20,2244.9002850,N,11351.2050477,E,4,09,1.0,29.267,M,-4.133,M,0.2,0000*66\r\n",
		"$GPHDT,120.360,T*33\r\n",
		"$GPGGA,083123.40,2244.9002848,N,11351.2050489,E,4,09,0.9,29.263,M,-4.133,M,0.4,0000*62\r\n",
		"$GPHDT,120.868,T*30\r\n",
		"$GPGGA,083123.60,2244.9002848,N,11351.2050494,E,4,09,0.9,29.266,M,-4.133,M,0.6,0000*6B\r\n",
		"$GPHDT,120.877,T*3E\r\n",
		"$GPGGA,083123.80,2244.9002855,N,11351.2050485,E,4,09,0.9,29.266,M,-4.133,M,0.8,0000*67\r\n",
		"$GPHDT,121.285,T*38\r\n"
#else
        "$GPGSV,2,1,08,01,05,005,80,02,05,050,80,03,05,095,80,04,05,140,80*7f\r\n",
        "$GPGSV,2,2,08,05,05,185,80,06,05,230,80,07,05,275,80,08,05,320,80*71\r\n",
        "$GPGSA,A,3,01,02,03,04,05,06,07,08,00,00,00,00,0.0,0.0,0.0*3a\r\n",
        "$GPRMC,173843,A,3349.896,N,11808.521,W,000.0,360.0,230108,013.4,E*69\r\n",
        "$GPGGA,111609.14,5001.27,N,3613.06,E,3,08,0.0,10.2,M,0.0,M,0.0,0000*70\r\n",		
        "$GPVTG,217.5,T,208.8,M,000.00,N,000.01,K*4C\r\n"
#endif		
    };

    nmeaINFO info;
    nmeaPARSER parser;

    nmea_zero_INFO(&info);
    nmea_parser_init(&parser);

    for( int it = 0; it < 14; ++it){
        nmea_parse(&parser, buff[it], (int)strlen(buff[it]), &info);
    }

    nmea_parser_destroy(&parser);

    return 0;
}

#endif

