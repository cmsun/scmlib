/**
******************************************************************************
* @��  ���� AppHardWareTest.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-May-2018
* @��  ���� Ӳ������������
******************************************************************************
* @�޸ļ�¼��
*   2018/05/08����ʼ�汾
*    
*
******************************************************************************
**/

//ͷ�ļ�����
#include "includes.h"



/*
******************************************************************************
*	�� �� ��: main
*	����˵��: ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#if 0
int main(void)
{
    static uint8_t tWriteTemp[10]={"hhhhhhhh"};
    static uint8_t tReadTemp[10]={"xxxxxxx"};
    static uint8_t *pReadBuff;
    static RTC_TIME_STRUCT tRtcTime;
    static int32_t tValue = 0;
    static float fValue1 = 0.0,fValue2 = 0.0,fValue11 = 0.0,fValue22 = 0.0;
    static LM95071_VALUE_STATE lm95071Vaild1,lm95071Vaild2;
    static MAX31865_VALUE_STATE max31865Vaild1,max31865Vaild2;
    static AD7478_VALUE_STATE ad7478Vaild;
    static int32_t tEncoderValue = 0;
    static uint16_t tExtIoValue = 0;

    GPIOx_init();
    RTCx_init();
    USARTx_init();

    Delay_init();
    Led_init();
    Rs485_init(RS485_1ST);
    Rs485_init(RS485_2ND);

    Ad7478_init();
    Mpu6515_init();
    M95m02dr_init();
    Lm95071_init();
    Max31865_init();

    while(1)
    {
        
        Led_setBlink(LED_ALL, BLINK_ONCE);
        USARTx_printf("Hello word!!!\r\n");

        M95m02dr_read(tReadTemp,0,10);
        
        Mpu6515_getValue();
        
        Lm95071_getValue(LM95071_1ST, &lm95071Vaild1, &fValue1);
        Lm95071_getValue(LM95071_2ND, &lm95071Vaild2, &fValue2);
        
        Max31865_getValue(MAX31865_1ST, &max31865Vaild1, &fValue11);
        Max31865_getValue(MAX31865_2ND, &max31865Vaild2, &fValue22);
        
        Ad7478_getValue(&ad7478Vaild, &tValue);
        
        Rs485_sendBuff(RS485_1ST, tWriteTemp, 10);
        Delay_mSec(10);
        pReadBuff = Rs485_readBuff(RS485_2ND);

        if(0 == memcmp(tWriteTemp,pReadBuff,10))
            USARTx_printf("RS485 SUCCESS!!!\r\n");
        else
            USARTx_printf("RS485 FAILED!!!\r\n");

        GPIOx_setExtOut(0x0000);
        GPIOx_getExtIn(&tExtIoValue);
        
        Delay_mSec(100);
        
        GPIOx_setExtOut(0xFFFF);
        GPIOx_getExtIn(&tExtIoValue);
        
        Delay_mSec(100);
    }
}
#else
int main(void)
{
    static uint8_t i = 0;
    static uint8_t tWriteTemp[10]={"hhhhhhhh"};
    static uint8_t tReadTemp[10]={"xxxxxxx"};
    static uint8_t *pReadBuff;
    static float fValue1 = 0.0,fValue2 = 0.0,fValue11 = 0.0,fValue22 = 0.0;
    static LM95071_VALUE_STATE lm95071Vaild1,lm95071Vaild2;
    static MAX31865_VALUE_STATE max31865Vaild1,max31865Vaild2;
    static uint16_t tExtIoValue = 0;

    GPIOx_init();
    RTCx_init();
    USARTx_init();

    Delay_init();
    Led_init();
    Rs485_init(RS485_1ST);
    Rs485_init(RS485_2ND);

    Ad7478_init();
    Mpu6515_init();
    M95m02dr_init();
    Lm95071_init();
    Max31865_init();

    /* IO����������� */
    for(i=0; i<5; i++){
        GPIOx_setExtOut(0x0000);
        Delay_mSec(100);
        GPIOx_getExtIn(&tExtIoValue);
        Delay_mSec(100);
        if(0x0000 != tExtIoValue){
            break;
        }

        GPIOx_setExtOut(0xFFFF);
        Delay_mSec(100);
        GPIOx_getExtIn(&tExtIoValue);
        Delay_mSec(100);
        if(0xFFFF != tExtIoValue){
            break;
        }
    }

    if(i == 4){
        USARTx_printf("GPIO TEST SUCCESS!!!\r\n");
    }else{
        USARTx_printf("GPIO TEST FAILED!!!\r\n");
    }

    /* RS485ͨ�Ų��� */
    for(i=0; i<5; i++){
        Rs485_sendBuff(RS485_1ST, tWriteTemp, 10);
        Delay_mSec(10);
        pReadBuff = Rs485_readBuff(RS485_2ND);
        if(0 != memcmp(tWriteTemp,pReadBuff,10)){
            break;
        }

        Rs485_sendBuff(RS485_2ND, tWriteTemp, 10);
        Delay_mSec(10);
        pReadBuff = Rs485_readBuff(RS485_1ST);
        if(0 != memcmp(tWriteTemp,pReadBuff,10)){
            break;
        }
    }
    
    if(i == 4){
        USARTx_printf("RS485 TEST SUCCESS!!!\r\n");
    }else{
        USARTx_printf("RS485 TEST FAILED!!!\r\n");
    }

    /* ����¶ȴ��������� */
    for(i=0; i<5; i++){
        Max31865_getValue(MAX31865_1ST, &max31865Vaild1, &fValue11);
        if(max31865Vaild1 == MAX31865_VALUE_INVAILD){
            break;
        }

        Max31865_getValue(MAX31865_2ND, &max31865Vaild2, &fValue22);
        if(max31865Vaild2 == MAX31865_VALUE_INVAILD){
            break;
        }
    }

    if(i == 4){
        USARTx_printf("MAX31865 TEST SUCCESS!!!\r\n");
    }else{
        USARTx_printf("MAX31865 TEST FAILED!!!\r\n");
    }

    /* �����¶ȴ��������� */
    for(i=0; i<5; i++){
        Lm95071_getValue(LM95071_1ST, &lm95071Vaild1, &fValue1);
        if(lm95071Vaild1 == LM95071_VALUE_INVAILD){
            break;
        }
        Lm95071_getValue(LM95071_2ND, &lm95071Vaild2, &fValue2);
        if(lm95071Vaild2 == LM95071_VALUE_INVAILD){
            break;
        }           
    }    

    if(i == 4){
        USARTx_printf("LM95071 TEST SUCCESS!!!\r\n");
    }else{
        USARTx_printf("LM95071 TEST FAILED!!!\r\n");
    }

    /* ��̬������ */


    /* ���ݴ洢������ */
    for(i=0; i<5; i++){
        M95m02dr_write(tWriteTemp,0,10);
        M95m02dr_read(tReadTemp,0,10);
        if(0 != memcmp(tWriteTemp,tReadTemp,10)){
            break;
        }
    }

    if(i == 4){
        USARTx_printf("M95M02DR TEST SUCCESS!!!\r\n");
    }else{
        USARTx_printf("M95M02DR TEST FAILED!!!\r\n");
    }

    while(1);
}
#endif
