/**
******************************************************************************
* @��  ���� AppAttitudeTest.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 23-Aug-2019
* @��  ���� ��̬����������
******************************************************************************
* @�޸ļ�¼��
*   2019/08/23����ʼ�汾
*    
*
******************************************************************************
**/

//ͷ�ļ�����
#include "includes.h"

//ͨ��֧��
#include "mod_ahrsCommu.h"

//�궨��
#define UPDATA_PERIOD   20							    //�����ϴ��ٶ�  ��λ Hz
#define UPDATA_TIMEOUT  ((1000 / UPDATA_PERIOD) / 2)    //�����ϴ���ʱ�䡣��λΪmS

//ö��
typedef enum { REPORT_ATTITUDE_INFO = 0, REPORT_RAW_INFO , REPORT_MAGN_INFO, MAX_REPORT }REPORT_ENUM;

//��̬����
REPORT_ENUM sReportSta = REPORT_ATTITUDE_INFO;

uint64_t framCnt = 0;



/*
******************************************************************************
*	�� �� ��: main
*	����˵��: ���������������������ó���������λ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
int main(void) 
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

    GPIOx_init();
    USARTx_init();
    I2Cx_init();
    
    Led_init();
    Delay_init();
    Timestamp_init();
    
    ParamInfoStruct.init();
    
    Mahony_Init(50);
    AhrsCommu_init();
    
    Delay_mSec(50);                                                         //������ʱ���ȴ�оƬ����
    Mpu6515_init();
    Hmc5883l_init();
    Delay_mSec(100);                                                        //������ʱ���ڷָ��ʼ�����ȡ
    
    while(1)
    {
        static float pitchDegree ,rollDegree, yawDegree;
        static int32_t calcuAttiCnt; 
        
        MPU6515_INFO_STRUCT uMpuInfo;
        HMC5883L_REAL_INFO  uHmcInfo;        
        
        if(true == Mpu6515_getMotionValue(&uMpuInfo)){                      //һ����⵽�������������̬����Ҫ100Hz�����ݸ���Ƶ��
#if 1
            if(true == Hmc5883l_getRealInfo(&uHmcInfo)){                    //����������ѹ�Ʋ�������֣����败����̬����
                
                Mahony_update(uMpuInfo.Gyro[0] * PI/180, uMpuInfo.Gyro[1] * PI/180, uMpuInfo.Gyro[2] * PI/180,
                          uMpuInfo.Accel[0], uMpuInfo.Accel[1], uMpuInfo.Accel[2],
                          uHmcInfo.Magn[0], uHmcInfo.Magn[1], uHmcInfo.Magn[2]);
            }else{
                I2Cx_init();
                Hmc5883l_init();
            }
#else
            Mahony_miniUpdate(uMpuInfo.Gyro[0] * PI/180, uMpuInfo.Gyro[1] * PI/180, uMpuInfo.Gyro[2] * PI/180,
                          uMpuInfo.Accel[0], uMpuInfo.Accel[1], uMpuInfo.Accel[2]);
#endif
            
            Mahony_computeAngles();                                         //��Ԫ��תŷ����
            calcuAttiCnt += 1;
            framCnt += 1;

            pitchDegree = getPitch();                                       //ֱ�ӻ�ȡ��̬��
            rollDegree = getRoll();
            yawDegree = getYaw();

            Led_setToggle(LED_1);
        }else{
            TIMESTAMP_STRUCT uNewTimeStamp,uOldTimeStamp;
            uNewTimeStamp = Timestamp_get();
            if(((uNewTimeStamp.cnt - uOldTimeStamp.cnt) > UPDATA_TIMEOUT)||
              (((uNewTimeStamp.cnt - uOldTimeStamp.cnt) < (UPDATA_TIMEOUT - UINT32_MAX))&&\
              (uNewTimeStamp.bFull == true))){                               //�ж�ʱ�䳬ʱ

                uNewTimeStamp.bFull = false;
                uOldTimeStamp = uNewTimeStamp;
                Led_setToggle(LED_0);

                switch(sReportSta){                                         //���ڷ���״̬
                    case REPORT_ATTITUDE_INFO:{
                        AhrsCommu_reportAttitudeInfo(yawDegree*10.0, pitchDegree*10.0 ,rollDegree*10.0,
                                                     0, 0, 0, UPDATA_PERIOD * calcuAttiCnt);
                        calcuAttiCnt = 0;
                        sReportSta = REPORT_RAW_INFO;
                    }break;
                    case REPORT_RAW_INFO:{
                        MPU6515_RAW_STRUCT uMpuRawInfo;
                        HMC5883L_RAW_INFO  uHmcRawInfo;
                        Mpu6515_getLastRaw(&uMpuRawInfo);
                        Hmc5883l_getLastValue(&uHmcRawInfo);
                        AhrsCommu_reportRawInfo(uMpuRawInfo.Accel,uMpuRawInfo.Gyro,uHmcRawInfo.Magn);
                        sReportSta = REPORT_ATTITUDE_INFO;
                        if(Hmc5883lCalibInfo.startFlag == 1){
                            sReportSta = REPORT_MAGN_INFO;
                        }
                    }break;
                    default:{
                        AhrsCommu_reportMagneticInfo(Hmc5883lCalibInfo.Max,Hmc5883lCalibInfo.Min,0);
                        sReportSta = REPORT_ATTITUDE_INFO;
                    }break;
                }
            }
            
            AHRSCOMMU_INFO_STRUCT uCmdInfo;
            AhrsCommu_loopRead();
            AhrsCommu_get(&uCmdInfo);
            switch(uCmdInfo.Cmd){
                case GYRO_INIT:{
                    Led_setState(LED_2, LED_ON);
                    while(false == Mpu6515_initGyroOffset());               //������������У׼
                    Led_setState(LED_2, LED_OFF);
                }break;
                case MAGN_CALIB:{
                    Hmc5883l_saveCalib();
                }break;
                case HIGH_INIT:{
                    // nothing
                }break;
                case MAGN_CALIB_BEGIN:{
                    Hmc5883l_startCalib();
                }break;
                default:break;
            }
        }
    }

    return 0;
}

