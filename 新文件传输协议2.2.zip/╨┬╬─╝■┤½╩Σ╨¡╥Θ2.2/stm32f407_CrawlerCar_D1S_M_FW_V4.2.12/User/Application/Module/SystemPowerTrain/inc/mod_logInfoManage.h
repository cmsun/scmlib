/**
*****************************************************************************
* @��  ���� mod_logInfoManage.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 12-Jun-2018
* @��  ���� ʱ�����ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/12����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_LOGINFOMANAGE_H_
#define _MOD_LOGINFOMANAGE_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//����ṹ��
typedef struct{
	int32_t errFlag;
	int32_t warnFlag;
	int32_t batVoltage;
	int32_t batChargeCur;
	int32_t batDischargeCur;
    float batCapacity;
	float firLm95071Temp;
	float secLm95071Temp;
	int8_t firLm95071Sta;
	int8_t secLm95071Sta;
	float firMax31865Temp;
	float secMax31865Temp;
	int8_t firMax31865Sta;
	int8_t secMax31865Sta;
	int8_t controllerSta;
	int8_t controllerCmd;
	int8_t limitSwitch;
	int8_t batPercent;
	int8_t curRobotSta;
	int8_t curRobotCmd;
	int8_t curWorkMethon;
	int8_t curLineVelocity;
	int8_t curAngleVelocity;
	int8_t gpsConnectSta;
	int8_t gpsVaildSta;
    int8_t azimuthSta;
	double gpsLongitude;
	double gpsLatitude;
	double azimuth;
}LOGINFO_DETAIL_STRUCT;


//�ӿں���
void LogInfoManage_init(void);
void LogInfoManage_loop(void);


#ifdef _cplusplus
	}
#endif

#endif
