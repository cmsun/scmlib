/**
*****************************************************************************
* @��  ���� mod_motionControl.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �˶�����ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/07����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_MOTIONCONTROL_H_
#define _MOD_MOTIONCONTROL_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//����ö��
typedef enum{
    DRIVER_OK = 0,
    DRIVER_ERR
}DRIVER_STATE_ENUM;

typedef enum{
    MOTION_DISABLE = 0x00,
    MOTION_ENABLE = 0x01,
    MOTION_CLEAR_ALARM = 0x02,
    MOTION_NONE_CMD = 0xF0
}MOTION_CONTROL_ENUM;

//����ṹ��
typedef struct{
    MOTION_CONTROL_ENUM MotionCtl; 
    double  linearVelocity;
    double  angularVelocity;
}MOTION_PARAM_STRUCT;

typedef struct{
    int16_t leftMotorRpm;
    int16_t rightMotorRpm;
    double leftMotorVelocity;
    double rightMotorVelocity;
}MOTOR_RPM_STRUCT;

typedef struct{
    double onceMeter;
    double onceSecond;
    uint64_t totalMeter;
	uint64_t totalSecond;
}MOTION_MILEAGE_STRUCT;

typedef struct{
    DRIVER_STATE_ENUM       LeftDriverSta;
    DRIVER_STATE_ENUM       RightDriverSta;
    MOTOR_RPM_STRUCT        MotorRpmStruct;
    MOTION_PARAM_STRUCT     MotionParmInfo;
    MOTION_MILEAGE_STRUCT   MileageInfo;
}MOTION_STATE_STRUCT;

typedef struct{
    MOTION_CONTROL_ENUM DriverCtl;
    MOTOR_RPM_STRUCT  MotorRpmStruct;
}MOTION_OUTPUT_STRUCT;

typedef struct{
    MOTION_PARAM_STRUCT     ParamConfigInfo;    //�趨���˶�����
    MOTION_PARAM_STRUCT     ParamPlanInfo;      //����Ĺ滮����
    MOTION_OUTPUT_STRUCT    OutputParam;        //���������Ĳ���
    MOTION_STATE_STRUCT     StateInfo;          //��ȡ�����˶�����
}MOTION_CONTROL_STRUCT;

//�ӿں���
void MotionControl_init(void);
void MotionControl_loop(void);
void MotionControl_setParam(MOTION_PARAM_STRUCT uMotionParam);
void MotionControl_getInfo(MOTION_STATE_STRUCT *pMotionState);

//�ⲿ����
extern MOTION_CONTROL_STRUCT MotionCtlStruct;

#ifdef _cplusplus
	}
#endif

#endif
