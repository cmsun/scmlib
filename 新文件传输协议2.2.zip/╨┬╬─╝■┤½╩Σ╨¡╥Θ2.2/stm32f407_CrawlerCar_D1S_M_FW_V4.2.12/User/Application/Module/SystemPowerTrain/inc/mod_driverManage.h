/**
*****************************************************************************
* @��  ���� mod_driverManage.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �������ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/07����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_DRIVERMANAGE_H_
#define _MOD_DRIVERMANAGE_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//����ö��
typedef enum{
    DRIVER_OFFLINE =  0,
    DRIVER_ONLINE
}CONNECT_STATE_ENUM;

typedef enum{
    DRIVER_DEFAULT_STATE = 0,
    DRIVER_INIT_STATE = 1,
    DRIVER_START_STATE = 2,
    DRIVER_WAS_RUNNING = 3,
    DRIVER_BE_READY = 4,
    DRIVER_ERR_STATE = 5,
    DRIVER_WAIT_POWERON = 8,
}READY_STATE_ENUM;

typedef enum{
    DRIVER_DISABLE = 0x00,
    DRIVER_ENABLE = 0x01,
    DRIVER_CLEAR_ALARM = 0x02,
    DRIVER_NONE_CMD = 0x10
}DRIVER_CONTROL_ENUM;

//����ṹ��
typedef struct{
    DRIVER_CONTROL_ENUM CtlCmd;
    CONNECT_STATE_ENUM  ConSta;
    READY_STATE_ENUM  ReadySta;
    int16_t             rpmVal;
    int16_t            errCode;
}MOTOR_DRIVER_STATE_STRUCT;

typedef struct{
    void (* rpmCheck)(void);
    void (* errCheck)(void);
    void (* staCheck)(void);
    void (* cmdCheck)(void);

    void (* drvCtl)(DRIVER_CONTROL_ENUM motorCtl);
    void (* rpmSet)(int16_t rpmVal);
    
    void (* valRefresh)(void);
    void (* valClean)(void);
    
    DRIVER_CONTROL_ENUM CurCmd;
}MOTOR_DRIVER_CONTROL_STRUCT;

//��װ����
typedef struct{
    MOTOR_DRIVER_STATE_STRUCT LeftDrvSta;
    MOTOR_DRIVER_STATE_STRUCT RightDrvSta;
    MOTOR_DRIVER_CONTROL_STRUCT LeftDrvCtl;
    MOTOR_DRIVER_CONTROL_STRUCT RightDrvCtl;
    void (* autoPoll)(void);
    void (* check)(void);
    void (* init)(void);
}DRIVER_MANAGE_STRUCT;


//�ⲿ����
extern DRIVER_MANAGE_STRUCT DriverManageStruct;


#ifdef _cplusplus
	}
#endif

#endif
