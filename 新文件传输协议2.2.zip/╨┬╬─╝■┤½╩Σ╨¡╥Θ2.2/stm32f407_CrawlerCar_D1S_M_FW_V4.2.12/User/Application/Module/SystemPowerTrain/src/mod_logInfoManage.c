/**
*****************************************************************************
* @��  ���� mod_logInfoManage.C 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 15-Jun-2018
* @��  ���� ��־����ģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/15����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_logInfoManage.h"

//ͷ�ļ�����
#include "includes.h"

//��̬����
LOGINFO_DETAIL_STRUCT   uLogInfoDetail;



/*
******************************************************************************
*	�� �� ��: LogInfoManage_init
*	����˵��: ��־��¼������ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LogInfoManage_init(void)
{
    static FATFS SdcardFs;

	FRESULT res = f_mount(&SdcardFs, "", 0);
	if(res != FR_OK){
		PRINT_DBG("f_mount erro = %d\r\n",res);
        Safety_setFlagBit(BIT_Error_SdCard,1);
	}

    int32_t rReturn = LogSys2Info_refresh();
    if(rReturn != 0){
        PRINT_DBG("LogSys2Info_refresh = %d\r\n",rReturn);
        Safety_setFlagBit(BIT_Error_SdCard,1);
    }
}

/*
******************************************************************************
*	�� �� ��: LogInfoManage_loop
*	����˵��: ��־��¼����������ѭ��,20ms����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LogInfoManage_loop(void)
{
#define LOG_SYS_PRIOD	(500-1)                                      		//20ms * 500
    static int32_t sLogRecordCnt = LOG_SYS_PRIOD;
    static POSITION_INFO_STRUCT uPosInfo;
    static ATTITUDE_INFO_STRUCT uAttInfo;
    static RTC_TIME_STRUCT sRtcTimeInfo;
    static char sLogBuff[512] = {0},sLogRecordTime[20] = {0};

    PositionInfo_get(&uPosInfo);
    
    uLogInfoDetail.errFlag = SafetyFlagUnion.SafetyFlagLevel.ErrorFlag;
    uLogInfoDetail.warnFlag = SafetyFlagUnion.SafetyFlagLevel.WarningFlag;
    uLogInfoDetail.batCapacity = BatMagStruct.getCapacity();
    uLogInfoDetail.batPercent = BatMagStruct.getPercent();
    uLogInfoDetail.batVoltage = BatteryInfoStruct.voltageAdjust;
    uLogInfoDetail.batChargeCur = BatteryInfoStruct.chargeCurrentAdjust;
    uLogInfoDetail.batDischargeCur = BatteryInfoStruct.dischargeCurrentAdjust;

    uLogInfoDetail.firLm95071Temp = TemperatureInfoStruct.curCabinet1stTemp;
    uLogInfoDetail.secLm95071Temp = TemperatureInfoStruct.curCabinet2ndTemp;
    uLogInfoDetail.firLm95071Sta = TemperatureInfoStruct.curCabinetTemp1stState;
    uLogInfoDetail.secLm95071Sta = TemperatureInfoStruct.curCabinetTemp2ndState;
    uLogInfoDetail.firMax31865Temp = TemperatureInfoStruct.curBattery1stTemp;
    uLogInfoDetail.secMax31865Temp = TemperatureInfoStruct.curBattery2ndTemp;
    uLogInfoDetail.firMax31865Sta = TemperatureInfoStruct.curBatteryTemp1stState;
    uLogInfoDetail.secMax31865Sta = TemperatureInfoStruct.curBatteryTemp2ndState;

    uLogInfoDetail.controllerSta = ControllerInfoStruct.ConnectState;
    uLogInfoDetail.controllerCmd = ControllerInfoStruct.MotionCmd;

    uLogInfoDetail.limitSwitch = LimitSwitchInfo_getBits();
    uLogInfoDetail.curRobotSta = RoTaskMagStruct.RunSta;
    uLogInfoDetail.curRobotCmd = RoTaskMagStruct.CtlCmd;
    uLogInfoDetail.curWorkMethon = RoTaskMagStruct.RunMethon;

    uLogInfoDetail.curLineVelocity = (int8_t)MotionCtlStruct.StateInfo.MotionParmInfo.linearVelocity;
    uLogInfoDetail.curAngleVelocity = (int8_t)MotionCtlStruct.StateInfo.MotionParmInfo.angularVelocity;

    uLogInfoDetail.gpsConnectSta = uPosInfo.PosConnectSta;
    uLogInfoDetail.gpsVaildSta = uPosInfo.PosVaildSta;
    uLogInfoDetail.azimuthSta = uPosInfo.AzimuthValidSta;
    uLogInfoDetail.gpsLongitude = CUR_POS_LON;
    uLogInfoDetail.gpsLatitude = CUR_POS_LAT;
    uLogInfoDetail.azimuth = uPosInfo.Azimuth;
	
    if(sLogRecordCnt > 0){
        sLogRecordCnt -= 1;
    }else{
        int32_t rReturn = LogSys2Info_refresh();
        if(rReturn != 0){
            Safety_setFlagBit(BIT_Error_SdCard,1);
        }

        RTCx_get(&sRtcTimeInfo);
        sprintf(sLogRecordTime,"%04d/%02d/%02d_%02d:%02d:%02d",
            sRtcTimeInfo.year,sRtcTimeInfo.month,sRtcTimeInfo.mday,
            sRtcTimeInfo.hour,sRtcTimeInfo.min,sRtcTimeInfo.sec);

        sprintf(sLogBuff,"%s,0x%x,0x%x,%d,%d,%d,%.6f,%hhd,%.1f,%.1f,%d,%d,%.1f,%.1f,%d,%d,%d,%d,0x%hhx,%d,%d,%d,%d,%d,%d,%d,%d,%.13f,%.13f,%.2f\r\n",
                sLogRecordTime,\
                uLogInfoDetail.errFlag,\
                uLogInfoDetail.warnFlag,\
                uLogInfoDetail.batVoltage,\
                uLogInfoDetail.batChargeCur,\
                uLogInfoDetail.batDischargeCur,\
                uLogInfoDetail.batCapacity,\
                uLogInfoDetail.batPercent,\
                uLogInfoDetail.firLm95071Temp,\
                uLogInfoDetail.secLm95071Temp,\
                uLogInfoDetail.firLm95071Sta,\
                uLogInfoDetail.secLm95071Sta,\
                uLogInfoDetail.firMax31865Temp,\
                uLogInfoDetail.secMax31865Temp,\
                uLogInfoDetail.firMax31865Sta,\
                uLogInfoDetail.secMax31865Sta,\
                uLogInfoDetail.controllerSta,\
                uLogInfoDetail.controllerCmd,\
                uLogInfoDetail.limitSwitch,\
                uLogInfoDetail.curRobotSta,\
                uLogInfoDetail.curRobotCmd,\
                uLogInfoDetail.curWorkMethon,\
                uLogInfoDetail.curLineVelocity,\
                uLogInfoDetail.curAngleVelocity,
                uLogInfoDetail.gpsConnectSta,\
                uLogInfoDetail.gpsVaildSta,\
                uLogInfoDetail.azimuthSta,\
                uLogInfoDetail.gpsLongitude,\
                uLogInfoDetail.gpsLatitude,\
                uLogInfoDetail.azimuth);

        LogSys2Info_dataRecord(sLogBuff);
        
        sLogRecordCnt = LOG_SYS_PRIOD;
    }
}

