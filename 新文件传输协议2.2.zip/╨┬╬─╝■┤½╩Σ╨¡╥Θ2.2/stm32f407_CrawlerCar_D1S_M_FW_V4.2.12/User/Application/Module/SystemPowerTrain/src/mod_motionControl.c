/**
*****************************************************************************
* @��  ��: mod_motionControl.c 
* @��  ��: 00Jackey
* @��  ��: V1.0.0
* @��  ��: 7-Jun-2018
* @��  ��: �˶�����ģ�����ļ�
******************************************************************************
* @�޸ļ�¼: 
*   2018/06/07: ��ʼ�汾
*   2018/08/29: �����˵���״̬����������
*   2018/09/19: �޸����������ߺ��ڼ�¼��̵�BUG
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_motionControl.h"

//�˲���
#include "mod_filter.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define 	WHEEL_RADIUS			0.0552f // ���Ӱ뾶 ��λ(m)
#define		WHEEL_TREAD				0.46f   // �־�     ��λ(m)
#define 	MOTION_MOTOR_RATIO		20.0f   // ���ٱ�   

#define     RPM_FILTER_CNT          2       // 2��ת�ٻ����˲���
#define     RPM_VALUE_SMOOTH_CNT    100   	// �������ڴ�С 100*20ms

#define     RECORDE_PER_SECOND      30*60   // 30���Ӽ�¼һ�Σ�����д��
#define     RECORDE_PER_METER       10      // 10�׼�¼һ�Σ�����д��

#define     DEBUG                   false
#define     MOTOR_DIR               (+1)    

//��̬����
static void MotionControl_velocityPlan(MOTION_STATE_STRUCT uMotionState,
                                        MOTION_PARAM_STRUCT uMotionParam,
                                        MOTION_PARAM_STRUCT *pMotionParaOut);

//��̬����
static Filter       RpmFilter[RPM_FILTER_CNT];
static FilterPtr    RpmFilterPtr[RPM_FILTER_CNT];
static float        RpmSmoothBuff[RPM_FILTER_CNT][RPM_VALUE_SMOOTH_CNT];

//ȫ�ֱ���
MOTION_CONTROL_STRUCT MotionCtlStruct;



/*
******************************************************************************
*	�� �� ��: MotionControl_init
*	����˵��: �˶����ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void MotionControl_init(void)
{
    ROBOT_MILEAGE_INFO_UNION uRobMileInfo;

    LimitSwitchInfo_init();
    DriverManageStruct.init();
    ParamInfoStruct.robotMileageStruct.read(&uRobMileInfo);

    MotionCtlStruct.StateInfo.MileageInfo.onceMeter = 0;
    MotionCtlStruct.StateInfo.MileageInfo.onceSecond = 0;
    MotionCtlStruct.StateInfo.MileageInfo.totalMeter = uRobMileInfo.Struct.totalMeter;
    MotionCtlStruct.StateInfo.MileageInfo.totalSecond = uRobMileInfo.Struct.totalSecond;

    for(uint8_t i = 0; i < RPM_FILTER_CNT; i++){
        RpmFilterPtr[i] = &RpmFilter[i];
        Filter_init(RpmFilterPtr[i], RPM_VALUE_SMOOTH_CNT, RpmSmoothBuff[i]);
    }
}

/*
******************************************************************************
*	�� �� ��: MotionControl_caluMatrix
*	����˵��: �˶����ƻ�ȡ��ʼ��
*	��    ��: 
*	�� �� ֵ: ��
******************************************************************************
*/
void  MotionControl_caluMatrix(float *M_matrix, float **MN_matrix,
                            float *N_matrix, uint8_t M, uint8_t N)
{
	uint8_t i = 0, j = 0;

	// initial a matrix
	for(i = 0; i < M; i++)
	{
		*(M_matrix + i) = 0;
	}

	// multiply two matrixes
	for(i = 0; i < M; i++)
	{
		for(j = 0; j < N; j++)
		{
			*(M_matrix + i) += (*((float*)MN_matrix + i*N +j) * *(N_matrix +j));
		}
	}
}

/*
******************************************************************************
*	�� �� ��: MotionControl_driverOutput
*	����˵��: �˶����Ƶ�����
*	��    ��: MotionParam��������в���
*	�� �� ֵ: ��
******************************************************************************
*/
void MotionControl_driverOutput(MOTION_OUTPUT_STRUCT motionOutput)
{
    DriverManageStruct.LeftDrvCtl.drvCtl((DRIVER_CONTROL_ENUM)motionOutput.DriverCtl);
    DriverManageStruct.RightDrvCtl.drvCtl((DRIVER_CONTROL_ENUM)motionOutput.DriverCtl);
    DriverManageStruct.LeftDrvCtl.rpmSet(motionOutput.MotorRpmStruct.leftMotorRpm);
    DriverManageStruct.RightDrvCtl.rpmSet(motionOutput.MotorRpmStruct.rightMotorRpm);
}

/*
******************************************************************************
*	�� �� ��: MotionControl_setParam
*	����˵��: �˶����ƻ�ȡ��ʼ��
*	��    ��: motionCtl��ʹ��  uMotionParam��������в���
*	�� �� ֵ: ��
******************************************************************************
*/
void MotionControl_setParam(MOTION_PARAM_STRUCT uMotionParam)
{
	MotionCtlStruct.ParamConfigInfo.MotionCtl = uMotionParam.MotionCtl;
	MotionCtlStruct.ParamConfigInfo.linearVelocity = uMotionParam.linearVelocity;
 	MotionCtlStruct.ParamConfigInfo.angularVelocity = uMotionParam.angularVelocity;
}

/*
******************************************************************************
*	�� �� ��: MotionControl_motionResolving
*	����˵��: �˶����ƻ�ȡ��ʼ��
*	��    ��: uMotionParam��������в���
*	�� �� ֵ: ��
*   ˵    ��: ������ҵ����ת�ٳ������ת����Ҫ���¼��� leftMotorVelocity > |+-30|
******************************************************************************
*/
void MotionControl_motionResolving(MOTION_PARAM_STRUCT uMotionParam, 
									MOTION_OUTPUT_STRUCT* pMotorOutputStruct)
{

	pMotorOutputStruct->MotorRpmStruct.leftMotorVelocity = \
        (uMotionParam.linearVelocity * 2.0f + uMotionParam.angularVelocity * WHEEL_TREAD) / 2.0f;

	pMotorOutputStruct->MotorRpmStruct.rightMotorVelocity = \
        (uMotionParam.linearVelocity * 2.0f - uMotionParam.angularVelocity * WHEEL_TREAD) / 2.0f;
  
	pMotorOutputStruct->MotorRpmStruct.leftMotorRpm =\
		(MOTOR_DIR)*pMotorOutputStruct->MotorRpmStruct.leftMotorVelocity\
		* MOTION_MOTOR_RATIO / (2.0f * PI * WHEEL_RADIUS);
		
	pMotorOutputStruct->MotorRpmStruct.rightMotorRpm =\
		(MOTOR_DIR)*pMotorOutputStruct->MotorRpmStruct.rightMotorVelocity\
		* MOTION_MOTOR_RATIO / (2.0f * PI * WHEEL_RADIUS);

    pMotorOutputStruct->DriverCtl = uMotionParam.MotionCtl;
}

/*
******************************************************************************
*	�� �� ��: MotionControl_getInfo
*	����˵��: �˶����ƻ�ȡ������Ϣ
*	��    ��: pMotionState����ȡ���˶���Ϣ
*	�� �� ֵ: ��
******************************************************************************
*/
void MotionControl_getInfo(MOTION_STATE_STRUCT *pMotionState)
{
    *pMotionState = MotionCtlStruct.StateInfo;
}

/*
******************************************************************************
*	�� �� ��: MotionControl_velocityPlan
*	����˵��: �˶�����ϵͳ�ٶȹ滮
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void MotionControl_velocityPlan(MOTION_STATE_STRUCT uMotionState,
                                MOTION_PARAM_STRUCT uMotionParam,
								MOTION_PARAM_STRUCT *pMotionParaOut)
{
	
#define	ACCELERATE_M_PER_SEC2	((float)6/12)		//		1/6 M/S2
#define	DECELERATE_M_PER_SEC2	((float)20/12)
#define ACCELERATE_V	(((float)ACCELERATE_M_PER_SEC2 * 60) * 20 / 1000)
#define DECELERATE_V	(((float)DECELERATE_M_PER_SEC2 * 60) * 20 / 1000)

#define ACCELERATE_W	((float)180 * 20 / 1000)
#define DECELERATE_W	((float)180 * 20 / 1000)

#define V_OUT_DELAY_TIME	15

#define MAX_V	25
#define MAX_W	50

	static int s_VoutStartCount = 0;

	if(uMotionParam.MotionCtl == MOTION_ENABLE)
	{
		pMotionParaOut->MotionCtl = MOTION_ENABLE;
		
		if(fabs(uMotionParam.linearVelocity) > MAX_V)
		{
			uMotionParam.linearVelocity = copysignf(MAX_V,uMotionParam.linearVelocity);
		}

		if(fabs(uMotionParam.angularVelocity) > MAX_W)
		{
			uMotionParam.angularVelocity = copysignf(MAX_W,uMotionParam.angularVelocity);
		}
	}
	else if(uMotionParam.MotionCtl == MOTION_DISABLE)
	{
		uMotionParam.linearVelocity = 0;
		uMotionParam.angularVelocity = 0;
		
		if((fabs(pMotionParaOut->linearVelocity) < 0.00001) && (fabs(pMotionParaOut->angularVelocity) < 0.00001))
		{
            if((uMotionState.MotorRpmStruct.leftMotorRpm < 30)&&(uMotionState.MotorRpmStruct.rightMotorRpm < 30))
            {
                pMotionParaOut->MotionCtl = MOTION_DISABLE;
            }
		}
	}
    else if(uMotionParam.MotionCtl == MOTION_CLEAR_ALARM)
    {
		pMotionParaOut->linearVelocity = 0;
		pMotionParaOut->angularVelocity = 0;
        pMotionParaOut->MotionCtl = MOTION_CLEAR_ALARM;
    }

    if(s_VoutStartCount < 10000)
    {
        s_VoutStartCount ++;
    }
    
    if(s_VoutStartCount > V_OUT_DELAY_TIME)
    {
        //------------------------------------------ linear v plan----------------------------------
        if(fabs(pMotionParaOut->linearVelocity - uMotionParam.linearVelocity) < (ACCELERATE_V + DECELERATE_V))
        {
           pMotionParaOut->linearVelocity = uMotionParam.linearVelocity;
        }
        else if(fabs(uMotionParam.linearVelocity) < 0.00009)
        {
            //decelerate
            pMotionParaOut->linearVelocity -= copysignf(DECELERATE_V,pMotionParaOut->linearVelocity);
        }
        else if((pMotionParaOut->linearVelocity * uMotionParam.linearVelocity) >= 0)
        {
            if(fabs(pMotionParaOut->linearVelocity) <= fabs(uMotionParam.linearVelocity))
            {
                //accelerate
                pMotionParaOut->linearVelocity += copysignf(ACCELERATE_V,uMotionParam.linearVelocity);
            }
            else
            {
                //decelerate
                pMotionParaOut->linearVelocity -= copysignf(DECELERATE_V,uMotionParam.linearVelocity);
            }
        }
        else
        {
            //decelerate
            pMotionParaOut->linearVelocity -= copysignf(DECELERATE_V,pMotionParaOut->linearVelocity);
        }

		//------------------------------------------ angular w plan----------------------------------
        if(fabs(pMotionParaOut->angularVelocity - uMotionParam.angularVelocity) < (ACCELERATE_W + DECELERATE_W))
        {
            pMotionParaOut->angularVelocity = uMotionParam.angularVelocity;
        }
        else if(fabs(uMotionParam.angularVelocity) < 0.00009)
        {
            //decelerate
            pMotionParaOut->angularVelocity -= copysignf(DECELERATE_W,pMotionParaOut->angularVelocity);
        }
        else if((pMotionParaOut->angularVelocity * uMotionParam.angularVelocity) >= 0)
        {
            if(fabs(pMotionParaOut->angularVelocity) <= fabs(uMotionParam.angularVelocity))
            {
                //accelerate
                pMotionParaOut->angularVelocity += copysignf(ACCELERATE_W,uMotionParam.angularVelocity);
            }
            else
            {
                //decelerate
                pMotionParaOut->angularVelocity -= copysignf(DECELERATE_W,uMotionParam.angularVelocity);
            }
        }
        else
        {
            //decelerate
            pMotionParaOut->angularVelocity -= copysignf(DECELERATE_W,pMotionParaOut->angularVelocity);
        }
    }

}

/*
******************************************************************************
*	�� �� ��: MotionControl_semiAutomatic
*	����˵��: �˶�����ϵͳ����Զ���
*	��    ��: ��
*	�� �� ֵ: ��
*   ��    ע: ���Ա����豸��������Ե�󣬵ı�������
******************************************************************************
*/
void MotionControl_semiAutomatic(MOTION_STATE_STRUCT uMotionState, MOTION_PARAM_STRUCT *pMotionParam)
{

#define SPEED_AVERAGE   (uMotionState.MotionParmInfo.linearVelocity/60)     //ת��Ϊ���ٶ�

#define LOW_SPEED     	(float)7.0                                          //7.0m/min
#define SAFETY_SPEED    (float)5.0                                          //5.0m/min
#define SAFETY_LENGTH   MOTION_SAFETY_LENGTH                                //0.02m�ֶ�ǰ������

    static float sMovLenth = 0.0;

    LIMIT_SWITCH_INFO_STRUCT uLimitSwitchInfo;
    LimitSwitchInfo_get(&uLimitSwitchInfo);

    if((DriverManageStruct.LeftDrvSta.ConSta == DRIVER_OFFLINE)             //��������ͨ�Ų��ɹ��Ļ����ٶ������ٶ�һֱΪ0
      ||(DriverManageStruct.RightDrvSta.ConSta == DRIVER_OFFLINE)){
        pMotionParam->linearVelocity = 0.0f;
        pMotionParam->angularVelocity = 0.0f;
        return;
    } 
    
    if((DriverManageStruct.LeftDrvSta.ReadySta != DRIVER_WAS_RUNNING)       //���������û��׼��������ٶ������ٶ�һֱΪ0
      ||(DriverManageStruct.RightDrvSta.ReadySta != DRIVER_WAS_RUNNING)){
        pMotionParam->linearVelocity = 0.0f;
        pMotionParam->angularVelocity = 0.0f;
        return;
    }

    if(!(LFO||RFO||LRO||RRO||LFI||RFI||LRI||RRI)){                          //û�д���������ֱ���˳�
        sMovLenth = 0;
        return;
    }

    if(LFI&&RFI&&LRI&&RRI){                                                 //����Ĺ�紫����,�ĸ���紥�����쳣
        pMotionParam->linearVelocity = (float)0.0;                          //��ͣ����
        pMotionParam->angularVelocity = (float)0.0;
        Safety_setFlagBit(BIT_Error_DropSensorsFault,1);                    //�趨�쳣���λ
        return;
    }

    if((LFO&&LRO)||(RFO&&RRO)||(LFO&&RRO)||(RFO&&LRO)){                     //����ĵ��ݴ��������߽ǶԽǴ������������쳣
        pMotionParam->linearVelocity = (float)0.0;                          //��ͣ����
        pMotionParam->angularVelocity = (float)0.0;
        Safety_setFlagBit(BIT_Error_DropSensorsFault,1);                    //�趨�쳣���λ
        return; 
    }
    
    if(LFI||LFO||RFI||RFO){                                                 //�жϳ�ǰ�Ĵ���������
        if(LFO||RFO){                                                       //�ǵ��ݴ�������������ٲ��������
            pMotionParam->angularVelocity = (float)0.0;
            sMovLenth += SPEED_AVERAGE * (float)0.02;
            if(fabs(sMovLenth) > SAFETY_LENGTH){                            //����SAFETY_LENGTH�����ֹͣ
                if(pMotionParam->linearVelocity > (float)0.00001){
                    pMotionParam->linearVelocity = 0.0;
                    BrushCtlStruct.set(BRUSH_DISABLE);
                    Safety_setFlagBit(BIT_Warning_DropSensorsWarn,1);
                }
            }else{
                pMotionParam->linearVelocity = pMotionParam->linearVelocity > SAFETY_SPEED ? \
                    SAFETY_SPEED : pMotionParam->linearVelocity;
            }
        }else{                                                              //ֻ�й�紫��������ʱֻ����
            pMotionParam->linearVelocity = pMotionParam->linearVelocity > LOW_SPEED ? \
                LOW_SPEED : pMotionParam->linearVelocity;
            sMovLenth = 0;
        }
    }else if(LRI||LRO||RRI||RRO){                                           //�жϳ���Ĵ���������
        if(LRO||RRO){                                                       //�ǵ��ݴ�������������ٲ��������
            pMotionParam->angularVelocity = (float)0.0;
            sMovLenth += SPEED_AVERAGE * (float)0.02;
            if(fabs(sMovLenth) > SAFETY_LENGTH){                            //����SAFETY_LENGTH�����ֹͣ
                if(pMotionParam->linearVelocity < (float)-0.00001){
                    pMotionParam->linearVelocity = 0.0;
                    BrushCtlStruct.set(BRUSH_DISABLE);
                    Safety_setFlagBit(BIT_Warning_DropSensorsWarn,1);
                }
            }else{
                pMotionParam->linearVelocity = pMotionParam->linearVelocity < -SAFETY_SPEED ? \
                    -SAFETY_SPEED : pMotionParam->linearVelocity;
            }
        }else{                                                              //ֻ�й�紫��������ʱֻ����
            pMotionParam->linearVelocity = pMotionParam->linearVelocity < -LOW_SPEED ? \
                -LOW_SPEED : pMotionParam->linearVelocity;
            sMovLenth = 0;
        }
    }

}

/*
******************************************************************************
*	�� �� ��: MotionControl_calculateState
*	����˵��: �˶�����ϵͳ״̬��Ϣ��ȡ
*	��    ��: ��
*	�� �� ֵ: ��
*   ��    ע: ���ٶ���ֵʱ��ʹ��\ʧ�ܲ��������ٶ�ֵ
******************************************************************************
*/
void MotionControl_calculateState(MOTION_STATE_STRUCT *pMotionState)
{
    float tLeftRpmValue = 0, tRightRpmValue = 0;
    float tLeftRpmSmoothValue = 0,tRightRpmSmoothValue = 0;

    tLeftRpmValue = DriverManageStruct.LeftDrvSta.rpmVal;
    tRightRpmValue = DriverManageStruct.RightDrvSta.rpmVal;

    tLeftRpmSmoothValue = Filter_insert(RpmFilterPtr[0],tLeftRpmValue);
    tRightRpmSmoothValue = Filter_insert(RpmFilterPtr[1],tRightRpmValue);

    pMotionState->MotorRpmStruct.leftMotorRpm = tLeftRpmSmoothValue;
    pMotionState->MotorRpmStruct.rightMotorRpm = tRightRpmSmoothValue;

    pMotionState->MotorRpmStruct.leftMotorVelocity = (MOTOR_DIR)*tLeftRpmSmoothValue * 2.0f * PI * WHEEL_RADIUS / MOTION_MOTOR_RATIO;
    pMotionState->MotorRpmStruct.rightMotorVelocity = (MOTOR_DIR)*tRightRpmSmoothValue * 2.0f * PI * WHEEL_RADIUS / MOTION_MOTOR_RATIO;
    
    pMotionState->LeftDriverSta = DriverManageStruct.LeftDrvSta.errCode == 0 ? DRIVER_OK : DRIVER_ERR;
    pMotionState->RightDriverSta = DriverManageStruct.RightDrvSta.errCode == 0 ? DRIVER_OK : DRIVER_ERR;

    pMotionState->MotionParmInfo.linearVelocity = (pMotionState->MotorRpmStruct.leftMotorVelocity + pMotionState->MotorRpmStruct.rightMotorVelocity) / 2;
    pMotionState->MotionParmInfo.angularVelocity = (pMotionState->MotorRpmStruct.leftMotorVelocity - pMotionState->MotorRpmStruct.rightMotorVelocity) / WHEEL_TREAD;

    if((fabs(pMotionState->MotionParmInfo.linearVelocity) > 0.001)\
      ||(fabs(pMotionState->MotionParmInfo.angularVelocity) > 0.001)){  //���ٶ�����ٶȲ�Ϊ0��¼����
        static double tSecond = 0.0,tMeter = 0.0,tTotalSecond = 0.0,tTotalMeter = 0.0;
        tSecond = 0.02; tMeter = (fabs(pMotionState->MotionParmInfo.linearVelocity)/60 * 0.02);
        pMotionState->MileageInfo.onceSecond += tSecond;
        pMotionState->MileageInfo.onceMeter += tMeter;
        tTotalSecond += tSecond;
        tTotalMeter += tMeter;
        if(tTotalSecond > floor(tTotalSecond)){
            pMotionState->MileageInfo.totalSecond += floor(tTotalSecond);                  
            tTotalSecond -= floor(tTotalSecond);
        }
        if(tTotalMeter > floor(tTotalMeter)){
            pMotionState->MileageInfo.totalMeter += floor(tTotalMeter);
            tTotalMeter -= floor(tTotalMeter);
        }
    }
                                                                    
    static ROBOT_MILEAGE_INFO_UNION sRobMileInfo = {0};              	//ÿ���30min/10m��¼һ�������
    if(RoTaskMagStruct.RunMethon == AUTO_RUN && RoTaskMagStruct.RunSta == RUNNING){
        if((pMotionState->MileageInfo.totalSecond > (sRobMileInfo.Struct.totalSecond + RECORDE_PER_SECOND))\
            ||(pMotionState->MileageInfo.totalMeter > (sRobMileInfo.Struct.totalMeter + RECORDE_PER_METER))){
            sRobMileInfo.Struct.totalSecond = pMotionState->MileageInfo.totalSecond;
            sRobMileInfo.Struct.totalMeter = pMotionState->MileageInfo.totalMeter;
            ParamInfoStruct.robotMileageStruct.write(sRobMileInfo);
        }
    }
}

/*
******************************************************************************
*	�� �� ��: MotionControl_loop
*	����˵��: �˶�����ϵͳ��ѭ��
*	��    ��: ��
*	�� �� ֵ: ��
*   ��    ע: ���ٶ���ֵʱ��ʹ��\ʧ�ܲ��������ٶ�ֵ
******************************************************************************
*/
void MotionControl_loop(void)
{
    MotionControl_calculateState(&MotionCtlStruct.StateInfo);

    MotionControl_semiAutomatic(MotionCtlStruct.StateInfo,
                                &MotionCtlStruct.ParamConfigInfo);

	MotionControl_velocityPlan(MotionCtlStruct.StateInfo,
                               MotionCtlStruct.ParamConfigInfo,
							   &MotionCtlStruct.ParamPlanInfo);
	
	MotionControl_motionResolving(MotionCtlStruct.ParamPlanInfo,
								  &MotionCtlStruct.OutputParam);

	MotionControl_driverOutput(MotionCtlStruct.OutputParam);
}
