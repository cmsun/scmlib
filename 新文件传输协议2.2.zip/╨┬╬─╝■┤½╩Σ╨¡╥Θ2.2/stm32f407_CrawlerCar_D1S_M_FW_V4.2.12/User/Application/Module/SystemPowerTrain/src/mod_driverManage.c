/**
*****************************************************************************
* @��  ���� mod_driverManage.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 7-Jun-2018
* @��  ���� ����������ģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/07����ʼ�汾
*   2019/01/03: ���ͨ�ŵ��ߵ����⣬�����������߼�,����OK
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_driverManage.h"

//Ӳ������
#include "hardware.h"

//֧���ļ�
#include "mod_modbusHostInfo.h"
#include "mod_logSys2Info.h"

//�궨��
#define LEFT_DRIVER_ADDR  1
#define RIGHT_DRIVER_ADDR 2

#define DEBUG       true	//modbus���ͽ������ָʾ�ƣ����Ե���		
#define FRAME_SPACE	true	//����֡���5mSec�������true�Ļ�,����ɸ�λʱ�ٶ��޷�����

//����ṹ��
typedef struct{
	int16_t p282; //   ENABLE/DIABLE/CLARM
    int16_t p282_newVal; 
    int16_t p282_setVal;
    int16_t p324; //   RPM SET
	int16_t p324_newVal;
    int16_t p324_setVal;
}WRITE_PARAM_06H_STRUCT;

typedef struct{
    int16_t p200; //   DRIVER STATE 
    int16_t p200_bCheck;
    int16_t p202; //   ERR CODE
    int16_t p202_bCheck; 	
    int16_t p221; //   RPM GET
    int16_t p221_bCheck; 
    int16_t p282; //   CMD GET
    int16_t p282_bCheck;
}READ_PARAM_03H_STRUCT;

typedef struct{
    WRITE_PARAM_06H_STRUCT  WriteParamInfo;
    READ_PARAM_03H_STRUCT   ReadParamInfo;
}MOTOR_DRIVER_PARAM_STRUCT;

//��̬����
static void DriverManage_init(void);
static void DriverManage_autoPoll(void);
static void DriverManage_check(void);

static void LeftDriver_valRefresh(void);
static void LeftDriver_valClean(void);
static void LeftDriver_rpmCheck(void);
static void LeftDriver_errCheck(void);
static void LeftDriver_staCheck(void);
static void LeftDriver_cmdCheck(void);
static void LeftDriver_rpmSet(int16_t rpmVal);
static void LeftDriver_drvCtl(DRIVER_CONTROL_ENUM drvCtl);

static void RightDriver_valRefresh(void);
static void RightDriver_valClean(void);
static void RightDriver_rpmCheck(void);
static void RightDriver_errCheck(void);
static void RightDriver_staCheck(void);
static void RightDriver_cmdCheck(void);
static void RightDriver_rpmSet(int16_t rpmVal);
static void RightDriver_drvCtl(DRIVER_CONTROL_ENUM drvCtl);

//��̬����
MOTOR_DRIVER_PARAM_STRUCT sLeftDriverParam,sRightDriverParam;

//ȫ�ֱ���
DRIVER_MANAGE_STRUCT DriverManageStruct = {

	.init = DriverManage_init,
	.check = DriverManage_check,
	.autoPoll = DriverManage_autoPoll,
	
	.LeftDrvCtl.rpmCheck = LeftDriver_rpmCheck,
	.LeftDrvCtl.errCheck = LeftDriver_errCheck,
    .LeftDrvCtl.staCheck = LeftDriver_staCheck,
    .LeftDrvCtl.cmdCheck = LeftDriver_cmdCheck,
	.LeftDrvCtl.drvCtl = LeftDriver_drvCtl,
	.LeftDrvCtl.rpmSet = LeftDriver_rpmSet,
	.LeftDrvCtl.valClean = 	LeftDriver_valClean,
	.LeftDrvCtl.valRefresh = LeftDriver_valRefresh,
	
	.RightDrvCtl.rpmCheck = RightDriver_rpmCheck,
	.RightDrvCtl.errCheck = RightDriver_errCheck,
    .RightDrvCtl.staCheck = RightDriver_staCheck,
    .RightDrvCtl.cmdCheck = RightDriver_cmdCheck,
	.RightDrvCtl.drvCtl = RightDriver_drvCtl,
	.RightDrvCtl.rpmSet = RightDriver_rpmSet,
	.RightDrvCtl.valRefresh = RightDriver_valRefresh,
	.RightDrvCtl.valClean = RightDriver_valClean,

};



/*
******************************************************************************
*	�� �� ��: DriverManage_init
*	����˵��: ��������ģ���ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void DriverManage_init(void)
{
    DriverManageStruct.LeftDrvSta.ConSta = DRIVER_OFFLINE;
    DriverManageStruct.LeftDrvSta.ReadySta = DRIVER_DEFAULT_STATE;
	DriverManageStruct.LeftDrvSta.rpmVal = 0;
	DriverManageStruct.LeftDrvSta.errCode = 0;

    DriverManageStruct.RightDrvSta.ConSta = DRIVER_OFFLINE;
    DriverManageStruct.RightDrvSta.ReadySta = DRIVER_DEFAULT_STATE;
	DriverManageStruct.RightDrvSta.rpmVal = 0;
	DriverManageStruct.RightDrvSta.errCode = 0;

	LeftDriver_valRefresh();
	RightDriver_valRefresh();
}


/*
******************************************************************************
*	�� �� ��: LeftDriver_valRefresh
*	����˵��: ������������ˢ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_valRefresh(void)
{
    sLeftDriverParam.ReadParamInfo.p202_bCheck = 1;
    sLeftDriverParam.ReadParamInfo.p200_bCheck = 1;
    sLeftDriverParam.ReadParamInfo.p221_bCheck = 1;
    sLeftDriverParam.ReadParamInfo.p282_bCheck = 1;
    
    sLeftDriverParam.WriteParamInfo.p324 = 0;
    sLeftDriverParam.WriteParamInfo.p282 = DRIVER_NONE_CMD;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_valClean
*	����˵��: ����������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_valClean(void)
{
    sLeftDriverParam.ReadParamInfo.p200 = 0;
    sLeftDriverParam.ReadParamInfo.p202 = 0;
    sLeftDriverParam.ReadParamInfo.p221 = 0;
    sLeftDriverParam.ReadParamInfo.p282 = 0;
    
	sLeftDriverParam.WriteParamInfo.p324_setVal = 0;
    sLeftDriverParam.WriteParamInfo.p282_setVal = DRIVER_NONE_CMD;
    
	DriverManageStruct.LeftDrvSta.ConSta = DRIVER_OFFLINE;
    DriverManageStruct.LeftDrvSta.CtlCmd = DRIVER_NONE_CMD;
	DriverManageStruct.LeftDrvSta.ReadySta = DRIVER_DEFAULT_STATE;
	DriverManageStruct.LeftDrvSta.rpmVal = 0;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_rpmCheck
*	����˵��: ����������ȡת��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_rpmCheck(void)
{
    sLeftDriverParam.ReadParamInfo.p221_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_errCheck
*	����˵��: ���������쳣���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_errCheck(void)
{
    sLeftDriverParam.ReadParamInfo.p202_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_staCheck
*	����˵��: ��������״̬���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_staCheck(void)
{
    sLeftDriverParam.ReadParamInfo.p200_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_cmdCheck
*	����˵��: ��������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_cmdCheck(void)
{
    sLeftDriverParam.ReadParamInfo.p282_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_rpmSet
*	����˵��: ���������ٶ��趨
*	��    ��: rpmVal:�趨ת��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_rpmSet(int16_t rpmVal)
{
    sLeftDriverParam.WriteParamInfo.p324_setVal = rpmVal;
}

/*
******************************************************************************
*	�� �� ��: LeftDriver_drvCtl
*	����˵��: ������������
*	��    ��: drvCtl����������
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void LeftDriver_drvCtl(DRIVER_CONTROL_ENUM drvCtl)
{
    DriverManageStruct.LeftDrvCtl.CurCmd = drvCtl;
    sLeftDriverParam.WriteParamInfo.p282_setVal = drvCtl;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_valRefresh
*	����˵��: ������������ˢ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_valRefresh(void)
{
    sRightDriverParam.ReadParamInfo.p200_bCheck = 1;
    sRightDriverParam.ReadParamInfo.p202_bCheck = 1;
    sRightDriverParam.ReadParamInfo.p221_bCheck = 1;
    sRightDriverParam.ReadParamInfo.p282_bCheck = 1;
    
    sRightDriverParam.WriteParamInfo.p324 = 0;
    sRightDriverParam.WriteParamInfo.p282 = DRIVER_NONE_CMD;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_valClean
*	����˵��: ����������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_valClean(void)
{
    sRightDriverParam.ReadParamInfo.p200 = 0;
    sRightDriverParam.ReadParamInfo.p202 = 0;
    sRightDriverParam.ReadParamInfo.p221 = 0;
    sRightDriverParam.ReadParamInfo.p282 = 0;
    
	sRightDriverParam.WriteParamInfo.p324_setVal = 0;
    sRightDriverParam.WriteParamInfo.p282_setVal = DRIVER_NONE_CMD;
    
    DriverManageStruct.RightDrvSta.ConSta = DRIVER_OFFLINE;
    DriverManageStruct.RightDrvSta.CtlCmd = DRIVER_NONE_CMD;
	DriverManageStruct.RightDrvSta.ReadySta = DRIVER_DEFAULT_STATE;
	DriverManageStruct.RightDrvSta.rpmVal = 0;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_rpmCheck
*	����˵��: ����������ȡת��
*	��    ��: ��
*	�� �� ֵ: ʵʱת��ֵ
******************************************************************************
*/
__inline void RightDriver_rpmCheck(void)
{
    sRightDriverParam.ReadParamInfo.p221_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_errCheck
*	����˵��: ���������쳣���
*	��    ��: ��
*	�� �� ֵ: ʵʱת��ֵ
******************************************************************************
*/
__inline void RightDriver_errCheck(void)
{
    sRightDriverParam.ReadParamInfo.p202_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_staCheck
*	����˵��: ��������״̬���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_staCheck(void)
{
    sRightDriverParam.ReadParamInfo.p200_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_cmdCheck
*	����˵��: ��������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_cmdCheck(void)
{
    sRightDriverParam.ReadParamInfo.p282_bCheck = 1;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_rpmSet
*	����˵��: ���������ٶ��趨
*	��    ��: rpmVal:�趨ת��
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_rpmSet(int16_t rpmVal)
{
    sRightDriverParam.WriteParamInfo.p324_setVal = rpmVal;
}

/*
******************************************************************************
*	�� �� ��: RightDriver_drvCtl
*	����˵��: ������������
*	��    ��: drvCtl����������
*	�� �� ֵ: ��
******************************************************************************
*/
__inline void RightDriver_drvCtl(DRIVER_CONTROL_ENUM drvCtl)
{
    DriverManageStruct.RightDrvCtl.CurCmd = drvCtl;
    sRightDriverParam.WriteParamInfo.p282_setVal = drvCtl;
}

/*
******************************************************************************
*	�� �� ��: DriverManage_autoPoll
*	����˵��: ������������������,5ms���ڸպÿ��Է���10�ֽ�
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#define MODBUS_ACK_PROCESS(ConnectStatus) \
{\
	if(s_TimeCnt > 0){\
		s_TimeCnt -= 1;\
	}else{\
		DialogState = 0;\
		if(s_ErrCnt > 0){\
			s_ErrCnt -= 1;\
		}else{\
            ConnectStatus = DRIVER_OFFLINE;\
			s_ErrCnt = MAX_ERR_CNT;\
            ModbusStatus += 1;\
		}\
		s_TimeCnt = MODBUS_TIMEOUT;\
	}\
}

void DriverManage_autoPoll(void)
{
#define MODBUS_TIMEOUT  20   // 5*20 100msͨ�ų�ʱ
#define MAX_ERR_CNT     3    // �����������û��Ӧ�𱨴�
	static int16_t s_TimeCnt = MODBUS_TIMEOUT;
	static int16_t s_ErrCnt = MAX_ERR_CNT;
	static uint16_t ModbusStatus = 0;
	static uint16_t DialogState = 0;

	switch(ModbusStatus){
		case 0:{
			if(DialogState == 0){
				if(sLeftDriverParam.WriteParamInfo.p282 != sLeftDriverParam.WriteParamInfo.p282_setVal){
					MODH_Send06H(LEFT_DRIVER_ADDR,282,sLeftDriverParam.WriteParamInfo.p282_setVal);
                    sLeftDriverParam.WriteParamInfo.p282_newVal = sLeftDriverParam.WriteParamInfo.p282_setVal;
                    ModbusStatus = 0;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
				}
			}else{
				if(g_tModH.fAck06H == 1){
					DialogState = 0;
					ModbusStatus = 1;
					s_ErrCnt = MAX_ERR_CNT;
                    DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
                    sLeftDriverParam.WriteParamInfo.p282 = sLeftDriverParam.WriteParamInfo.p282_newVal;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}	
		}
		case 1:{
			if(DialogState == 0){
				if(sRightDriverParam.WriteParamInfo.p282 != sRightDriverParam.WriteParamInfo.p282_setVal){
					MODH_Send06H(RIGHT_DRIVER_ADDR,282,sRightDriverParam.WriteParamInfo.p282_setVal);
                    sRightDriverParam.WriteParamInfo.p282_newVal = sRightDriverParam.WriteParamInfo.p282_setVal;
                    ModbusStatus = 1;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
				}
			}else{
				if(g_tModH.fAck06H == 1){
					DialogState = 0;
					ModbusStatus = 2;
					s_ErrCnt = MAX_ERR_CNT;
                    DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
					sRightDriverParam.WriteParamInfo.p282 = sRightDriverParam.WriteParamInfo.p282_newVal;   
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}                
		}
		case 2:{
			if(DialogState == 0){
				if(sLeftDriverParam.WriteParamInfo.p324 != sLeftDriverParam.WriteParamInfo.p324_setVal){
                    sLeftDriverParam.WriteParamInfo.p324_newVal = sLeftDriverParam.WriteParamInfo.p324_setVal;
					MODH_Send06H(LEFT_DRIVER_ADDR,324,sLeftDriverParam.WriteParamInfo.p324_setVal);
                    ModbusStatus = 2;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck06H == 1){
					DialogState = 0;
					ModbusStatus = 3;
					s_ErrCnt = MAX_ERR_CNT;
                    DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
                    sLeftDriverParam.WriteParamInfo.p324 = sLeftDriverParam.WriteParamInfo.p324_newVal;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}	
		}
		case 3:{
			if(DialogState == 0){
				if(sRightDriverParam.WriteParamInfo.p324 != sRightDriverParam.WriteParamInfo.p324_setVal){
                    sRightDriverParam.WriteParamInfo.p324_newVal = sRightDriverParam.WriteParamInfo.p324_setVal;
					MODH_Send06H(RIGHT_DRIVER_ADDR,324,sRightDriverParam.WriteParamInfo.p324_setVal);
                    ModbusStatus = 3;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck06H == 1){
					DialogState = 0;
					ModbusStatus = 4;
					s_ErrCnt = MAX_ERR_CNT;
                    DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
                    sRightDriverParam.WriteParamInfo.p324 = sRightDriverParam.WriteParamInfo.p324_newVal;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}	
		}
		case 4:{
			if(DialogState == 0){
				if(sLeftDriverParam.ReadParamInfo.p221_bCheck == 1){
					MODH_Send03H(LEFT_DRIVER_ADDR,221,1);
                    ModbusStatus = 4;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 5;
					s_ErrCnt = MAX_ERR_CNT;
                    sLeftDriverParam.ReadParamInfo.p221_bCheck = 0;
					sLeftDriverParam.ReadParamInfo.p221 = g_tVar.P221;
					DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
					DriverManageStruct.LeftDrvSta.rpmVal = sLeftDriverParam.ReadParamInfo.p221;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}
		}
		case 5:{
			if(DialogState == 0){
				if(sRightDriverParam.ReadParamInfo.p221_bCheck == 1){
					MODH_Send03H(RIGHT_DRIVER_ADDR,221,1);
                    ModbusStatus = 5;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 6;
					s_ErrCnt = MAX_ERR_CNT;
                    sRightDriverParam.ReadParamInfo.p221_bCheck = 0;
					sRightDriverParam.ReadParamInfo.p221 = g_tVar.P221;
                    DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
					DriverManageStruct.RightDrvSta.rpmVal = sRightDriverParam.ReadParamInfo.p221;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}
		}
		case 6:{
			if(DialogState == 0){
				if(sLeftDriverParam.ReadParamInfo.p202_bCheck == 1){
					MODH_Send03H(LEFT_DRIVER_ADDR,202,1);
                    ModbusStatus = 6;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 7;
					s_ErrCnt = MAX_ERR_CNT;
                    sLeftDriverParam.ReadParamInfo.p202_bCheck = 0;
					sLeftDriverParam.ReadParamInfo.p202 = g_tVar.P202;
                    DriverManageStruct.LeftDrvSta.errCode = sLeftDriverParam.ReadParamInfo.p202;
					DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}
		}
		case 7:{
			if(DialogState == 0){
				if(sRightDriverParam.ReadParamInfo.p202_bCheck == 1){
					MODH_Send03H(RIGHT_DRIVER_ADDR,202,1);
                    ModbusStatus = 7;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 8;
					s_ErrCnt = MAX_ERR_CNT;
                    sRightDriverParam.ReadParamInfo.p202_bCheck = 0;
					sRightDriverParam.ReadParamInfo.p202 = g_tVar.P202;
                    DriverManageStruct.RightDrvSta.errCode = sRightDriverParam.ReadParamInfo.p202;
					DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}
		}
		case 8:{
			if(DialogState == 0){
				if(sLeftDriverParam.ReadParamInfo.p200_bCheck == 1){
					MODH_Send03H(LEFT_DRIVER_ADDR,200,1);
                    ModbusStatus = 8;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 9;
					s_ErrCnt = MAX_ERR_CNT;
                    sLeftDriverParam.ReadParamInfo.p200_bCheck = 0;
					sLeftDriverParam.ReadParamInfo.p200 = g_tVar.P200;
                    DriverManageStruct.LeftDrvSta.ReadySta = (READY_STATE_ENUM)g_tVar.P200;
					DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}
		}
		case 9:{
			if(DialogState == 0){
				if(sRightDriverParam.ReadParamInfo.p200_bCheck == 1){
					MODH_Send03H(RIGHT_DRIVER_ADDR,200,1);
                    ModbusStatus = 9;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 10;
					s_ErrCnt = MAX_ERR_CNT;
                    sRightDriverParam.ReadParamInfo.p200_bCheck = 0;
					sRightDriverParam.ReadParamInfo.p200 = g_tVar.P200;
					DriverManageStruct.RightDrvSta.ReadySta = (READY_STATE_ENUM)g_tVar.P200;                    
					DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}
		}
		case 10:{
			if(DialogState == 0){
				if(sLeftDriverParam.ReadParamInfo.p282_bCheck == 1){
					MODH_Send03H(LEFT_DRIVER_ADDR,282,1);
                    ModbusStatus = 10;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 11;
					s_ErrCnt = MAX_ERR_CNT;
                    sLeftDriverParam.ReadParamInfo.p282_bCheck = 0;
					sLeftDriverParam.ReadParamInfo.p282 = g_tVar.P282;
                    DriverManageStruct.LeftDrvSta.CtlCmd = (DRIVER_CONTROL_ENUM)g_tVar.P282;
					DriverManageStruct.LeftDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.LeftDrvSta.ConSta);
                    break;
				}
			}
		}
		case 11:{
			if(DialogState == 0){
				if(sRightDriverParam.ReadParamInfo.p282_bCheck == 1){
					MODH_Send03H(RIGHT_DRIVER_ADDR,282,1);
                    ModbusStatus = 11;
					DialogState = 1;
					if(DEBUG)Led_setState(LED_1,LED_ON);
					break;
                }
			}else{
				if(g_tModH.fAck03H == 1){
					DialogState = 0;
					ModbusStatus = 0;
					s_ErrCnt = MAX_ERR_CNT;
                    sRightDriverParam.ReadParamInfo.p282_bCheck = 0;
					sRightDriverParam.ReadParamInfo.p282 = g_tVar.P282;
					DriverManageStruct.RightDrvSta.CtlCmd = (DRIVER_CONTROL_ENUM)g_tVar.P282;                    
					DriverManageStruct.RightDrvSta.ConSta = DRIVER_ONLINE;
					if(DEBUG)Led_setState(LED_1,LED_OFF);
					if(FRAME_SPACE)break;
				}else{
					MODBUS_ACK_PROCESS(DriverManageStruct.RightDrvSta.ConSta);
                    break;
				}
			}
		}
		default:{
			if(ModbusStatus == 12){          								//�����������ڶϵ���������Ҫˢ����ر���,ֻ�е��������ϵ�Ż�valClean()
				LeftDriver_valClean();
				RightDriver_valClean();
				LOG_INF("Driver was offline,so clean the value, ModbusStatus = %d",ModbusStatus);
			}
            ModbusStatus = 0;												//ֻ�е�û����Ҫˢ�µı�����ʱ��Ż�ִ���ⲽ
		}break;
	}
    
}

/*
******************************************************************************
*	�� �� ��: DriverManage_check
*	����˵��: ������������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
static void DriverManage_check(void)
{
#define ERR_CHECK_PRIOD  2													//50MS -> 20*(2+1)
	static int16_t sDriverChoose = 0;
	static int16_t sErrCheckPriod = ERR_CHECK_PRIOD;
    
	if(sErrCheckPriod > 0){
		sErrCheckPriod -= 1 ;
	}else{
		if(sDriverChoose == 0){
			LeftDriver_errCheck();
			sDriverChoose = 1; 
		}else if(sDriverChoose == 1){
			RightDriver_errCheck();
			sDriverChoose = 2; 
		}else if(sDriverChoose == 2){
			LeftDriver_rpmCheck();
            sDriverChoose = 3; 			            
		}else if(sDriverChoose == 3){
			RightDriver_rpmCheck();
			sDriverChoose = 4; 
		}else if(sDriverChoose == 4){
			LeftDriver_staCheck();
            sDriverChoose = 5; 			            
		}else if(sDriverChoose == 5){
			RightDriver_staCheck();
			sDriverChoose = 6; 
		}else if(sDriverChoose == 6){
			LeftDriver_cmdCheck();
			sDriverChoose = 7; 
		}else if(sDriverChoose == 7){
			RightDriver_cmdCheck();
			sDriverChoose = 0; 
        }
        
		sErrCheckPriod = ERR_CHECK_PRIOD;
	}
}
