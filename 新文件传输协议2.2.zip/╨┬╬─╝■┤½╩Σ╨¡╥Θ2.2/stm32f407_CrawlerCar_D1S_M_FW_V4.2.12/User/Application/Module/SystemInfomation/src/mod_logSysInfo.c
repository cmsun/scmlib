/**
*****************************************************************************
* @��  ��:  mod_logSysInfo.c 
* @��  ��:  00Jackey
* @��  ��:  V1.0.0
* @��  ��:  6-Jun-2018
* @��  ��:  ��־��Ϣϵͳ���ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/06: ��ʼ�汾����ͨ����ɺ��������Բ���
*   2018/09/19: �ȶ��汾
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_logSysInfo.h"

//Ӳ������
#include "hardware.h"

//�궨��
#define CHIPSET_PAGE             	(uint32_t)M95M02DR_PAGE_SIZE

#define LOGSYS_OUTAGE_ADDRESS   	(uint32_t)(CHIPSET_PAGE * 10)
#define LOGSYS_INDEX_ADDRESS    	(uint32_t)(CHIPSET_PAGE * 11)
#define LOGSYS_INFO_ADDRESS     	(uint32_t)(CHIPSET_PAGE * 12)

#define LOGSYS_INFO_TOTAL_CNT      (uint32_t)(2000)
#define LOGSYS_INFO_TOAL_SIZE      (uint32_t)(LOGSYS_INFO_TOTAL_CNT * EACH_LOG_SPACE)

#define LOG_WRITE_FLAG             (uint8_t)(0xA5)

#define LOGSYS_WRITE				M95m02dr_write
#define LOGSYS_READ					M95m02dr_read


//����ṹ��
typedef struct{
	uint32_t curIndex;
	uint32_t cntTotal;
	uint8_t  writeFlag;
}LOG_INDEX_STRUCT;

//����������
typedef union{
	LOG_INDEX_STRUCT IndexStruct;
	uint8_t IndexArry[LOG_INDEX_TOTAL+1];
}LOG_INDEX_UNION;


//��̬����
static LOG_PROC_STATE_ENUM LogSysInfo_initInfo(void);
static LOG_PROC_STATE_ENUM LogSysInfo_recordInfo(LOG_CONTENT_UNION uLogContentUnion);
static LOG_PROC_STATE_ENUM LogSysInfo_getRecentInfo(LOG_CONTENT_UNION* pLogContentUnion, int32_t recentNum);
static LOG_PROC_STATE_ENUM LogSysInfo_getSerialInfo(LOG_CONTENT_UNION* pLogContentUnion, int32_t serialNum);

static LOG_PROC_STATE_ENUM LogSysInfo_initIndex(void);
static LOG_PROC_STATE_ENUM LogSysInfo_setIndex(LOG_INDEX_UNION uLogIndexUnion);
static LOG_PROC_STATE_ENUM LogSysInfo_getIndex(LOG_INDEX_UNION* pLogIndexUnion);

static LOG_PROC_STATE_ENUM LogSysInfo_clrOutage(void);
static LOG_PROC_STATE_ENUM LogSysInfo_setOutage(LOG_CONTENT_UNION  uLogContentUnion);
static LOG_PROC_STATE_ENUM LogSysInfo_getOutage(LOG_CONTENT_UNION* pLogContentUnion);

static LOG_PROC_STATE_ENUM LogSysInfo_init(void);

static uint32_t LogSysInfo_getRawTotal(void);

static uint8_t LogSysInfo_calcXor8(uint8_t *pVarArry, uint8_t len);

//��̬����
LOG_INDEX_UNION	sLogIndexUnion = {

	.IndexStruct.curIndex = (LOGSYS_INFO_ADDRESS - EACH_LOG_SPACE),
    .IndexStruct.cntTotal = 0,
    .IndexStruct.writeFlag = LOG_WRITE_FLAG,
};

//ȫ�ֱ���
LOGSYS_INFO_STRUCT LogSysInfoStruct = {

    .ContentStruct.init = LogSysInfo_initInfo,
    .ContentStruct.record = LogSysInfo_recordInfo,
    .ContentStruct.getRecent = LogSysInfo_getRecentInfo,
    .ContentStruct.getSerial = LogSysInfo_getSerialInfo,

    .OutageStruct.clr = LogSysInfo_clrOutage,
    .OutageStruct.set = LogSysInfo_setOutage,
    .OutageStruct.get = LogSysInfo_getOutage,

    .init = LogSysInfo_init,

	.getRawTotal = LogSysInfo_getRawTotal,
};



/*
******************************************************************************
*	�� �� ��: LogSysInfo_init
*	����˵��: ��־ϵͳ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_init(void)
{
	if(LOG_PROC_FAILED == LogSysInfo_initIndex())
		return LOG_PROC_FAILED;
	else 
		return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_getRawTotal
*	����˵��: ��ȡ��־�����洢����־����
*	��    ��: ��
*	�� �� ֵ: ִ��״̬
******************************************************************************
*/
uint32_t LogSysInfo_getRawTotal(void)
{
	return sLogIndexUnion.IndexStruct.cntTotal;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_initIndex
*	����˵��: ��־������ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_initIndex(void)
{
	LOG_INDEX_UNION tLogIndexUnion;
    LOG_PROC_STATE_ENUM rState;
    
	rState = LogSysInfo_getIndex(&tLogIndexUnion);
	if(rState ==  LOG_PROC_FAILED){
		LOGSYS_WRITE(sLogIndexUnion.IndexArry,LOGSYS_INDEX_ADDRESS,sizeof(LOG_INDEX_STRUCT));
		rState = LogSysInfo_getIndex(&tLogIndexUnion);
		if(rState ==  LOG_PROC_FAILED){
			rState = LOG_PROC_FAILED;
		}
	}else{
		sLogIndexUnion = tLogIndexUnion;
        rState = LOG_PROC_SUCCEED;
	}

	return rState;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_setIndex
*	����˵��: �洢��־����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_setIndex(LOG_INDEX_UNION uLogIndexUnion)
{
	sLogIndexUnion = uLogIndexUnion;
	LOGSYS_WRITE(uLogIndexUnion.IndexArry,LOGSYS_INDEX_ADDRESS,sizeof(LOG_INDEX_UNION));
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_getIndex
*	����˵��: ��ȡ��־����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_getIndex(LOG_INDEX_UNION* pLogIndexUnion)
{
	LOGSYS_READ(pLogIndexUnion->IndexArry,LOGSYS_INDEX_ADDRESS,sizeof(LOG_INDEX_UNION));
	if(pLogIndexUnion->IndexArry[LOG_INDEX_TOTAL] != LOG_WRITE_FLAG){
		return LOG_PROC_FAILED;
	}else{
		return LOG_PROC_SUCCEED;
	}
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_initInfo
*	����˵��: ��־ϵͳ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_initInfo(void)
{
	LOG_INDEX_UNION tLogIndexUnion;
	LOG_CONTENT_UNION  tLogOutageUnion;

	//1st: get the SYS_LOG_INDEX_ADDRESS page 
	LogSysInfo_getIndex(&tLogIndexUnion);
	//2nd: get the powerdown logging
	LogSysInfo_getOutage(&tLogOutageUnion);
	//3rd: write the log at the syslog
	if(tLogOutageUnion.ContentStruct.writeFlag == LOG_WRITE_FLAG){
		LogSysInfo_recordInfo(tLogOutageUnion);
	}else{
		/* warnning  --------------------*/
	}
	//4th: erase the power outage buff page
	LogSysInfo_clrOutage();
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_recordInfo
*	����˵��: ��¼һ����־��Ϣ����������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_recordInfo(LOG_CONTENT_UNION uLogContentUnion)
{
	/*1st: According to index calculate the adress */
	sLogIndexUnion.IndexStruct.cntTotal += 1;	
	sLogIndexUnion.IndexStruct.curIndex = (sLogIndexUnion.IndexStruct.cntTotal - 1)%\
        LOGSYS_INFO_TOTAL_CNT * EACH_LOG_SPACE + LOGSYS_INFO_ADDRESS;
	if(sLogIndexUnion.IndexStruct.curIndex >= (LOGSYS_INFO_TOAL_SIZE + LOGSYS_INFO_ADDRESS))
		sLogIndexUnion.IndexStruct.curIndex = LOGSYS_INFO_ADDRESS;
	/*2nd: record the log index to eeprom */
    sLogIndexUnion.IndexStruct.writeFlag = LOG_WRITE_FLAG;
	LogSysInfo_setIndex(sLogIndexUnion);
	/*3rd: get the log number */
	uLogContentUnion.ContentStruct.curNum = sLogIndexUnion.IndexStruct.cntTotal;
	uLogContentUnion.ContentStruct.curTime = RTCx_getCount();
	uLogContentUnion.ContentStruct.verifyVal = LogSysInfo_calcXor8(uLogContentUnion.ConentArry,LOG_CONTENT_TOTAL);
	uLogContentUnion.ContentStruct.writeFlag = LOG_WRITE_FLAG;
    /*4th: record the loginfo */
	LOGSYS_WRITE(uLogContentUnion.ConentArry,sLogIndexUnion.IndexStruct.curIndex,EACH_LOG_SPACE);

	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_getRecentInfo
*	����˵��: ��ȡ���ĳһ����־��Ϣ
*	��    ��: pLogContentUnion:��־��Ϣָ�� recentNum: 0��ʾ�������־��(0~LOGSYS_INFO_TOTAL_CNT-1)
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_getRecentInfo(LOG_CONTENT_UNION* pLogContentUnion, int32_t recentNum)
{
	int32_t tSysLogAddr = 0;

	/*Only more than need is ok*/
	if(sLogIndexUnion.IndexStruct.cntTotal <= recentNum){
		return LOG_PROC_FAILED;
	}
	
	/* Get the real index */
	tSysLogAddr = ((sLogIndexUnion.IndexStruct.cntTotal - recentNum - 1) % LOGSYS_INFO_TOTAL_CNT) *\
		EACH_LOG_SPACE + LOGSYS_INFO_ADDRESS;
	/* For protect , do not reach there */
	if(tSysLogAddr < LOGSYS_INFO_ADDRESS){
		tSysLogAddr = LOGSYS_INFO_TOAL_SIZE + LOGSYS_INFO_ADDRESS - EACH_LOG_SPACE;
	}
	
	LOGSYS_READ(pLogContentUnion->ConentArry,tSysLogAddr,EACH_LOG_SPACE);
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_getSerialInfo
*	����˵��: ��ȡָ����ŵ���־
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_getSerialInfo(LOG_CONTENT_UNION* pLogContentUnion, int32_t serNum)
{
	int32_t tSysLogAddr = 0x000000;
	int32_t tSysLogNum = 0;

	/*Only more than need is ok*/
	if(serNum <= 0){
		return LOG_PROC_FAILED;
	}
	
	if(sLogIndexUnion.IndexStruct.cntTotal < serNum){
		return LOG_PROC_FAILED;
	}
	
	tSysLogNum = serNum % LOGSYS_INFO_TOTAL_CNT;
	tSysLogAddr = (tSysLogNum -1) * EACH_LOG_SPACE + LOGSYS_INFO_ADDRESS; 

	LOGSYS_READ(pLogContentUnion->ConentArry,tSysLogAddr,EACH_LOG_SPACE);
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_clrLogOutage
*	����˵��: �����������־����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_clrOutage(void)
{
	uint8_t tBytesFill[EACH_LOG_SPACE]= {0};
	
	LOGSYS_WRITE(tBytesFill,LOGSYS_OUTAGE_ADDRESS,EACH_LOG_SPACE);
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_setLogOutage
*	����˵��: �洢��������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_setOutage(LOG_CONTENT_UNION uLogContentUnion)
{
	LOGSYS_WRITE(uLogContentUnion.ConentArry,LOGSYS_OUTAGE_ADDRESS,EACH_LOG_SPACE);
	
	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_getOutage
*	����˵��: ��ȡ��������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
LOG_PROC_STATE_ENUM LogSysInfo_getOutage(LOG_CONTENT_UNION* pLogContentUnion)
{
	LOGSYS_READ(pLogContentUnion->ConentArry,LOGSYS_OUTAGE_ADDRESS,EACH_LOG_SPACE);

	return LOG_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: LogSysInfo_calcXor8
*	����˵��: ����У��ֵ
*	��    ��: pVarArry:��ҪУ������� len�����ݳ���
*	�� �� ֵ: ��
******************************************************************************
*/
uint8_t LogSysInfo_calcXor8(uint8_t *pVarArry, uint8_t len)
{
	uint8_t rvalue;
	rvalue = pVarArry[0];

	for(uint8_t i = 1; i < len; i++){
		rvalue ^= pVarArry[i];
	}

	return rvalue;
}
