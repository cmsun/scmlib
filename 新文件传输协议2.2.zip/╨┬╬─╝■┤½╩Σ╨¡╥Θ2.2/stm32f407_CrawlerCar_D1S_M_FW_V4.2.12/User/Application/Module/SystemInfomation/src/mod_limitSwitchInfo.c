/**
*****************************************************************************
* @��  ���� mod_limitSwitchInfo.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �¶���Ϣ��ȡģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*   2018/07/12: ����˸���λ����
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_limitSwitchInfo.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define LEFT_FRONT_IN_LIMIT_SWITCH_READ()       (!sampleboard_limitSwMagLI())
#define LEFT_FRONT_OUT_LIMIT_SWITCH_READ()      (!sampleboard_limitSwMagLO())
#define RIGHT_FRONT_IN_LIMIT_SWITCH_READ()      (!sampleboard_limitSwMagRI())
#define RIGHT_FRONT_OUT_LIMIT_SWITCH_READ()     (!sampleboard_limitSwMagRO())

#define LEFT_REAR_IN_LIMIT_SWITCH_READ()        GPIOx_getExtInSingle(EXT_IN5)
#define LEFT_REAR_OUT_LIMIT_SWITCH_READ()       GPIOx_getExtInSingle(EXT_IN4)
#define RIGHT_REAR_IN_LIMIT_SWITCH_READ()       GPIOx_getExtInSingle(EXT_IN1)
#define RIGHT_REAR_OUT_LIMIT_SWITCH_READ()      GPIOx_getExtInSingle(EXT_IN0)

#define IN_GARAGE_LIMIT_SWITCH_READ()           GPIOx_getExtInSingle(EXT_IN7)

//��̬����
static void LimitSwitchInfo_gpioInit(void);

//ȫ�ֱ���
LIMIT_SWITCH_INFO_STRUCT LimitSwitchInfoStruct;

/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo_gpioInit
*	����˵��: ��λ����IO�ڳ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LimitSwitchInfo_gpioInit(void)
{
    //֮ǰֱ�ӵ���GPIOx_init��ɳ�ʼ����
}

#if 0
/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo_loopRead
*	����˵��: ѭ����ȡ��λ����״̬
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LimitSwitchInfo_loopRead(void)
{
    LimitSwitchInfoStruct.LeftFrontInSta = (LIMIT_SWITCH_STATE_ENUM)LEFT_FRONT_IN_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.LeftFrontOutSta = (LIMIT_SWITCH_STATE_ENUM)LEFT_FRONT_OUT_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.LeftRearInSta = (LIMIT_SWITCH_STATE_ENUM)LEFT_REAR_IN_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.LeftRearOutSta = (LIMIT_SWITCH_STATE_ENUM)LEFT_REAR_OUT_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.RightFrontInSta = (LIMIT_SWITCH_STATE_ENUM)RIGHT_FRONT_IN_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.RightFrontOutSta = (LIMIT_SWITCH_STATE_ENUM)RIGHT_FRONT_OUT_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.RightRearInSta = (LIMIT_SWITCH_STATE_ENUM)RIGHT_REAR_IN_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.RightRearOutSta = (LIMIT_SWITCH_STATE_ENUM)RIGHT_REAR_OUT_LIMIT_SWITCH_READ();
    LimitSwitchInfoStruct.InGarageSta =  (LIMIT_SWITCH_STATE_ENUM)IN_GARAGE_LIMIT_SWITCH_READ();
}
#endif

/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo__loopRead
*	����˵��: ѭ����ȡ��λ����״̬���˲�(5ms period)
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LimitSwitchInfo_loopRead(void)
{
#define LIMIT_SWITCH_KEEP_TIME  5
    static int32_t sLeftFrontInTimeOut = 0, sLeftFrontOutTimeOut = 0;
    static int32_t sRightFrontInTimeOut = 0, sRightFrontOutTimeOut = 0;
    static int32_t sLeftRearInTimeOut = 0, sLeftRearOutTimeOut = 0;
    static int32_t sRightRearInTimeOut = 0, sRightRearOutTimeOut = 0;
    static int32_t sInGarageTimeOut = 0;

    if(LimitSwitchInfoStruct.LeftFrontInSta != (LIMIT_SWITCH_STATE_ENUM)LEFT_FRONT_IN_LIMIT_SWITCH_READ()){                 //��ǰ��
        sLeftFrontInTimeOut = 0;
    }else{
        sLeftFrontInTimeOut += 1;
        if(sLeftFrontInTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.LeftFrontInSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.LeftFrontInSta;
            sLeftFrontInTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.LeftFrontOutSta != (LIMIT_SWITCH_STATE_ENUM)LEFT_FRONT_OUT_LIMIT_SWITCH_READ()){               //��ǰ��
        sLeftFrontOutTimeOut = 0;
    }else{
        sLeftFrontOutTimeOut += 1;
        if(sLeftFrontOutTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.LeftFrontOutSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.LeftFrontOutSta;
            sLeftFrontOutTimeOut = 0;
        }
    }    

    if(LimitSwitchInfoStruct.LeftRearInSta != (LIMIT_SWITCH_STATE_ENUM)LEFT_REAR_IN_LIMIT_SWITCH_READ()){                   //�����
        sLeftRearInTimeOut = 0;
    }else{
        sLeftRearInTimeOut += 1;
        if(sLeftRearInTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.LeftRearInSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.LeftRearInSta;
            sLeftRearInTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.LeftRearOutSta != (LIMIT_SWITCH_STATE_ENUM)LEFT_REAR_OUT_LIMIT_SWITCH_READ()){                 //�����
        sLeftRearOutTimeOut = 0;
    }else{
        sLeftRearOutTimeOut += 1;
        if(sLeftRearOutTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.LeftRearOutSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.LeftRearOutSta;
            sLeftRearOutTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.RightFrontInSta != (LIMIT_SWITCH_STATE_ENUM)RIGHT_FRONT_IN_LIMIT_SWITCH_READ()){               //��ǰ��
        sRightFrontInTimeOut = 0;
    }else{
        sRightFrontInTimeOut += 1;
        if(sRightFrontInTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.RightFrontInSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.RightFrontInSta;
            sRightFrontInTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.RightFrontOutSta != (LIMIT_SWITCH_STATE_ENUM)RIGHT_FRONT_OUT_LIMIT_SWITCH_READ()){             //��ǰ��
        sRightFrontOutTimeOut = 0;
    }else{
        sRightFrontOutTimeOut += 1;
        if(sRightFrontOutTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.RightFrontOutSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.RightFrontOutSta;
            sRightFrontOutTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.RightRearInSta != (LIMIT_SWITCH_STATE_ENUM)RIGHT_REAR_IN_LIMIT_SWITCH_READ()){                 //�Һ���             
        sRightRearInTimeOut = 0;
    }else{
        sRightRearInTimeOut += 1;
        if(sRightRearInTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.RightRearInSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.RightRearInSta;
            sRightRearInTimeOut = 0;
        }
    }

    if(LimitSwitchInfoStruct.RightRearOutSta != (LIMIT_SWITCH_STATE_ENUM)RIGHT_REAR_OUT_LIMIT_SWITCH_READ()){               //�Һ���
        sRightRearOutTimeOut = 0;
    }else{
        sRightRearOutTimeOut += 1;
        if(sRightRearOutTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.RightRearOutSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.RightRearOutSta;
            sRightRearOutTimeOut = 0;
        }
    }

   if(LimitSwitchInfoStruct.InGarageSta != (LIMIT_SWITCH_STATE_ENUM)IN_GARAGE_LIMIT_SWITCH_READ()){                         //ͣ��λ��Ϊ�˱����޷�������Ӧͣ��λ���������������˲�ʱ��
        sInGarageTimeOut = 0;
    }else{
        sInGarageTimeOut += 2;
        if(sInGarageTimeOut >= LIMIT_SWITCH_KEEP_TIME){
            LimitSwitchInfoStruct.InGarageSta = (LIMIT_SWITCH_STATE_ENUM)!LimitSwitchInfoStruct.InGarageSta;
            sInGarageTimeOut = 0;
        }
    }

}

/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo_init
*	����˵��: ֱ�Ӷ�ȡ��λ����״̬
*	��    ��: pLimSwInfo������״̬�ṹ��ָ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LimitSwitchInfo_init(void)
{
    LimitSwitchInfo_gpioInit();

    LimitSwitchInfoStruct.LeftFrontInSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.LeftFrontOutSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.LeftRearInSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.LeftRearOutSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.RightFrontInSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.RightFrontOutSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.RightRearInSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.RightRearOutSta = LIMIT_SWITCH_ON;
    LimitSwitchInfoStruct.InGarageSta = LIMIT_SWITCH_ON;
}

/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo_get
*	����˵��: ֱ�Ӷ�ȡ��λ����״̬
*	��    ��: pLimSwInfo������״̬�ṹ��ָ��
*	�� �� ֵ: ��
******************************************************************************
*/
void LimitSwitchInfo_get(LIMIT_SWITCH_INFO_STRUCT *pLimSwInfo)
{
   *pLimSwInfo = LimitSwitchInfoStruct;
}

/*
******************************************************************************
*	�� �� ��: LimitSwitchInfo_getBits
*	����˵��: ֱ�Ӷ�ȡ��λ����״̬
*	��    ��: pLimSwInfo������״̬�ṹ��ָ��
*	�� �� ֵ: ��
******************************************************************************
*/
uint8_t LimitSwitchInfo_getBits(void)
{
    uint8_t tValue = 0;
	LIMIT_SWITCH_INFO_STRUCT uLimitSwitchInfo;

	LimitSwitchInfo_get(&uLimitSwitchInfo);
	
    if(LFO) tValue |= 1<<0;
    if(RFO) tValue |= 1<<1;
    if(LRO) tValue |= 1<<2;
    if(RRO) tValue |= 1<<3;

    if(LFI) tValue |= 1<<4;
    if(RFI) tValue |= 1<<5;
    if(LRI) tValue |= 1<<6;
    if(RRI) tValue |= 1<<7;

    return tValue;
}
