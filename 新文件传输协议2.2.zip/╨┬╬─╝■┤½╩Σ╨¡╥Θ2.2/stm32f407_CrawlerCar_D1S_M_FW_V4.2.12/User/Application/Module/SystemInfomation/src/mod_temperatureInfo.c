/**
*****************************************************************************
* @��  ���� mod_temperatureInfo.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �¶���Ϣ��ȡģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_temperatureInfo.h"

//�˲���
#include "mod_filter.h"

//Ӳ������
#include "hardware.h"
#include "includes.h"

//�궨��
#define LM95071_USED
#define MAX31865_USED

//#define TEMPERATURE_INFO_DIRECT_READ
#define TEMP_FILTER_CNT         2       // 2���¶Ȼ����˲���
#define TEMP_VALUE_SMOOTH_CNT   20      // �������ڴ�С 20*100 ms

//��̬����
static Filter Lm95071Filter[TEMP_FILTER_CNT];
static Filter Max31865Filter[TEMP_FILTER_CNT];
static FilterPtr Lm95071FilterPtr[TEMP_FILTER_CNT];
static FilterPtr Max31865FilterPtr[TEMP_FILTER_CNT];
static float Lm9507SmoothBuff[TEMP_FILTER_CNT][TEMP_VALUE_SMOOTH_CNT];
static float Max31865SmoothBuff[TEMP_FILTER_CNT][TEMP_VALUE_SMOOTH_CNT];

//ȫ�ֱ���
TEMPERATURE_INFO_STRUCT TemperatureInfoStruct = {
    .curCabinetTemp1stState = TEMP_VALUE_VAILD,
    .curCabinetTemp2ndState = TEMP_VALUE_VAILD,
    .curBatteryTemp1stState = TEMP_VALUE_VAILD,
    .curBatteryTemp2ndState = TEMP_VALUE_VAILD,
};



/*
******************************************************************************
*	�� �� ��: TemperatureInfo_init
*	����˵��: �¶���Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void TemperatureInfo_init(void)
{
#ifdef LM95071_USED
    Lm95071_init();
    
    for(uint8_t i = 0; i < TEMP_FILTER_CNT; i++){
        Lm95071FilterPtr[i] = &Lm95071Filter[i];
        Filter_init(Lm95071FilterPtr[i], TEMP_VALUE_SMOOTH_CNT, Lm9507SmoothBuff[i]);
    }
#endif
    
#ifdef MAX31865_USED
    Max31865_init();

    for(uint8_t i = 0; i < TEMP_FILTER_CNT; i++){
        Max31865FilterPtr[i] = &Max31865Filter[i];
        Filter_init(Max31865FilterPtr[i], TEMP_VALUE_SMOOTH_CNT, Max31865SmoothBuff[i]);
    }
#endif
}

/*
******************************************************************************
*	�� �� ��: temperatureInfo_get
*	����˵��: ֱ�ӻ�ȡ���е��¶ȴ��������� 
*	��    ��: pTempInfo �¶����ṹ��
*	�� �� ֵ: ��
******************************************************************************
*/
void TemperatureInfo_get(TEMPERATURE_INFO_STRUCT *pTempInfo)
{

#ifdef TEMPERATURE_INFO_DIRECT_READ 

    Lm95071_getValue(LM95071_1ST, 
        (LM95071_VALUE_STATE*)&pTempInfo->curCabinetTemp1stState,
        &pTempInfo->curCabinet1stTemp);
    
    Lm95071_getValue(LM95071_2ND, 
        (LM95071_VALUE_STATE*)&pTempInfo->curCabinetTemp2ndState,
        &pTempInfo->curCabinet2ndTemp);   
    
    Max31865_getValue(MAX31865_1ST,
        (MAX31865_VALUE_STATE*)&pTempInfo->curBatteryTemp1stState,
        &pTempInfo->curBattery1stTemp);
    
    Max31865_getValue(MAX31865_2ND,
        (MAX31865_VALUE_STATE*)&pTempInfo->curBatteryTemp2ndState,
        &pTempInfo->curBattery2ndTemp);
    
    /* ����ȡ�����ݷ���ȫ�ֱ����� */
    memcpy(&TemperatureInfoStruct,pTempInfo,sizeof(TEMPERATURE_INFO_STRUCT));

#else

    *pTempInfo = TemperatureInfoStruct;

#endif

}

#if 0
/*
******************************************************************************
*	�� �� ��: TemperatureInfo_loopRead
*	����˵��: ��ȡ���е��¶ȴ��������ݣ������쳣��λоƬ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void TemperatureInfo_loopRead(void)
{
#ifdef LM95071_USED
    /* ��ȡ�ĸ��¶ȴ��������� */
    Lm95071_getValue(LM95071_1ST, 
        (LM95071_VALUE_STATE*)&TemperatureInfoStruct.curCabinetTemp1stState,
        &TemperatureInfoStruct.curCabinet1stTemp);
    
    Lm95071_getValue(LM95071_2ND, 
        (LM95071_VALUE_STATE*)&TemperatureInfoStruct.curCabinetTemp2ndState,
        &TemperatureInfoStruct.curCabinet2ndTemp);

    /* ����ƽ���¶� */
    int32_t tCabinetTotal = 0; float tCabinetTempTotal = 0.0;
    if(TemperatureInfoStruct.curCabinetTemp1stState == TEMP_VALUE_VAILD){
        tCabinetTotal += 1;
        tCabinetTempTotal += TemperatureInfoStruct.curCabinet1stTemp;
    }
    if(TemperatureInfoStruct.curCabinetTemp2ndState == TEMP_VALUE_VAILD){
        tCabinetTotal += 1;
        tCabinetTempTotal += TemperatureInfoStruct.curCabinet2ndTemp;
    }
#endif
    
#ifdef MAX31865_USED
    Max31865_getValue(MAX31865_1ST,
        (MAX31865_VALUE_STATE*)&TemperatureInfoStruct.curBatteryTemp1stState,
        &TemperatureInfoStruct.curBattery1stTemp);
    
    Max31865_getValue(MAX31865_2ND,
        (MAX31865_VALUE_STATE*)&TemperatureInfoStruct.curBatteryTemp2ndState,
        &TemperatureInfoStruct.curBattery2ndTemp);

    /* оƬ�����쳣��Ҫ��λ���� */
    if(TemperatureInfoStruct.curBatteryTemp1stState == MAX31865_VALUE_INVAILD){
        Max31865_reset(MAX31865_1ST);
    }

    if(TemperatureInfoStruct.curBatteryTemp2ndState == MAX31865_VALUE_INVAILD){
        Max31865_reset(MAX31865_2ND);
    }

    /* ����ƽ���¶� */
    int32_t tBatteryTotal = 0; float tBatteryTempTotal = 0.0;
    if(TemperatureInfoStruct.curBatteryTemp1stState == TEMP_VALUE_VAILD){
        tBatteryTotal += 1;
        tBatteryTempTotal += TemperatureInfoStruct.curBattery1stTemp;
    }
    if(TemperatureInfoStruct.curBatteryTemp2ndState == TEMP_VALUE_VAILD){
        tBatteryTotal += 1;
        tBatteryTempTotal += TemperatureInfoStruct.curBattery2ndTemp;
    }
#endif

}
#endif

/*
******************************************************************************
*	�� �� ��: TemperatureInfo_loopRead
*	����˵��: ��ȡ���е��¶ȴ��������ݣ������쳣��λоƬ,ƽ���˲�
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void TemperatureInfo_loopRead(void)
{
#ifdef LM95071_USED
    LM95071_VALUE_STATE lm95071Vaild1,lm95071Vaild2;
    float fLm95071Value1 = 0.0,fLm95071Value2 = 0.0;
    float fLm95071SmoothValue1 = 0.0,fLm95071SmoothValue2 = 0.0;

    /* ��ȡ�ĸ��¶ȴ��������� */
    Lm95071_getValue(LM95071_1ST, &lm95071Vaild1, &fLm95071Value1);
    Lm95071_getValue(LM95071_2ND, &lm95071Vaild2, &fLm95071Value2);

    /* �¶������˲����� */
    if(lm95071Vaild1 == LM95071_VALUE_VAILD){
        fLm95071SmoothValue1 = Filter_insert(Lm95071FilterPtr[0],fLm95071Value1);
    }
    if(lm95071Vaild2 == LM95071_VALUE_VAILD){
        fLm95071SmoothValue2 = Filter_insert(Lm95071FilterPtr[1],fLm95071Value2);
    }

    /* ��ֵ��ȫ�ֱ����� */
    TemperatureInfoStruct.curCabinetTemp1stState = (TEMP_VALUE_STATE)lm95071Vaild1;
    TemperatureInfoStruct.curCabinetTemp2ndState = (TEMP_VALUE_STATE)lm95071Vaild2;

    TemperatureInfoStruct.curCabinet1stTemp = fLm95071SmoothValue1;
    TemperatureInfoStruct.curCabinet2ndTemp = fLm95071SmoothValue2;

    /* ����ƽ���¶� */
    int32_t tCabinetTotal = 0; float tCabinetTempTotal = 0.0;
    if(TemperatureInfoStruct.curCabinetTemp1stState == TEMP_VALUE_VAILD){
        tCabinetTotal += 1;
        tCabinetTempTotal += TemperatureInfoStruct.curCabinet1stTemp;
    }
    if(TemperatureInfoStruct.curCabinetTemp2ndState == TEMP_VALUE_VAILD){
        tCabinetTotal += 1;
        tCabinetTempTotal += TemperatureInfoStruct.curCabinet2ndTemp;
    }
    
	if(tCabinetTotal > 0){
		TemperatureInfoStruct.curCabinetAverage = tCabinetTempTotal / tCabinetTotal;
	}

#endif

#ifdef MAX31865_USED 

//    MAX31865_VALUE_STATE max31865Vaild1,max31865Vaild2;
//    float fMax31865Value1 = 0.0,fMax31865Value2 = 0.0;
//    float fMax31865SmoothValue1 = 0.0,fMax31865SmoothValue2 = 0.0;
//    
//    Max31865_getValue(MAX31865_1ST, &max31865Vaild1, &fMax31865Value1);
//    Max31865_getValue(MAX31865_2ND, &max31865Vaild2, &fMax31865Value2);
//    
//    if(max31865Vaild1 == MAX31865_VALUE_VAILD){
//        fMax31865SmoothValue1 = Filter_insert(Max31865FilterPtr[0],fMax31865Value1);
//    }

//    if(max31865Vaild2 == MAX31865_VALUE_VAILD){
//        fMax31865SmoothValue2 = Filter_insert(Max31865FilterPtr[1],fMax31865Value2);
//    }

    /* оƬ�����쳣��Ҫ��λ���� */
//    if(TemperatureInfoStruct.curBatteryTemp1stState == MAX31865_VALUE_INVAILD){
//        Max31865_reset(MAX31865_1ST);
//    }

//    if(TemperatureInfoStruct.curBatteryTemp2ndState == MAX31865_VALUE_INVAILD){
//        Max31865_reset(MAX31865_2ND);
//    }
//    
//    TemperatureInfoStruct.curBatteryTemp1stState = (TEMP_VALUE_STATE)max31865Vaild1;
//    TemperatureInfoStruct.curBatteryTemp2ndState = (TEMP_VALUE_STATE)max31865Vaild2;
//    
//    TemperatureInfoStruct.curBattery1stTemp = fMax31865SmoothValue1;
//    TemperatureInfoStruct.curBattery2ndTemp = fMax31865SmoothValue2;

//    /* ����ƽ���¶� */
//    int32_t tBatteryTotal = 0; float tBatteryTempTotal = 0.0;
//    if(TemperatureInfoStruct.curBatteryTemp1stState == TEMP_VALUE_VAILD){
//        tBatteryTotal += 1;
//        tBatteryTempTotal += TemperatureInfoStruct.curBattery1stTemp;
//    }
//    if(TemperatureInfoStruct.curBatteryTemp2ndState == TEMP_VALUE_VAILD){
//        tBatteryTotal += 1;
//        tBatteryTempTotal += TemperatureInfoStruct.curBattery2ndTemp;
//    }
//    
//	if(tBatteryTotal > 0){
//		TemperatureInfoStruct.curBatteryAverage = tBatteryTempTotal / tBatteryTotal;
//	}

    BatteryBMSInfo_TypeDef info;
    battery_get_info(&info);
    TemperatureInfoStruct.curBatteryAverage = (info.temprature1 + info.temprature2) / 2;
    TemperatureInfoStruct.curBattery1stTemp = info.temprature1;
    TemperatureInfoStruct.curBattery2ndTemp = info.temprature2;
    if(fabs(info.temprature1 - info.temprature2) > 10)
    {
        Safety_setFlagBit(BIT_Error_BatTempSensor,1);
    }

#endif

}
