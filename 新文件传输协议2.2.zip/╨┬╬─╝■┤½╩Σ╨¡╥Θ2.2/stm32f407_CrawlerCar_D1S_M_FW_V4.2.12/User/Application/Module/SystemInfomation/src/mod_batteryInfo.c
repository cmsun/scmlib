/**
*****************************************************************************
* @��  ���� mod_batteryInfo.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �����Ϣ��ȡģ�����ļ�
* @��  ע�� ��λ��mV��
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_batteryInfo.h"

//�˲���
#include "mod_filter.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define VOLTAGE_AMPLIFIER_RATIO			11									//��ѹ�Ŵ�ϵ��
#define VOLTAGE_VALUE_SMOOTH_CNT		400									//5ms����

#define ATTENUATION                     (10.0 / 15.6)                     	//�����ѹϵ��
#define CURRENT_REFER_VOL               (2500.0 * ATTENUATION)              //0A �ο���ѹ
#define CURRENT_UNIT_VOL                (10.0 / ATTENUATION)              	//0.1mV/mA 100mV/A ��ѹת������
#define CURRENT_VALUE_SMOOTH_CNT		400									//5ms����

#define BANCHMARK_3V                    (3000.0/3300.0*4096.0)              //��ѹ��׼Դֱ�ӻ�����ֵ

#if 0
    #define VOL_FORMULA_PARAM_K       		sBatteryFormulaInfo.Struct.VolParam.K
    #define VOL_FORMULA_PARAM_B       		sBatteryFormulaInfo.Struct.VolParam.B

    #define CHARGE_CUR_FORMULA_PARAM_K  	sBatteryFormulaInfo.Struct.ChargeCurParam.K
    #define CHARGE_CUR_FORMULA_PARAM_B   	sBatteryFormulaInfo.Struct.ChargeCurParam.B

    #define DISCHARGE_CUR_FORMULA_PARAM_K 	sBatteryFormulaInfo.Struct.DisChargeCurParam.K
    #define DISCHARGE_CUR_FORMULA_PARAM_B	sBatteryFormulaInfo.Struct.DisChargeCurParam.B
#else
    #define VOL_FORMULA_PARAM_K       		1.000000000                 	// y = a * x + b
    #define VOL_FORMULA_PARAM_B         	0.000000000                  	// y = 1.000 x + (0.0)

    #define CHARGE_CUR_FORMULA_PARAM_K    	1.000000000               		// y = a * x + b
    #define CHARGE_CUR_FORMULA_PARAM_B     	0.000000000                		// y = 1.000 x + (0.0)

    #define DISCHARGE_CUR_FORMULA_PARAM_K 	1.000000000               		// y = a * x + b
    #define DISCHARGE_CUR_FORMULA_PARAM_B  	0.000000000                		// y = 1.000 x + (0.0)
#endif

//��̬����
static void BatteryInfo_setAdaptLine(void);
static void BatteryInfo_getAdaptLine(void);

//ȫ�ֱ���
BATTERY_INFO_STRUCT BatteryInfoStruct;
BATTERY_FORMULA_INFO_UNION sBatteryFormulaInfo;

//��̬����
static Filter ReferFilter,VoltageFilter,ChargeCurrentFilter,DischargeCurrentFilter;
static FilterPtr ReferFilterPtr,VoltageFilterPtr,ChargeCurrentFilterPtr,DischargeCurrentFilterPtr;
static float ReferSmoothBuff[VOLTAGE_VALUE_SMOOTH_CNT],VoltageSmoothBuff[VOLTAGE_VALUE_SMOOTH_CNT];
static float ChargeCurrentSmoothBuff[VOLTAGE_VALUE_SMOOTH_CNT],DischargeCurrentSmoothBuff[VOLTAGE_VALUE_SMOOTH_CNT];



/*
******************************************************************************
*	�� �� ��: BatteryInfo_init
*	����˵��: �����Ϣ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_init(void)
{
	GPIO_InitTypeDef gpioInitStrcut;
	
	gpioInitStrcut.GPIO_Mode = GPIO_Mode_AN;
	gpioInitStrcut.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_2 | GPIO_Pin_3 | GPIO_Pin_4;    //PC0/PC2 Current PC3 Voltage PC4 Refer
	gpioInitStrcut.GPIO_Speed = GPIO_Speed_50MHz;
    gpioInitStrcut.GPIO_PuPd = GPIO_PuPd_NOPULL;

	GPIO_Init(GPIOC, &gpioInitStrcut);
	
	ADCx_init(HADC1);

    {
        ReferFilterPtr = &ReferFilter;
        VoltageFilterPtr = &VoltageFilter;
        ChargeCurrentFilterPtr = &ChargeCurrentFilter;
        DischargeCurrentFilterPtr = &DischargeCurrentFilter;
        
        Filter_init(ReferFilterPtr,VOLTAGE_VALUE_SMOOTH_CNT,ReferSmoothBuff);
        Filter_init(VoltageFilterPtr,VOLTAGE_VALUE_SMOOTH_CNT,VoltageSmoothBuff);
        Filter_init(ChargeCurrentFilterPtr,CURRENT_VALUE_SMOOTH_CNT,ChargeCurrentSmoothBuff);
        Filter_init(DischargeCurrentFilterPtr,CURRENT_VALUE_SMOOTH_CNT,DischargeCurrentSmoothBuff);
    }
}

#if 0
/*
******************************************************************************
*	�� �� ��: BatteryInfo_loopRead
*	����˵��: ��ȡ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_loopRead(void)
{
	int32_t tVoltageValueRaw = ADCx_getRawValue(HADC1, ADC_Channel_12, 2);
	int32_t tCurrentValueRaw = ADCx_getRawValue(HADC1, ADC_Channel_10, 2);
	BatteryInfoStruct.voltageRaw = tVoltageValueRaw * VOLTAGE_REFERENCE >> 12;
	BatteryInfoStruct.currentRaw = tCurrentValueRaw * VOLTAGE_REFERENCE >> 12;
	BatteryInfoStruct.voltageAdjust = BatteryInfoStruct.voltageRaw * VOLTAGE_AMPLIFIER_RATIO + DECREMENT_VOL;
	BatteryInfoStruct.currentAdjust = (BatteryInfoStruct.currentRaw - CURRENT_REFER_VOL) * CURRENT_UNIT_VOL;
}
#endif

/*
******************************************************************************
*	�� �� ��: BatteryInfo_loopRead
*	����˵��: ��ȡ�����Ϣƽ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_loopRead(void)
{
	int32_t tRawReferValue = 0,tRawVoltageValue = 0,tRawChargeCurrentValue = 0,tRawDischargeCurrentValue = 0;

    float tReferVoltageRatio = 1.0;
	float tReferValue = 0,tVoltageValue = 0,tChargeCurrentValue = 0,tDischargeCurrentValue = 0;
	float tReferSmoothValue = 0,tVoltageSmoothValue = 0,tChargeCurrentSmoothValue = 0,tDischargeCurrentSmoothValue = 0;

    tRawReferValue = ADCx_getRawValue(HADC1, ADC_Channel_14, 1); 
	tRawVoltageValue = ADCx_getRawValue(HADC1, ADC_Channel_12, 1);
	tRawChargeCurrentValue = ADCx_getRawValue(HADC1, ADC_Channel_10, 1);
    tRawDischargeCurrentValue = ADCx_getRawValue(HADC1, ADC_Channel_13, 1);

    tReferValue = tRawReferValue;
    tReferSmoothValue = Filter_insert(ReferFilterPtr,tReferValue);
    tReferVoltageRatio = tReferSmoothValue / BANCHMARK_3V;
	BatteryInfoStruct.referVoltageAdjustRatio = tReferVoltageRatio;

	tVoltageValue = tRawVoltageValue * VOLTAGE_REFERENCE / tReferVoltageRatio / 4096.0f;
	tChargeCurrentValue = tRawChargeCurrentValue * VOLTAGE_REFERENCE / tReferVoltageRatio / 4096.0f;    
    tDischargeCurrentValue = tRawDischargeCurrentValue * VOLTAGE_REFERENCE / tReferVoltageRatio / 4096.0f;
    
	tVoltageSmoothValue = Filter_insert(VoltageFilterPtr,tVoltageValue);
	tChargeCurrentSmoothValue = Filter_insert(ChargeCurrentFilterPtr,tChargeCurrentValue);
    tDischargeCurrentSmoothValue = Filter_insert(DischargeCurrentFilterPtr,tDischargeCurrentValue);
	
    BatteryInfoStruct.referRaw = tReferSmoothValue * VOLTAGE_REFERENCE / 4096.0f;
    
	BatteryInfoStruct.voltageRaw = tVoltageSmoothValue;
	BatteryInfoStruct.chargeCurrentRaw = tChargeCurrentSmoothValue;
	BatteryInfoStruct.dischargeCurrentRaw = tDischargeCurrentSmoothValue;
	BatteryInfoStruct.voltageAdjust = (float)(tVoltageSmoothValue * VOLTAGE_AMPLIFIER_RATIO) \
		* VOL_FORMULA_PARAM_K + VOL_FORMULA_PARAM_B;
	BatteryInfoStruct.chargeCurrentAdjust = (float)((tChargeCurrentSmoothValue - CURRENT_REFER_VOL) * CURRENT_UNIT_VOL) \
		* CHARGE_CUR_FORMULA_PARAM_K + CHARGE_CUR_FORMULA_PARAM_B;	
	BatteryInfoStruct.dischargeCurrentAdjust = (float)((tDischargeCurrentSmoothValue - CURRENT_REFER_VOL) * CURRENT_UNIT_VOL) \
		* CHARGE_CUR_FORMULA_PARAM_K + CHARGE_CUR_FORMULA_PARAM_B;
}

/*
******************************************************************************
*	�� �� ��: BatteryInfo_getValue
*	����˵��: ��ȡ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_getValue(BATTERY_INFO_STRUCT *pInfo)
{
	//*pInfo = BatteryInfoStruct;
    
    BatteryBMSInfo_TypeDef batinfo;
    battery_get_info(&batinfo);
    pInfo->chargeCurrentAdjust = batinfo.current;
    pInfo->dischargeCurrentAdjust = batinfo.current;
    pInfo->voltageAdjust = batinfo.voltage;
}

/*
******************************************************************************
*	�� �� ��: BatteryInfo_getAdaptLine
*	����˵��: ��ȡ���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_getAdaptLine(void)
{
    PARAM_PROC_STATE_ENUM rSta;
    
	rSta = ParamInfoStruct.batteryFormulaStruct.read(&sBatteryFormulaInfo); //��ȡ�����������߲���
    if(rSta == PARAM_PROC_FAILED){
        Safety_setFlagBit(BIT_Error_Eeprom,1);
        LOG_ERR("batteryFormulaStruct.read is Faild",0);
    }
}

/*
******************************************************************************
*	�� �� ��: BatteryInfo_setAdaptLine
*	����˵��: ��ȡ���
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void BatteryInfo_setAdaptLine(void)
{
	sBatteryFormulaInfo.Struct.VolParam.K = 0.9923529327;			        // y = 0.9923529327 x + 256.9222135829 
	sBatteryFormulaInfo.Struct.VolParam.B = +256.9222135829;

	sBatteryFormulaInfo.Struct.ChargeCurParam.K = 1.0028448738;			    // y = 1.0028448738 x - 129.7604010526 
	sBatteryFormulaInfo.Struct.ChargeCurParam.B = -129.7604010526;

	sBatteryFormulaInfo.Struct.DisChargeCurParam.K = 1.0028448738;		    // y = 1.0028448738 x - 129.7604010526 
	sBatteryFormulaInfo.Struct.DisChargeCurParam.B = -129.7604010526;
					
	ParamInfoStruct.batteryFormulaStruct.write(sBatteryFormulaInfo);		//��ȡ�����������߲���
}
