#include "mod_peripheralDev.h"
#include "mod_modbusLib.h"
#include "includes.h"

#define RS485_NUM RS485_2ND

#define ADDR_SAMPLE_BOARD 1
#define ADDR_MAGNETIC_SENSOR 2
#define ADDR_BATTERY_BMS 3

#define PERIOD_SAMPLE_BOARD 4       //���ݲɼ���ÿ��20msͨ��һ��
#define PERIOD_MAGNETIC_SENSOR 20   //AGV�ŵ���������ÿ��100msͨ��һ��
#define PERIOD_BATTERY_BMS 200      //���BMSÿ��1��ͨ��һ��
#define COMMUNICATION_TIMEOUT 20    //100ms���ղ������ݼ���һ��ͨ��ʧ��

PeripheralDev_TypeDef PeripheralDev = {
    .sample.modbuscmd = {0x02, 0x03, 0x00, 0x00, 0x00, 0x05, 0x85, 0xFA},
    .magnetic.modbuscmd = {0x01, 0x03, 0x00, 0x08, 0x00, 0x01, 0x05, 0xC8},
    .battery.modbuscmd = {0x03, 0x03, 0x00, 0x12, 0x00, 0x17, 0xA4, 0x23},
};

void rs485_tx_callback(void)
{
    Rs485_setTransMode(RS485_NUM, RS485_RX);
}

void rs485_rx_callback(void)
{
    PeripheralDev.received = true;
}

//��ʼ��ͨ��
void peripheral_communication_init(void)
{
    RS485_CALLBACK CallBack;
    CallBack.RxCompletePtr = rs485_rx_callback;
    CallBack.TxCompletePtr = rs485_tx_callback;
	Rs485_init(RS485_NUM,CallBack);
}

//ͨ��ʧ�ܣ����ð�ȫ��־λ
void peripheral_communication_fialed(void)
{
    PeripheralDev.busy = false;
    PeripheralDev.timeout = 0;
    if(PeripheralDev.targetslave == ADDR_SAMPLE_BOARD)
    {
        if(++PeripheralDev.sample.fialed_times == 3)
        {
            PeripheralDev.sample.fialed_times = 0;
            Safety_setFlagBit(BIT_Error_SampleBoardOffline, 1);
        }
    }
    else if(PeripheralDev.targetslave == ADDR_MAGNETIC_SENSOR)
    {
        if(++PeripheralDev.magnetic.fialed_times == 5)
        {
            PeripheralDev.magnetic.fialed_times = 0;
            Safety_setFlagBit(BIT_Error_SampleBoardOffline, 1);
        }
    }
    else if(PeripheralDev.targetslave == ADDR_BATTERY_BMS)
    {
        if(++PeripheralDev.battery.fialed_times == 3)
        {
            PeripheralDev.battery.fialed_times = 0;
            Safety_setFlagBit(BIT_Error_SampleBoardOffline, 1);
        }
    }
}

//���ݲɼ������ݴ���
void sample_board_process(uint8_t *data, uint16_t len)
{
	PeripheralDev.sample.info.radar1st = (data[3]<<8) | data[4];
	PeripheralDev.sample.info.radar2nd = (data[5]<<8) | data[6];
	PeripheralDev.sample.info.radar3rd = (data[7]<<8) | data[8];
	PeripheralDev.sample.info.radar4th = (data[9]<<8) | data[10];
	PeripheralDev.sample.info.radarSta1st = (data[11]>>0) & 1;
	PeripheralDev.sample.info.radarSta2nd = (data[11]>>1) & 1;
	PeripheralDev.sample.info.radarSta3rd = (data[11]>>2) & 1;
	PeripheralDev.sample.info.radarSta4th = (data[11]>>3) & 1;
	PeripheralDev.sample.info.limitSwMagLI = (data[12]>>0) & 1;
	PeripheralDev.sample.info.limitSwMagLO = (data[12]>>1) & 1;
	PeripheralDev.sample.info.limitSwMagRI = (data[12]>>2) & 1;
	PeripheralDev.sample.info.limitSwMagRO = (data[12]>>3) & 1;
}

//�Ŵ��������ݴ���
void magnetic_sensor_process(uint8_t *data, uint16_t len)
{
    int temp = 0;
    static bool valid = false;
    static int delay = 0;

    temp = ~data[3] ^ 0xffffff00;
    
    if(valid == false)
    {
        if(temp == 0)
        {
            delay = 0;
        }
        else if(delay++ > 5) //��⵽������0.5����Ч
        {
            delay = 0;
            valid = true;
        }
    }
    
    if(valid == true)
    {
        PeripheralDev.magnetic.info = temp;
        if(temp == 0 && delay++ > 5)
        {
            delay = 0;
            valid = false;
        }
    }
}

//��ع���ϵͳ���ݴ���
void battery_process(uint8_t *data, uint16_t len)
{
    BatteryBMSInfoRaw_TypeDef info;
    memcpy((void *)&info, data+3, sizeof(info));
    PeripheralDev.battery.info.voltage = ntohs(info.voltage) * 10;
    PeripheralDev.battery.info.current = (int16_t)ntohs(info.current) * 10;
    PeripheralDev.battery.info.remainpower = ntohs(info.remainpower) * 10;
    PeripheralDev.battery.info.temprature1 = (ntohs(info.temprature1) - 2731) / 10;
    PeripheralDev.battery.info.temprature2 = (ntohs(info.temprature2) - 2731) / 10;
    PeripheralDev.battery.info.capacity = ntohs(info.capacity) * 10;
    PeripheralDev.battery.info.SOC = ntohs(info.SOC);
    for(int i = 0; i < 16; ++i)
    {
        PeripheralDev.battery.info.cellvoltage[i] = ntohs(info.cellvoltage[i]);
    }
}

void peripheral_task_loop(void)
{
    uint16_t count = 0;
    uint8_t buff[128] = {0};
    
    //�������ݲɼ����ͨ��ͬ��
    if((PeripheralDev.busy == false || PeripheralDev.targetslave != ADDR_SAMPLE_BOARD)
        && ++PeripheralDev.sample.period == PERIOD_SAMPLE_BOARD)
    {
        PeripheralDev.sample.period = 0;
        PeripheralDev.sample.active = true;
    }
    //����AGV�ŵ�����������ͨ��ͬ��
    if((PeripheralDev.busy == false || PeripheralDev.targetslave != ADDR_MAGNETIC_SENSOR)
        && ++PeripheralDev.magnetic.period == PERIOD_MAGNETIC_SENSOR)
    {
        PeripheralDev.magnetic.period = 0;
        if((RoTaskMagStruct.RunSta == IN_GARAGE || RoTaskMagStruct.RunSta == OUT_GARAGE))
        {
            PeripheralDev.magnetic.active = true;
        }
    }
    //������BMS��ͨ��ͬ��
    if((PeripheralDev.busy == false || PeripheralDev.targetslave != ADDR_BATTERY_BMS)
        && ++PeripheralDev.battery.period == PERIOD_BATTERY_BMS)
    {
        PeripheralDev.battery.period = 0;
        PeripheralDev.battery.active = true;
    }
    
    //MODBUS��λ��������Ѯ֡
    if(PeripheralDev.busy == false)
    {
        if(PeripheralDev.sample.active == true)
        {
            PeripheralDev.busy = true;
            PeripheralDev.sample.active = false;
            PeripheralDev.targetslave = ADDR_SAMPLE_BOARD;
            Rs485_sendBuff(RS485_NUM, (uint8_t *)PeripheralDev.sample.modbuscmd, sizeof(PeripheralDev.sample.modbuscmd));
        }
        else if(PeripheralDev.magnetic.active == true)
        {
            PeripheralDev.busy = true;
            PeripheralDev.magnetic.active = false;
            PeripheralDev.targetslave = ADDR_MAGNETIC_SENSOR;
            Rs485_sendBuff(RS485_NUM, (uint8_t *)PeripheralDev.magnetic.modbuscmd, sizeof(PeripheralDev.magnetic.modbuscmd));
        }
        else if(PeripheralDev.battery.active == true)
        {
            PeripheralDev.busy = true;
            PeripheralDev.battery.active = false;
            PeripheralDev.targetslave = ADDR_BATTERY_BMS;
//            uint16_t crc = CRC16_Modbus((uint8_t *)PeripheralDev.battery.modbuscmd, MODBUS_CMD_LENGTH-2);
//            PeripheralDev.battery.modbuscmd[MODBUS_CMD_LENGTH-2] = crc >> 8;
//            PeripheralDev.battery.modbuscmd[MODBUS_CMD_LENGTH-1] = crc & 0xff;
            Rs485_sendBuff(RS485_NUM, (uint8_t *)PeripheralDev.battery.modbuscmd, sizeof(PeripheralDev.battery.modbuscmd));
        }
    }
    
    //����ͨ�ų�ʱ
    if(PeripheralDev.busy == true && ++PeripheralDev.timeout == COMMUNICATION_TIMEOUT)
    {
        peripheral_communication_fialed();
    }
    
    //���յ�����
    if(PeripheralDev.received == true)
    {
        PeripheralDev.busy = false;
        PeripheralDev.received = false;
        PeripheralDev.timeout = 0;
        
        count = Rs485_recvBuff(RS485_NUM, buff, sizeof(buff));
        if(CRC16_Modbus(buff, count) == 0)
        {
            if(PeripheralDev.targetslave == ADDR_SAMPLE_BOARD)
            {
                sample_board_process(buff, count);
                PeripheralDev.sample.fialed_times = 0;
            }
            else if(PeripheralDev.targetslave == ADDR_MAGNETIC_SENSOR)
            {
                magnetic_sensor_process(buff, count);
                PeripheralDev.magnetic.fialed_times = 0;
            }
            else if(PeripheralDev.targetslave == ADDR_BATTERY_BMS)
            {
                battery_process(buff, count);
                PeripheralDev.battery.fialed_times = 0;
            }
        }
        else
        {
            peripheral_communication_fialed();
        }
    }
}

void sample_get_info(SampleBoardInfo_Typedef *info)
{
    memcpy(info, &PeripheralDev.sample.info, sizeof(PeripheralDev.sample.info));
}

uint32_t magnetic_get_info(void)
{
    return PeripheralDev.magnetic.info;
}

void battery_get_info(BatteryBMSInfo_TypeDef *info)
{
    memcpy(info, &PeripheralDev.battery.info, sizeof(PeripheralDev.battery.info));
}