#include <stdio.h>
#include <string.h>
#include "mod_communication.h"
#include "mod_configureInfo.h"

#include "includes.h"

static ROBOT_ID_INFO_UNION sRobotIdInfo = {0};  //������ID
MAP_INFO_UNION sMapInfo = {0};                  //��ǰʹ�õĵ�ͼ���͵�ͼ����

//����������ڵ�C�ļ�����ֻÿ�ζ����롣���÷���Ϊ������Ҽ������ߴ����ϵ�Դ�ļ���
//Ȼ���� Options for file -> properties -> Always Build ѡ��������ɫ���
//ǰ�����ֽڱ�ʾ�꣨�����ֽ��򣩣��������ֽڱ�ʾ�·ݣ����ĸ��ֽڱ�ʾ��
uint8_t g_Version[4] = {0};

uint64_t g_feature_timestamp = 0;
uint32_t g_feature_random = 0;



//�ѱ��������ַ���__DATE__ת���ɰ汾��
void parseVersionString(void)
{
    uint16_t year, month, day;
    const char *pMonth[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    char monthString[4];
    
    sscanf(__DATE__, "%3s %2hd %4hd", monthString, &day, &year);
    for(month = 0; month < 12; ++month)
    {
        if(strcmp(monthString, pMonth[month]) == 0)
            break;
    }
    g_Version[0] = year >> 8;
    g_Version[1] = year & 0xff;
    g_Version[2] = month + 1;
    g_Version[3] = day;
}

void communication_init(void)
{
    parseVersionString();
    ParamInfoStruct.robotIdStruct.read(&sRobotIdInfo);
    ParamInfoStruct.mapInfoStruct.read(&sMapInfo);
    //np_load_feature(&g_feature_timestamp, &g_feature_random);
}

void identity_process(uint8_t *data, SEND_FUNC send)
{    
    Frame_GetID_Req *req;
    Frame_GetID_Ack ack;
    ROBOT_ID_INFO_UNION uRobotIdInfo;
    
    req = (Frame_GetID_Req *)data;
    
    if(req->readWriteSwitch == WRITE_ID)
    {
        for(int i = 0; i < ID_LENGTH; ++i)
            uRobotIdInfo.Struct.robotId[i] = req->ID[i];
        ParamInfoStruct.robotIdStruct.write(uRobotIdInfo);
        ParamInfoStruct.robotIdStruct.read(&sRobotIdInfo);
    }
    
    ack.head = FRAME_HEAD;
    ack.type = req->type + 1;
    ack.length = sizeof(ack) - 5;
    ack.serial = req->serial;
    memcpy(ack.ID, sRobotIdInfo.Struct.robotId, sizeof(ack.ID));
    ack.readWriteSwitch = req->readWriteSwitch;
    ack.checksum = CheckCode_xor8((uint8_t *)&ack, sizeof(ack)-2);
    ack.tail = FRAME_TAIL;
    
    send((uint8_t *)&ack, sizeof(ack));
}

void command_process(uint8_t *data, SEND_FUNC send)
{
    Frame_Command_Req *req;
    Frame_Command_Ack ack;
    
    req = (Frame_Command_Req *)data;
    
    ControllerInfoStruct.MotionCmd = (CONTROLLER_COMMAND_ENUM)req->motionCmd;
    ControllerInfoStruct.MotionParam.linearVelocity = req->linearVelocity;
    ControllerInfoStruct.MotionParam.angularVelocity = req->angularVelocity;
    ControllerInfoStruct.BrushCtl = (CONTROLLER_CLEAN_ENUM)req->brushCtl;
    ControllerInfoStruct.MotionMethon = (CONTROLLER_METHON_ENUM)req->motionMethon;
    
    ack.head = FRAME_HEAD;
    ack.type = req->type + 1;
    ack.length = sizeof(ack) - 5;
    ack.serial = req->serial;
    memcpy(ack.ID, sRobotIdInfo.Struct.robotId, sizeof(ack.ID));
	ack.robotState = RoTaskMagStruct.RunSta;
	ack.linearVelocity = (int8_t)(round(MotionCtlStruct.StateInfo.MotionParmInfo.linearVelocity));
	ack.angularVelocity =(int8_t)(round(MotionCtlStruct.StateInfo.MotionParmInfo.angularVelocity));
	ack.brushState = BrushCtlStruct.Sta;
	ack.motionMethon = ControllerInfoStruct.MotionMethon;
	ack.faultFlag = htonl(SafetyFlagUnion.SafetyFlag);
	ack.curMileage = htonl(MotionCtlStruct.StateInfo.MileageInfo.totalMeter*100);
	ack.curCleanTime = htonl(MotionCtlStruct.StateInfo.MileageInfo.totalSecond);
	ack.batteryVol = htons(BatteryInfoStruct.voltageAdjust);
	ack.dropLimitState = LimitSwitchInfo_getBits();
	ack.reserve = 0x0000;
    ack.checksum = CheckCode_xor8((uint8_t *)&ack, sizeof(ack)-2);
    ack.tail = FRAME_TAIL;
    
    send((uint8_t *)&ack, sizeof(ack));
}

void parmeter_process(uint8_t *data, SEND_FUNC send)
{
    Frame_Param_Req *req;
    Frame_Param_Ack ack;
    ROBOT_MOTION_INFO_UNION motionInfo;
    
    req = (Frame_Param_Req *)data;
    
    if(req->ParamProc == PARAM_WRITE){								//д����,������Ч
		motionInfo.Struct.safetyLV = req->safetyLV;						
		motionInfo.Struct.goStraightLV = req->goStraightLV;
		motionInfo.Struct.backToPanelLV = req->backToPanelLV;
		motionInfo.Struct.moveBack50cmLV = req->moveBack50cmLV;
		motionInfo.Struct.moveForward20cmLV = req->moveForward20cmLV;
		motionInfo.Struct.turnStraightAV = req->turnStraightAV;
		motionInfo.Struct.rotateAngleAV = req->rotateAngleAV;		
 		ParamInfoStruct.robotMotionStruct.write(motionInfo);			    
	}else if(req->ParamProc == PARAM_READ) {						//��ȡ����
		ParamInfoStruct.robotMotionStruct.read(&motionInfo);
		ack.safetyLV = motionInfo.Struct.safetyLV;
		ack.goStraightLV = motionInfo.Struct.goStraightLV;
		ack.backToPanelLV = motionInfo.Struct.backToPanelLV;
		ack.moveBack50cmLV = motionInfo.Struct.moveBack50cmLV;
		ack.moveForward20cmLV = motionInfo.Struct.moveForward20cmLV;
		ack.turnStraightAV = motionInfo.Struct.turnStraightAV;
		ack.rotateAngleAV = motionInfo.Struct.rotateAngleAV;
	}
    
    ack.head = FRAME_HEAD;
    ack.type = req->type + 1;
    ack.length = sizeof(ack) - 5;
    ack.serial = req->serial;
    memcpy(ack.ID, sRobotIdInfo.Struct.robotId, sizeof(ack.ID));
    ack.checksum = CheckCode_xor8((uint8_t *)&ack, sizeof(ack)-2);
    ack.tail = FRAME_TAIL;
    
    send((uint8_t *)&ack, sizeof(ack));
}

void heartbeat_send_frame(uint8_t *data, SEND_FUNC send)
{
    POSITION_INFO_STRUCT posInfo;
    BATTERY_INFO_STRUCT  batInfo;
    GPS_INFO_STRUCT      gpsInfo;

    static uint8_t serial = 0;
    
    Gps_getInfo(&gpsInfo);
    PositionInfo_get(&posInfo);
    BatteryInfo_getValue(&batInfo);
        
    Frame_HeartBeat_Ack frame;
    frame.head = FRAME_HEAD;
    frame.type = FRAME_TYPE_HEART_BEAT + 1;
    frame.length = sizeof(frame) - 5;
    frame.serial = (data != NULL ? data[3] : serial++);
    memcpy(frame.ID, sRobotIdInfo.Struct.robotId, sizeof(frame.ID));
    memcpy(frame.firmwareVersion, g_Version, sizeof(frame.firmwareVersion));
    frame.controlMethod = RoTaskMagStruct.RunMethon;
    frame.taskStatus = RoTaskMagStruct.RunSta;
    frame.warningFlag = htonl((SafetyFlagUnion.SafetyFlagLevel.WarningFlag));
    frame.dropSersor = LimitSwitchInfo_getBits();
    frame.radarSersor = *(uint8_t *)&g_SampleBoardInfo;
    frame.radarLeftFront = htons(g_SampleBoardInfo.radar1st);
    frame.radarLeftRear = htons(g_SampleBoardInfo.radar2nd);
    frame.radarRightFront = htons(g_SampleBoardInfo.radar3rd);
    frame.radarRightRear = htons(g_SampleBoardInfo.radar4th);
    frame.magnaticGuider = htonl(g_MagInfo);
    frame.longtitude = htonll(posInfo.CurPoint.longitude * 1E13);
    frame.lattitude = htonll(posInfo.CurPoint.latitude * 1E13);
    frame.azimuth = htons((uint16_t)(posInfo.AzimuthReal * 100));
    frame.linearVelocity = (int8_t)(round(MotionCtlStruct.StateInfo.MotionParmInfo.linearVelocity));
    frame.angleVelocity = (int8_t)(round(MotionCtlStruct.StateInfo.MotionParmInfo.angularVelocity));
    frame.brushStatus = BrushCtlStruct.Sta;
    frame.currentMileage = htonl(MotionCtlStruct.StateInfo.MileageInfo.onceMeter);
    frame.currentCleanTime = htonl(MotionCtlStruct.StateInfo.MileageInfo.onceSecond);
    frame.batteryVoltage = htons((int16_t)BatteryInfoStruct.voltageAdjust);
    frame.batteryStatus = (uint8_t)BatMagStruct.getPercent();
    frame.batteryTemp = htons((int16_t)(TemperatureInfoStruct.curBatteryAverage * 100));
    frame.cabinetTemp = htons((int16_t)(TemperatureInfoStruct.curCabinetAverage * 100));
    frame.temperature = htons(0);
    frame.windVelocity = htons(0);
    frame.weather = 0;
    frame.totalMileage = htonll(MotionCtlStruct.StateInfo.MileageInfo.totalMeter);
    frame.totalCleanTime = htonll(MotionCtlStruct.StateInfo.MileageInfo.totalSecond);
    frame.disChargeCurrent = htons((int16_t)batInfo.dischargeCurrentAdjust);
    frame.chargeCurrent = htons((int16_t)batInfo.chargeCurrentAdjust);
    frame.timestamp = htonll(sMapInfo.Struct.feature.timestamp); //htonll(g_feature_timestamp);
    frame.random = htonl(sMapInfo.Struct.feature.random); //htonl(g_feature_random);
    frame.satInView = (uint8_t)gpsInfo.satliteInView;
    frame.satInUse = (uint8_t)gpsInfo.satliteInUse;
    frame.isTaskBreak = (uint8_t)AutopilotInfoStruct.isTaskBreak;
    frame.posValid = posInfo.PosVaildSta;
    frame.dirValid = posInfo.AzimuthValidSta;
    memcpy(frame.mapName, sMapInfo.Struct.name, sizeof(sMapInfo.Struct.name));
    memset(frame.reserve, 0, sizeof(frame.reserve));
	frame.cruiseTotal = htonl(AutopilotInfoStruct.cruiseTotal);
	frame.cruiseIndex = htonl(AutopilotInfoStruct.cruiseIndex);
    frame.leftDrvErrCode = DriverManageStruct.LeftDrvSta.errCode;
    frame.rightDrvErrCode = DriverManageStruct.RightDrvSta.errCode;
    frame.leftDrvStaCode = DriverManageStruct.LeftDrvSta.ReadySta;
    frame.rightDrvStaCode = DriverManageStruct.RightDrvSta.ReadySta;
    frame.errorFlag = htonl(SafetyFlagUnion.SafetyFlagLevel.ErrorFlag);
    frame.onSectorType = (uint8_t)AutopilotInfoStruct.onSectorType;
    frame.checkSum = CheckCode_xor8((uint8_t *)&frame, sizeof(frame)-2);
    frame.tail = FRAME_TAIL;
    
    send((uint8_t *)&frame, sizeof(frame));
}

void heartbeat_process(uint8_t *data, SEND_FUNC send)
{
#define ADJUST_PERIOD 201600                              //һ������У׼һ��RTC�����ֵ����3��һ����������ġ�
    static uint32_t adjustRTCPeriod = ADJUST_PERIOD;      //У׼RTC������
    Frame_HeartBeat_Req *frame;
    RTC_TIME_STRUCT rtc;
    
    frame = (Frame_HeartBeat_Req *)data;
    
    if(frame->deveice == DEVICE_PAD)
    {
        heartbeat_send_frame(data, send);
    }
    else
    {
        g_WH_State.connectTimeoutCnt = 0;
        Safety_setFlagBit(BIT_Warning_CellularAbnormal, 0);
        
//        if(adjustRTCPeriod++ > ADJUST_PERIOD)
//        {
//            adjustRTCPeriod = 0;
//            rtc.year = ntohs(frame->year);
//            rtc.month = frame->month;
//            rtc.mday = frame->day;
//            rtc.wday = 0;
//            rtc.hour = frame->time[0];
//            rtc.min = frame->time[1];
//            rtc.sec = frame->time[2];
//            RTCx_set(rtc);
//        }
    }
}
