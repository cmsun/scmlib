/**
*****************************************************************************
* @��  ���� mod_paramaterInfo.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 6-Jun-2018
* @��  ���� ������Ϣģ�����ļ�
******************************************************************************
* @��  ע����Ҫ�ȳ�ʼ����������
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_paramaterInfo.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define CHIPSET_PAGE_SIZE           (uint16_t)FLASH_PAGE_SIZE

#define PARAM_DEFAULR_WRITE			(bool)true
#define FORCE_TO_WRITE_ID			(bool)false

#define BATTERY_FORMULA_ADDRESS 	CHIPSET_PAGE_SIZE * 0
#define ROBOT_MILEAGE_ADDRESS       CHIPSET_PAGE_SIZE * 1
#define ROBOT_MOTION_ADDRESS 		CHIPSET_PAGE_SIZE * 2
#define ROBOT_RESUME_ADDRESS 		CHIPSET_PAGE_SIZE * 3
#define ROBOT_TIME_ADDRESS 			CHIPSET_PAGE_SIZE * 4
#define ROBOT_ID_ADDRESS            CHIPSET_PAGE_SIZE * 5
#define MAP_INFO_ADDRESS            CHIPSET_PAGE_SIZE * 6
#define IMU_OFFSET_ADDRESS			CHIPSET_PAGE_SIZE * 7
#define HMC_OFFSET_ADDRESS          CHIPSET_PAGE_SIZE * 8

#define PARAM_WRITE_FLAG			(uint8_t)0xA5

#define CALCU_CRC                   CheckCode_crc16

#if MEM_MEDIUM_SEL
	#define PARAM_INIT           	W25qxx_init
	#define PARAM_WRITE				W25qxx_writeBuffer
	#define PARAM_READ				W25qxx_readBuffer
#else
	#define PARAM_INIT          	M95m02dr_init
	#define PARAM_WRITE				M95m02dr_write
	#define PARAM_READ				M95m02dr_read
#endif


//��̬����
static PARAM_PROC_STATE_ENUM ParamInfo_init(void);

static PARAM_PROC_STATE_ENUM ParamInfo_initBatFormula(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeBatFormula(BATTERY_FORMULA_INFO_UNION uBatFormulaInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readBatFormula(BATTERY_FORMULA_INFO_UNION *pBatFormulaInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initRobotMileage(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeRobotMileage(ROBOT_MILEAGE_INFO_UNION uRobotMileageInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readRobotMileage(ROBOT_MILEAGE_INFO_UNION *pRobotMileageInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initRobotMotion(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeRobotMotion(ROBOT_MOTION_INFO_UNION uRobotMotionInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readRobotMotion(ROBOT_MOTION_INFO_UNION *pRobotMotionInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initRobotTime(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeRobotTime(ROBOT_TIME_INFO_UNION uRobotTimeInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readRobotTime(ROBOT_TIME_INFO_UNION *pRobotTimeInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initRobotResume(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeRobotResume(ROBOT_RESUME_INFO_UNION uRoboResumeInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readRobotResume(ROBOT_RESUME_INFO_UNION *pRoboResumeInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initRobotId(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeRobotId(ROBOT_ID_INFO_UNION uRobotIdInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readRobotId(ROBOT_ID_INFO_UNION *pRobotIdInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initMapInfo(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeMapInfo(MAP_INFO_UNION uMapInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readMapInfo(MAP_INFO_UNION *pMapInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initImuOffset(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeImuOffset(IMU_OFFSET_UNION uImuOffsetInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readImuOffset(IMU_OFFSET_UNION *pImuOffsetInfo);

static PARAM_PROC_STATE_ENUM ParamInfo_initHmcOffset(void);
static PARAM_PROC_STATE_ENUM ParamInfo_writeHmcOffset(HMC_OFFSET_UNION uHmcOffsetInfo);
static PARAM_PROC_STATE_ENUM ParamInfo_readHmcOffset(HMC_OFFSET_UNION *pHmcOffsetInfo);


//��̬����
static const ROBOT_ID_INFO_UNION sDefaultId = {
	.Struct.robotId[0] = 0x18,	/* Type */
	.Struct.robotId[1] = 0x91,	/* Modle */
	.Struct.robotId[2] = 0x55,	/* Factory */
	.Struct.robotId[3] = 0x18,	/* Data  */
	.Struct.robotId[4] = 0x07,	
	.Struct.robotId[5] = 0x15,	
	.Struct.robotId[6] = 0x00,	/* Number */
	.Struct.robotId[7] = 0x00,
	.Struct.robotId[8] = 0x01,
	.Struct.writeFlag =  PARAM_WRITE_FLAG,
};

static const ROBOT_MILEAGE_INFO_UNION sDefaultMileage = {
	.Struct.totalMeter = 0,
	.Struct.totalSecond = 0,
	.Struct.writeFlag = PARAM_WRITE_FLAG,
};

static const ROBOT_MOTION_INFO_UNION sDefaultMotion = {
    .Struct.safetyLV = 8,
    .Struct.goStraightLV = 15,
    .Struct.backToPanelLV = 5,
    .Struct.moveBack50cmLV = 10,
    .Struct.moveForward20cmLV = 10,
    .Struct.turnStraightAV = 10,
	.Struct.rotateAngleAV = 5,
	.Struct.writeFlag = PARAM_WRITE_FLAG,
};

static const ROBOT_TIME_INFO_UNION sDefaultTime = {
	.Struct.timeRange.startHour = 6,
	.Struct.timeRange.startMinuter = 0,
	.Struct.timeRange.endHour = 18,
	.Struct.timeRange.endMinuter = 00,

	.Struct.timeStart.startYear = 2018,
	.Struct.timeStart.startMouth = 1,
	.Struct.timeStart.startDay = 1,
	.Struct.writeFlag = PARAM_WRITE_FLAG
};

static const ROBOT_RESUME_INFO_UNION sDefaultResume = {
	.Struct.garageSelect = -1,
	.Struct.returnListSelect = 0,
	.Struct.resumeTarget = 0,
    .Struct.cruiseIndex = 0,
	.Struct.isTaskBreak = 0,
	.Struct.writeFlag = PARAM_WRITE_FLAG,
};

static const BATTERY_FORMULA_INFO_UNION sDefaultFormula = {
    .Struct.VolParam = {1.0,0.0},
    .Struct.ChargeCurParam = {1.0,0.0},
    .Struct.DisChargeCurParam = {1.0,0.0},
	.Struct.writeFlag = PARAM_WRITE_FLAG
};

static const MAP_INFO_UNION sDefaultMapInfo = {
    .Struct.name = {0},
    .Struct.feature.timestamp = 0,
    .Struct.feature.random = 0,
    .Struct.writeFlag = PARAM_WRITE_FLAG
};

static const IMU_OFFSET_UNION sDefaultImuOffsetInfo = {
    .Struct.Accel = {0,0,0},
    .Struct.Gyro = {0,0,0}
};

static const HMC_OFFSET_UNION sDefaultHmcOffsetInfo = {
    .Struct.Max = {0,0,0},
    .Struct.Min = {0,0,0}
};

//ȫ�ֱ���
PARAMATER_INFO_STRUCT ParamInfoStruct = {
	
    .batteryFormulaStruct.init = ParamInfo_initBatFormula,
    .batteryFormulaStruct.write = ParamInfo_writeBatFormula,
    .batteryFormulaStruct.read = ParamInfo_readBatFormula,

    .robotMileageStruct.init = ParamInfo_initRobotMileage,
    .robotMileageStruct.write = ParamInfo_writeRobotMileage,
    .robotMileageStruct.read = ParamInfo_readRobotMileage,

    .robotMotionStruct.init = ParamInfo_initRobotMotion,
    .robotMotionStruct.write = ParamInfo_writeRobotMotion,
    .robotMotionStruct.read = ParamInfo_readRobotMotion,

    .robotResumeStruct.init = ParamInfo_initRobotResume,
    .robotResumeStruct.write = ParamInfo_writeRobotResume,
    .robotResumeStruct.read = ParamInfo_readRobotResume,

    .robotTimeStruct.init = ParamInfo_initRobotTime,
    .robotTimeStruct.write = ParamInfo_writeRobotTime,
    .robotTimeStruct.read = ParamInfo_readRobotTime,

    .robotIdStruct.init = ParamInfo_initRobotId,
    .robotIdStruct.write = ParamInfo_writeRobotId,
    .robotIdStruct.read = ParamInfo_readRobotId,
    
    .mapInfoStruct.init = ParamInfo_initMapInfo,
    .mapInfoStruct.write = ParamInfo_writeMapInfo,
    .mapInfoStruct.read = ParamInfo_readMapInfo,

	.imuOffsetStruct.init = ParamInfo_initImuOffset,
	.imuOffsetStruct.write = ParamInfo_writeImuOffset,
	.imuOffsetStruct.read = ParamInfo_readImuOffset,

	.hmcOffsetStruct.init = ParamInfo_initHmcOffset,
	.hmcOffsetStruct.write = ParamInfo_writeHmcOffset,
	.hmcOffsetStruct.read = ParamInfo_readHmcOffset,

	.init = ParamInfo_init
};



/*
******************************************************************************
*	�� �� ��: ParamInfo_init
*	����˵��: ������Ϣ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_init(void)
{
	PARAM_PROC_STATE_ENUM rSta;

	PARAM_INIT();

	rSta = ParamInfo_initRobotId();

	if(rSta == PARAM_PROC_SUCCEED)
		rSta = ParamInfo_initRobotMileage();

	if(rSta == PARAM_PROC_SUCCEED)
		rSta = ParamInfo_initRobotMotion();

	if(rSta == PARAM_PROC_SUCCEED)
		rSta = ParamInfo_initRobotResume();

	if(rSta == PARAM_PROC_SUCCEED)	
		rSta = ParamInfo_initRobotTime();

	if(rSta == PARAM_PROC_SUCCEED)	
		rSta = ParamInfo_initBatFormula();
    
    if(rSta == PARAM_PROC_SUCCEED)	
		rSta = ParamInfo_initMapInfo();

    if(rSta == PARAM_PROC_SUCCEED)	
		rSta = ParamInfo_initImuOffset();

    if(rSta == PARAM_PROC_SUCCEED)	
		rSta = ParamInfo_initHmcOffset();
    
	if(rSta != PARAM_PROC_SUCCEED)
		Safety_setFlagBit(BIT_Error_Eeprom,1);

	return rSta;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotId
*	����˵��: ������Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initRobotId(void)
{
	ROBOT_ID_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;

	rState = ParamInfo_readRobotId(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeRobotId(sDefaultId);
		rState = ParamInfo_readRobotId(&tInfo);
	}else{
		if(FORCE_TO_WRITE_ID){												//ǿ��дID,�����β���
			if(0 != memcmp(tInfo.Struct.robotId,sDefaultId.Struct.robotId,ID_LENGTH)){
				ParamInfo_writeRobotId(sDefaultId);
			}
		}
	}
    
    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeRobotId
*	����˵��: д�豸ID��Ϣ
*	��    ��: uInfo���豸ID�ṹ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeRobotId(ROBOT_ID_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry, ROBOT_ID_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, ROBOT_ID_ADDRESS, ROBOT_ID_INFO_LENGTH);
	
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readRobotId
*	����˵��: ���豸ID��Ϣ
*	��    ��: pRobotIdInfo���豸ID�ṹ��ָ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readRobotId(ROBOT_ID_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Struct.robotId,ROBOT_ID_ADDRESS,ROBOT_ID_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){						//У����
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, ROBOT_ID_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){							//У������
            return PARAM_PROC_SUCCEED;
        }
	}
    
    return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotMileage
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initRobotMileage(void)
{
	ROBOT_MILEAGE_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readRobotMileage(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeRobotMileage(sDefaultMileage);
		rState = ParamInfo_readRobotMileage(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeRobotMileage
*	����˵��: д�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeRobotMileage(ROBOT_MILEAGE_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,ROBOT_MILEAGE_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, ROBOT_MILEAGE_ADDRESS, ROBOT_MILEAGE_INFO_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readRobotMileage
*	����˵��: ��ȡ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readRobotMileage(ROBOT_MILEAGE_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,ROBOT_MILEAGE_ADDRESS,ROBOT_MILEAGE_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, ROBOT_MILEAGE_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}


/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotMotion
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initRobotMotion(void)
{
	ROBOT_MOTION_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readRobotMotion(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeRobotMotion(sDefaultMotion);
		rState = ParamInfo_readRobotMotion(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeRobotMotion
*	����˵��: д�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeRobotMotion(ROBOT_MOTION_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,ROBOT_MOTION_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, ROBOT_MOTION_ADDRESS, ROBOT_MOTION_INFO_LENGTH);

    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readRobotMotion
*	����˵��: ��ȡ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readRobotMotion(ROBOT_MOTION_INFO_UNION *pRobotMotionInfo)
{
    PARAM_PROC_STATE_ENUM rState;
    
	PARAM_READ((uint8_t*)pRobotMotionInfo,ROBOT_MOTION_ADDRESS,ROBOT_MOTION_INFO_LENGTH + 1);

	if(pRobotMotionInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        rState = PARAM_PROC_SUCCEED;
	}else{
        rState = PARAM_PROC_FAILED;
    }

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotResume
*	����˵��: ���ݲ�����ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initRobotResume(void)
{
	ROBOT_RESUME_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readRobotResume(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeRobotResume(sDefaultResume);
		rState = ParamInfo_readRobotResume(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeRobotResume
*	����˵��: д���ݲ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeRobotResume(ROBOT_RESUME_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,ROBOT_RESUME_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, ROBOT_RESUME_ADDRESS, ROBOT_RESUME_INFO_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readRobotResume
*	����˵��: ��ȡ������Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readRobotResume(ROBOT_RESUME_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,ROBOT_RESUME_ADDRESS,ROBOT_RESUME_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, ROBOT_RESUME_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotTime
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initRobotTime(void)
{
	ROBOT_TIME_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readRobotTime(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeRobotTime(sDefaultTime);
		rState = ParamInfo_readRobotTime(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeRobotTime
*	����˵��: д�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeRobotTime(ROBOT_TIME_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,ROBOT_TIME_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, ROBOT_TIME_ADDRESS, ROBOT_TIME_INFO_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readRobotTime
*	����˵��: ��ȡ�����Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readRobotTime(ROBOT_TIME_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,ROBOT_TIME_ADDRESS,ROBOT_TIME_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, ROBOT_TIME_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotTime
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initBatFormula(void)
{
	BATTERY_FORMULA_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readBatFormula(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeBatFormula(sDefaultFormula);
		rState = ParamInfo_readBatFormula(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initRobotTime
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeBatFormula(BATTERY_FORMULA_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,BAT_FORMULA_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, BATTERY_FORMULA_ADDRESS, BAT_FORMULA_INFO_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readBatFormula
*	����˵��: �����Ϣ��ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readBatFormula(BATTERY_FORMULA_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,BATTERY_FORMULA_ADDRESS,BAT_FORMULA_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, BAT_FORMULA_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initMapInfo
*	����˵��: ��ͼ��Ϣ��ʼ������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initMapInfo(void)
{
	MAP_INFO_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readMapInfo(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeMapInfo(sDefaultMapInfo);
		rState = ParamInfo_readMapInfo(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_writeMapInfo
*	����˵��: ��ͼ��Ϣд��EEPROM����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeMapInfo(MAP_INFO_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry, MAP_INFO_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, MAP_INFO_ADDRESS, MAP_INFO_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readMapInfo
*	����˵��: ��ͼ��Ϣ��EEPROM��ȡ����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readMapInfo(MAP_INFO_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry, MAP_INFO_ADDRESS, MAP_INFO_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, MAP_INFO_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initImuOffset
*	����˵��: IMUƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initImuOffset(void)
{
	IMU_OFFSET_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readImuOffset(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeImuOffset(sDefaultImuOffsetInfo);
		rState = ParamInfo_readImuOffset(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initImuOffset
*	����˵��: IMUƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeImuOffset(IMU_OFFSET_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,IMU_OFFSET_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, IMU_OFFSET_ADDRESS, IMU_OFFSET_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readImuOffset
*	����˵��: IMUƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readImuOffset(IMU_OFFSET_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,IMU_OFFSET_ADDRESS,IMU_OFFSET_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, IMU_OFFSET_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initHmcOffset
*	����˵��: HMCƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_initHmcOffset(void)
{
	HMC_OFFSET_UNION tInfo;
    PARAM_PROC_STATE_ENUM rState;
	
	rState = ParamInfo_readHmcOffset(&tInfo);
	if(rState == PARAM_PROC_FAILED){
		if(PARAM_DEFAULR_WRITE) ParamInfo_writeHmcOffset(sDefaultHmcOffsetInfo);
		rState = ParamInfo_readHmcOffset(&tInfo);
	}

    return rState;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_initHmcOffset
*	����˵��: Hmcƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_writeHmcOffset(HMC_OFFSET_UNION uInfo)
{
	uInfo.Struct.writeFlag = PARAM_WRITE_FLAG;
    uInfo.Struct.checkSum = CALCU_CRC(uInfo.Arry,HMC_OFFSET_LENGTH - 2);
	PARAM_WRITE(uInfo.Arry, HMC_OFFSET_ADDRESS, HMC_OFFSET_LENGTH);
    
    return PARAM_PROC_SUCCEED;
}

/*
******************************************************************************
*	�� �� ��: ParamInfo_readHmcOffset
*	����˵��: Hmcƫ�ƻ�ȡ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
PARAM_PROC_STATE_ENUM ParamInfo_readHmcOffset(HMC_OFFSET_UNION *pInfo)
{
	PARAM_READ(pInfo->Arry,HMC_OFFSET_ADDRESS,HMC_OFFSET_LENGTH);

	if(pInfo->Struct.writeFlag == PARAM_WRITE_FLAG){
        uint16_t tCheckSum = CALCU_CRC(pInfo->Arry, HMC_OFFSET_LENGTH - 2); 
        if(tCheckSum == pInfo->Struct.checkSum){
            return PARAM_PROC_SUCCEED;
        }
    }

	return PARAM_PROC_FAILED;
}
