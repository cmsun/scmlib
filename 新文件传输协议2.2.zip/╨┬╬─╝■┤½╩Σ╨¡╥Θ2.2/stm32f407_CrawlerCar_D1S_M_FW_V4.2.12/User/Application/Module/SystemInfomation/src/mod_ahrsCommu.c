/**
*****************************************************************************
* @��  ���� mod_ahrsCommu.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 27-Aug-2019
* @��  ���� ��������̬������λ��ͨ��
******************************************************************************
* @�޸ļ�¼��
*   2019/08/27����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_ahrsCommu.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define AHRC_COMMU_PORT     HUSART3

#define AHRS_FRAME_HEAD1    0xA5
#define AHRS_FRAME_HEAD2    0x5A
#define AHRS_FRAME_TAIL     0xAA

//��̬����
static uint16_t AhrsCommu_getFrame(uint8_t *pBuf);
static uint16_t  AhrsCommu_cmdHandle(uint8_t *pFrame, uint16_t framCnt);

//��̬����
static int32_t rxAhrsCommuCnt = 0;
static int32_t txAhrsCommuCnt = 0;

//ȫ�ֱ���
AHRSCOMMU_INFO_STRUCT   sAhrscommuInfo;



/*
******************************************************************************
*	�� �� ��: AhrsCommuCallBack
*	����˵��: �����жϻص�����
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommuCallBack_Rx(void){
 	rxAhrsCommuCnt += 1;
}
 
void AhrsCommuCallBack_Tx(void){
 	txAhrsCommuCnt += 1;
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_portInit
*	����˵��: ��������ϢIO�ڳ�ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_portInit(void)
{
	USARTx_CALLBACK CallBack;
	CallBack.RxCompletePtr = AhrsCommuCallBack_Rx;
	CallBack.TxCompletePtr = AhrsCommuCallBack_Tx;
    USARTx_initNum(AHRC_COMMU_PORT,CallBack);
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_init
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_init(void)
{
    AhrsCommu_portInit();
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_send
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_send(uint8_t *pBuf, uint16_t length)
{
    USARTx_sendBuff(AHRC_COMMU_PORT, pBuf, length);
}

/*
******************************************************************************
*	�� �� ��: Ahrscommu_reportMagneticInfo
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_reportMagneticInfo(int16_t *pMax, int16_t *pMin, int16_t percent)
{
    MAGNETIC_INFO_REPORT_STRUCT uMagnInfo;
    uint8_t *pTxBuf = (uint8_t*)&uMagnInfo;
    
    uMagnInfo.head1 = AHRS_FRAME_HEAD1;
    uMagnInfo.head2 = AHRS_FRAME_HEAD2;
    uMagnInfo.length = (14 + 4);
    uMagnInfo.type = 0xA4;
    
    uMagnInfo.Max[0] = pMax[0];
    uMagnInfo.Max[1] = pMax[1];
    uMagnInfo.Max[2] = pMax[2];
    
    uMagnInfo.Min[0] = pMin[0];
    uMagnInfo.Min[1] = pMin[1];
    uMagnInfo.Min[2] = pMin[2];
    
    uMagnInfo.percentage = percent;
    
    if(uMagnInfo.Max[0] < 0)
        uMagnInfo.Max[0] = INT16_MAX - uMagnInfo.Max[0] + 1;
    if(uMagnInfo.Max[1] < 0)
        uMagnInfo.Max[1] = INT16_MAX - uMagnInfo.Max[1] + 1;
    if(uMagnInfo.Max[2] < 0)
        uMagnInfo.Max[2] = INT16_MAX - uMagnInfo.Max[2] + 1;
    
    if(uMagnInfo.Min[0] < 0)
        uMagnInfo.Min[0] = INT16_MAX - uMagnInfo.Min[0] + 1;
    if(uMagnInfo.Min[1] < 0)
        uMagnInfo.Min[1] = INT16_MAX - uMagnInfo.Min[1] + 1;
    if(uMagnInfo.Min[2] < 0)
        uMagnInfo.Min[2] = INT16_MAX - uMagnInfo.Min[2] + 1;
    
    uMagnInfo.Max[0] = htons(uMagnInfo.Max[0]);
    uMagnInfo.Max[1] = htons(uMagnInfo.Max[1]);
    uMagnInfo.Max[2] = htons(uMagnInfo.Max[2]);
    
    uMagnInfo.Min[0] = htons(uMagnInfo.Min[0]);
    uMagnInfo.Min[1] = htons(uMagnInfo.Min[1]);
    uMagnInfo.Min[2] = htons(uMagnInfo.Min[2]);
    
    uMagnInfo.percentage = htons(uMagnInfo.percentage);
    
    uMagnInfo.checkSum = CheckCode_sum(pTxBuf + 2, 14 + 2);
    uMagnInfo.tail = AHRS_FRAME_TAIL;

    AhrsCommu_send(pTxBuf,sizeof(RAW_INFO_REPORT_STRUCT));
}

/*
******************************************************************************
*	�� �� ��: Ahrscommu_reportRawInfo
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_reportRawInfo(int16_t *pAccel,int16_t *pGryo, int16_t *pMagn)
{
    RAW_INFO_REPORT_STRUCT uRawInfo;
    uint8_t *pTxBuf = (uint8_t*)&uRawInfo;

    uRawInfo.head1 = AHRS_FRAME_HEAD1;
    uRawInfo.head2 = AHRS_FRAME_HEAD2;
    uRawInfo.length = (18 + 4);
    uRawInfo.type = 0xA2;
    uRawInfo.Accel[0] = pAccel[0];
    uRawInfo.Accel[1] = pAccel[1];
    uRawInfo.Accel[2] = pAccel[2];
    uRawInfo.Gyro[0] = pGryo[0];
    uRawInfo.Gyro[1] = pGryo[1];
    uRawInfo.Gyro[2] = pGryo[2];
    uRawInfo.Magn[0] = pMagn[0];
    uRawInfo.Magn[1] = pMagn[1];
    uRawInfo.Magn[2] = pMagn[2];

    if(uRawInfo.Accel[0] < 0)
        uRawInfo.Accel[0] = INT16_MAX - uRawInfo.Accel[0] + 1;
    if(uRawInfo.Accel[1] < 0)
        uRawInfo.Accel[1] = INT16_MAX - uRawInfo.Accel[1] + 1;
    if(uRawInfo.Accel[2] < 0)
        uRawInfo.Accel[2] = INT16_MAX - uRawInfo.Accel[2] + 1;
    if(uRawInfo.Gyro[0] < 0)
        uRawInfo.Gyro[0] = INT16_MAX - uRawInfo.Gyro[0] + 1;
    if(uRawInfo.Gyro[1] < 0)
        uRawInfo.Gyro[1] = INT16_MAX - uRawInfo.Gyro[1] + 1;
    if(uRawInfo.Gyro[2] < 0)
        uRawInfo.Gyro[2] = INT16_MAX - uRawInfo.Gyro[2] + 1;
    if(uRawInfo.Magn[0] < 0)
        uRawInfo.Magn[0] = INT16_MAX - uRawInfo.Magn[0] + 1;
    if(uRawInfo.Magn[1] < 0)
        uRawInfo.Magn[1] = INT16_MAX - uRawInfo.Magn[1] + 1;
    if(uRawInfo.Magn[2] < 0)
        uRawInfo.Magn[2] = INT16_MAX - uRawInfo.Magn[2] + 1;
    
    uRawInfo.Accel[0] = htons(uRawInfo.Accel[0]);
    uRawInfo.Accel[1] = htons(uRawInfo.Accel[1]);
    uRawInfo.Accel[2] = htons(uRawInfo.Accel[2]);

    uRawInfo.Gyro[0] = htons(uRawInfo.Gyro[0]);
    uRawInfo.Gyro[1] = htons(uRawInfo.Gyro[1]);
    uRawInfo.Gyro[2] = htons(uRawInfo.Gyro[2]);

    uRawInfo.Magn[0] = htons(uRawInfo.Magn[0]);
    uRawInfo.Magn[1] = htons(uRawInfo.Magn[1]);
    uRawInfo.Magn[2] = htons(uRawInfo.Magn[2]);

    uRawInfo.checkSum = CheckCode_sum(pTxBuf + 2, 18 + 2);
    uRawInfo.tail = AHRS_FRAME_TAIL;

    AhrsCommu_send(pTxBuf,sizeof(RAW_INFO_REPORT_STRUCT));
}

/*
******************************************************************************
*	�� �� ��: Ahrscommu_reportAttitudeInfo
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_reportAttitudeInfo(int16_t yaw, int16_t pitch, int16_t roll, 
                                  int16_t height, int16_t temprature, int16_t pressure, int16_t calcuFreq)
{
    ATTITUDE_INFO_REPORT_STRUCT uAttitudeInfo;
    uint8_t *pTxBuf = (uint8_t*)&uAttitudeInfo;

    uAttitudeInfo.head1 = AHRS_FRAME_HEAD1;
    uAttitudeInfo.head2 = AHRS_FRAME_HEAD2;
    uAttitudeInfo.length = (14 + 4);
    uAttitudeInfo.type = 0xA1;

    uAttitudeInfo.yaw = yaw;
    uAttitudeInfo.pitch = pitch;
    uAttitudeInfo.roll = roll;
    uAttitudeInfo.height = height;
    uAttitudeInfo.temperature = temprature;
    uAttitudeInfo.pressure = pressure;
    uAttitudeInfo.calcuFreq = calcuFreq;

    if(uAttitudeInfo.yaw < 0)
        uAttitudeInfo.yaw = INT16_MAX - uAttitudeInfo.yaw + 1;
    if(uAttitudeInfo.pitch < 0)
        uAttitudeInfo.pitch = INT16_MAX - uAttitudeInfo.pitch + 1;
    if(uAttitudeInfo.roll < 0)
        uAttitudeInfo.roll = INT16_MAX - uAttitudeInfo.roll + 1;
    if(uAttitudeInfo.height < 0)
        uAttitudeInfo.height = INT16_MAX - uAttitudeInfo.height + 1;
    if(uAttitudeInfo.temperature < 0)
        uAttitudeInfo.temperature = INT16_MAX - uAttitudeInfo.temperature + 1;
    if(uAttitudeInfo.pressure < 0)
        uAttitudeInfo.pressure = INT16_MAX - uAttitudeInfo.pressure + 1;
    if(uAttitudeInfo.calcuFreq < 0)
        uAttitudeInfo.calcuFreq = INT16_MAX - uAttitudeInfo.calcuFreq + 1;
    
    uAttitudeInfo.yaw = htons(uAttitudeInfo.yaw);
    uAttitudeInfo.pitch = htons(uAttitudeInfo.pitch);
    uAttitudeInfo.roll = htons(uAttitudeInfo.roll);
    uAttitudeInfo.height = htons(uAttitudeInfo.height);
    uAttitudeInfo.temperature = htons(uAttitudeInfo.temperature);
    uAttitudeInfo.pressure = htons(uAttitudeInfo.pressure);
    uAttitudeInfo.calcuFreq = htons(uAttitudeInfo.calcuFreq);

    uAttitudeInfo.checkSum = CheckCode_sum(pTxBuf + 2, 14  + 2);
    uAttitudeInfo.tail = AHRS_FRAME_TAIL;

    AhrsCommu_send(pTxBuf,sizeof(ATTITUDE_INFO_REPORT_STRUCT));
}


/*
******************************************************************************
*	�� �� ��: AhrsCommu_loopRead
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_loopRead(void)
{
#define FRAME_LENGTH    64
    static uint16_t FrameBuffCnt = 0;
    static uint8_t FrameBuff[FRAME_LENGTH] = {0};
   
    if(rxAhrsCommuCnt > 0){
        rxAhrsCommuCnt = 0;                                                 //�������㣬���ڿɽ�������
        FrameBuffCnt = USARTx_recvFrame(AHRC_COMMU_PORT, FrameBuff, FRAME_LENGTH);
        uint16_t rSta = AhrsCommu_cmdHandle(FrameBuff, FrameBuffCnt);
        if(rSta != 0){
            PRINT_DBG("Something wrong!!!",0);
        }
    }
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_get
*	����˵��: ��������Ϣʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
void AhrsCommu_get(AHRSCOMMU_INFO_STRUCT *pInfo)
{
    *pInfo = sAhrscommuInfo;

    sAhrscommuInfo.Cmd = NONE_INIT;
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_sumCheck
*	����˵��: ��������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
uint16_t AhrsCommu_sumCheck(uint8_t *pFrame, uint16_t framCnt)
{
	uint32_t checkSum = 0;
    uint16_t contentLen = pFrame[2];

	for (uint8_t i = 2; i < contentLen; i++)
		checkSum += pFrame[i];

	if ((checkSum % 256) == pFrame[contentLen])
		return 0;
	else
		return 1;
}

/*
******************************************************************************
*	�� �� ��: AhrsCommu_cmdHandle
*	����˵��: ��������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
uint16_t AhrsCommu_cmdHandle(uint8_t *pFrame, uint16_t framCnt)
{
    uint16_t rSta = 0;
    rSta = AhrsCommu_sumCheck(pFrame,framCnt);
    if(rSta != 0){
        return 1;
    }

    sAhrscommuInfo.Cmd = (AHRSCOMMU_CMD_ENUM)pFrame[3];
    
    return 0;
}
