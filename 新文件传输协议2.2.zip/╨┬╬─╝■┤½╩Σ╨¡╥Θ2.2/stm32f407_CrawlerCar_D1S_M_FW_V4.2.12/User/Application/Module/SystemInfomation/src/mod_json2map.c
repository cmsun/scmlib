#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <ff.h>
#include "mod_json2map.h"
#include "cJSON.h"
#include "mod_update.h"
#include "includes.h"

//cJSON��json�ļ��Ľ�����Ҫ�ϴ�Ķѿռ䣬����heap��СӦ������5K�������json�ļ��Ľ����������

extern FRESULT f_deldir(const TCHAR *path);

int js_write_block(FIL *fp, cJSON *root, int index)
{
	cJSON *array, *member, *item;
	int elementCount, size, blockNum, blockType;
    UINT btw, bw;
	double lon[4], lat[4];
	char buff[256];

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if (item == NULL) return UPDATE_ERR_JSON;
	elementCount = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if (array == NULL) return UPDATE_ERR_JSON;

	size = cJSON_GetArraySize(array);
	if (size != elementCount) return UPDATE_ERR_JSON;

	member = cJSON_GetArrayItem(array, 0);
	if (member == NULL) return UPDATE_ERR_JSON;

	item = cJSON_GetObjectItem(member, KEY_block_number);
	if (item == NULL) return UPDATE_ERR_JSON;
	blockNum = item->valueint;

	item = cJSON_GetObjectItem(member, KEY_block_type);
	if (item == NULL) return UPDATE_ERR_JSON;
	blockType = item->valueint;

	for (int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lon[i] = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lat[i] = item->valuedouble;
	}

	btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f\r\n",
            index, blockNum, blockType, lon[0], lat[0], lon[1], lat[1], lon[2], lat[2], lon[3], lat[3]);
    
	if(f_write(fp, buff, btw, &bw) != FR_OK)
        return 9;

	return 0;
}

int js_write_cruise(FIL *fp, cJSON *root)
{
	cJSON *array, *member, *item;
	int elementCount, size, blockNum, blockType, pointNum, speed;
    UINT btw, bw;
	double lon, lat;
	char buff[256];

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if (item == NULL) return UPDATE_ERR_JSON;
	elementCount = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if (array == NULL) return UPDATE_ERR_JSON;

	size = cJSON_GetArraySize(array);
	if (size != elementCount) return UPDATE_ERR_JSON;

	for (int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_block_number);
		if (item == NULL) return UPDATE_ERR_JSON;
		blockNum = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_block_type);
		if (item == NULL) return UPDATE_ERR_JSON;
		blockType = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_point_number);
		if (item == NULL) return UPDATE_ERR_JSON;
		pointNum = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lon = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lat = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_speed);
		if (item == NULL) return UPDATE_ERR_JSON;
		speed = item->valueint;

		btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%.13f,%.13f,%d\r\n",
                pointNum, blockNum, blockType, lon, lat, speed);
        
		if(f_write(fp, buff, btw, &bw) != FR_OK)
            return UPDATE_ERR_STORAGE;
	}

	return 0;
}

int js_write_garage(FIL *fp, cJSON *root, int *prevGarageNum, int *index)
{
	cJSON *array, *member, *item;
	int elementCount, size, blockNum, blockType, pointNum, speed, garageNum, garageDataType;
	double lon, lat;
	char buff[256], name[32];
    UINT btw, bw;
    FIL *hFile = NULL;

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if (item == NULL) return UPDATE_ERR_JSON;
	elementCount = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if (array == NULL) return UPDATE_ERR_JSON;

	size = cJSON_GetArraySize(array);
	if (size != elementCount) return UPDATE_ERR_JSON;

	for (int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_block_number);
		if (item == NULL) return UPDATE_ERR_JSON;
		blockNum = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_block_type);
		if (item == NULL) return UPDATE_ERR_JSON;
		blockType = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_point_number);
		if (item == NULL) return UPDATE_ERR_JSON;
		pointNum = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lon = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if (item == NULL) return UPDATE_ERR_JSON;
		lat = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_speed);
		if (item == NULL) return UPDATE_ERR_JSON;
		speed = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_garage_number);
		if (item == NULL) return UPDATE_ERR_JSON;
		garageNum = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_garage_data_type);
		if (item == NULL) return UPDATE_ERR_JSON;
		garageDataType = item->valueint;

		if (garageNum != *prevGarageNum)
		{
			*prevGarageNum = garageNum;
            *index = 0;
			snprintf(name, sizeof(name), "%s/%s%d", DIR_ROUTER, DIR_GARAGE, garageNum);
			f_mkdir(name);
            
            f_close(&fp[0]);
            f_close(&fp[1]);
            f_close(&fp[2]);
            
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, garageNum, NAME_OUTGARAGE);
            f_open(&fp[0], name, FA_CREATE_ALWAYS|FA_WRITE);
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, garageNum, NAME_INGARAGE);
            f_open(&fp[1], name, FA_CREATE_ALWAYS|FA_WRITE);
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, garageNum, NAME_RETURN);
            f_open(&fp[2], name, FA_CREATE_ALWAYS|FA_WRITE);
		}
        
        if(garageDataType == NAV_GARAGE_OUT)
            hFile = &fp[0];
        else if(garageDataType == NAV_GARAGE_IN)
            hFile = &fp[1];
        else 
            hFile = &fp[2];
        
        if(garageDataType >= NAV_GARAGE_RETURN)
        {   //����Ƿ����ߣ���Ҫ���Ϸ����ߵ����
            btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%u,%.13f,%.13f,%d\r\n",
                (*index)++, garageDataType - 2, blockNum, blockType, lon, lat, speed);
        }
        else
        {
            btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%.13f,%.13f,%d\r\n",
                pointNum, blockNum, blockType, lon, lat, speed);
        }

		if(f_write(hFile, buff, btw, &bw) != FR_OK)
            return UPDATE_ERR_STORAGE;
	}

	return 0;
}

int json2map (const char *json)
{
	char buff[2048], name[32];
	cJSON *root, *item, *timestamp, *random;
	int navigation_data_type, blockIndex = 0, returnPointIndex = 0, prevGarageNum = -1, ackflag = 0;
	FIL hJson, hBlock, hCruise, hGarage[3], hID;
    FRESULT res;
    uint32_t btw, bw;

    f_deldir(DIR_ROUTER);
	res = f_mkdir(DIR_ROUTER);
    
    snprintf(name, sizeof(name), "%s/%s", DIR_MAP, json);
	res |= f_open(&hJson, name, FA_OPEN_EXISTING|FA_READ);
	snprintf(name, sizeof(name), "%s/%s", DIR_ROUTER, NAME_BLOCK);
	res |= f_open(&hBlock, name, FA_CREATE_ALWAYS|FA_WRITE);
	snprintf(name, sizeof(name), "%s/%s", DIR_ROUTER, NAME_CRUISE);
	res |= f_open(&hCruise, name, FA_CREATE_ALWAYS|FA_WRITE);
    snprintf(name, sizeof(name), "%s/%s", DIR_ROUTER, NAME_IDENTITY);
    res |= f_open(&hID, name, FA_CREATE_ALWAYS|FA_WRITE);
    
    //��ͼ��д��ID.csv�ļ���
    res |= f_write(&hID, json, strlen(json), &bw);
    if(res != FR_OK) return UPDATE_ERR_STORAGE;
	
    while(!f_eof(&hJson))
	{
		IWDGx_feed();
		Led_setToggle(WDI_3);
		
        f_gets(buff, sizeof(buff), &hJson);
		root = cJSON_Parse(buff);

		if (root == NULL)
		{
            return UPDATE_ERR_JSON;
		}
		else
		{
			if ((item = cJSON_GetObjectItem(root, KEY_navigation_data_type)) != NULL)
			{
				navigation_data_type = item->valueint;
				switch (navigation_data_type)
				{
				case NAV_TYPE_BLOCK:
					ackflag = js_write_block(&hBlock, root, blockIndex++);
					break;
				case NAV_TYPE_CRUISE:
					ackflag = js_write_cruise(&hCruise, root);
					break;
				case NAV_TYPE_GARAGE:
					ackflag = js_write_garage(hGarage, root, &prevGarageNum, &returnPointIndex);
					break;
				default:
					break;
				}
			}
            else if ((item = cJSON_GetObjectItem(root, KEY_map_feature)) != NULL)   //��ͼ����д��ID.csv�ļ���
            {
                ackflag = 0;
                
                if ((timestamp = cJSON_GetArrayItem(item, 0)) == NULL)
                    ackflag = UPDATE_ERR_JSON;
                if ((random = cJSON_GetArrayItem(item, 1)) == NULL)
                    ackflag = UPDATE_ERR_JSON;
                btw = snprintf(buff, sizeof(buff), ",%s,%s", timestamp->valuestring, random->valuestring);
                if (f_write(&hID, buff, btw, &bw) != FR_OK)
                    ackflag = UPDATE_ERR_STORAGE;
            }
            
			cJSON_Delete(root);
            if(ackflag != 0) return ackflag;
		}
	}

	f_close(&hJson);
	f_close(&hBlock);
    f_close(&hCruise);
	f_close(&hGarage[0]);
    f_close(&hGarage[1]);
    f_close(&hGarage[2]);
    f_close(&hID);

	return 0;
}
