#ifndef _MOD_MAGNETIC_SAMPLBOARD_INTERFACE_H
#define _MOD_MAGNETIC_SAMPLBOARD_INTERFACE_H

#include <stdint.h>
#include "includes.h"

//���ݲɼ����ϵ�����
typedef struct SampleBoardInfo_TypeDef
{
    uint16_t radar1st;
    uint16_t radar2nd;
    uint16_t radar3rd;
    uint16_t radar4th;
    uint8_t  radarSta1st:  1;
    uint8_t  radarSta2nd:  1;
    uint8_t  radarSta3rd:  1;
    uint8_t  radarSta4th:  1;
    uint8_t  limitSwMagLI: 1;
    uint8_t  limitSwMagLO: 1;
    uint8_t  limitSwMagRI: 1;
    uint8_t  limitSwMagRO: 1;
} SampleBoardInfo_TypeDef;

extern SampleBoardInfo_TypeDef g_SampleBoardInfo;
extern int g_MagInfo;

void magnetic_sampleboard_init(void);
void magnetic_samplboard_request(void);
void magnetic_sampleboard_poll(void);

extern SampleBoardInfo_TypeDef magnetic_info;

static inline int magneitc_get_info(void)
{
    return g_MagInfo;
}

static inline const SampleBoardInfo_TypeDef *sampleboard_get_info(void)
{
    return &g_SampleBoardInfo;
}

static inline int sampleboard_limitSwMagLO(void)
{
    return g_SampleBoardInfo.limitSwMagLO;
}

static inline int sampleboard_limitSwMagLI(void)
{
    return g_SampleBoardInfo.limitSwMagLI;
}

static inline int sampleboard_limitSwMagRO(void)
{
    return g_SampleBoardInfo.limitSwMagRO;
}

static inline int sampleboard_limitSwMagRI(void)
{
    return g_SampleBoardInfo.limitSwMagRI;
}

#endif
