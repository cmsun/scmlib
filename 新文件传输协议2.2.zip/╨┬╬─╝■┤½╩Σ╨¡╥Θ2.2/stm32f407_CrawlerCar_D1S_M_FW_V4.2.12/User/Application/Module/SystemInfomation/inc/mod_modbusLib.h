/**
*****************************************************************************
* @��  ���� mod_modbusLib.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 8-Jun-2018
* @��  ���� modbus�û���ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/11����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_MODBUSLIB_H_
#define _MOD_MODBUSLIB_H_

#ifdef _cplusplus
	extern "C" {
#endif


//C��
#include <stdint.h>


//�ӿں���
int32_t str_len(int8_t *_str);
void str_cpy(int8_t *_tar, int8_t *_src);
int32_t str_cmp(int8_t * s1, int8_t * s2);
void mem_set(int8_t *_tar, int8_t _data, int32_t _len);

void int_to_str(int32_t _iNumber, int8_t *_pBuf, uint8_t _len);
int32_t str_to_int(int8_t *_pStr);

uint16_t BEBufToUint16(uint8_t *_pBuf);
uint16_t LEBufToUint16(uint8_t *_pBuf);

uint32_t BEBufToUint32(uint8_t *_pBuf);
uint32_t LEBufToUint32(uint8_t *_pBuf);

uint16_t CRC16_Modbus(uint8_t *_pBuf, uint16_t _usLen) ;
int32_t  CaculTwoPoint(int32_t x1, int32_t y1, int32_t x2, int32_t y2, int32_t x);

int8_t BcdToint8_t(uint8_t _bcd);
void HexToAscll(uint8_t * _pHex, int8_t *_pAscii, uint16_t _BinBytes);
uint32_t AsciiToUint32(int8_t *pAscii);

#endif

