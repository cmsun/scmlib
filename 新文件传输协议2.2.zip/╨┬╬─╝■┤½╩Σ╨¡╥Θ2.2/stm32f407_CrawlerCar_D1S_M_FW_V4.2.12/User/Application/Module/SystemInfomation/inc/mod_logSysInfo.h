/**
*****************************************************************************
* @��  ���� mod_logSysInfo.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 5-Jun-2018
* @��  ���� ��־��Ϣϵͳ�ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_LOGSYSINFO_H_
#define _MOD_LOGSYSINFO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//�궨��
#define LOG_INDEX_TOTAL        	   (uint32_t)(8)
#define EACH_INDEX_SPACE           (uint32_t)(16)

#define LOG_CONTENT_TOTAL          (uint32_t)(52)
#define EACH_LOG_SPACE             (uint32_t)(64)


//����ö��
typedef enum {
    LOG_NOT_USE = 0, 
    LOG_BE_WRITE = 1, 
    LOG_BE_READ = 2
}LOG_OPERATE_STATE_ENUM;

typedef enum{
	LOG_PROC_SUCCEED = 0,
	LOG_PROC_FAILED = 1
}LOG_PROC_STATE_ENUM;

//����ṹ��
typedef struct{
	uint8_t dateArry[LOG_CONTENT_TOTAL];
	uint32_t curNum;
    uint32_t curTime;
	uint16_t length;
	uint8_t  verifyVal;
	uint8_t  writeFlag;
}LOG_CONTENT_STRUCT;

//����������
typedef union{
	LOG_CONTENT_STRUCT ContentStruct;
	uint8_t ConentArry[EACH_LOG_SPACE];
}LOG_CONTENT_UNION;


//������װ
typedef struct{
	LOG_PROC_STATE_ENUM (*init)(void);
	LOG_PROC_STATE_ENUM (*record)(LOG_CONTENT_UNION uLogInfoUnion);
	LOG_PROC_STATE_ENUM (*getRecent)(LOG_CONTENT_UNION* pLogInfoUnion, int32_t recentNum);
    LOG_PROC_STATE_ENUM (*getSerial)(LOG_CONTENT_UNION* pLogInfoUnion, int32_t serialNum);
}LOGSYS_CONTENT_STRUCT;

typedef struct{
	LOG_PROC_STATE_ENUM (*clr)(void);
	LOG_PROC_STATE_ENUM (*set)(LOG_CONTENT_UNION  uLogInfoUnion);
	LOG_PROC_STATE_ENUM (*get)(LOG_CONTENT_UNION* pLogInfoUnion);
}LOGSYS_OUTAGE_STRUCT;

typedef struct{
	LOGSYS_OUTAGE_STRUCT 	 OutageStruct;
	LOGSYS_CONTENT_STRUCT    ContentStruct;
	LOG_OPERATE_STATE_ENUM   LogOperateFlag;

	LOG_PROC_STATE_ENUM (*init)(void);
	uint32_t (*getRawTotal)(void);
}LOGSYS_INFO_STRUCT;


//�ⲿ����
extern LOGSYS_INFO_STRUCT LogSysInfoStruct;


#ifdef _cplusplus
	}
#endif

#endif
