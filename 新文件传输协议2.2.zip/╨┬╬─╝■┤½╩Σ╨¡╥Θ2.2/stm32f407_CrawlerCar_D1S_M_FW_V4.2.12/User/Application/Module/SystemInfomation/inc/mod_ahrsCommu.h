/**
*****************************************************************************
* @��  ���� mod_ahrsCommu.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 27-Aug-2019
* @��  ���� ��������̬������λ��ͨ�Žӿ�
******************************************************************************
* @�޸ļ�¼��
*   2019/08/27����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_AHRSCOMMU_H_
#define _MOD_AHRSCOMMU_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//��ѧ��
#include <math.h>

//����ö��
typedef enum {
    NONE_INIT = 0x00,
    GYRO_INIT = 0xE0,
	MAGN_CALIB = 0xE1,
	HIGH_INIT = 0xE2,
    MAGN_CALIB_BEGIN = 0xE3,
} AHRSCOMMU_CMD_ENUM;

//֡�ṹ
#pragma pack (1) 
typedef struct {
	uint8_t  head1;
	uint8_t  head2;
	uint8_t  length;
	uint8_t  type;
	int16_t yaw;
	int16_t pitch;
	int16_t roll;
	int16_t height;
	int16_t temperature;
	int16_t pressure;
	int16_t calcuFreq;
	uint8_t  checkSum;
	uint8_t  tail;
} ATTITUDE_INFO_REPORT_STRUCT;

typedef struct {
	uint8_t  head1;
	uint8_t  head2;
	uint8_t  length;
	uint8_t  type;
	int16_t  Accel[3];
	int16_t  Gyro[3];
	int16_t  Magn[3];
	uint8_t  checkSum;
	uint8_t  tail;
} RAW_INFO_REPORT_STRUCT;

typedef struct{
	uint8_t  head1;
	uint8_t  head2;
	uint8_t  length;
	uint8_t  type;
	int16_t  Max[3];
	int16_t  Min[3];
    int16_t  percentage;
	uint8_t  checkSum;
	uint8_t  tail;
} MAGNETIC_INFO_REPORT_STRUCT;
#pragma pack (1) 

//����ṹ��
typedef struct {
	AHRSCOMMU_CMD_ENUM 		Cmd;
} AHRSCOMMU_INFO_STRUCT;


//�ӿں���     
void AhrsCommu_init(void);
void AhrsCommu_loopRead(void);
void AhrsCommu_get(AHRSCOMMU_INFO_STRUCT *pInfo);

void AhrsCommu_reportRawInfo(int16_t *pAccel,int16_t *pGryo, int16_t *pMagn);
void AhrsCommu_reportMagneticInfo(int16_t *pMax, int16_t *pMin, int16_t percent);
void AhrsCommu_reportAttitudeInfo(int16_t yaw, int16_t pitch, int16_t roll, int16_t height, int16_t temprature, int16_t pressure, int16_t calcuFreq);


#ifdef _cplusplus
	}
#endif

#endif
