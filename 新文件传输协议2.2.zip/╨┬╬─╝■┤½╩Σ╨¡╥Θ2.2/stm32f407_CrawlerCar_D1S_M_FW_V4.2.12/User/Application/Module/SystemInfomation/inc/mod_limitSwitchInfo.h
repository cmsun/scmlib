/**
*****************************************************************************
* @��  ���� mod_limitSwitchInfo.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 6-Jun-2018
* @��  ���� �¶���Ϣ��ȡģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/06����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_LIMITSWITCHINFO_H_
#define _MOD_LIMITSWITCHINFO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>


//����ö��
typedef enum{
    LIMIT_SWITCH_OFF = 0,
    LIMIT_SWITCH_ON
}LIMIT_SWITCH_STATE_ENUM;

//����ṹ��
typedef struct{
    LIMIT_SWITCH_STATE_ENUM LeftFrontInSta;
    LIMIT_SWITCH_STATE_ENUM LeftFrontOutSta;
    LIMIT_SWITCH_STATE_ENUM RightFrontInSta;
    LIMIT_SWITCH_STATE_ENUM RightFrontOutSta;    
    LIMIT_SWITCH_STATE_ENUM LeftRearInSta;
    LIMIT_SWITCH_STATE_ENUM LeftRearOutSta;
    LIMIT_SWITCH_STATE_ENUM RightRearInSta;
    LIMIT_SWITCH_STATE_ENUM RightRearOutSta;
    LIMIT_SWITCH_STATE_ENUM InGarageSta;
}LIMIT_SWITCH_INFO_STRUCT;

//�ӿں���
void LimitSwitchInfo_init(void);
void LimitSwitchInfo_loopRead(void);
void LimitSwitchInfo_loopReadSmooth(void);
void LimitSwitchInfo_get(LIMIT_SWITCH_INFO_STRUCT *pLimSwInfo);
uint8_t LimitSwitchInfo_getBits(void);

//�ⲿ����
extern LIMIT_SWITCH_INFO_STRUCT LimitSwitchInfoStruct;


#ifdef _cplusplus
	}
#endif

#endif
