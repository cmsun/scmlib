/**
*****************************************************************************
* @��  ���� mod_logSys2Info.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 5-Jun-2018
* @��  ���� ��־��Ϣϵͳ�ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_LOGSYS2INFO_H_
#define _MOD_LOGSYS2INFO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//�궨��
#define LOG_INF(format, ...)	LogSys2Info_debugRecord(" [INF]%s_%d: " format "\r\n", __func__,__LINE__, __VA_ARGS__)
#define LOG_WRN(format, ...)	LogSys2Info_debugRecord(" [WRN]%s_%d: " format "\r\n", __func__,__LINE__, __VA_ARGS__) 
#define LOG_ERR(format, ...)	LogSys2Info_debugRecord(" [ERR]%s_%d: " format "\r\n", __func__,__LINE__, __VA_ARGS__)
#define LOG_RCD(format, ...)	LogSys2Info_debugRecord(" [RCD]%s_%d: " format "\r\n", __func__,__LINE__, __VA_ARGS__)
#define LOG_IMP(format, ...)	//LogSys2Info_debugRecord(" [IMP]%s_%d: " format "\r\n", __func__,__LINE__, __VA_ARGS__)
		
//�ⲿ����
int32_t LogSys2Info_refresh(void);
int32_t LogSys2Info_dataRecord(char *pData);
int32_t LogSys2Info_debugRecord(char *pData,...);


#ifdef _cplusplus
	}
#endif

#endif
