/**
*****************************************************************************
* @��  ���� mod_paramaterInfo.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 5-Jun-2018
* @��  ���� ������Ϣģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/05����ʼ�汾
*   2018/07/12������18λID
*
******************************************************************************
**/

#ifndef _MOD_PARAMATERINFO_H_
#define _MOD_PARAMATERINFO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdbool.h>

//��������
#include "configure.h"

//�궨��
#define ROBOT_ID_INFO_LENGTH        (uint8_t)ID_LENGTH + 4
#define ROBOT_MILEAGE_INFO_LENGTH   (uint8_t)20
#define ROBOT_MOTION_INFO_LENGTH    (uint8_t)10
#define ROBOT_RESUME_INFO_LENGTH	(uint8_t)24
#define ROBOT_TIME_INFO_LENGTH      (uint8_t)12
#define BAT_FORMULA_INFO_LENGTH     (uint8_t)52
#define MAP_INFO_LENGTH             (uint8_t)24
#define IMU_OFFSET_LENGTH			(uint8_t)16
#define HMC_OFFSET_LENGTH	        (uint8_t)16

//����ö��
typedef enum {
    PARAM_PROC_FAILED = 0,
	PARAM_PROC_SUCCEED = 1,
}PARAM_PROC_STATE_ENUM;

#pragma pack (1)    //���ֽڶ���

//����ṹ��
typedef struct{
	uint8_t 	robotId[ID_LENGTH];
	uint8_t	 	writeFlag;
    uint8_t     reserve;
	uint16_t    checkSum;
}ROBOT_ID_INFO_STRUCT;

typedef struct{
	uint64_t 	totalMeter;
	uint64_t 	totalSecond;
	uint8_t 	writeFlag;
    uint8_t     reserve;
	uint16_t    checkSum;
}ROBOT_MILEAGE_INFO_STRUCT;

typedef struct{
	uint8_t 	safetyLV;
	uint8_t 	goStraightLV;
	uint8_t 	backToPanelLV;
	uint8_t 	moveBack50cmLV;
	uint8_t 	moveForward20cmLV;
	uint8_t 	turnStraightAV;
	uint8_t 	rotateAngleAV;
	uint8_t 	writeFlag;
	uint16_t    checkSum;
}ROBOT_MOTION_INFO_STRUCT;

typedef struct{
	double K;
	double B;
}FORMULA_PARAM;

typedef struct{
	FORMULA_PARAM VolParam;
	FORMULA_PARAM ChargeCurParam;
	FORMULA_PARAM DisChargeCurParam;
	uint8_t 	writeFlag;
    uint8_t     reserve;
	uint16_t    checkSum;
}BATTERY_FORMULA_INFO_STRUCT;

typedef struct{
	uint8_t startHour;
	uint8_t startMinuter;
	uint8_t endHour;
	uint8_t endMinuter;
}TIME_RANGE_STRUCT;

typedef struct{
	uint16_t startYear;
	uint8_t  startMouth;
	uint8_t  startDay;
}TIME_START_STRUCT;

typedef struct{
	TIME_RANGE_STRUCT timeRange;
	TIME_START_STRUCT timeStart;
	uint8_t 	writeFlag;
    uint8_t     reserve;
	uint16_t    checkSum;
}ROBOT_TIME_INFO_STRUCT;

typedef struct{
	int32_t 	garageSelect;
	int32_t 	returnListSelect;
	int32_t 	resumeTarget;
    int32_t 	cruiseIndex;
	int32_t 	isTaskBreak;
	uint8_t 	writeFlag;
    uint8_t     reserve;
	uint16_t    checkSum;
}ROBOT_RESUME_INFO_STRUCT;

typedef struct{
    uint64_t timestamp;
    uint32_t random;
}MAP_FEATURE;

typedef struct{
    uint8_t name[8];
    MAP_FEATURE feature;
    uint8_t writeFlag;
    uint8_t reserve;
    uint16_t checkSum;
}MAP_INFO_STRUCT;

typedef struct{
	int16_t Gyro[3];
	int16_t	Accel[3];
    uint8_t writeFlag;
    uint8_t reserve;
    uint16_t checkSum;
}IMU_OFFSET_STRUCT;

typedef struct{
	int16_t Max[MAX_Axis];
	int16_t Min[MAX_Axis];
    uint8_t writeFlag;
    uint8_t reserve;
    uint16_t checkSum;
}HMC_OFFSET_STRUCT;

//����������
typedef union{
	ROBOT_ID_INFO_STRUCT 		Struct;
	uint8_t Arry[ROBOT_ID_INFO_LENGTH];
}ROBOT_ID_INFO_UNION;

typedef union{
	ROBOT_MILEAGE_INFO_STRUCT	Struct;
	uint8_t Arry[ROBOT_MILEAGE_INFO_LENGTH];
}ROBOT_MILEAGE_INFO_UNION;

typedef union{
	ROBOT_MOTION_INFO_STRUCT	Struct;
	uint8_t Arry[ROBOT_MOTION_INFO_LENGTH];
}ROBOT_MOTION_INFO_UNION;

typedef union{
	ROBOT_RESUME_INFO_STRUCT 	Struct;
	uint8_t Arry[ROBOT_RESUME_INFO_LENGTH];
}ROBOT_RESUME_INFO_UNION;

typedef union{
	ROBOT_TIME_INFO_STRUCT 		Struct;
	uint8_t Arry[ROBOT_TIME_INFO_LENGTH];
}ROBOT_TIME_INFO_UNION;

typedef union{
	BATTERY_FORMULA_INFO_STRUCT Struct;
	uint8_t Arry[BAT_FORMULA_INFO_LENGTH];
}BATTERY_FORMULA_INFO_UNION;

typedef union{
    MAP_INFO_STRUCT 			Struct;
    uint8_t Arry[MAP_INFO_LENGTH];
}MAP_INFO_UNION;

typedef union{
	IMU_OFFSET_STRUCT 			Struct;
	uint8_t Arry[IMU_OFFSET_LENGTH];
}IMU_OFFSET_UNION;

typedef union{
	HMC_OFFSET_STRUCT		Struct;
	uint8_t Arry[HMC_OFFSET_LENGTH];
}HMC_OFFSET_UNION;

#pragma pack ()     //�ָ�Ĭ�϶���

//������װ
typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(ROBOT_ID_INFO_UNION uRobotIdInfo);
	PARAM_PROC_STATE_ENUM (*read)(ROBOT_ID_INFO_UNION *pRobotIdInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}ROBOT_ID_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(ROBOT_MILEAGE_INFO_UNION uRobotMileageInfo);
	PARAM_PROC_STATE_ENUM (*read)(ROBOT_MILEAGE_INFO_UNION *pRobotMileageInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}ROBOT_MILEAGE_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(ROBOT_MOTION_INFO_UNION uRobotMotionInfo);
	PARAM_PROC_STATE_ENUM (*read)(ROBOT_MOTION_INFO_UNION *pRobotMotionInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}ROBOT_MOTION_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(ROBOT_TIME_INFO_UNION uRobotTimeInfo);
	PARAM_PROC_STATE_ENUM (*read)(ROBOT_TIME_INFO_UNION *pRobotTimeInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}ROBOT_TIME_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(ROBOT_RESUME_INFO_UNION uRobotResumeInfo);
	PARAM_PROC_STATE_ENUM (*read)(ROBOT_RESUME_INFO_UNION *pRobotResumeInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}ROBOT_RESUME_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(BATTERY_FORMULA_INFO_UNION uBatFormulaInfo);
	PARAM_PROC_STATE_ENUM (*read)(BATTERY_FORMULA_INFO_UNION *pBatFormulaInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);
}BATTERY_FORMULA_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(MAP_INFO_UNION uMapInfo);
	PARAM_PROC_STATE_ENUM (*read)(MAP_INFO_UNION *uMapInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);    
}MAP_INFO_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(IMU_OFFSET_UNION uMapInfo);
	PARAM_PROC_STATE_ENUM (*read)(IMU_OFFSET_UNION *uMapInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);  
}IMU_OFFSET_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM (*write)(HMC_OFFSET_UNION uMapInfo);
	PARAM_PROC_STATE_ENUM (*read)(HMC_OFFSET_UNION *uMapInfo);
	PARAM_PROC_STATE_ENUM (*init)(void);  
}HMC_OFFSET_MANAGE_STRUCT;

typedef struct{
	PARAM_PROC_STATE_ENUM 			(*init)(void);
	BATTERY_FORMULA_MANAGE_STRUCT	batteryFormulaStruct;
	ROBOT_MILEAGE_MANAGE_STRUCT 	robotMileageStruct;
	ROBOT_MOTION_MANAGE_STRUCT		robotMotionStruct;
	ROBOT_RESUME_MANAGE_STRUCT		robotResumeStruct;
	ROBOT_TIME_MANAGE_STRUCT		robotTimeStruct;
	ROBOT_ID_MANAGE_STRUCT 			robotIdStruct;
    MAP_INFO_MANAGE_STRUCT          mapInfoStruct;
	IMU_OFFSET_MANAGE_STRUCT		imuOffsetStruct;
    HMC_OFFSET_MANAGE_STRUCT	    hmcOffsetStruct;
}PARAMATER_INFO_STRUCT;

//�ⲿ����
extern PARAMATER_INFO_STRUCT ParamInfoStruct;


#ifdef _cplusplus
	}
#endif

#endif
