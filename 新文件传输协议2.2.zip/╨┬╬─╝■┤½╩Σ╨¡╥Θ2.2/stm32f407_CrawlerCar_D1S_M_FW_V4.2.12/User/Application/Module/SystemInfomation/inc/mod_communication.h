/*
********************************************************************************
*                              COPYRIGHT NOTICE
*                             Copyright (c) 2016
*                             All rights reserved
*
*  @fileName       : mod_communication.h
*  @author         : scm 351721714@qq.com
*  @create         : 2019/03/14 14:24:20
********************************************************************************
*/

#ifndef MOD_COMMUNICATION_H
#define MOD_COMMUNICATION_H

#include <stdint.h>
#include "configure.h"
#include "mod_controllerInfo.h"

#define FRAME_HEAD             0x10
#define FRAME_HEAD_2           0x20 //Ϊ�˼��ݾɰ汾APP���°汾��ͳһʹ��0x10��Ϊ֡ͷ
#define FRAME_TAIL             0x88

#define FRAME_TYPE_COMMAND     0x21
#define FRAME_TYPE_PARAM       0x31
#define FRAME_TYPE_LOG         0x41
#define FRAME_TYPE_GET_ID      0x61
#define FRAME_TYPE_UPDATE_CMD  0x71  //�̼�����������֡����
#define FRAME_TYPE_UPDATE_DATA 0x7A  //�̼�����������֡����
#define FRAME_TYPE_POINT_CMD   0x81  //�����������أ�����֡����
#define FRAME_TYPE_POINT_DATA  0x8A  //�����������أ�����֡����
#define FRAME_TYPE_HEART_BEAT  0x91

typedef uint16_t (*SEND_FUNC)(uint8_t *, uint16_t);

enum {
    DEVICE_SERVER = 0,  //�������ͨ��
    DEVICE_PAD = 1      //��ƽ��ͨ��
};

#pragma pack(1)

typedef struct {
    uint8_t head;                                                           //֡ͷ
    uint8_t type;                                                           //֡����
    uint8_t length;                                                         //֡����
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    uint8_t motionCmd;
    int8_t linearVelocity;
    int8_t angularVelocity;
    uint8_t brushCtl;
    uint8_t motionMethon;
    uint8_t checksum;                                                       //У��ֵ
    uint8_t tail;
} Frame_Command_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    uint8_t robotState;
    int8_t linearVelocity;
    int8_t angularVelocity;
    uint8_t brushState;
    uint8_t motionMethon;
    uint32_t faultFlag;
    uint32_t curMileage;
    uint32_t curCleanTime;
    uint16_t batteryVol;
    uint8_t dropLimitState;
    uint16_t reserve;
    uint8_t checksum;
    uint8_t tail;
} Frame_Command_Ack;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    CONTROL_ID_PROCESS_ENUM readWriteSwitch;
    uint16_t reserve;
    uint8_t checksum;
    uint8_t tail;
} Frame_GetID_Req;

typedef Frame_GetID_Req Frame_GetID_Ack;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    PARAM_PROCESS_ENUM ParamProc;                                           //�����������
	uint8_t safetyLV;                                                       //��ȫǰ���ٶ�
	uint8_t goStraightLV;                                                   //ȫ��ǰ���ٶ�
	uint8_t backToPanelLV;                                                  //��������ٶ�
	uint8_t moveBack50cmLV;                                                 //����50cm�ٶ�
	uint8_t moveForward20cmLV;                                              //ǰ��20cm�ٶ�
	uint8_t turnStraightAV;                                                 //תֱ�ǽ��ٶ�
	uint8_t rotateAngleAV;                                                  //תС�ǶȽ��ٶ�
    uint8_t checksum;
    uint8_t tail;
} Frame_Param_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    PARAM_PROCESS_ENUM ParamProc;                                           //�����������
	uint8_t safetyLV;                                                       //��ȫǰ���ٶ�
	uint8_t goStraightLV;                                                   //ȫ��ǰ���ٶ�
	uint8_t backToPanelLV;                                                  //��������ٶ�
	uint8_t moveBack50cmLV;                                                 //����50cm�ٶ�
	uint8_t moveForward20cmLV;                                              //ǰ��20cm�ٶ�
	uint8_t turnStraightAV;                                                 //תֱ�ǽ��ٶ�
	uint8_t rotateAngleAV;                                                  //תС�ǶȽ��ٶ�
    uint8_t checksum;
    uint8_t tail;
} Frame_Param_Ack;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t time[3];
    uint8_t deveice;
    uint8_t reserve[16];
    uint8_t checkSum;
    uint8_t tail;
} Frame_HeartBeat_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint8_t length;
    uint8_t serial;
    uint8_t ID[ID_LENGTH];
    uint8_t firmwareVersion[4];
    uint8_t controlMethod;
    uint8_t taskStatus;
    uint32_t warningFlag;
    uint8_t dropSersor;
    uint8_t radarSersor;
    uint16_t radarLeftFront;
    uint16_t radarLeftRear;
    uint16_t radarRightFront;
    uint16_t radarRightRear;
    uint32_t magnaticGuider;
    uint64_t longtitude;
    uint64_t lattitude;
    uint16_t azimuth;
    int8_t linearVelocity;
    int8_t angleVelocity;
    uint8_t brushStatus;
    uint32_t currentMileage;
    uint32_t currentCleanTime;
    uint16_t batteryVoltage;
    uint8_t batteryStatus;    //��ص���
    int16_t batteryTemp;
    int16_t cabinetTemp;
    int16_t temperature;
    uint16_t windVelocity;
    uint8_t weather;
    uint64_t totalMileage;
    uint64_t totalCleanTime;
    uint16_t disChargeCurrent;
    uint16_t chargeCurrent;
    uint64_t timestamp;
    uint32_t random;
    uint8_t satInView;    
    uint8_t satInUse;
    uint8_t isTaskBreak;
    uint8_t posValid;
    uint8_t dirValid;
    uint8_t mapName[8];
	uint32_t cruiseTotal;
	uint32_t cruiseIndex;
    uint8_t leftDrvErrCode;
    uint8_t rightDrvErrCode;
    uint8_t leftDrvStaCode;
    uint8_t rightDrvStaCode;
    uint32_t errorFlag;
    uint8_t onSectorType;
    uint8_t reserve[27];
    uint8_t checkSum;
    uint8_t tail;
} Frame_HeartBeat_Ack;

#pragma pack()

void communication_init(void);
void identity_process(uint8_t *data, SEND_FUNC send);
void command_process(uint8_t *data, SEND_FUNC send);
void parmeter_process(uint8_t *data, SEND_FUNC send);
void heartbeat_process(uint8_t *data, SEND_FUNC send);
void heartbeat_send_frame(uint8_t *data, SEND_FUNC send);

#endif /* end of include guard: MOD_COMMUNICATION_H */

