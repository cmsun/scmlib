#ifndef _MOD_PERIPHERALDEV_H
#define _MOD_PERIPHERALDEV_H

#include <stdint.h>
#include <stdbool.h>
#include <string.h>

#define MODBUS_CMD_LENGTH 8 //modbusָ���

typedef struct
{
    uint16_t radar1st;
    uint16_t radar2nd;
    uint16_t radar3rd;
    uint16_t radar4th;
    uint8_t  radarSta1st:  1;
    uint8_t  radarSta2nd:  1;
    uint8_t  radarSta3rd:  1;
    uint8_t  radarSta4th:  1;
    uint8_t  limitSwMagLI: 1;
    uint8_t  limitSwMagLO: 1;
    uint8_t  limitSwMagRI: 1;
    uint8_t  limitSwMagRO: 1;
} SampleBoardInfo_Typedef;

typedef struct {
    int16_t voltage;
    int16_t current;
    int16_t remainpower;
    int16_t cellvoltage[16];
    int16_t temprature1;
    int16_t temprature2;
    int16_t capacity;
    uint16_t SOC;
} BatteryBMSInfoRaw_TypeDef;

typedef struct {
    int32_t voltage;
    int32_t current;
    int32_t remainpower;
    int32_t cellvoltage[16];
    int32_t temprature1;
    int32_t temprature2;
    int32_t capacity;
    uint8_t SOC;
} BatteryBMSInfo_TypeDef;

typedef struct {
    const uint8_t modbuscmd[MODBUS_CMD_LENGTH];
    uint16_t period;
    bool active;
    uint8_t fialed_times;
    SampleBoardInfo_Typedef info;
} SampleBoard_TypeDef;

typedef struct {
    const uint8_t modbuscmd[MODBUS_CMD_LENGTH];
    uint16_t period;
    bool active;
    uint8_t fialed_times;
    uint32_t info;
} MagneticSensor_TypeDef;

typedef struct {
    const uint8_t modbuscmd[MODBUS_CMD_LENGTH];
    uint16_t period;
    bool active;
    uint8_t fialed_times;
    BatteryBMSInfo_TypeDef info;
} BatteryBMS_TypeDef;

typedef struct {
    SampleBoard_TypeDef sample;
    MagneticSensor_TypeDef magnetic;
    BatteryBMS_TypeDef battery;
    uint8_t targetslave;
    bool busy;
    bool received;
    uint16_t timeout;
} PeripheralDev_TypeDef;

extern PeripheralDev_TypeDef PeripheralDev;

void peripheral_communication_init(void);
void peripheral_task_loop(void);
void sample_get_info(SampleBoardInfo_Typedef *info);
uint32_t magnetic_get_info(void);
void battery_get_info(BatteryBMSInfo_TypeDef *info);

#endif