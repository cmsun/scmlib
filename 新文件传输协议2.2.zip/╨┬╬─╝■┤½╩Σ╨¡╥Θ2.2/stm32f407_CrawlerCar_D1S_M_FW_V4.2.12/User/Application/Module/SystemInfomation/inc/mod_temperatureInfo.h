/**
*****************************************************************************
* @��  ���� mod_temperatureInfo.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 4-Jun-2018
* @��  ���� �¶���Ϣ��ȡģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/04����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_TEMPERATUREINFO_H_
#define _MOD_TEMPERATUREINFO_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <string.h>

//����ö��
typedef enum {TEMP_VALUE_INVAILD = 0, TEMP_VALUE_VAILD } TEMP_VALUE_STATE;

//����ṹ��
typedef struct
{
    float curCabinetAverage;
    float curBatteryAverage;

    float curCabinet1stTemp;
    float curCabinet2ndTemp;
    float curBattery1stTemp;
    float curBattery2ndTemp;

    TEMP_VALUE_STATE  curCabinetTemp1stState;
    TEMP_VALUE_STATE  curCabinetTemp2ndState;
    TEMP_VALUE_STATE  curBatteryTemp1stState;
    TEMP_VALUE_STATE  curBatteryTemp2ndState;
}TEMPERATURE_INFO_STRUCT;

//�ӿں���
void TemperatureInfo_init(void);
void TemperatureInfo_loopRead(void);
void TemperatureInfo_loopReadSmooth(void);
void TemperatureInfo_get(TEMPERATURE_INFO_STRUCT *pTempInfo);

//�ⲿ����
extern TEMPERATURE_INFO_STRUCT TemperatureInfoStruct;


#ifdef _cplusplus
	}
#endif

#endif
