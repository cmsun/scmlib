/**
*****************************************************************************
* @��  ���� mod_safety.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 12-Jun-2018
* @��  ���� �쳣ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/06/12����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_SAFETY_H_
#define _MOD_SAFETY_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//�궨��
#define	BIT_Warning_OneBatTempSensorErr    	0 
#define	BIT_Warning_OneCabTempSensorErr   	1
#define	BIT_Warning_BatTempAbnormal     	2
#define	BIT_Warning_CabTempAbnormal     	3

#define BIT_Warning_RunForbiddenByAmuzith 	4
#define BIT_Warning_RunForbiddenByTemp  	5
#define BIT_Warning_RunForbiddenByBatCap	6
#define BIT_Warning_RunForbiddenByRtk	    7

#define BIT_Warning_BatteryVolLow			8
#define BIT_Warning_BatteryCapLow			9
#define BIT_Warning_CellularAbnormal		10
#define	BIT_Warning_DropSensorsWarn		    11

#define	BIT_Warning_StopButNotTrigSwitch	12
#define	BIT_Warning_ChargingNoCurrent		13
#define	BIT_Warning_ChargeForbiddenByTemp	14
#define	BIT_Warning_BrushOutOfCtl		    15

#define BIT_Warning_InGarageNoTrig          16
#define BIT_Warning_InGarageShift           17
#define BIT_Warning_OutGarageWrongAmuzith   18
#define BIT_Warning_RtkErrorToReboot        19

#define	BIT_Warning_ImuNeedCorrect          20

/*-----------------------------------------------*/
#define	BIT_Error_SdCard				32
#define	BIT_Error_Eeprom				33
#define BIT_Error_Mpu6515Err		    34
#define BIT_Error_Hmc5843Err		    35

#define	BIT_Error_RtkConnectFailed		36
#define	BIT_Error_BatteryVolTooLow		37
#define BIT_Error_SampleBoardOffline	38
#define BIT_Error_MagnetometerOffline   39

#define	BIT_Error_CoordInfo				40
#define BIT_Error_GetSectorType			41
#define BIT_Error_PosNotIngGarage	    42
#define BIT_Error_FindLine				43

#define	BIT_Error_BatTempSensor       	44
#define	BIT_Error_CabTempSensor       	45
#define BIT_Error_RollDrift				46
#define	BIT_Error_DropSensorsFault		47

#define	BIT_Error_LeftDriverConnect     48
#define	BIT_Error_LeftDriverControl     49
#define	BIT_Error_LeftDriverPmip      	50
#define	BIT_Error_LeftDriverAlam      	51

#define	BIT_Error_RightDriverConnect    52
#define	BIT_Error_RightDriverControl    53
#define	BIT_Error_RightDriverPmip     	54
#define	BIT_Error_RightDriverAlam     	55

#define	BIT_Error_RunHoldBack     	    56


//����ö��
typedef enum{
	NORMAL_STATE = 0,
	WARN_STATE,
	ERROR_STATE
}SAFETY_STATE_ENUM;

//����ṹ��
typedef union{
    uint64_t SafetyFlag;
	uint8_t  SafetyFlagArry[8];
    struct {
        uint32_t WarningFlag;
        uint32_t ErrorFlag;
    } SafetyFlagLevel;

	struct{
		uint64_t bit_OneBatTempSensorErr:1;		//0
		uint64_t bit_OneCabTempSensorErr:1;
		uint64_t bit_BatTempAbnormal:1;
		uint64_t bit_CabTempAbnormal:1;

		uint64_t bit_RunForbiddenByAmuzith:1;	//4
		uint64_t bit_RunForbiddenByTemp:1;
		uint64_t bit_RunForbiddenByBatCap:1;
		uint64_t bit_RunForbiddenByRtk:1;

		uint64_t bit_BatteryVolLow:1; 			//8
		uint64_t bit_BatteryCapLow:1;
		uint64_t bit_CellularAbnormal:1;
        uint64_t bit_DropSensorsWarn:1;

		uint64_t bit_StopButNotTrigSwitch:1;    //12
		uint64_t bit_ChargingNoCurrent:1;
        uint64_t bit_ChargeForbiddenByTemp:1;
        uint64_t bit_BrushOutOfCtl:1;
        
        uint64_t bit_InGarageNoTrig:1;          //16
        uint64_t bit_InGarageShift:1;
        uint64_t bit_OutGarageWrongAmuzith:1;
        uint64_t bit_RtkErrorToReboot:1;
        
        uint64_t bit_ImuNeedCorrect:1;          //20
        uint64_t bit_Warning_21:1;
        uint64_t bit_Warning_22:1;
        uint64_t bit_Warning_23:1;
        
        uint64_t bit_Warning_24:1;              //24
        uint64_t bit_Warning_25:1;
        uint64_t bit_Warning_26:1;
        uint64_t bit_Warning_27:1;
        
        uint64_t bit_Warning_28:1;              //28
        uint64_t bit_Warning_29:1;
        uint64_t bit_Warning_30:1;
        uint64_t bit_Warning_31:1;
//--------------------------------------above are warning--------------------------

//--------------------------------------below are error----------------------------
		uint64_t bit_SdCard:1;                  //32
		uint64_t bit_Eeprom:1;
		uint64_t bit_Mpu6515Err:1;              
        uint64_t bit_Hmc5843Err:1;

		uint64_t bit_RtkConnectFailed:1;        //36
		uint64_t bit_BatteryVolTooLow:1;
		uint64_t bit_SampleBoardOffline:1;
        uint64_t bit_MagnetometerOffline:1;

        uint64_t bit_CoordInfo:1;               //40
        uint64_t bit_GetSectorType:1;
        uint64_t bit_PosNotInGarage:1;
		uint64_t bit_FindLine:1;

		uint64_t bit_BatTempSensor:1;           //44
		uint64_t bit_CabTempSensor:1;
        uint64_t bit_RollDrift:1;
        uint64_t bit_DropSensorsFault:1;

        uint64_t bit_LeftDriverConnect:1;       //48
		uint64_t bit_LeftDriverControl:1;    
        uint64_t bit_LeftDriverPmip:1;
		uint64_t bit_LeftDriverAlam:1;          
        
        uint64_t bit_RightDriverConnect:1;      //52
		uint64_t bit_RightDriverControl:1;
        uint64_t bit_RightDriverPmip:1;
        uint64_t bit_RightDriverAlam:1;
        
        uint64_t bit_RunHoldBack:1;             //56
        uint64_t bit_Error_57:1;
        uint64_t bit_Error_58:1;
        uint64_t bit_Error_59:1;
        
        uint64_t bit_Error_60:1;                //60
        uint64_t bit_Error_61:1;
        uint64_t bit_Error_62:1;
        uint64_t bit_Error_63:1; 
	}SafetyFlagBit;
}SAFETY_FLAG_UNION;

//�ӿں���
void Safety_init(void);
void Safety_cleanFlag(void);
SAFETY_FLAG_UNION Safety_getFlag(void);
SAFETY_STATE_ENUM Safety_getState(void);
void Safety_setFlagBit(uint8_t bitSort,uint8_t bitVal);

//�ⲿ����
extern SAFETY_FLAG_UNION SafetyFlagUnion;

#ifdef _cplusplus
	}
#endif

#endif
