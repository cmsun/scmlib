/**
*****************************************************************************
* @��  ���� mod_queue.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 09-Dec-2018
* @��  ���� Queueģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2019/08/05����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_QUEUE_H_
#define _MOD_QUEUE_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

//�ṹ�嶨��
typedef struct queue{
    uint32_t read;
    uint32_t write;
    uint32_t size;
    uint8_t *payload;
}Queue, *QueuePtr;

//�ӿں���
uint32_t Queue_getUsed(const QueuePtr queue);
uint32_t Queue_getFree(const QueuePtr queue);
uint32_t Queue_write(QueuePtr queue, const void* buf, uint32_t length);
uint32_t Queue_read(QueuePtr queue, void* buf, uint32_t length);

void Queue_clear(QueuePtr queue);
void Queue_errBack(QueuePtr queue, uint32_t len);
void Queue_init(QueuePtr queue, uint32_t size, void* payload);
void Queue_destory(QueuePtr queue);
int32_t Queue_isFull(const QueuePtr queue);
int32_t Queue_isEmpty(const QueuePtr queue);
QueuePtr Queue_create(uint32_t size);


#ifdef _cplusplus
	}
#endif

#endif
