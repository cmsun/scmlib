/**
*****************************************************************************
* @��  ���� mod_bigExLitter.c
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 09-Aug-2019
* @��  ���� ��С��ת��ģ���ļ�
******************************************************************************
* @�޸ļ�¼��
*   2019/08/28����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_bigExLitter.h"




/**
 * Convert an uint16_t from host- to network byte order.
 *
 * @param n uint16_t in host byte order
 * @return n in network byte order
 */
uint16_t htons(uint16_t n)
{
    return ((n & 0xff) << 8) | ((n & 0xff00) >> 8);
}

/**
 * Convert an uint16_t from network- to host byte order.
 *
 * @param n uint16_t in network byte order
 * @return n in host byte order
 */
uint16_t ntohs(uint16_t n)
{
    return htons(n);
}

/**
 * Convert an uint32_t from host- to network byte order.
 *
 * @param n uint32_t in host byte order
 * @return n in network byte order
 */
uint32_t htonl(uint32_t n)
{
    return ((n & 0xff) << 24) |
           ((n & 0xff00) << 8) |
           ((n & 0xff0000UL) >> 8) |
           ((n & 0xff000000UL) >> 24);
}

/**
 * Convert an uint32_t from network- to host byte order.
 *
 * @param n uint32_t in network byte order
 * @return n in host byte order
 */
uint32_t ntohl(uint32_t n)
{
    return htonl(n);
}

/**
 * Convert an uint64_t from host- to network byte order.
 *
 * @param n uint64_t in host byte order
 * @return n in network byte order
 */
uint64_t htonll(uint64_t n)
{
    return ((n & 0xff) << 56) |
           ((n & 0xff00) << 40) |
           ((n & 0xff0000) << 24) |
           ((n & 0xff000000) << 8) |
           ((n & 0xff00000000) >> 8) |
           ((n & 0xff0000000000) >> 24) |
           ((n & 0xff000000000000) >> 40) |
           ((n & 0xff00000000000000) >> 56);
}

/**
 * Convert an uint64_t from network- to host byte order.
 *
 * @param n uint64_t in network byte order
 * @return n in host byte order
 */
uint64_t ntohll(uint64_t n)
{
    return htonll(n);
}
