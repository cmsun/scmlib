/**
*****************************************************************************
* @��  ���� mod_pid.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 9-Dec-2018
* @��  ���� PIDģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/11/09����ʼ�汾
*    
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_pid.h"


//�궨��
#define DIGITAL_THROTTLE_VALVE_MAX_DEGREE 20


/*
*********************************************************************************************************
* Function Name : PID_Init
* Description   : PID��ʼ��
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static void PID_Init(struct PID *this, double targetPoint)
{
    this->targetPoint = targetPoint;
    this->lastError = 0;
    this->prevError = 0;    
}

/*
*********************************************************************************************************
* Function Name : PID_OutputLimit
* Description   : PID�������
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static double PID_OutputLimit(struct PID *this, double output)
{
    if (output < -DIGITAL_THROTTLE_VALVE_MAX_DEGREE) {
        output = -DIGITAL_THROTTLE_VALVE_MAX_DEGREE;
    } else if (output > DIGITAL_THROTTLE_VALVE_MAX_DEGREE) {
        output = DIGITAL_THROTTLE_VALVE_MAX_DEGREE;
    }
    return output;
}

/*
*********************************************************************************************************
* Function Name : PID_SetParameter
* Description   : PID���ò���
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static void PID_SetParameter(struct PID *this, float kp, float ki, float kd)
{
    this->kp = kp;
    this->ki = ki;
    this->kd = kd;
}

/*
*********************************************************************************************************
* Function Name : PID_SetTargetValue
* Description   : PID����Ŀ��ֵ
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
void PID_SetTargetValue(struct PID *this, double targetPoint)
{
    this->targetPoint = targetPoint;
}

/*
*********************************************************************************************************
* Function Name : PID_GetTargetValue
* Description   : PID��ȡĿ��ֵ
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
double PID_GetTargetValue(struct PID *this)
{
    return this->targetPoint;
}

/*
*********************************************************************************************************
* Function Name : PID_IncCalculate
* Description   : ����ʽPID����
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static double PID_IncCalculate(struct PID *this, double samplePoint)
{   
    double nowError = this->targetPoint - samplePoint;
    double out = this->kp * nowError +\
                 this->ki * this->lastError +\
                 this->kd * this->prevError;
    this->prevError = this->lastError;
    this->lastError = nowError;

    if (this->outputLimit) {
        out = this->outputLimit(this, out);
    }

    return out;
}

/*
*********************************************************************************************************
* Function Name : PID_PosInit
* Description   : λ��ʽPID��ʼ��
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static void PID_PosInit(struct PID *this, double targetPoint)
{
    PID_Init(this, targetPoint);
    struct PID_POS *pid_Handle = (struct PID_POS *)this;
    pid_Handle->iSum = 0;
}

/*
*********************************************************************************************************
* Function Name : PID_PosCalculate
* Description   : λ��ʽPID����
* Input         : None
* Output        : None
* Return        : None
*********************************************************************************************************
*/
static double PID_PosCalculate(struct PID *this, double samplePoint)
{
    struct PID_POS *pid_Handle = (struct PID_POS *)this;

    double nowError = this->targetPoint - samplePoint;
    this->lastError = nowError;
    //�����ۼ����
    pid_Handle->iSum += nowError;
    double out = this->kp * nowError +\
                 this->ki * pid_Handle->iSum +\
                 this->kd * (nowError - this->prevError);   
    this->prevError = nowError;

    if (this->outputLimit) {
        out = this->outputLimit(this, out);
    }

    return out;
}

/*
*********************************************************************************************************
*                                           ����ʽPID
*********************************************************************************************************
*/
struct PID_INC g_PID_Inc = {
    .pid = {
        .mode           = PID_INC,
        .init           = PID_Init,
        .outputLimit    = PID_OutputLimit,
        .setParameter   = PID_SetParameter,
        .calculate      = PID_IncCalculate,
        .setTargetValue = PID_SetTargetValue,
        .getTargetValue = PID_GetTargetValue,
    },
};


/*
*********************************************************************************************************
*                                           λ��ʽPID
*********************************************************************************************************
*/
struct PID_POS g_PID_Pos = {
    .pid = {
        .mode           = PID_POS,
        .init           = PID_PosInit,
        .outputLimit    = PID_OutputLimit,
        .setParameter   = PID_SetParameter,
        .calculate      = PID_PosCalculate,
        .setTargetValue = PID_SetTargetValue,
        .getTargetValue = PID_GetTargetValue,
    },
};

