/**
*****************************************************************************
* @��  ���� mod_navigate.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 30-Nov-2018
* @��  ���� ��������ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/11/30����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_NAVIGATE_H_
#define _MOD_NAVIGATE_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//�����ļ�
#include "configure.h"

//����ö��
typedef enum{
    NAVIGATE_STANDBY_STOP = 0,
    NAVIGATE_CHARGE_STOP,
    NAVIGATE_EMERCY_STOP,
    NAVIGATE_PAUSE_STOP,
    NAVIGATE_OUT_GARAGE,
    NAVIGATE_IN_GARAGE,
    NAVIGATE_RETURNING,
    NAVIGATE_RUNNING,
    NAVIGATE_RESUME,
    NAVIGATE_HOLD,
    NAVIGATE_NONE,
}NAVIGATE_STAGE_ENUM;

typedef enum{
    NAVIGATE_IDLE = 0,
    NAVIGATE_KEEP,
    NAVIGATE_BUSY,
}NAVIGATE_STA_ENUM;

typedef enum{
    NAVIGATE_BY_CURRENT = 0,
    NAVIGATE_BY_FORWARD,
    NAVIGATE_BY_BACKWARD,
}NAVIGATE_BY_POS;

typedef struct{
    int32_t  serNum;
    int32_t  secNum;
    int32_t  secType;
    int32_t  velocity;
    POINT_STRUCT Point;
}NAVIGATE_CONTENT_STRUCT;

//����ṹ
typedef struct{
    NAVIGATE_STA_ENUM       NavigateSta;
    NAVIGATE_STAGE_ENUM     TargetNaviStage; 
    NAVIGATE_CONTENT_STRUCT TargetSegmentInfo;
    NAVIGATE_CONTENT_STRUCT NextTargetSegmentInfo;
    NAVIGATE_CONTENT_STRUCT ReferSegmentInfo;
}NAVIGATE_INFO_STRUCT;

//�ӿں���
void Navigate_init(void);
void Navigate_loop(void);
void Navigate_setStage(NAVIGATE_STAGE_ENUM naviStage);
void Navigate_setRefer(NAVIGATE_CONTENT_STRUCT uSegment);
void Navigate_setTarget(NAVIGATE_CONTENT_STRUCT uSegment);
void Navigate_getTarget(NAVIGATE_CONTENT_STRUCT *pSegment);
void Navigate_getNextTarget(NAVIGATE_CONTENT_STRUCT *pSegment);


NAVIGATE_STA_ENUM Navigate_getSta(void);
void Navigate_refreshSegment(void);

#ifdef _cplusplus
	}
#endif

#endif

