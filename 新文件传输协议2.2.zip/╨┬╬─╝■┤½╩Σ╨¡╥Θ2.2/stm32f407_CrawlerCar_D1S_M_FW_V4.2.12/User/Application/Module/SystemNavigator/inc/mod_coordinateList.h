/**
*****************************************************************************
* @��  ���� mod_coordinateList.h 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 29-Nov-2018
* @��  ���� ������Ϣ�б�ģ��ӿ��ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/11/29����ʼ�汾
*    
*
******************************************************************************
**/

#ifndef _MOD_COORDINATELIST_H_
#define _MOD_COORDINATELIST_H_

#ifdef _cplusplus
	extern "C" {
#endif

//C��
#include <stdint.h>

//�����ļ�
#include "configure.h"

//�궨��
#define MAX_GARAGE              	(uint32_t)(20)
#define MAX_RETURN					(uint32_t)(97)

#define EACH_COORD_SPACE            (uint32_t)(32)
#define EACH_SECTOR_SPACE           (uint32_t)(128)
#define AMOUNT_CONTENT_SPACE        (uint32_t)(4096)


//����ö��
typedef enum{
    GETLIST_FAILED = 0,
    GETLIST_SUCESS
}GETLIST_STATE_ENUM;

typedef enum{
	DOWNLOAD_IDLE = 0,
	DOWNLOAD_BUSY,
	DOWNLOAD_ERR,
	DOWNLOAD_OK
}DOWNLOAD_STATE_ENUM;

typedef enum{
	START_STEP = 0,
	BLOCK_STEP,
    CRUISE_STEP,
    GARAGE_STEP,
    INGARAGE_STEP,
    OUTGARAGE_STEP,
    RETRUN_STEP,
	FINISH_STEP,
    ERROR_STEP,
}DOWMLOAD_STEP_ENUM;

typedef enum{
    OPEN_STEP = 0,
    LOAD_STEP
}FILE_STEP_ENUM;

//����ṹ��
typedef struct{
	uint16_t	pointTotal;
    uint16_t 	inGarageTotal;
    uint16_t 	outGarageTotal;
	uint16_t 	returnListTotal;
    uint16_t 	returnTotal[MAX_RETURN];
}LINE_INFO;

typedef struct{
    LINE_INFO   LineInfo[MAX_GARAGE];
    uint32_t    sectorTotal;
    uint32_t    cruiseTotal;
	uint32_t	garageTotal;
    uint32_t    pointTotal;
	uint32_t	reserve[9];
	uint8_t     isVaild;
    uint8_t     writeFlag;
    uint16_t    checkSum;
}SEGMENT_AMOUNT_STRUCT;

typedef struct{
    uint32_t serNum;
    uint32_t secNum;
    POINT_STRUCT Point[4];
    uint16_t pointType;
    uint8_t  reserve[51];
    uint8_t  writeFlag;
    uint16_t checkSum;
}SECTOR_AREA_STRUCT;

typedef struct{
    POINT_STRUCT Point;
    int32_t serNum;
    int32_t secNum;
    int16_t velocity;
    int16_t pointType;
	uint8_t  reserve;
    uint8_t  writeFlag;
    uint16_t checkSum;
}SEGMENT_CONTENT_STRUCT;

//����������
typedef union{
    SECTOR_AREA_STRUCT Struct;
    uint8_t Arry[EACH_SECTOR_SPACE];
}SECTOR_AREA_UNION;

typedef union{
    SEGMENT_CONTENT_STRUCT Struct;
    uint8_t Arry[EACH_COORD_SPACE];
}SEGMENT_CONTENT_UNION;

typedef union{
    SEGMENT_AMOUNT_STRUCT Struct;
    uint8_t Arry[AMOUNT_CONTENT_SPACE];
}SEGMENT_AMOUNT_UNION;

//������װ
typedef struct{
    GETLIST_STATE_ENUM (*getAmount)(SEGMENT_AMOUNT_UNION *pAmount);
    GETLIST_STATE_ENUM (*setAmount)(SEGMENT_AMOUNT_UNION  uAmount);
}AMOUNT_PROCESS_STRUCT;

typedef struct{
    GETLIST_STATE_ENUM (*getContent)(int32_t serNum, SECTOR_AREA_UNION *pContent);
    GETLIST_STATE_ENUM (*setContent)(int32_t serNum, SECTOR_AREA_UNION  uContent);
}SECTOR_PROCESS_STRUCT;

typedef struct{
    GETLIST_STATE_ENUM (*getContent)(int32_t serNum, SEGMENT_CONTENT_UNION *pContent);
    GETLIST_STATE_ENUM (*setContent)(int32_t serNum, SEGMENT_CONTENT_UNION  uContent);
}SEGMENT_PROCESS_STRUCT;

typedef struct{
    GETLIST_STATE_ENUM (*getContent)(int32_t garageNum, int32_t serNum, SEGMENT_CONTENT_UNION *pContent);
    GETLIST_STATE_ENUM (*setContent)(int32_t garafeNum, int32_t serNum, SEGMENT_CONTENT_UNION  uContent);
}GARAGE_SEGMENT_PROCESS_STRUCT;

typedef struct{
    GETLIST_STATE_ENUM (*getContent)(int32_t garageNum, int32_t returnNum, int32_t serNum, SEGMENT_CONTENT_UNION *pContent);
    GETLIST_STATE_ENUM (*setContent)(int32_t garageNum, int32_t returnNum, int32_t serNum, SEGMENT_CONTENT_UNION  uContent);
}GARAGE_SEGMENTS_PROCESS_STRUCT;

typedef struct{
    GARAGE_SEGMENT_PROCESS_STRUCT  InGarageProcess;
    GARAGE_SEGMENT_PROCESS_STRUCT  OutGarageProcess;
    GARAGE_SEGMENTS_PROCESS_STRUCT ReturnsProcess;
}GARAGE_ROUTER_STRUCT;

typedef struct{
    AMOUNT_PROCESS_STRUCT   AmountProcess;
    SECTOR_PROCESS_STRUCT   SectorProcess;
    SEGMENT_PROCESS_STRUCT  CruiseProcess;
    GARAGE_ROUTER_STRUCT    GarageStruct;
}ROUTER_STRUCT;

typedef struct{
    ROUTER_STRUCT       Router;
    GETLIST_STATE_ENUM  (*init)(void);
    GETLIST_STATE_ENUM  (*loop)(void);
    uint32_t            (*isPolygon)(POINT_STRUCT uCurPoint, POINT_STRUCT *pRectPoints);
    uint32_t            (*areaReduce)(SECTOR_AREA_UNION uSecArea,SECTOR_AREA_UNION *pSecArea);
}COORDINATE_LIST_STRUCT;

//�ⲿ����
extern COORDINATE_LIST_STRUCT CoordinateListStruct;

#ifdef _cplusplus
	}
#endif

#endif

