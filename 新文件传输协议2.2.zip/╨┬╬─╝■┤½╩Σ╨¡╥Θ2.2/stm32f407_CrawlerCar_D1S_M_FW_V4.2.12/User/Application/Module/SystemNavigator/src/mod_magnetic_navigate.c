/**
*****************************************************************************
* @��  ���� mod_magnetic_navigate.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 13-June-2018
* @��  ���� �ŵ�������ģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2019/01/04: ��ʼ�汾
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_magnetic_navigate.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define SET_POINT ((SENSOR_POINT_COUNT - 1) / 2.0)	    //3.5
#define MAX_ADJUST_ANGLE	    45		                //45��

//������װ
typedef struct _PID_TypeDef
{
	float SetPoint;		//�趨Ŀ�� Desired Value
	float IntegralBias;	//������
	float Kp;			//�������� Proportional Const
	float Ki;			//���ֳ��� Integral Const
	float Kd;			//΢�ֳ��� Derivative Const
	float CurBias;		//Bias[0]
	float LastBias;		//Bias[-1]
} _PID_TypeDef;

static _PID_TypeDef g_PID = {
	.SetPoint = SET_POINT,
	.Kp = 5,
	.Ki = 2,
	.Kd = 1
};


/*
******************************************************************************
*	�� �� ��: magnav_calculate_coordinate
*	����˵��: �ŵ�������ƽ��ֵ
*	��    ��: magdata: �ŵ���ֵ
*	�� �� ֵ: �Ŵ�������ǰ��
******************************************************************************
*/
float magnav_calculate_coordinate(uint32_t magdata)
{
	int magPointCnt = 0;
	int magCoorSum = 0;
	float magCoorReturn = 0;
	
	/* sum magnetism of every coordinate point valid */
	for(int i = 0; i < SENSOR_POINT_COUNT; i ++)
	{
		if((magdata >> i) & 0x01)
		{
			magPointCnt++;
			magCoorSum += i;
		}
	}
	
	/* calculate magnetism coordinate */
	if(magPointCnt != 0)
	{
		magCoorReturn = (float)magCoorSum / (float)magPointCnt;
	}
	else
	{
		magCoorReturn = -1;
	}
	
	return magCoorReturn;
}


#if 0

float magnav_pid_calculate(_PID_TypeDef *pid, float curPoint)
{
	pid->CurBias = pid->SetPoint - curPoint; 
	pid->IntegralBias = pid->CurBias;
	float angleVel = (pid->Kp * pid->CurBias) + (pid->Ki * pid->IntegralBias) + (pid->Kd * (pid->CurBias - pid->LastBias));
	pid->LastBias = pid->CurBias;
	return angleVel;
}

void magnav_track_loop(void)
{
	MOTION_PARAM_STRUCT motorParm;
	float magData, curPoint;
	magData = g_MagInfo;
	curPoint = magnav_calculate_coordinate(magData);
	
	if(curPoint < 0)
	{
		motorParm.angularVelocity = 0;
		motorParm.angularVelocity = 0;
		motorParm.MotionCtl = MOTION_DISABLE;
	}
	else
	{
		motorParm.MotionCtl = MOTION_ENABLE;
		motorParm.angularVelocity = magnav_pid_calculate(&g_PID, curPoint);
		if(curPoint <= 1)
		{
			motorParm.linearVelocity = -3;
		}
		else
		{
			motorParm.linearVelocity = -5;
		}
	}
	MotionControl_setParam(motorParm);
}

#else

/*
******************************************************************************
*	�� �� ��: magnav_track_inGarage
*	����˵��: �ŵ�����ѭ��
*	��    ��: ��
*	�� �� ֵ: 0:�����ŵ��� 1:��ʧ���� 2:������ͣ��λ
******************************************************************************
*/
uint32_t magnav_track_inGarage(void)
{
    CHASSIS_PARAM_STRUCT chasisParam;
	POSITION_INFO_STRUCT uPositionInfo;
	LIMIT_SWITCH_INFO_STRUCT uLimitSwitchInfo;

	PositionInfo_get(&uPositionInfo);
	LimitSwitchInfo_get(&uLimitSwitchInfo);

    int32_t rSta = 0;
	float magData = magneitc_get_info();
	float curPoint = magnav_calculate_coordinate(magData);
    
    chasisParam.linearVecity = 0;
    chasisParam.amuzithAngle =  uPositionInfo.Azimuth;
    chasisParam.chassisCtl = CHASSIS_ENABLE;
    
	if(curPoint < 0){
		rSta = 1;
	}else{
		if(GARAGE_SWITCH_TRIG){
			chasisParam.chassisCtl = CHASSIS_DISABLE;
			chasisParam.amuzithAngle = uPositionInfo.Azimuth;
			chasisParam.linearVecity = 0;
			rSta = 2;
		}else{
			chasisParam.chassisCtl = CHASSIS_ENABLE;
			chasisParam.amuzithAngle = uPositionInfo.Azimuth + (SET_POINT - curPoint)/(SENSOR_POINT_COUNT - 1) * MAX_ADJUST_ANGLE;
			if((curPoint <= 1)||(curPoint >= 6)){
				chasisParam.linearVecity = -3;
			}else{
				chasisParam.linearVecity = -6;
			}
		}
	}
	
	ChassisControl_setParam(chasisParam);

	return rSta;
}

/*
******************************************************************************
*	�� �� ��: magnav_track_outGarage
*	����˵��: �ŵ�����ѭ��
*	��    ��: ��
*	�� �� ֵ: 0:�����ŵ��� 1:��ʧ����
******************************************************************************
*/
uint32_t magnav_track_outGarage(void)
{
    CHASSIS_PARAM_STRUCT chasisParam;
	POSITION_INFO_STRUCT uPositionInfo;
	LIMIT_SWITCH_INFO_STRUCT uLimSwInfo;

	PositionInfo_get(&uPositionInfo);
	LimitSwitchInfo_get(&uLimSwInfo);

    int32_t rSta = 0;
	float magData = magneitc_get_info();
	float curPoint = magnav_calculate_coordinate(magData);
    
    chasisParam.linearVecity = 0;
    chasisParam.amuzithAngle =  uPositionInfo.Azimuth;
    chasisParam.chassisCtl = CHASSIS_ENABLE;
    
	if(curPoint < 0){
		rSta = 1;
	}else{
		chasisParam.chassisCtl = CHASSIS_ENABLE;
		chasisParam.amuzithAngle = uPositionInfo.Azimuth - (SET_POINT - curPoint)/(SENSOR_POINT_COUNT - 1) * MAX_ADJUST_ANGLE;
		if((curPoint <= 1)||(curPoint >= 6)){
			chasisParam.linearVecity = 3;
		}else{
			chasisParam.linearVecity = 6;
		}
	}
	
	ChassisControl_setParam(chasisParam);

	return rSta;
}

#endif
