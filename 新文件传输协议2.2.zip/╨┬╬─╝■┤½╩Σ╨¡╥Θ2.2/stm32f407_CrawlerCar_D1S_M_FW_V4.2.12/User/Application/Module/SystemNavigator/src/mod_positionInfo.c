/**
*****************************************************************************
* @��  ���� mod_positionInfo.c 
* @��  �ߣ� 00Jackey
* @��  ���� V1.0.0
* @��  �ڣ� 13-June-2018
* @��  ���� λ����Ϣģ�����ļ�
******************************************************************************
* @�޸ļ�¼��
*   2018/09/11����ʼ�汾(��GPS�Ľ�������)
*   2019/04/10����GPS����λ���복����ת����λ�ã����������������
*
******************************************************************************
**/

//�ӿ�ͷ�ļ�
#include "mod_positionInfo.h"

//�˲���
#include "mod_filter.h"

//ͷ�ļ�����
#include "includes.h"

//�궨��
#define RTK_ADAPT_HEIGHT        (+0.213*0.001)   //+213mm
#define RTK_ADAPT_ANGLE         (+10.0)          //+10��

#define RTK_CURRENT_DISTANCE    (+0.060*0.001)  //+060mm
#define RTK_FORWARD_DISTANCE    (+0.150*0.001)  //+150mm  
#define RTK_BACKWARD_DISTANCE   (-0.150*0.001)  //-150mm

#define AZIMUTH_VALUE_SMOOTH_CNT 5	            //100ms*5


//ȫ�ֱ���
POSITION_INFO_STRUCT sPositionInfo = {
    .PosVaildSta = POS_INVALID,
    .AzimuthValidSta = POS_INVALID,
    .PosConnectSta = POS_DISCONNECT,
};



/*
******************************************************************************
*	�� �� ��: PositionInfo_init
*	����˵��: λ����Ϣ��ʼ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
int32_t PositionInfo_init(void)
{
    Gps_init();
    
    return 0;
}


/*
******************************************************************************
*	�� �� ��: PositionInfo_calcuAzimuthDis
*	����˵��: λ����Ϣ��ȡ����ǲ�ֵ
*	��    ��: formAzimuth:�����Ƕ�  toAzimuth������Ƕ�
*	�� �� ֵ: -180 ~ +180 
******************************************************************************
*/
double PositionInfo_calcuAzimuthDis(double formAzimuth, double toAzimuth)
{
    double tDisAzimuth = toAzimuth - formAzimuth;
    if(tDisAzimuth > 180.0){
        tDisAzimuth -= 360.0;
    }else if(tDisAzimuth < -180.0){
        tDisAzimuth += 360.0;
    }

    return tDisAzimuth;
}

/*
******************************************************************************
*	�� �� ��: PositionInfo_postionReserve
*	����˵��: λ����Ϣ������������
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
int32_t PositionInfo_postionReserve(GPS_INFO_STRUCT uGpsInfo)
{
    nmeaPOS uFromPos,uMidPos,uTgtPos;
    double toAzimuth = 0.0,ttAngle = 0.0,tLen = 0.0,ttLen = 0.0;

	if((uGpsInfo.azimuth < 0.0f)||(uGpsInfo.azimuth >= 360.0f))             //��������Ƕ�
		return -1;
    
    ttAngle = (uGpsInfo.azimuth > 180) ? (360 - uGpsInfo.azimuth) : uGpsInfo.azimuth;
    ttAngle = ttAngle * -1/9 + 10;                                          //����õ�(-10~+10)
    
    uGpsInfo.azimuth = (uGpsInfo.azimuth + DECLINATION);                    //�����Ƕ���RTK���߽ǶȲ�ֵ
    uGpsInfo.azimuth >= 360.0f ? (uGpsInfo.azimuth -= 360.0f) : uGpsInfo.azimuth;

    uFromPos.lat = nmea_degree2radian(uGpsInfo.latitude);                   //�Ƚ��ǶȻ��ɻ���
    uFromPos.lon = nmea_degree2radian(uGpsInfo.longitude);

    tLen = RTK_ADAPT_HEIGHT * sin(nmea_degree2radian(RTK_ADAPT_ANGLE));     //����ˮƽͶӰ����
    nmea_move_horz(&uFromPos,&uMidPos,0,tLen);                              //���㴹ֱƫ�ƣ��������Ƿ���ƫ��
    //nmea_move_horz_ellipsoid(&uFromPos,&uMidPos,0,tLen,&toAzimuth);
    
/*--------------------------------------------------------------------------*/
    ttLen = RTK_CURRENT_DISTANCE * cos(nmea_degree2radian(ttAngle));
    nmea_move_horz(&uMidPos,&uTgtPos,uGpsInfo.azimuth,ttLen);               //����ˮƽƫ��
    //nmea_move_horz_ellipsoid(&uMidPos,&uTgtPos,nmea_degree2radian(uGpsInfo.azimuth),ttLen,&toAzimuth); //����ˮƽƫ��
    sPositionInfo.CurPoint.latitude = nmea_radian2degree(uTgtPos.lat);      //ת������
    sPositionInfo.CurPoint.longitude = nmea_radian2degree(uTgtPos.lon);

    ttLen = RTK_FORWARD_DISTANCE * cos(nmea_degree2radian(ttAngle));
    nmea_move_horz(&uMidPos,&uTgtPos,uGpsInfo.azimuth,ttLen);               //����ˮƽƫ��
    //nmea_move_horz_ellipsoid(&uMidPos,&uTgtPos,nmea_degree2radian(uGpsInfo.azimuth),ttLen,&toAzimuth); //����ˮƽƫ��
    sPositionInfo.ForwardPoint.latitude = nmea_radian2degree(uTgtPos.lat);  //ת������
    sPositionInfo.ForwardPoint.longitude = nmea_radian2degree(uTgtPos.lon);

    ttLen = RTK_BACKWARD_DISTANCE * cos(nmea_degree2radian(ttAngle));
    nmea_move_horz(&uMidPos,&uTgtPos,uGpsInfo.azimuth,ttLen);               //����ˮƽƫ��
    //nmea_move_horz_ellipsoid(&uMidPos,&uTgtPos,nmea_degree2radian(uGpsInfo.azimuth),ttLen,&toAzimuth); //����ˮƽƫ��
    sPositionInfo.BackwardPoint.latitude = nmea_radian2degree(uTgtPos.lat); //ת������
    sPositionInfo.BackwardPoint.longitude = nmea_radian2degree(uTgtPos.lon);
/*--------------------------------------------------------------------------*/    

    sPositionInfo.speed = uGpsInfo.speed;                                   //��ֵ״̬���ٶ�
    sPositionInfo.height = uGpsInfo.height;
    if(uGpsInfo.ConnectSta == GPS_CONNECTED){
        sPositionInfo.PosConnectSta = POS_CONNECTED;
    }else{
        sPositionInfo.PosConnectSta = POS_DISCONNECT;  
    }
                                                                            //�ж�ֵ�Ƿ���Ч 
    if((uGpsInfo.QualitySta ==  GPS_FIXED_SOLUTION)&&(uGpsInfo.HdopSta == POS_VALID)
      &&(uGpsInfo.ConnectSta == POS_CONNECTED)&&(uGpsInfo.InUseSta == INUSE_VALID)){
        sPositionInfo.PosVaildSta = POS_VALID;
    }else{
        sPositionInfo.PosVaildSta = POS_INVALID;
    }

    return 0;
}

/*
******************************************************************************
*	�� �� ��: PositionInfo_amuzithReserve
*	����˵��: λ����Ϣ������ѭ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
#if 0
void PositionInfo_amuzithReserve(GPS_INFO_STRUCT uGpsInfo)
{
    static float sAmuizth = 0.0f;
    static int32_t sCnt = 0;
	
    float tRealAngle = 0.0;
    int32_t tRealCircle = 0;

    static double azimuthRateByRtk = 0.0;
    static double azimuthRateByMotor = 0.0;

    POS_VALID_ENUM tAzimuthValidState = POS_VALID;                          //��ʼ״̬λ��Ч

	MOTION_STATE_STRUCT uMotionState;										//�˶�״̬
    MotionControl_getInfo(&uMotionState);									//��ȡ���̷���������

    if(uGpsInfo.AmuzithSta != AZIMUTH_VALID){                               //ֻ�����Ƕ��ж�                   
        tAzimuthValidState = POS_INVALID;
        goto AttitudeExit;
    }

	if((uGpsInfo.azimuth < 0.0f)||(uGpsInfo.azimuth >= 360.0f)){          	//��������Ƕ�
        tAzimuthValidState = POS_INVALID;
		goto AttitudeExit;
    }

    sPositionInfo.AzimuthReal = uGpsInfo.azimuth;                           //����ԭʼֵ
    
    tRealCircle = sAmuizth / CIRCLE_ANGLE;                                	//������ת�˶���Ȧ����ʵ�ʽǶȣ�-360~+360��
    tRealAngle = sAmuizth - (tRealCircle * CIRCLE_ANGLE);

    if(tRealAngle < 0){                                                   	//����-360 ~ 0��ת��Ϊ��0 ~ 360��
        tRealAngle += CIRCLE_ANGLE;
    }

    if((uGpsInfo.azimuth - tRealAngle) > 180){                            	//������ת�ۼƽǶ�
        sCnt -= 1;
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }else if((uGpsInfo.azimuth - tRealAngle) < -180){
        sCnt += 1;
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }else{
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }

#if 1
#define INPUT_TIMEOUT			    60									    // 60*5mS 100mSec�Ƕ�ˢ������ 300/100 
#define AZIMUTH_RATE_DIFF_TIMEOUT 	400									    //400*5mS 2000mSec�ĽǶ��ж�
	static float sInputAmuizth = 0.0f;
	static int32_t sInputTimeout = INPUT_TIMEOUT;
	float tAngleDiff = sAmuizth - sInputAmuizth;
	if((fabs(tAngleDiff) < 6.00)){											//���RTK���ĽǶȱ仯С��6.00������Ϊ��Ч������20rad/min = 2��/time
		sInputAmuizth = sAmuizth;
        sInputTimeout = INPUT_TIMEOUT;
        float fAzimuthRateSmoothValue = Filter_insert(AzimuthFilterPtr,tAngleDiff); //�����˲�����ֵ
        azimuthRateByRtk = fAzimuthRateSmoothValue * 200;			                //����Ϊ�Ƕ�/�� 5mS * 200    
    }else{																	//����Ƕȴ���6.00�ȳ���2��,���ݻ��ǲ������㵫�ǽǶ�������Ч
		if(sInputTimeout > 0)
            sInputTimeout -= 1;
        else
            sInputAmuizth = sAmuizth;                                       //��ʱ����
        
        LOG_RCD("tAngleDiff = %f,sAmuizth = %f,sInputAmuizth = %f",tAngleDiff,sAmuizth,sInputAmuizth);
        tAzimuthValidState = POS_INVALID;
		goto AttitudeExit;
	}
#endif

#if 1
	static int32_t sAzimuthRateTimeoutCnt = 0;
	azimuthRateByMotor = uMotionState.MotionParmInfo.angularVelocity * 180 / PI  / 60;												
	double tYawRateDiff = fabs(azimuthRateByRtk - azimuthRateByMotor);
	if(tYawRateDiff < 10.0){												//�ȽϽ��ٶ�,>10.0��/s,�ұ���ʱ�䳬��2s����Ϊ�Ƕ���Ч
		sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
	}else{
		LOG_RCD("tYawRateDiff = %.3f,azimuthRateByRtk = %.3f,azimuthRateByMotor = %.3f",tYawRateDiff, azimuthRateByRtk, azimuthRateByMotor);
		if(sAzimuthRateTimeoutCnt > 0){
			sAzimuthRateTimeoutCnt -= 1;
		}else{
			LOG_RCD("tYawRateDiff is more than 10 last 2 seconds",0);
            tAzimuthValidState = POS_INVALID;
			goto AttitudeExit;
		}
	}
#endif
    
#if 1
    #define ZERO_RATE_BY_MOTOR	1000 //5mSec * 400
    static int32_t sZeroRateByMotor = ZERO_RATE_BY_MOTOR;
    if((fabs(uMotionState.MotionParmInfo.angularVelocity) < 0.0001)\
      &&(fabs(uMotionState.MotionParmInfo.linearVelocity) < 0.0001)){		//���̾�ֹ״̬�£�RTK����Ľ��ٶ�һ������2��/S֮�����룬����Ϊ��Ч
        if(fabs(azimuthRateByRtk) < 2.0){
            if(sZeroRateByMotor > 0){
                sZeroRateByMotor -= 1;
                tAzimuthValidState = POS_INVALID;
            }
        }else{
            LOG_RCD("The chassis is stop, but azimuthRateByRtk = %f",azimuthRateByRtk);
            sZeroRateByMotor = ZERO_RATE_BY_MOTOR;
            tAzimuthValidState = POS_INVALID;
        }
    }else{
        sZeroRateByMotor = ZERO_RATE_BY_MOTOR;
    }
#endif

#if 1
    static double sfAngleTotal = 0.0;
    if(fabs(uMotionState.MotionParmInfo.linearVelocity) < 0.1){             // ������ת��ʱ�����ٶ�Ϊ0(<0.1m/Min),����ۼƽǶȴ���360�ȣ��򱨴�
        if((uMotionState.MotionParmInfo.angularVelocity *  sfAngleTotal) > 0.0){
            sfAngleTotal += (uMotionState.MotionParmInfo.angularVelocity * 180 / PI);
            if(fabs(sfAngleTotal) > 360.0){
                tAzimuthValidState = POS_INVALID;
            }
        }else{
            sfAngleTotal = 0.0;
        }
    }else{
        sfAngleTotal = 0.0;
    }
#endif
    
AttitudeExit:
    sPositionInfo.AzimuthValidSta = tAzimuthValidState;
    sPositionInfo.Azimuth = sAmuizth + DECLINATION;						    //����������趨ֵΪ��Ч
}

#elif 0

void PositionInfo_amuzithReserve(GPS_INFO_STRUCT uGpsInfo)
{
    static float sAmuizth = 0.0f;
    static int32_t sCnt = 0;
	
    float tRealAngle = 0.0;
    int32_t tRealCircle = 0;
    
	static float sInputAmuizth = 0.0f;
    static double sAzimuthRateByRtk = 0.0;
    static double sAzimuthRateByImu = 0.0;

    ATTITUDE_INFO_STRUCT uAttituInfo;
    AttitudeInfo_get(&uAttituInfo);                                         //��ȡ��̬��Ϣ
    sAzimuthRateByImu = uAttituInfo.AngleSpeed[Z_Axis];                     //��ֵ��ȫ�ֱ���

    if(uGpsInfo.AmuzithSta != AZIMUTH_VALID){                               //ֻ�����Ƕ��ж�                   
        sPositionInfo.AzimuthValidSta = POS_INVALID;
        goto AttitudeExit;
    }

	if((uGpsInfo.azimuth < 0.0f)||(uGpsInfo.azimuth >= 360.0f)){          	//��������Ƕ�
        sPositionInfo.AzimuthValidSta = POS_INVALID;
		goto AttitudeExit;
    }
                       
   if((uGpsInfo.QualitySta != GPS_FIXED_SOLUTION)||(uGpsInfo.HdopSta != POS_VALID)
      ||(uGpsInfo.ConnectSta != POS_CONNECTED)||(uGpsInfo.InUseSta != INUSE_VALID)){
        sPositionInfo.AzimuthValidSta = POS_INVALID;                        //�����λ��Ч�����Ҳ��Ч
		goto AttitudeExit;
    }

    sPositionInfo.AzimuthReal = uGpsInfo.azimuth;                           //����ԭʼֵ
    
    tRealCircle = sAmuizth / CIRCLE_ANGLE;                                	//������ת�˶���Ȧ����ʵ�ʽǶȣ�-360~+360��
    tRealAngle = sAmuizth - (tRealCircle * CIRCLE_ANGLE);

    if(tRealAngle < 0){                                                   	//����-360 ~ 0��ת��Ϊ��0 ~ 360��
        tRealAngle += CIRCLE_ANGLE;
    }

    if((uGpsInfo.azimuth - tRealAngle) > 180){                            	//������ת�ۼƽǶ�
        sCnt -= 1;
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }else if((uGpsInfo.azimuth - tRealAngle) < -180){
        sCnt += 1;
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }else{
        sAmuizth = uGpsInfo.azimuth + sCnt * CIRCLE_ANGLE;
    }

#if 1
    #define AZIMUTH_SEL 5                                                   // 1:ֱ���ж� 2:��ʱ�ж� 3:��ʱ�ӱ��� 4:�洢������Ϣ 5:���Բ���
	float tAngleDiff = sAmuizth - sInputAmuizth;
    float fAzimuthRateSmoothValue = Filter_insert(AzimuthFilterPtr,tAngleDiff);
    sAzimuthRateByRtk = fAzimuthRateSmoothValue * 10;			            //����Ϊ�Ƕ�/�� 100mS * 10   
    sInputAmuizth = sAmuizth;
    #if (AZIMUTH_SEL == 1)
        #define DIFF_DEGREE   5                                             //���ٶ�������ֵ
        #define AZIMUTH_RATE_DIFF_TIMEOUT 	10							    //10*100mS 1000mSec�ĽǶ��ж�
        static int32_t sAzimuthRateTimeoutCnt = 0;
        float sDiffDegree = fabs((sAzimuthRateByRtk - sAzimuthRateByImu));
        if(sDiffDegree < DIFF_DEGREE ){                                     //�Ƕȱ�ֵС��DIFF_RATEΪ��Чֵ
            sPositionInfo.AzimuthValidSta = POS_VALID;
        }else{
            sPositionInfo.AzimuthValidSta = POS_INVALID;
            goto AttitudeExit;
        }
    #elif (AZIMUTH_SEL == 2)
        #define DIFF_DEGREE   10                                            //���ٶ�������ֵ
        #define AZIMUTH_RATE_DIFF_TIMEOUT 	10							    //10*100mS 1000mSec�ĽǶ��ж�
        static int32_t sAzimuthRateTimeoutCnt = 0;
        float sDiffDegree = fabs((sAzimuthRateByRtk - sAzimuthRateByImu));
        if(sDiffDegree < DIFF_DEGREE ){                                     //�Ƕȱ�ֵС��DIFF_RATEΪ��Чֵ
            if(sPositionInfo.AzimuthValidSta == POS_VALID){                 //֮ǰ��״̬Ϊ��Ч��λ����
                sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
            }else{                                                          //�����λ��Ч��ʱ����Ϊ��Ч
                if(sAzimuthRateTimeoutCnt > 0){
                    sAzimuthRateTimeoutCnt -= 1;
                }else{
                    sPositionInfo.AzimuthValidSta = POS_VALID;
                }
            }
        }else{
            if(sPositionInfo.AzimuthValidSta == POS_INVALID){
                sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
            }else{
                if(sAzimuthRateTimeoutCnt > 0){
                    sAzimuthRateTimeoutCnt -= 1;
                }else{
                    sPositionInfo.AzimuthValidSta = POS_INVALID;
                }
            }
        }
        goto AttitudeExit;
    #elif (AZIMUTH_SEL == 3)    
        #define DIFF_PERCENTAGE  1                                          //���ٶ�����ֵ
        #define AZIMUTH_RATE_DIFF_TIMEOUT 	10							    //10*100mS 1000mSec�ĽǶ��ж�
        static int32_t sAzimuthRateTimeoutCnt = 0;
        float sDiffDegree = fabs((sAzimuthRateByRtk - sAzimuthRateByImu));
        if((sDiffDegree / sAzimuthRateByImu) < DIFF_PERCENTAGE ){           //�Ƕȱ�ֵС��DIFF_RATEΪ��Чֵ
            if(sPositionInfo.AzimuthValidSta == POS_VALID){                 //֮ǰ��״̬Ϊ��Ч��λ����
                sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
            }else{                                                          //�����λ��Ч��ʱ����Ϊ��Ч
                if(sAzimuthRateTimeoutCnt > 0){
                    sAzimuthRateTimeoutCnt -= 1;
                }else{
                    sPositionInfo.AzimuthValidSta = POS_VALID;
                }
            }
        }else{
            if(sPositionInfo.AzimuthValidSta == POS_INVALID){
                sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
            }else{
                if(sAzimuthRateTimeoutCnt > 0){
                    sAzimuthRateTimeoutCnt -= 1;
                }else{
                    sPositionInfo.AzimuthValidSta = POS_INVALID;
                }
            }
        }
        goto AttitudeExit;
    #elif (AZIMUTH_SEL == 4)
        static float sDiffRate = 0.0;
        static float sDiffPercentage = 0.0;
        sPositionInfo.AzimuthValidSta = POS_VALID;
        sDiffRate = sAzimuthRateByRtk - sAzimuthRateByImu;
        sDiffPercentage = (sDiffRate / sAzimuthRateByImu) * 100;
        LOG_INF("TEST value = %.6f,%.6f,%.6f,%.6f",sAzimuthRateByRtk,sAzimuthRateByImu,sDiffRate,sDiffPercentage);
        goto AttitudeExit;
    #elif (AZIMUTH_SEL == 5)
        static float sDiffRate = 0.0;
        static float sDiffDegree = 0.0;
        static float sDiffPercentage = 0.3;
        static int32_t sAzimuthRateDiffTimeout = 10;
        static int32_t sAzimuthRateTimeoutCnt = 0;
        #define DIFF_BOUNDARY    5                                          //��������
        #define DIFF_DEGREE      2                                          //���ٶȲ�ֵ
        #define DIFF_PERCENTAGE  sDiffPercentage                            //���ٶȲ�ٷֱ�
        #define AZIMUTH_RATE_DIFF_TIMEOUT sAzimuthRateDiffTimeout			//10*100mS 1000mSec�ĽǶ��ж�
        
        sDiffDegree = fabs(sAzimuthRateByRtk - sAzimuthRateByImu);
        if(fabs(sAzimuthRateByImu) > DIFF_BOUNDARY){
            sDiffRate = (sDiffDegree / fabs(sAzimuthRateByImu));
            if(sDiffRate < DIFF_PERCENTAGE ){                               //�Ƕȱ�ֵС��DIFF_RATEΪ��Чֵ
                if(sPositionInfo.AzimuthValidSta == POS_VALID){             //֮ǰ��״̬Ϊ��Ч��λ����
                    sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
                }else{                                                      //�����λ��Ч��ʱ����Ϊ��Ч
                    if(sAzimuthRateTimeoutCnt > 0){
                        sAzimuthRateTimeoutCnt -= 1;
                    }else{
                        sPositionInfo.AzimuthValidSta = POS_VALID;
                    }
                }
            }else{
                if(sPositionInfo.AzimuthValidSta == POS_INVALID){
                    sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
                }else{
                    if(sAzimuthRateTimeoutCnt > 0){
                        sAzimuthRateTimeoutCnt -= 1;
                    }else{
                        sPositionInfo.AzimuthValidSta = POS_INVALID;
                    }
                }
            }
        }else{
            if(sDiffDegree < DIFF_DEGREE ){                                 //�Ƕȱ�ֵС��DIFF_RATEΪ��Чֵ
                if(sPositionInfo.AzimuthValidSta == POS_VALID){             //֮ǰ��״̬Ϊ��Ч��λ����
                    sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
                }else{                                                      //�����λ��Ч��ʱ����Ϊ��Ч
                    if(sAzimuthRateTimeoutCnt > 0){
                        sAzimuthRateTimeoutCnt -= 1;
                    }else{
                        sPositionInfo.AzimuthValidSta = POS_VALID;
                    }
                }
            }else{
                if(sPositionInfo.AzimuthValidSta == POS_INVALID){
                    sAzimuthRateTimeoutCnt = AZIMUTH_RATE_DIFF_TIMEOUT;
                }else{
                    if(sAzimuthRateTimeoutCnt > 0){
                        sAzimuthRateTimeoutCnt -= 1;
                    }else{
                        sPositionInfo.AzimuthValidSta = POS_INVALID;
                    }
                }
            }
        }
        goto AttitudeExit;   
    #endif
#endif

AttitudeExit:
    sPositionInfo.Azimuth = sAmuizth + DECLINATION;
}

#elif 1

void PositionInfo_amuzithReserve(GPS_INFO_STRUCT uGpsInfo)
{
#define AZIMUTH_DISTANCE   3.0                                              //����3.0���򱨴�    
#define COMPARE_LENTH       10                                              //�ж�һ�����Ƕȱ仯��ֵ  
  
    static double sAmuizthByRtk = 0.0f;
    
    ATTITUDE_INFO_STRUCT uAttituInfo;
    AttitudeInfo_get(&uAttituInfo);                                         //��ȡ��̬��Ϣ,�����̬��Ч������Ч
    if(uAttituInfo.ValidSta != ATTITUDE_VAILD){
        sPositionInfo.AzimuthValidSta = POS_INVALID;
        goto AttitudeExit;
    }

   if((uGpsInfo.QualitySta != GPS_FIXED_SOLUTION)||(uGpsInfo.HdopSta != POS_VALID)
      ||(uGpsInfo.ConnectSta != POS_CONNECTED)||(uGpsInfo.InUseSta != INUSE_VALID)){
        sPositionInfo.AzimuthValidSta = POS_INVALID;                        //�����λ��Ч�����Ҳ��Ч
		goto AttitudeExit;
    }

    if(uGpsInfo.AmuzithSta != AZIMUTH_VALID){                               //ֻ�����Ƕ��ж�                   
        sPositionInfo.AzimuthValidSta = POS_INVALID;
        goto AttitudeExit;
    }

	if((uGpsInfo.azimuth < 0.0f)||(uGpsInfo.azimuth >= 360.0f)){          	//��������Ƕ�
        sPositionInfo.AzimuthValidSta = POS_INVALID;
		goto AttitudeExit;
    }
#if 1
    static double sOldAzimuth = 0.0,sOldNewDisAngle = 0.0;                  //�����������4��
    sOldNewDisAngle = PositionInfo_calcuAzimuthDis(sOldAzimuth,uGpsInfo.azimuth);
    sOldAzimuth = uGpsInfo.azimuth;
    if(fabs(sOldNewDisAngle) > (AZIMUTH_DISTANCE + 1.0)){
        sPositionInfo.AzimuthValidSta = POS_INVALID;
		goto AttitudeExit;
    }
#endif
    static double sAzimuthByRtkArry[COMPARE_LENTH] = {0};                   //������
    static double sAzimuthByImuArry[COMPARE_LENTH] = {0};
    static bool sIsBuffFill = false;
    static int32_t sCnt = 0;                                                //�ۼƼ���

    sAzimuthByRtkArry[sCnt % COMPARE_LENTH] = uGpsInfo.azimuth;             //�������
    sAzimuthByImuArry[sCnt % COMPARE_LENTH] = uAttituInfo.Angle[Z_Axis];

    if(sIsBuffFill){
        double tAzimuthDisByRtk,tAzimuthDisByImu,tAzimuthDisByRtkImu;       //һ���ڼ���ж�
        tAzimuthDisByRtk = PositionInfo_calcuAzimuthDis(sAzimuthByRtkArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByRtkArry[sCnt % COMPARE_LENTH]);
        tAzimuthDisByImu = PositionInfo_calcuAzimuthDis(sAzimuthByImuArry[(sCnt+1) % COMPARE_LENTH],sAzimuthByImuArry[sCnt % COMPARE_LENTH]);
        tAzimuthDisByRtkImu = tAzimuthDisByRtk - tAzimuthDisByImu;
        //LOG_RCD("tAzimuthDisByRtk = %.6f,tAzimuthDisByImu = %.6f,tAzimuthDisByRtkImu = %.6f",tAzimuthDisByRtk,tAzimuthDisByImu,tAzimuthDisByRtkImu);
        if(fabs(tAzimuthDisByRtkImu) > AZIMUTH_DISTANCE){
            sPositionInfo.AzimuthValidSta = POS_INVALID;
            goto IncCountExit;
        }
    #if 1
        double tSquareAzimuthDisByRtk = 0.0,tSquareAzimuthDisByImu = 0.0;   //һ���ڲ�������,
        for(uint32_t i = 0; i < (COMPARE_LENTH-1); i++){
            double tAzimuthDisByRtk = PositionInfo_calcuAzimuthDis(sAzimuthByRtkArry[(sCnt+i) % COMPARE_LENTH],sAzimuthByRtkArry[(sCnt+1+i) % COMPARE_LENTH]);
            double tAzimuthDisByImu = PositionInfo_calcuAzimuthDis(sAzimuthByImuArry[(sCnt+i) % COMPARE_LENTH],sAzimuthByImuArry[(sCnt+1+i) % COMPARE_LENTH]);
            tSquareAzimuthDisByRtk += fabs(tAzimuthDisByRtk);
            tSquareAzimuthDisByImu += fabs(tAzimuthDisByImu);
        }
        //LOG_RCD("tSquareAzimuthDisByRtk = %.6f,tSquareAzimuthDisByImu = %.6f",tSquareAzimuthDisByRtk,tSquareAzimuthDisByImu);
        if(fabs(tSquareAzimuthDisByRtk - tSquareAzimuthDisByImu) > (AZIMUTH_DISTANCE+4)){
            sPositionInfo.AzimuthValidSta = POS_INVALID;	
            goto IncCountExit;
        }
    #endif
    }
    
    int32_t tRealCircle = sAmuizthByRtk / CIRCLE_ANGLE;                     //������ת�˶���Ȧ
    double tRealAngle = sAmuizthByRtk - (tRealCircle * CIRCLE_ANGLE);       //ʣ��Ƕ�
    if(tRealAngle < 0.0){                                                   //���Ƕ���(0.0~-360.0]��ʱ����Ҫ��tRealAngle��Ϊ[0~360),���Լ�360��ʱ����Ҫ��һȦ
        tRealAngle += CIRCLE_ANGLE;
        tRealCircle -= 1;
    }
    if((uGpsInfo.azimuth - tRealAngle) > 180.0){                            //������ת�ۼƽǶ�,From -> To => To - From
        tRealCircle -= 1;
    }else if((uGpsInfo.azimuth - tRealAngle) < -180.0){
        tRealCircle += 1;
    }
    sAmuizthByRtk = uGpsInfo.azimuth + tRealCircle * CIRCLE_ANGLE;
    
    sPositionInfo.AzimuthReal = uGpsInfo.azimuth;                           //����ԭʼֵ
    sPositionInfo.AzimuthValidSta = POS_VALID;                              //���Ϊ��Ч

IncCountExit:
    if(++sCnt >= (COMPARE_LENTH*100))   sCnt = 0;                           //����ֵ��ֵֹ���,ʹ��10�ı���
    if(sCnt >= (COMPARE_LENTH - 1)){                                        //10����ֻ���9���񣬵���9�󣬾Ϳ��Լ���
        if(sIsBuffFill == false){
            sIsBuffFill = true;
        }
    }

AttitudeExit:
    sPositionInfo.Azimuth = sAmuizthByRtk + DECLINATION;
}

#endif

/*
******************************************************************************
*	�� �� ��: PositionInfo_reviseInfo
*	����˵��: λ����Ϣ������ѭ��
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
int32_t PositionInfo_reviseInfo(void)
{
    GPS_INFO_STRUCT uGpsInfo;
    uint16_t rVal = Gps_getInfo(&uGpsInfo);
    
    if(rVal | (1<<4)){
        PositionInfo_amuzithReserve(uGpsInfo);    
    }
    if(rVal | (1<<8)){
        PositionInfo_postionReserve(uGpsInfo);
    }
    
    return rVal;
}

/*
******************************************************************************
*	�� �� ��: PositionInfo_loopRead
*	����˵��: λ����Ϣ������ѭ��
*	��    ��: ��
*	�� �� ֵ: 0:�������� 1:δ����
******************************************************************************
*/
int32_t PositionInfo_loopRead(void)
{
    Gps_infoAnalyse();
    
#define POS_REFRESH_CNT (20)  //5*20mSec 
    static int16_t sPosRefreshCnt = POS_REFRESH_CNT;
    
    if(sPosRefreshCnt > 1){
        sPosRefreshCnt -= 1;
        return 1;
    }else{
        sPosRefreshCnt = POS_REFRESH_CNT;
        PositionInfo_reviseInfo();
        return 0;
    }
}

/*
******************************************************************************
*	�� �� ��: PositionInfo_get
*	����˵��: λ����Ϣ��ȡ������Ϣ
*	��    ��: ��
*	�� �� ֵ: ��
******************************************************************************
*/
int32_t PositionInfo_get(POSITION_INFO_STRUCT *pPosInfo)
{
    *pPosInfo = sPositionInfo;

    return 0;
}
