#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "mod_transmit.h"
#include "mbedtls/md5.h"
#include "ff.h"

#define DIR_NAME_FIRMWARE   "firmware"      //����̼����ļ���
#define DIR_NAME_MAP        "map"           //�����ͼ���ļ���

#define FILE_NAME_TEMP      "temp.dat"      //��ʱ�ļ���
#define FILE_NAME_FIRMWARE  "update.bin"    //�̼��ļ���
#define FILE_NAME_MD5       "update.md5"    //����̼�MD5У����ļ�
#define FILE_NAME_MAP       "map.js"        //������ͼĬ���ļ���

typedef enum {
    TRANSMIT_REPLY_NONE = 0,
    TRANSMIT_REPLY_READY = 1,               //�ȴ�����֡����
    TRANSMIT_REPLY_COMPLETE = 2,            //����ļ�����
    TRANSMIT_REPLY_LOST_FRAME = 3,          //������֡��ʧ
    TRANSMIT_REPLY_RUNNING = 4,             //�������������У�������������
    TRANSMIT_REPLY_STORAGE_ERR = 5,         //�洢������
    TRANSMIT_REPLY_MD5_ERR = 6,             //�ļ���MD5У�����
    TRANSMIT_REPLY_FORMAT_ERR = 7,          //����֡��ʽ����
} TRANSMIT_STATUS_FLAG;

typedef enum {
    FILE_TYPE_COMMON = 0,                   //������ͨ�ļ�
    FILE_TYPE_FIRMWARE,                     //����̼��ļ�
    FILE_TYPE_MAP                           //�����ͼ�ļ�
} FILE_TYPE_ENUM;

typedef struct {
    FILE_TYPE_ENUM filetype;
    uint32_t filesize;                      //�ļ���С
    uint16_t data_frame_max_content;        //ÿ������֡���������������
    uint16_t data_frame_cnt;                //�ļ��ܹ�Ҫ��ֳɶ��ٸ�����֡���д���
    uint8_t frameindex[128];                //һ��λ��ʾ���յ�һ������֡��
    uint8_t md5[16];
    char filename[64];
    FIL filobj;
    bool busy;
    uint32_t timeout;
    TRANSMIT_SEND_FUNC send;
} TransmitDataStruct_TypeDef;

TransmitDataStruct_TypeDef Transmit;

uint8_t transmit_checksum(uint8_t *data, int len)
{
    uint8_t sum = 0;
    for(int i = 0; i < len; ++i)
    {
        sum ^= data[i];
    }
    return sum;
}

void transmit_clear(void)
{
    f_close(&Transmit.filobj);
    
    Transmit.filetype = FILE_TYPE_COMMON;
    Transmit.filesize = 0;
    Transmit.data_frame_cnt = 0;
    Transmit.data_frame_max_content = 0;
    memset(&Transmit.frameindex, 0, sizeof(Transmit.frameindex));
    memset(&Transmit.md5, 0, sizeof(Transmit.md5));
    memset(&Transmit.filename, 0, sizeof(Transmit.filename));
    memset(&Transmit.filobj, 0, sizeof(Transmit.filobj));
    Transmit.busy = false;
    Transmit.timeout = 0;
    Transmit.send = NULL;
}

bool transmit_md5_check(FIL *f)
{
    mbedtls_md5_context ctx;
    uint8_t md5[16], buff[64];
    uint32_t br;
    
    mbedtls_md5_init(&ctx);
    mbedtls_md5_starts(&ctx);
    f_rewind(f);
    while(f_read(f, buff, sizeof(buff), &br) == FR_OK && br > 0)
    {
        mbedtls_md5_update(&ctx, buff, br);
    }
    mbedtls_md5_finish(&ctx, md5);
    mbedtls_md5_free(&ctx);
    return memcmp(Transmit.md5, md5, sizeof(md5)) == 0;
}

FRESULT transmit_save_md5(void)
{
    FIL f;
    UINT btw, bw;
    FRESULT res = FR_OK;
    char buff[64] = {0};
    snprintf(buff, sizeof(buff), "%s/%s", DIR_NAME_FIRMWARE, FILE_NAME_MD5);
    res = f_open(&f, buff, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
    for(int i = 0; i < sizeof(Transmit.md5); ++i)
    {
        btw = snprintf(buff, sizeof(buff),
                       ((i == sizeof(Transmit.md5)-1) ? "%hhx\r\n" : "%hhx,"),
                       Transmit.md5[i]);
        if((res = f_write(&f, buff, btw, &bw)) != FR_OK)
            return res;
    }
    res = f_close(&f);
    return res;
}

void transmit_reply(uint8_t flag, uint16_t *lostframe, uint16_t lost_frame_cnt)
{
    uint8_t buff[1024], *p_checksum, *p_tail;
    uint16_t maxcount, framelen;
    TransmitStatusFrame_TypeDef *frame = (TransmitStatusFrame_TypeDef *)buff; 
    
    //���㵱ǰbuff�ܷ�����ٶ�ʧ����֡��ƫ��ֵ
    maxcount = ((sizeof(buff)-sizeof(*frame)-sizeof(frame->lostframe)-2) / sizeof(frame->lostframe));
    if(lost_frame_cnt > maxcount)
    {
        lost_frame_cnt = maxcount;
    }
    
    frame->head = TRANSMIT_FRAME_HEAD;
    frame->type = TRANSMIT_FRAME_CMD + 1;
    frame->flag = flag;
    frame->lost_frame_cnt = htons(lost_frame_cnt);
    for(int i = 0; i < lost_frame_cnt; ++i)
    {
        (&frame->lostframe)[i] = htons(lostframe[i]);
    }
    p_checksum = (uint8_t *)(&frame->lostframe + lost_frame_cnt);
    p_tail = p_checksum + 1;
    framelen = p_tail - buff + 1;
    frame->length = htons(framelen);
    *p_checksum = transmit_checksum((uint8_t *)frame, framelen - 2);
    *p_tail = TRANSMIT_FRAME_TAIL;
    Transmit.send(buff, framelen);
}

void transmit_cmd_process(uint8_t *data, TRANSMIT_SEND_FUNC send)
{
    FRESULT res;
    TransmitCmdFrame_TypeDef *req = (TransmitCmdFrame_TypeDef *)data;
    
    Transmit.filetype = req->filetype;
    Transmit.filesize = ntohl(req->filesize);
    Transmit.data_frame_max_content = ntohs(req->data_frame_max_content);
    Transmit.data_frame_cnt = Transmit.filesize / Transmit.data_frame_max_content;
    if((Transmit.filesize % Transmit.data_frame_max_content) != 0)
    {
        Transmit.data_frame_cnt++;
    }
    memcpy(Transmit.md5, (uint8_t *)req->md5, sizeof(Transmit.md5));
    memcpy(Transmit.filename, (uint8_t *)&req->filename, req->file_name_len);
    res = f_open(&Transmit.filobj, FILE_NAME_TEMP, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
    Transmit.busy = true;
    Transmit.timeout = 0;
    Transmit.send = send;
    
    if(res != FR_OK)
    {
        transmit_clear();
        transmit_reply(TRANSMIT_REPLY_STORAGE_ERR, NULL, 0);
    }
    else 
    {
        transmit_reply(TRANSMIT_REPLY_READY, NULL, 0);
    }
}

void transmit_data_process(uint8_t *data)
{
#define MAX_WRITE_CNT 500
    UINT btw, bw;
    uint8_t *dataptr = NULL;
    TransmitDataFrame_TypeDef *req = (TransmitDataFrame_TypeDef *)data;
    int index = ntohs(req->frameindex) / 8;
    int offset = ntohs(req->frameindex) % 8;
    uint16_t len = ntohs(req->datalen);
    uint32_t seek = ntohs(req->frameindex) * Transmit.data_frame_max_content;

    Transmit.timeout = 0;
    Transmit.frameindex[index] |= 1<<offset;
    
    dataptr = &req->data;
    while(len > 0)
    {
        if(len > MAX_WRITE_CNT)
        {
            btw = MAX_WRITE_CNT;
        }
        else
        {
            btw = len;
        }
        
        f_lseek(&Transmit.filobj, seek);
        if(f_write(&Transmit.filobj, dataptr, btw, &bw) != FR_OK)
        {
            transmit_clear();
            transmit_reply(TRANSMIT_REPLY_STORAGE_ERR, NULL, 0);
            break;
        }
        len -= btw;
        seek += btw;
        dataptr += btw;
    }
}

void transmit_timeout(void)
{
    FRESULT res;
    bool end = false;
    char name[128] = {0};
    uint16_t lostFrameCnt = 0, lostFrame[100] = {0};
    for(int i = 0; i < sizeof(Transmit.frameindex) && !end; ++i)
    {
        for(int j = 0; j < 8 && !end; ++j)
        {
            if((Transmit.frameindex[i] & (1<<j)) == 0)
            {
                lostFrame[lostFrameCnt] = i*8 + j;
                lostFrameCnt++;
            }
            
            if(i*8 + j == Transmit.data_frame_cnt-1
                || lostFrameCnt == sizeof(lostFrame)/sizeof(lostFrame[0]))
            {
                end = true;
            }
        }
    }
    
    if(lostFrameCnt > 0)
    {
        Transmit.timeout = 0;
        transmit_reply(TRANSMIT_REPLY_LOST_FRAME, lostFrame, lostFrameCnt);
    }
    else
    {
        if(transmit_md5_check(&Transmit.filobj) == true)
        {
            if(Transmit.filetype == FILE_TYPE_FIRMWARE)
            {
                f_mkdir(DIR_NAME_FIRMWARE);
                snprintf(name, sizeof(name), "%s/%s", DIR_NAME_FIRMWARE, Transmit.filename);
            }
            else if(Transmit.filetype == FILE_TYPE_MAP)
            {
                f_mkdir(DIR_NAME_MAP);
                snprintf(name, sizeof(name), "%s/%s", DIR_NAME_MAP, Transmit.filename);
            }
            else
            {
                snprintf(name, sizeof(name), "%s", Transmit.filename);
            }

            f_close(&Transmit.filobj);
            f_unlink(name);
            res = f_rename(FILE_NAME_TEMP, name);
            if(res != FR_OK)
            {
                transmit_reply(TRANSMIT_REPLY_STORAGE_ERR, NULL, 0);
            }
            else
            {
                if(Transmit.filetype == FILE_TYPE_FIRMWARE && transmit_save_md5() != FR_OK)
                {
                    transmit_reply(TRANSMIT_REPLY_STORAGE_ERR, NULL, 0);
                }
                else
                {
                    transmit_reply(TRANSMIT_REPLY_COMPLETE, NULL, 0);
                }
            }
        }
        else
        {
            transmit_reply(TRANSMIT_REPLY_MD5_ERR, NULL, 0);
        }
        
        transmit_clear();
    }
}

void transmit_task_loop(void)
{
#define TRANSMIT_TIMEOUT_COUNT 400
#define TRANSMIT_REQUEST_LOST_TIMES 20
    
    //����20�ζ�ʧ�����ݺ���û������ļ���������Ϊ����ʧ�ܡ�
    static int request_lost_times = 0;
    
    if(Transmit.busy == true)
    {
        if(++Transmit.timeout == TRANSMIT_TIMEOUT_COUNT)
        {
            Transmit.timeout = 0;
            transmit_timeout();
            if(++request_lost_times == TRANSMIT_REQUEST_LOST_TIMES)
            {
                transmit_clear();
            }
        }
    }
    else
    {
        Transmit.timeout = 0;
        request_lost_times = 0;
    }
}

bool transmit_is_busy(void)
{
    return Transmit.busy;
}