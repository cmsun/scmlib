import sys
import time
import hashlib
import functools
from ctypes import *
from socket import *

frame_head = 0x20       #帧头
frame_tail = 0x88       #帧尾
frame_type_cmd = 0x20   #帧类型：命令帧
frame_type_data = 0x2A  #帧类型：数据帧

file_type_common = 0    #传输普通文件
file_type_firmware = 1  #传输固件文件
file_type_map = 2       #传输地图文件

transmit_reply_ready = 1        #接收方准备接收数据，发送方可以发送数据
transmit_reply_complete = 2     #数据接收完成
transmit_reply_lost_frame = 3   #有丢失的数据帧，请求重传丢失的数据帧
transmit_reply_running = 4      #设备正在运行，不要发送数据
transmit_reply_storage_err = 5  #存储器错误
transmit_reply_md5_err = 6      #MD5校验错误
transmit_reply_format = 7       #通信帧格式错误

frame_max_content = 900         #数据帧一次最大包含900个字节

robot_identity =  (c_ubyte * 9)(0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99) #设备ID

sock = None                         #UDP套接字
netaddr = ('192.168.3.20', 9000)    #WIFI板的UDP通信地址

def checksum(data):
    return functools.reduce(lambda x,y: x^y, data)

def show(data):
    for i in data:
        print('{:02x}'.format(i), end=' ')
    print('')

class TransmitCmdFrame_Base(BigEndianStructure):
    """
    文件传输的命令帧
    """
    _pack_=1
    _fields_=[
        ('head', c_ubyte),
        ('type', c_ubyte),
        ('length', c_uint16),
        ('indentity', c_ubyte * 9),
        ('filetype', c_ubyte),
        ('filesize', c_uint32),
        ('data_frame_max_content', c_uint16),
        ('md5', c_uint8 * 16),
        ('file_name_len', c_ubyte),
        ('filename', c_ubyte * 0)
        # ('checksum', c_ubyte),
        # ('tail', c_ubyte)
    ]

class TransmitStatuFrame_Base(BigEndianStructure):
    """
    文件传输的状态帧
    """
    _pack_=1
    _fields_=[
        ('head', c_ubyte),
        ('type', c_ubyte),
        ('length', c_uint16),
        ('indentity', c_ubyte * 9),
        ('flag', c_ubyte),
        ('lost_frame_cnt', c_uint16),
        ('lostframe', c_uint16 * 0),
        # ('checksum', c_ubyte),
        # ('tail', c_ubyte)
    ]

class TransmitDataFrame_Base(BigEndianStructure):
    """
    文件传输的数据帧
    """
    _pack_=1
    _fields_=[
        ('head', c_ubyte),
        ('type', c_ubyte),
        ('length', c_uint16),
        ('indentity', c_ubyte * 9),
        ('frameindex', c_uint16),
        ('datalen', c_uint16),
        ('data', c_uint8 * 0),
        # ('checksum', c_ubyte),
        # ('tail', c_ubyte)
    ]

def generate_cmd_frame(filetype, filedata, dstfilename):
    class TransmitCmdFrame(TransmitCmdFrame_Base):
        _fields_=[('filename', c_ubyte * len(dstfilename)),
                  ('checksum', c_ubyte),
                  ('tail', c_ubyte)]
    frame = TransmitCmdFrame()
    frame.head = frame_head
    frame.type = frame_type_cmd
    frame.length = sizeof(frame)
    frame.indentity = robot_identity
    frame.filetype = filetype
    frame.filesize = len(filedata)
    frame.data_frame_max_content = frame_max_content
    frame.md5 = (c_ubyte * 16)(* hashlib.md5(filedata).digest())
    frame.file_name_len = len(dstfilename)
    frame.filename = (c_ubyte * len(dstfilename))(* dstfilename.encode())
    frame.checksum = checksum(string_at(addressof(frame), sizeof(frame)-2))
    frame.tail = frame_tail
    return frame

def generate_statu_frame(data):
    frame = TransmitStatuFrame_Base()
    memmove(addressof(frame), data, sizeof(TransmitStatuFrame_Base))
    class TransmitStatuFrame(TransmitStatuFrame_Base):
        _fields_=[('lostframe', c_uint16 * frame.lost_frame_cnt),
                  ('checksum', c_ubyte),
                  ('tail', c_ubyte)]
    if frame.lost_frame_cnt > 0:
        frame = TransmitStatuFrame()
        memmove(addressof(frame), data, sizeof(TransmitStatuFrame))
    return frame

def generate_data_frame(frameindex, data2send):
    class TransmitDataFrame(TransmitDataFrame_Base):
        _fields_=[('data', c_ubyte * len(data2send)),
                  ('checksum', c_ubyte),
                  ('tail', c_ubyte)]
    frame = TransmitDataFrame()
    frame.head = frame_head
    frame.type = frame_type_data
    frame.length = sizeof(frame)
    frame.indentity = robot_identity
    frame.frameindex = frameindex
    frame.datalen = len(data2send)
    frame.data = (c_ubyte * len(data2send))(* data2send)
    frame.checksum = checksum(string_at(addressof(frame), sizeof(frame)-2))
    frame.tail = frame_tail
    return frame

def send_frame(frame):
    stream = string_at(addressof(frame), sizeof(frame))
    sock.sendto(stream, netaddr)
    show(stream)

def read_frame(timeout):
    frame = None
    sock.settimeout(timeout)
    try:
        data, addr = sock.recvfrom(1024)
        judgelen = (len(data) >= sizeof(TransmitStatuFrame_Base)+2 and len(data) == data[2]<<8|data[3])
        judgeformat = (judgelen and data[0] == frame_head and data[-1] == frame_tail)
        judgechecksum = (judgeformat and data[-2] == checksum(data[:-2]))
        if judgechecksum == True and data[1] == frame_type_cmd+1:
            frame = generate_statu_frame(data)
        for i in filter(lambda x: not x[0], zip((judgelen, judgeformat, judgechecksum),
                                                ("Length error!", "Format error!", "Checksum error!"))):
            print(i[1])
        print(addr, end = ' : ')
        show(data)
    except:
        pass
    return frame

def transmit_file(srcfilename, dstfilename):
    global sock
    sock = socket(AF_INET, SOCK_DGRAM)
    sock.setblocking(True)
    sock.settimeout(3)

    if srcfilename.endswith('.bin'):
        filetype = file_type_firmware
    elif srcfilename.endswith('.map'):
        filetype = file_type_map
    else:
        filetype = file_type_common
    
    filedata = open(srcfilename, 'rb').read()
    datalist = [filedata[i:i+frame_max_content] for i in range(0, len(filedata), frame_max_content)]
    
    frame = generate_cmd_frame(filetype, filedata, dstfilename)
    send_frame(frame)
    ack = read_frame(1)
    if ack == None:
        print("Timed out!")
        return False
    elif ack.flag == transmit_reply_storage_err:
        print("SD card error!")
        return False

    for i in range(len(datalist)):
        frame = generate_data_frame(i, datalist[i])
        send_frame(frame)
        time.sleep(0.1)

    t = time.time()
    while time.time() - t < 180.0:
        frame = read_frame(0.5)
        if frame != None:
            if frame.flag == transmit_reply_complete:
                print("Transmit complete!")
                return True
            elif frame.flag == transmit_reply_storage_err:
                print("SD card error!")
                return False
            elif frame.flag == transmit_reply_md5_err:
                print("MD5 error!")
                return False
            elif frame.flag == transmit_reply_lost_frame and frame.lost_frame_cnt > 0:
                for i in frame.lostframe:
                    frame = generate_data_frame(i, datalist[i])
                    send_frame(frame)
                    time.sleep(0.1)
    print("Transmit timed out!")
    return False

if __name__ == "__main__":
    src = sys.argv[1]
    if src.endswith('.map'):
        dst = src.split('.')[0]
    else:
        dst = src
    transmit_file(src, dst)