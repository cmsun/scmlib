#ifndef _MOD_TRANSMIT_H_
#define _MOD_TRANSMIT_H_

#include <stdint.h>
#include <stdbool.h>

#define TRANSMIT_FRAME_HEAD 0x20
#define TRANSMIT_FRAME_TAIL 0x88
#define TRANSMIT_FRAME_CMD  0x20
#define TRANSMIT_FRAME_DATA 0x2A

typedef uint16_t (* TRANSMIT_SEND_FUNC)(uint8_t *, uint16_t); //�ļ�������ʹ�õ�ͨ�Ŷ˿ڵķ��ͺ���

#pragma pack(1)

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t identity[9];
    uint8_t filetype;
    uint32_t filesize;
    uint16_t data_frame_max_content;
    uint8_t md5[16];
    uint8_t file_name_len;
    uint8_t filename;
} TransmitCmdFrame_TypeDef;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t identity[9];
    uint8_t flag;
    uint16_t lost_frame_cnt;
    uint16_t lostframe;
} TransmitStatusFrame_TypeDef;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t identity[9];
    uint16_t frameindex;
    uint16_t datalen;
    uint8_t data;
} TransmitDataFrame_TypeDef;

#pragma pack()

void transmit_cmd_process(uint8_t *data, TRANSMIT_SEND_FUNC send);
void transmit_data_process(uint8_t *data);
void transmit_task_loop(void);
bool transmit_is_busy(void);

#endif
