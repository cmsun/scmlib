/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

#include "stm32f4xx_ll_usart.h"
#include "stm32f4xx_ll_rcc.h"
#include "stm32f4xx_ll_bus.h"
#include "stm32f4xx_ll_cortex.h"
#include "stm32f4xx_ll_system.h"
#include "stm32f4xx_ll_utils.h"
#include "stm32f4xx_ll_pwr.h"
#include "stm32f4xx_ll_gpio.h"
#include "stm32f4xx_ll_dma.h"

#include "stm32f4xx_ll_exti.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define Cellular_RELOAD_Pin GPIO_PIN_2
#define Cellular_RELOAD_GPIO_Port GPIOE
#define Cellular_PWR_CTRL_Pin GPIO_PIN_3
#define Cellular_PWR_CTRL_GPIO_Port GPIOE
#define Cellular_POWER_KEY_Pin GPIO_PIN_4
#define Cellular_POWER_KEY_GPIO_Port GPIOE
#define Cellular_RESET_Pin GPIO_PIN_5
#define Cellular_RESET_GPIO_Port GPIOE
#define Cellular_WORK_Pin GPIO_PIN_6
#define Cellular_WORK_GPIO_Port GPIOE
#define BatChargeCurrent_PC0_Pin GPIO_PIN_0
#define BatChargeCurrent_PC0_GPIO_Port GPIOC
#define CabinetTemp_Pin GPIO_PIN_1
#define CabinetTemp_GPIO_Port GPIOC
#define BatVoltage_PC2_Pin GPIO_PIN_2
#define BatVoltage_PC2_GPIO_Port GPIOC
#define BatDischargeCurrent_PC3_Pin GPIO_PIN_3
#define BatDischargeCurrent_PC3_GPIO_Port GPIOC
#define Cellular_UART4_TX_Pin GPIO_PIN_0
#define Cellular_UART4_TX_GPIO_Port GPIOA
#define Cellular_UART4_RX_Pin GPIO_PIN_1
#define Cellular_UART4_RX_GPIO_Port GPIOA
#define SERVO_USART2_TX_Pin GPIO_PIN_2
#define SERVO_USART2_TX_GPIO_Port GPIOA
#define SERVO_USART2_RX_Pin GPIO_PIN_3
#define SERVO_USART2_RX_GPIO_Port GPIOA
#define EEPROM_SPI1_CS_Pin GPIO_PIN_4
#define EEPROM_SPI1_CS_GPIO_Port GPIOA
#define EEPROM_SPI1_SCK_Pin GPIO_PIN_5
#define EEPROM_SPI1_SCK_GPIO_Port GPIOA
#define EEPROM_SPI1_MISO_Pin GPIO_PIN_6
#define EEPROM_SPI1_MISO_GPIO_Port GPIOA
#define EEPROM_SPI1_MOSI_Pin GPIO_PIN_7
#define EEPROM_SPI1_MOSI_GPIO_Port GPIOA
#define VREF3V_ADC1_IN14_Pin GPIO_PIN_4
#define VREF3V_ADC1_IN14_GPIO_Port GPIOC
#define BRUSH_RS485_DE_Pin GPIO_PIN_5
#define BRUSH_RS485_DE_GPIO_Port GPIOC
#define MPU6515_2ND_SPI2_CS_Pin GPIO_PIN_0
#define MPU6515_2ND_SPI2_CS_GPIO_Port GPIOB
#define SERVO_RS485_DE_Pin GPIO_PIN_1
#define SERVO_RS485_DE_GPIO_Port GPIOB
#define Cellular_NET_Pin GPIO_PIN_7
#define Cellular_NET_GPIO_Port GPIOE
#define APEXIN0_Pin GPIO_PIN_8
#define APEXIN0_GPIO_Port GPIOE
#define APEXIN1_Pin GPIO_PIN_9
#define APEXIN1_GPIO_Port GPIOE
#define APEXIN2_Pin GPIO_PIN_10
#define APEXIN2_GPIO_Port GPIOE
#define APEXIN3_Pin GPIO_PIN_11
#define APEXIN3_GPIO_Port GPIOE
#define APEXIN4_Pin GPIO_PIN_12
#define APEXIN4_GPIO_Port GPIOE
#define WIFI_USART3_TX_Pin GPIO_PIN_10
#define WIFI_USART3_TX_GPIO_Port GPIOB
#define WIFI_USART3_RX_Pin GPIO_PIN_11
#define WIFI_USART3_RX_GPIO_Port GPIOB
#define MAX31865_1ST_SPI_CS_Pin GPIO_PIN_12
#define MAX31865_1ST_SPI_CS_GPIO_Port GPIOB
#define MAX31865_SPI2_SCK_Pin GPIO_PIN_13
#define MAX31865_SPI2_SCK_GPIO_Port GPIOB
#define MAX31865_SPI2_MISO_Pin GPIO_PIN_14
#define MAX31865_SPI2_MISO_GPIO_Port GPIOB
#define MAX31865_SPI2_MOSI_Pin GPIO_PIN_15
#define MAX31865_SPI2_MOSI_GPIO_Port GPIOB
#define APEXOUT7_Pin GPIO_PIN_8
#define APEXOUT7_GPIO_Port GPIOD
#define APEXOUT6_POWER_OFF_Pin GPIO_PIN_9
#define APEXOUT6_POWER_OFF_GPIO_Port GPIOD
#define APEXOUT5_Pin GPIO_PIN_10
#define APEXOUT5_GPIO_Port GPIOD
#define APEXOUT4_Pin GPIO_PIN_11
#define APEXOUT4_GPIO_Port GPIOD
#define APEXOUT3_SteeringGear_TIM4_CH1_Pin GPIO_PIN_12
#define APEXOUT3_SteeringGear_TIM4_CH1_GPIO_Port GPIOD
#define APEXOUT2_Pin GPIO_PIN_13
#define APEXOUT2_GPIO_Port GPIOD
#define APEXOUT1_SteeringGear_TIM4_CH3_Pin GPIO_PIN_14
#define APEXOUT1_SteeringGear_TIM4_CH3_GPIO_Port GPIOD
#define APEXOUT0_Pin GPIO_PIN_15
#define APEXOUT0_GPIO_Port GPIOD
#define BRUSH_USART6_TX_Pin GPIO_PIN_6
#define BRUSH_USART6_TX_GPIO_Port GPIOC
#define BRUSH_USART6_RX_Pin GPIO_PIN_7
#define BRUSH_USART6_RX_GPIO_Port GPIOC
#define RTK_PWR_CTRL_Pin GPIO_PIN_8
#define RTK_PWR_CTRL_GPIO_Port GPIOA
#define RTK_USART1_TX_Pin GPIO_PIN_9
#define RTK_USART1_TX_GPIO_Port GPIOA
#define RTK_USART1_RX_Pin GPIO_PIN_10
#define RTK_USART1_RX_GPIO_Port GPIOA
#define LED1_Pin GPIO_PIN_3
#define LED1_GPIO_Port GPIOD
#define LED0_Pin GPIO_PIN_4
#define LED0_GPIO_Port GPIOD
#define WIFI_PWR_CTRL_Pin GPIO_PIN_5
#define WIFI_PWR_CTRL_GPIO_Port GPIOD
#define Cellular_LINKA_Pin GPIO_PIN_6
#define Cellular_LINKA_GPIO_Port GPIOD
#define Cellular_LINKB_Pin GPIO_PIN_7
#define Cellular_LINKB_GPIO_Port GPIOD
#define I2C1_SCL_Pin GPIO_PIN_6
#define I2C1_SCL_GPIO_Port GPIOB
#define I2C1_SDA_Pin GPIO_PIN_7
#define I2C1_SDA_GPIO_Port GPIOB
#define WDI_Pin GPIO_PIN_0
#define WDI_GPIO_Port GPIOE
#define LED2_Pin GPIO_PIN_1
#define LED2_GPIO_Port GPIOE
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
