#ifndef _MODBUSDEVICES_H_
#define _MODBUSDEVICES_H_

#include <stdint.h>
#include <stdbool.h>
#include "sensor.h"

#define MODBUS_CMD_LENGTH 8

typedef enum {
    STATION_MAG = 1,
    STATION_BRUSH,
    STATION_BATTERY,
    STATION_END
} ModBusStation_Enum;

typedef enum {
    BRUSH_CTRL_NONE,
    BRUSH_CTRL_RUN,
    BRUSH_CTRL_STOP
} BRUSH_CTRL_ENUM;

//����һ����������������Ϊ������ModbusStation_TypeDef�ṹ�������δ�����ModbusMaster_TypeDef�ṹ�塣
typedef struct ModbusMaster_TypeDef_ ModbusMaster_TypeDef;

typedef struct {
    const uint32_t  PERIOD;
    uint32_t        period;
    bool            active;
    uint8_t         failed_cnt;
    void            (*master_query)(ModbusMaster_TypeDef *master);
    void            (*slave_ack)(uint8_t *data, uint16_t len);
    void            (*error_handle)(void);
} ModbusStation_TypeDef;

typedef struct {
    ModbusStation_TypeDef station;
    
    uint8_t cmd[MODBUS_CMD_LENGTH];
    uint8_t value;
} MagPrivatData_TypeDef;

typedef struct {
    ModbusStation_TypeDef station;
    
    uint8_t enable[MODBUS_CMD_LENGTH];
    uint8_t disable[MODBUS_CMD_LENGTH];
    uint8_t readregs[MODBUS_CMD_LENGTH];
    uint8_t stop[MODBUS_CMD_LENGTH];
    uint8_t setrpm[MODBUS_CMD_LENGTH];
    
    #define REG(number) (number-200) //����Ҫ��ȡ�Ĵ���P203��ֵ����brush_register[REG(203)]
    uint8_t brush_register[25];
    bool register_update;
    
    BRUSH_CTRL_ENUM ctrl_cmd;
    int16_t rpm_set;
} BrushPrivatData_TypeDef;

typedef struct {
    ModbusStation_TypeDef station;
    
    uint8_t cmd[MODBUS_CMD_LENGTH];
    
    int32_t voltage;
    int32_t current;
    int32_t remain_power;
    int16_t cells_voltage[16];
    int32_t temprature1;
    int32_t temprature2;
    int32_t capacity;
    uint8_t SOC;
} BatteryPrivatData_TypeDef;

struct ModbusMaster_TypeDef_{
    ModbusStation_TypeDef   *objects_table[STATION_END-1];
    uint8_t                 sequence;
    bool                    bus_busy;
    uint32_t                interval;
    uint32_t                ack_timeout;
};

//--------------------------------------------------------

typedef struct {
    const uint8_t   cmd[MODBUS_CMD_LENGTH];
    uint32_t        period;
    bool            active;
    uint8_t         failed_cnt;
    uint8_t         info;
} MagneticSensor_TypeDef;

typedef struct {
    uint16_t P200;
    uint16_t P201;
    uint16_t P202;
    uint16_t P203;
    uint16_t P204;
    uint16_t P205;
    uint16_t P206;
    uint16_t P207;
    uint16_t P208;
    uint16_t P209;
    uint16_t P210;
    uint16_t P211;
    uint16_t P212;
    uint16_t P213;
    uint16_t P214;
    uint16_t P215;
    uint16_t P216;
    uint16_t P217;
    uint16_t P218;
    uint16_t P219;
    uint16_t P220;
    uint16_t P221;
    uint16_t P222;
    uint16_t P223;
    uint16_t P224;
} BrushRegisters_TypeDef;

typedef struct {
    struct {
        const uint8_t       enable[MODBUS_CMD_LENGTH];
        const uint8_t       disable[MODBUS_CMD_LENGTH];
        const uint8_t       readregs[MODBUS_CMD_LENGTH];
        uint8_t             stop[MODBUS_CMD_LENGTH];
        uint8_t             setrpm[MODBUS_CMD_LENGTH];
    } cmd;
    uint32_t                period;
    bool                    active;
    uint16_t                failed_cnt;
    
    BRUSH_CTRL_ENUM         ctrl;
    int16_t                 rpm;
    BrushRegisters_TypeDef  regs;
    bool regs_update;
} BrushCtrl_TypeDef;

typedef struct {
    int16_t voltage;
    int16_t current;
    int16_t remain_power;
    int16_t cells_voltage[16];
    int16_t temprature1;
    int16_t temprature2;
    int16_t capacity;
    uint16_t SOC;
} BatteryBMSInfoRaw_TypeDef;

typedef struct {
    int32_t voltage;
    int32_t current;
    int32_t remain_power;
    int16_t cells_voltage[16];
    int32_t temprature1;
    int32_t temprature2;
    int32_t capacity;
    uint8_t SOC;
} BatteryBMSInfo_TypeDef;

typedef struct {
    uint8_t                 cmd[MODBUS_CMD_LENGTH];
    uint32_t                period;
    bool                    active;
    uint8_t                 failed_cnt;
    BatteryBMSInfo_TypeDef  info;
} BatteryBMS_TypeDef;

typedef struct {
    uint8_t cmd[MODBUS_CMD_LENGTH];
    uint32_t period;
    bool active;
    uint8_t failed_cnt;
    
    uint16_t distance[4];
    struct
    {
        SENSOR_STATE left_front;
        SENSOR_STATE right_front;
        SENSOR_STATE left_rear;
        SENSOR_STATE right_rear;
    } state;
} Radar_TypeDef;

typedef struct {
    MagneticSensor_TypeDef  magnetic;
    BrushCtrl_TypeDef       brush;
    BatteryBMS_TypeDef      battery;
    Radar_TypeDef           radar;
    uint8_t                 station_code;
    bool                    wait_ack;
    uint32_t                ack_timeout;
    uint32_t                bus_release_delay;
} ModbusDevices_TypeDef;

void modbusdevs_init(void);
void modbusdevs_task(void);
uint8_t magnetic_info(void);
void brush_set_rpm(int16_t rpm);
void brush_stop(void);
bool brush_is_running(void);
void battery_info(BatteryBMSInfo_TypeDef *info);
SENSOR_STATE radar_left_front(void);
SENSOR_STATE radar_left_rear(void);
SENSOR_STATE radar_right_front(void);
SENSOR_STATE radar_right_rear(void);

#endif
