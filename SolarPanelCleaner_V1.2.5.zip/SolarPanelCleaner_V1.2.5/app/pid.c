#include "pid.h"
#include "utility.h"

void pid_init(PID_TypeDef *pid)
{
    pid->Kp = PID_DEFAULT_KP;
    pid->Ki = PID_DEFAULT_KI;
    pid->Kd = PID_DEFAULT_KD;
    pid->biase = 0;
    pid->intergral = 0;
    pid->output_min = PID_DEFAULT_MIN;
    pid->output_max = PID_DEFAULT_MAX;
    pid->intergral_min = -PID_INTERGRAL_RANGE;
    pid->intergral_max = PID_INTERGRAL_RANGE;
}

void pid_set_param(PID_TypeDef *pid, float p, float i, float d)
{
    pid->Kp = p;
    pid->Ki = i;
    pid->Kd = d;
}

void pid_set_output_limit(PID_TypeDef *pid, float min, float max)
{
    pid->output_min = min;
    pid->output_max = max;
}

void pid_set_intergral_limit(PID_TypeDef *pid, float min, float max)
{
    pid->intergral_min = min;
    pid->intergral_max = max;
}

void pid_reset(PID_TypeDef *pid)
{
    pid->biase = 0;
    pid->intergral = 0;
}

float pid_compute(PID_TypeDef *pid, float setpoint, float input)
{
    float output;
    float currbiase;
    
    currbiase = setpoint - input;
    pid->intergral += currbiase;
    output = pid->Kp*currbiase + pid->Ki*pid->intergral + pid->Kd*(currbiase - pid->biase);
    pid->biase = currbiase;
    
    output = range(output, pid->output_min, pid->output_max);
    
    //���ƻ��ֵ���������ֹ����ϵͳ������������¹��Ȼ��֣�����ϵͳ���ƿ��Ʋ������������ø����ء�
    pid->intergral = range(pid->intergral, pid->intergral_min, pid->intergral_max);
    
    return output;
}