#ifndef _TEMPERATURE_H_
#define _TEMPERATURE_H_

void temp_init(void);
void temp_task(void);
float temp_battery(void);
float temp_cabinet(void);

#endif