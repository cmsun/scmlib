#ifndef _LOG_H_
#define _LOG_H_

#include <stdint.h>

void log_init(void);
void log_task(void);

void log_debug_write(const uint8_t *data, uint16_t len);
void log_debug_printf(const char *fmt, ...);
void log_rtk_write(const uint8_t *data, uint16_t len);
void log_rtk_printf(const char *fmt, ...);

#endif