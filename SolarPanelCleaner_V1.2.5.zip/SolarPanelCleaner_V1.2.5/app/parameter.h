#ifndef _PARAMETER_H_
#define _PARAMETER_H_

#include <stdint.h>

#define VERSION_LENGTH          3
#define BUILD_DATE_LENGTH       4
#define ROBOT_ID_LENGTH         9

#define RTC_PARAM_MAGIC_NUMBER  0x1122

#pragma pack(1)
typedef union
{
    volatile uint32_t reg[20];
    struct
    {
        //每个成员都必须是4字节的整数倍，否则会读写数据出错，因为RTC备份寄存器不能按字节访问。
        volatile uint32_t   magic;
        volatile uint32_t   date;
        volatile float      dayly_mileage;
        volatile float      dayly_work_time;
        volatile double     mileage_records;
        volatile double     work_time_records;
        volatile float      battery_power;
    } param;
} RtcBpkParam_TypeDef;
#pragma pack()

typedef union {
    uint32_t value;
    struct {
        uint32_t limit_left_front : 1;
        uint32_t limit_right_front : 1;
        uint32_t limit_left_rear : 1;
        uint32_t limit_right_rear : 1;
        uint32_t magnetic : 1;
        uint32_t battery_temp : 1;
        uint32_t cabinet_temp : 1;
    } bit;
} Sensor_mask;

typedef struct {
    uint8_t firmware_version[VERSION_LENGTH];   //固件版本号
    uint8_t build_date[BUILD_DATE_LENGTH];      //固件编译日期
    uint8_t robot_id[ROBOT_ID_LENGTH];          //机器人ID
    float raduction_ratio;                      //电机减速比。假如数值是20，则减速比为20:1。
    int16_t brush_speed_low;                    //毛刷低档速度，单位：RPM
    int16_t brush_speed_high;                   //毛刷高档速度，单位：RPM
    Sensor_mask sensor_mask;                    //屏蔽传感器
    uint8_t force_charge;                       //0:暂停、待机和急停时不打开充电继电器  1:暂停、待机和急停时强制打开充电继电器
    uint32_t over_current1;                     //过流保护值1，持续3秒钟断电。单位：毫安
    uint32_t over_current2;                     //过流保护值1，持续100毫秒钟断电。单位：毫安
    uint32_t over_current3;                     //过流保护值1，马上断电。单位：毫安
    uint32_t blocking_linear_biase;             //机器受阻，直线偏差，单位：厘米
    uint32_t blocking_angle_biase;              //机器受阻，角度偏差，单位：度
    uint32_t battery_capacity;                  //电池容量，单位：毫安时
    uint8_t homeward_soc;                       //机器人返航电量
    float lowpower_voltage;                     //当电压低于lowpower_voltage时，持续lowpower_trigger_time时间，就会触发低电量返航。
    uint8_t lowpower_trigger_time;              //当电压低于lowpower_voltage时，持续lowpower_trigger_time时间，就会触发低电量返航。
    uint8_t writeFlag;
    uint8_t reserve;
	uint16_t checksum;
} RobotParam_TypeDef;

extern RtcBpkParam_TypeDef *BpkParam;
extern RobotParam_TypeDef RobotParam;

void param_init(void);
void param_set_limit(RobotParam_TypeDef *param);
void com_parse_build_date(RobotParam_TypeDef *param);
void param_read(RobotParam_TypeDef *param);
void param_write(RobotParam_TypeDef *param);
    
    
#endif

