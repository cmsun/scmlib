#include <string.h>
#include "map.h"
#include "utility.h"

bool convert = false;
char name[] = "92675878";

bool read_blocks = false;
int block_index = 0;
NavigateBlock_TypeDef blocks[17];

bool read_cruises = false;
int cruise_index = 0;
NavigatePoint_TypeDef cruises[10];

bool read_block_cruises =  false;
int cruise_block_num = 1;
int cruise_index_from_block = 0;
NavigatePoint_TypeDef block_cruises[10];

bool read_homewards = false;
int block_number = 0;
int homeward_index = 0;
NavigatePoint_TypeDef homewards[10];

bool read_local_block = false;
GPS_Point_TypeDef gps_point = {28.1198459943726, 112.990533265242};
NavigateBlock_TypeDef local_block;
int local_block_num = -1;

bool cacl_angle = false;
GPS_Point_TypeDef a = {28.1198452203333, 112.990554200333};
GPS_Point_TypeDef b = {28.119843084, 112.990542441833};
GPS_Point_TypeDef c = {28.1198517786666, 112.990540074833};
GPS_Point_TypeDef d = {28.1198539104999, 112.990552058};
GPS_Point_TypeDef e = {(28.1198452203333+28.1198517786666)/2, (112.990554200333+112.990540074833)/2};
Vector_TypeDef ab, bc, cd, da, ae;
double angle_abbc = -1, angle_abcd = -1, angle_abda = -1, angle_abae;

bool cacl_two_points_bearing = false;
double bearing_ab = -1, bearing_bc = -1;

bool test_vertical_vector = false;
Vector_TypeDef vv;
double angle_abvv = -1;

bool test_azimuth_unit_vector = false;
Vector_TypeDef unit_v;
double angle_ab_v;

void map_test_task(void)
{
    uint32_t period = 0;
    int cnt = 0;
    
    if(millis()  - period >= 100)
    {
        if(convert == true)
        {
            convert = false;
            map_json_convert_binary(name);
        }
        
        if(read_blocks == true)
        {
            read_blocks = false;
            map_read_block(&RobotMap, block_index, blocks, count(blocks));
        }
        
        if(read_cruises == true)
        {
            read_cruises = false;
            map_read_cruise(&RobotMap, cruise_index, cruises, count(cruises));
        }
        
        if(read_block_cruises == true)
        {
            read_block_cruises = false;
            map_read_block_cruise(&RobotMap, cruise_block_num, cruise_index_from_block, block_cruises, count(block_cruises));
        }
        
        if(read_homewards == true)
        {
            read_homewards = false;
            cnt = map_read_homeward(&RobotMap, block_number, homeward_index, homewards, count(homewards));
            if(cnt == 0)
            {
                //memset(homewards, 0, sizeof(homewards));
            }
        }
        
        if(read_local_block == true)
        {
            read_local_block = false;
            local_block_num = map_get_local_block(&gps_point, &local_block);
        }
        
        if(cacl_angle == true)
        {
            cacl_angle = false;
            gps_vector_generate(&a, &b, &ab);
            gps_vector_generate(&b, &c, &bc);
            gps_vector_generate(&c, &d, &cd);
            gps_vector_generate(&d, &a, &da);
            gps_vector_generate(&a, &e, &ae);
            angle_abbc = vector_angle(&ab, &bc);
            angle_abcd = vector_angle(&ab, &cd);
            angle_abda = vector_angle(&ab, &da);
            angle_abae = vector_angle(&ab, &ae);
        }
        
        if(cacl_two_points_bearing == true)
        {
            cacl_two_points_bearing = false;
            bearing_ab = gps_two_points_bearing(&a, &b);
            bearing_bc = gps_two_points_bearing(&b, &c);
        }
        
        if(test_vertical_vector == true)
        {
            test_vertical_vector = false;
            gps_vector_generate(&a, &b, &ab);
            gps_get_vertical_vector(&a, &b, &c, &vv);
            angle_abvv = vector_angle(&ab, &vv);
        }
        
        if(test_azimuth_unit_vector == true)
        {
            test_azimuth_unit_vector = false;
            gps_vector_generate(&a, &b, &ab);
            get_azimuth_identity_vector(50, &unit_v);
            angle_ab_v = vector_angle(&ab, &unit_v);
        }
    }
}