#ifndef _PID_H_
#define _PID_H_

#define PID_DEFAULT_KP      (1E-1f)
#define PID_DEFAULT_KI      (1E-10f)
#define PID_DEFAULT_KD      0
#define PID_DEFAULT_MIN     (-0.6f)
#define PID_DEFAULT_MAX     (+0.6f)
#define PID_INTERGRAL_RANGE (150.0f)

typedef struct {
    float Kp;
    float Ki;
    float Kd;
    float output_min;
    float output_max;
    float biase;
    float intergral;
    float intergral_min;
    float intergral_max;
} PID_TypeDef;

void pid_init(PID_TypeDef *pid);
void pid_set_param(PID_TypeDef *pid, float p, float i, float d);
void pid_set_output_limit(PID_TypeDef *pid, float min, float max);
void pid_set_intergral_limit(PID_TypeDef *pid, float min, float max);
void pid_reset(PID_TypeDef *pid);
float pid_compute(PID_TypeDef *pid, float setpoint, float input);

#endif