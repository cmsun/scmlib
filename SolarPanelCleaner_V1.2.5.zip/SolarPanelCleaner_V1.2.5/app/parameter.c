#include <stdio.h>
#include <string.h>
#include <math.h>
#include "parameter.h"
#include "rtc.h"
#include "utility.h"
#include "ff.h"
#include "safety.h"
#include "w25qxx.h"

#define PARAM_FILE_PATH "0:/param.dat"
FIL param_f;
RtcBpkParam_TypeDef *BpkParam;
RobotParam_TypeDef RobotParam;

static const RobotParam_TypeDef RobotParamDefalt = 
{
    .firmware_version        = {1, 2, 5},
    .build_date              = {0},
    .robot_id                = {0x18, 0x91, 0x55, 0x20, 0x09, 0x21, 0x00, 0x02, 0x09},
    .raduction_ratio         = 32.0f,               //电机减速比。假如数值是20，则减速比为20:1。
    .brush_speed_low         = -1000,               //毛刷低档速度，单位：RPM
    .brush_speed_high        = -2500,               //毛刷高档速度，单位：RPM
    .sensor_mask             = {.bit.magnetic = 1}, //屏蔽传感器
    .force_charge            = 0,                   //0:暂停、待机和急停时不打开充电继电器  1:暂停、待机和急停时强制打开充电继电器
    .over_current1           = 10000,               //过流保护值1，持续3秒钟断电。单位：毫安
    .over_current2           = 15000,               //过流保护值2，持续100毫秒钟断电。单位：毫安
    .over_current3           = 20000,               //过流保护值3，马上断电。单位：毫安
    .blocking_linear_biase   = 10000,               //机器受阻，直线偏差，单位：厘米
    .blocking_angle_biase    = 1080,                //机器受阻，角度偏差，单位：度
    .battery_capacity        = 12000,               //电池容量，单位：毫安时
    .homeward_soc            = 28,                  //机器人返航电量
    .lowpower_voltage        = 24.5,                //触发低电量的电压，单位：伏
    .lowpower_trigger_time   = 10,                  //低电压触发低电量的持续时间，单位：秒
};

void param_set_limit(RobotParam_TypeDef *param)
{
    param->raduction_ratio = range(param->raduction_ratio, 1, 100);
    param->brush_speed_low = range(param->brush_speed_low, -3000, 3000);
    param->brush_speed_high = range(param->brush_speed_high, -3000, 3000);
    param->force_charge = range(param->force_charge, 0, 1);
    param->over_current1 = range(param->over_current1, 1000, 30000);
    param->over_current2 = range(param->over_current2, 1000, 30000);
    param->over_current3 = range(param->over_current3, 1000, 30000);
    param->blocking_linear_biase = range(param->blocking_linear_biase, 10, 10000);
    param->blocking_angle_biase = range(param->blocking_angle_biase, 10, 360*3);
    param->battery_capacity = range(param->battery_capacity, 10000, 50000);
    param->homeward_soc = range(param->homeward_soc, 10, 90);
    param->lowpower_voltage = range(param->lowpower_voltage, 20.0f, 26.0f);
    param->lowpower_trigger_time = range(param->lowpower_trigger_time, 1, 60);
}

//parameter.c文件必须每次都编译。设置方法为：鼠标右键点击左边窗口上的源文件，
//然后点击 Options for file -> properties -> Always Build 选项让其颜色变深。
//前两个字节表示年（网络字节序），第三个字节表示月份，第四个字节表示日
void parse_build_date(RobotParam_TypeDef *param)
{
    uint16_t year, month, day;
    const char *months[] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    char monthstr[4];
    
    sscanf(__DATE__, "%3s %2hd %4hd", monthstr, &day, &year);
    for(month = 0; month < 12; ++month)
    {
        if(strcmp(monthstr, months[month]) == 0)
            break;
    }
    param->build_date[0] = year >> 8;
    param->build_date[1] = year & 0xff;
    param->build_date[2] = month + 1;
    param->build_date[3] = day;
}

void param_init(void)
{
    FRESULT res;
    uint8_t id[10] = {0};
    
    res = f_open(&param_f, PARAM_FILE_PATH, FA_OPEN_EXISTING|FA_READ|FA_WRITE);
    if(res == FR_OK)
    {
        param_read(&RobotParam);
        param_set_limit(&RobotParam);
    }
    else
    {
        memcpy(&RobotParam, &RobotParamDefalt, sizeof(RobotParam));
        param_set_limit(&RobotParam);
        res = f_open(&param_f, PARAM_FILE_PATH, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
        if(res == FR_OK)
        {
            param_write(&RobotParam);
        }
    }
    
    W25QXX_Read(id, 0, count(id));
    if(id[count(id)-1] == 0xA5)
    {
        memcpy(RobotParam.robot_id, id, count(id)-1);
    }
    
    memcpy(RobotParam.firmware_version, RobotParamDefalt.firmware_version, sizeof(RobotParam.firmware_version));
    parse_build_date(&RobotParam);
    
    //RTC时钟源必须选择LSE时钟，否则断电后无法保存RTC备份寄存器的数据。
    __HAL_RCC_PWR_CLK_ENABLE();
    HAL_PWR_EnableBkUpAccess();
    __HAL_RCC_BKPSRAM_CLK_ENABLE();
    HAL_PWREx_EnableBkUpReg();
    BpkParam = (RtcBpkParam_TypeDef *)&RTC->BKP0R;
    if(BpkParam->param.magic != 0xA5A5)
    {
        memset(BpkParam, 0, sizeof(RtcBpkParam_TypeDef));
        BpkParam->param.magic = 0xA5A5;
    }
    //第一次读取RTC备份寄存器里的数据时可能不是一个合法的浮点数，从而导致程序用使用到该数据的地方全都变成无效浮点数。
    if(fpclassify(BpkParam->param.battery_power) != FP_NORMAL)
    {
        BpkParam->param.battery_power = 0;
    }
}

void param_read(RobotParam_TypeDef *param)
{
    UINT br;
    FRESULT res;
    
    f_rewind(&param_f);
    res = f_read(&param_f, param, sizeof(RobotParam), &br);
    if(res != FR_OK || br != sizeof(RobotParam))
    {
        Error.Eeprom = 1;
        memcpy(param, &RobotParamDefalt, sizeof(RobotParam));
    }
}

void param_write(RobotParam_TypeDef *param)
{
    FRESULT res;
    UINT bw;
    
    f_rewind(&param_f);
    res = f_write(&param_f, param, sizeof(RobotParam), &bw);
    if(res != FR_OK || bw != sizeof(RobotParam))
    {
        Error.Eeprom = 1;;
    }
    else
    {
        f_sync(&param_f);
    }
}