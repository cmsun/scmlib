#include "led.h"
#include "main.h"
#include "utility.h"

void led_init(void)
{

}

void led_on(LED_ENUM led)
{
    switch((int)led)
    {
        case LED_0:
            LL_GPIO_ResetOutputPin(LED0_GPIO_Port, LED0_Pin);
            break;
        case LED_1:
            LL_GPIO_ResetOutputPin(LED1_GPIO_Port, LED1_Pin);
            break;
        case LED_2:
            LL_GPIO_ResetOutputPin(LED2_GPIO_Port, LED2_Pin);
            break;
        default:
            break;
    }
}

void led_off(LED_ENUM led)
{
    switch((int)led)
    {
        case LED_0:
            LL_GPIO_SetOutputPin(LED0_GPIO_Port, LED0_Pin);
            break;
        case LED_1:
            LL_GPIO_SetOutputPin(LED1_GPIO_Port, LED1_Pin);
            break;
        case LED_2:
            LL_GPIO_SetOutputPin(LED2_GPIO_Port, LED2_Pin);
            break;
        default:
            break;
    }
}

void led_toggle(LED_ENUM led)
{
    switch((int)led)
    {
        case LED_0:
            LL_GPIO_TogglePin(LED0_GPIO_Port, LED0_Pin);
            break;
        case LED_1:
            LL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
            break;
        case LED_2:
            LL_GPIO_TogglePin(LED2_GPIO_Port, LED2_Pin);
            break;
        default:
            break;
    }
}

void led_blink_task(LED_ENUM led, uint8_t Hz, float duty)
{
    uint32_t cur_tick, period;
    static uint32_t last_tick = 0;
    
    period = 1000.0f/Hz;
    cur_tick = millis();
    if(cur_tick - last_tick < period*duty)
    {
        led_on(led);
    }
    else
    {
        led_off(led);
        if(cur_tick - last_tick >= period)
        {
            led_on(led);
            last_tick = cur_tick;
        }
    }
}