#include <math.h>
#include "battery.h"
#include "adc.h"
#include "utility.h"
#include "parameter.h"
#include "safety.h"

float ChargeFilterBuff[14];
float VoltageFilterBuff[14];
float DischargeFilterBuff[14];
float CabinetTempFilterBuff[14];
SmoothFilter_TypeDef ChargeFilter;
SmoothFilter_TypeDef VoltageFilter;
SmoothFilter_TypeDef DischargeFilter;
SmoothFilter_TypeDef CabinetTempFilter;

typedef struct {
    uint16_t charge;        //battery charge current
    uint16_t voltage;       //battery voltage
    uint16_t discharge;     //battery discharge current
    uint16_t vrefex;        //ADC external reference voltage
    uint16_t vrefin;        //ADC interior reference voltage
#ifdef VERSION_D3
    uint16_t cabinettemp;   //Cabinet temperature
#endif
} ADC_RAW_TypeDef;

typedef struct
{
    ADC_RAW_TypeDef adc_raw;
    float raw2vol_ratio;    //ADCԭʼ����ת���ɵ�ѹ�ı���
    float charge;           //��س����� UNIT��A
    float voltage;          //��ص�ѹ UNIT��V
    float discharge;        //��طŵ������UNIT��A
    float capacity;         //��ص����� UNIT��mA*h
    float power;            //���ʣ����� UNIT��mA*h
    uint8_t soc;            //���״̬��ʣ������ٷֱ�
    bool charge_enable;     //���ʹ��
} BatteryData_TypeDef;

__attribute__((section(".ARM.__at_0x20000284"))) BatteryData_TypeDef Battery = {0}; //DMAֻ�ܷ���IRAM1�ڴ�ռ�

void battery_init(void)
{
    smooth_filter_init(&ChargeFilter, ChargeFilterBuff, count(ChargeFilterBuff));
    smooth_filter_init(&VoltageFilter, VoltageFilterBuff, count(VoltageFilterBuff));
    smooth_filter_init(&DischargeFilter, DischargeFilterBuff, count(DischargeFilterBuff));
    smooth_filter_init(&CabinetTempFilter, CabinetTempFilterBuff, count(CabinetTempFilterBuff));

    Battery.capacity = RobotParam.battery_capacity;
    Battery.power = BpkParam->param.battery_power;
    Battery.charge_enable = false;
    
    //����ADM����ת��ģʽ��ContinuousConvMode = ENABLE;
    //����DMA��������ģʽ��DMAContinuousRequests = ENABLE
    //DMA���ݴ���ģʽΪѭ��ģʽ��Mode = DMA_CIRCULAR
    //�������������Ժ����һ������ĺ�����ADC�᲻��ת�����ݲ�ͨ��DMA���˵�Battery.adc_raw.array�����С�
    HAL_ADC_Start_DMA(&hadc1, (uint32_t *)&Battery.adc_raw, sizeof(Battery.adc_raw)/sizeof(uint16_t));
}

void battery_task(void)
{
#define BATTERY_TASK_PERIOD 200
    static uint32_t period = 0, delay2alarm = 0;
    float adcvol;
    
    if(millis() - period >= BATTERY_TASK_PERIOD)
    {
        period = millis();
        Battery.raw2vol_ratio = 3.0f / Battery.adc_raw.vrefex;          //ʹ���ⲿ3.0���ο���ѹ
        //Battery.raw2vol_ratio = 1.2f / Battery.adc_raw.vrefin;          //ʹ���ڲ�1.2���ο���ѹ    
        //�����һ�����е�ʱ��ADC��ֵΪ0��0��Ϊ��������ʹ��raw2vol_ratioΪ�Ƿ���������
        if(fpclassify(Battery.raw2vol_ratio) == FP_NORMAL)
        {
            adcvol = Battery.adc_raw.charge * Battery.raw2vol_ratio;    //ADC�⵽�ĵ�ѹ
            Battery.charge = ((adcvol/(10.0f/15.6f)) - 2.5f) / 0.1f;    //����Ϊ0��ʱ�ĵ�ѹΪ2.5V��0.1V��ѹ��Ӧ1A����
            Battery.charge = smooth_filter(&ChargeFilter, Battery.charge);
            
            adcvol = Battery.adc_raw.voltage * Battery.raw2vol_ratio;   //ADC�⵽�ĵ�ѹ
            Battery.voltage = adcvol * 11;                              //ʵ�ʵ�ص�ѹ
            Battery.voltage = smooth_filter(&VoltageFilter, Battery.voltage);
            
            adcvol = Battery.adc_raw.discharge * Battery.raw2vol_ratio; //ADC�⵽�ĵ�ѹ
            Battery.discharge = ((adcvol/(10.0f/15.6f)) - 2.5f) / 0.1f; //����Ϊ0��ʱ�ĵ�ѹΪ2.5V��0.1V��ѹ��Ӧ1A����
            Battery.discharge = smooth_filter(&DischargeFilter, Battery.discharge);
            
            Battery.power -= Battery.discharge*1000 * ((double)BATTERY_TASK_PERIOD/(double)(60*60*1000));
            if(Battery.soc < 99 || Battery.voltage < 27.0f)
            {
                if(Battery.charge_enable)
                {
                    if(Battery.charge >= 0.5f)
                    {
                        Battery.power += Battery.charge*1000 * ((double)BATTERY_TASK_PERIOD/(double)(60*60*1000));
                        Warning.ChargingNoCurrent = 0;
                        delay2alarm = millis();
                    }
                    else if(Battery.voltage >= 27.5f)
                    {
                        Battery.power = RobotParam.battery_capacity;
                        Warning.ChargingNoCurrent = 0;
                        delay2alarm = millis();
                    }
                    else if(Battery.voltage < 27.0f && millis() - delay2alarm > 10*1000)
                    {
                        Warning.ChargingNoCurrent = 1;
                    }
                }
                else
                {
                    Warning.ChargingNoCurrent = 0;
                    delay2alarm = millis();
                }
            }
            Battery.power = range(Battery.power, 0, Battery.capacity);
            Battery.soc = round(Battery.power / Battery.capacity * 100);
            
            BpkParam->param.battery_power = Battery.power;
        }
    }
}

void battery_calibrate(void)
{
    double energy, v;
    
    v = Battery.voltage * 1000; //��ѹ��λ��mV
    
    if(v > 26018)
        //6.11747125146722E-13*Y4^5 - 8.22413660726901E-08*Y4^4 + 0.00442215495359303*Y4^3 - 118.881185686535*Y4^2 + 1597820.95878923*Y4 - 8589514920.71208
        energy = 6.11747125146722E-13*powl(v, 5) - 8.22413660726901E-08*powl(v, 4) + 0.00442215495359303*powl(v, 3) - 118.881185686535*powl(v, 2) + 1597820.95878923*v - 8589514920.71208;
    else if(v > 24972.0)
        //4.12319369098684E-13*Y119^6 - 6.30013681336513E-08*Y119^5 + 0.00401084607986381*Y119^4 - 136.176376667451*Y119^3 + 2600585.5188539*Y119^2 - 26486240583.3462*Y119 + 112393027992925
        energy = 4.12319369098684E-13*powl(v, 6) - 6.30013681336513E-08*powl(v, 5) + 0.00401084607986381*powl(v, 4) - 136.176376667451*powl(v, 3) + 2600585.5188539*powl(v, 2) - 26486240583.3462*v + 112393027992925;
    else if(v > 24914)
        //-2.67929711269911E-10*Y947^4 + 0.0000314262034498892*Y947^3 - 1.34313612127354*Y947^2 + 24984.4040048946*Y947 - 171522264.590447
        energy = -2.67929711269911E-10*powl(v, 4) + 0.0000314262034498892*powl(v, 3) - 1.34313612127354*powl(v, 2) + 24984.4040048946*v - 171522264.590447;
    else if(v > 19616)
        //6.02841070292631E-09*Y1080^3 - 0.000363803368832026*Y1080^2 + 7.35881345930714*Y1080 - 49872.8758369578
        energy = 6.02841070292631E-09*powl(v, 3) - 0.000363803368832026*powl(v, 2) + 7.35881345930714*v - 49872.8758369578;
    else
        energy = 0.0;

	energy = range(energy, 0, RobotParam.battery_capacity);
    Battery.power = energy;
    BpkParam->param.battery_power = energy;
}

float battery_voltage(void) {return Battery.voltage;}
float battery_charge_current(void) {return Battery.charge;}
float battery_discharge_current(void) {return Battery.discharge;}
float battery_soc(void) {return Battery.soc;}
void battery_enable_charge(void) { Battery.charge_enable = true; HAL_GPIO_WritePin(APEXOUT2_GPIO_Port, APEXOUT2_Pin, GPIO_PIN_SET); }
void battery_disable_charge(void) { Battery.charge_enable = false; HAL_GPIO_WritePin(APEXOUT2_GPIO_Port, APEXOUT2_Pin, GPIO_PIN_RESET);}
#ifdef VERSION_D3
float cabinet_adc_voltage(void) {return smooth_filter(&CabinetTempFilter, Battery.raw2vol_ratio * Battery.adc_raw.cabinettemp);}
#endif