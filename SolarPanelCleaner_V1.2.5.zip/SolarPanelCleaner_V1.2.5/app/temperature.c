#include "temperature.h"
#include "main.h"
#include "spi.h"
#include "battery.h"
#include "utility.h"
#include "config.h"

typedef struct
{
    float CabinetTemp1ST;
    float CabinetTemp2ND;
    float BatTemp1ST;
    float BatTemp2ND;
} Temperature_TypeDef;

Temperature_TypeDef Temp;

#ifdef VERSION_D2
static inline void lm95071_1st_spi_cs_low(void)
{
    LL_GPIO_ResetOutputPin(LM95071_1ST_SPI_CS_GPIO_Port, LM95071_1ST_SPI_CS_Pin);
}

static inline void lm95071_1st_spi_cs_high(void)
{
    LL_GPIO_SetOutputPin(LM95071_1ST_SPI_CS_GPIO_Port, LM95071_1ST_SPI_CS_Pin);
}

static inline void lm95071_2nd_spi_cs_low(void)
{
    LL_GPIO_ResetOutputPin(LM95071_2ND_SPI_CS_GPIO_Port, LM95071_2ND_SPI_CS_Pin);
}

static inline void lm95071_2nd_spi_cs_high(void)
{
    LL_GPIO_SetOutputPin(LM95071_2ND_SPI_CS_GPIO_Port, LM95071_2ND_SPI_CS_Pin);
}

static float lm95071_1st_get_temp(void)
{
    uint16_t tx, rx;
    lm95071_1st_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi3, (uint8_t *)&tx, (uint8_t *)&rx, sizeof(rx), 10);
    lm95071_1st_spi_cs_high();
    rx = ntohs(rx);
    return (rx >> 2) * (float)0.03125;
}

static float lm95071_2nd_get_temp(void)
{
    uint16_t tx, rx;
    lm95071_2nd_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi3, (uint8_t *)&tx, (uint8_t *)&rx, sizeof(rx), 10);
    lm95071_2nd_spi_cs_high();
    rx = ntohs(rx);
    return (rx >> 2) * (float)0.03125;
}
#else
static float cabinet_get_temp(void)
{
    //�����������ֵ���¶ȵĶ��ձ�
    float temp = 100;
    const float RegTempTable[18][2] = {{0.25f, 130}, {0.30f, 120}, {0.40f, 110},
                                       {0.50f, 100}, {0.60f, 90},  {0.80f, 80},
                                       {1.00f, 70},  {1.50f, 60},  {2.00f, 50},
                                       {3.00f, 40},  {4.00f, 30},  {6.00f, 20},
                                       {8.00f, 10},  {15.00f, 0},  {20.00f, -10},
                                       {35.00f, -20},{60.00f, -30},{100.00f, -40}};
    //adc_voltage����Ƭ��ADC�ɼ����ĵ�ѹ
    //reg�������������ֵ
    //�� R1<=reg<R2 �� T1<=Temprature<T2������С��Χ��Ϊ���Թ�ϵ
    float adc_voltage, reg, R1, R2, T1, T2;
                                           
    adc_voltage = 1000 * cabinet_adc_voltage();
    reg = (5.1f * adc_voltage) / (3000.0f - adc_voltage);
    if(reg < RegTempTable[0][0])
    {
        temp = RegTempTable[0][1];
    }
    else if(reg > RegTempTable[17][0])
    {
        temp = RegTempTable[17][1];
    }
    else
    {
        for(int i = 0; i < 17; ++i)
        {
            R1 = RegTempTable[i][0];
            R2 = RegTempTable[i+1][0];
            T1 = RegTempTable[i][1];
            T2 = RegTempTable[i+1][1];
            if(reg >= R1 && reg < R2)
            {
                temp = T1 + ((T2 - T1) * ((reg - R1) / (R2 - R1)));
                break;
            }
        }
    }
    
    return temp;
}
#endif

static inline void max31865_1st_spi_cs_low(void)
{
    LL_GPIO_ResetOutputPin(MAX31865_1ST_SPI_CS_GPIO_Port, MAX31865_1ST_SPI_CS_Pin);
}

static inline void max31865_1st_spi_cs_high(void)
{
    LL_GPIO_SetOutputPin(MAX31865_1ST_SPI_CS_GPIO_Port, MAX31865_1ST_SPI_CS_Pin);
}

static float max31865_1st_get_temp(void)
{
    //Ƭѡʹ���Ժ��͵�һ����ַ����ʱ���ص���������Ч�ġ�
    //����Ƭѡʹ��״̬�ٷ�����һ����ַ����ʱ���ص�����һ��
    //��ַ��Ӧ�����ݣ��������ơ�
    uint8_t addr[9] = {0, 1, 2, 3, 4, 5, 6, 7, 0xff};
    uint8_t rx[9] = {0};
    max31865_1st_spi_cs_low();
#ifdef VERSION_D2
    HAL_SPI_TransmitReceive(&hspi3, addr, rx, sizeof(rx), 10);
#else
    HAL_SPI_TransmitReceive(&hspi2, addr, rx, sizeof(rx), 10);
#endif
    max31865_1st_spi_cs_high();
    return ((((rx[2]<<8|rx[3])) >> 1) / (float)32) - 265;
}

#ifdef VERSION_D2
static inline void max31865_2nd_spi_cs_low(void)
{
    LL_GPIO_ResetOutputPin(MAX31865_2ND_SPI_CS_GPIO_Port, MAX31865_2ND_SPI_CS_Pin);
}

static inline void max31865_2nd_spi_cs_high(void)
{
    LL_GPIO_SetOutputPin(MAX31865_2ND_SPI_CS_GPIO_Port, MAX31865_2ND_SPI_CS_Pin);
}

static float max31865_2nd_get_temp(void)
{
    //Ƭѡʹ���Ժ��͵�һ����ַ����ʱ���ص���������Ч�ġ�
    //����Ƭѡʹ��״̬�ٷ�����һ����ַ����ʱ���ص�����һ��
    //��ַ��Ӧ�����ݣ��������ơ�
    uint8_t addr[9] = {0, 1, 2, 3, 4, 5, 6, 7, 0xff};
    uint8_t rx[9] = {0};
    max31865_2nd_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi3, addr, rx, sizeof(rx), 10);
    max31865_2nd_spi_cs_high();
    return ((((rx[2]<<8|rx[3])) >> 1) / (float)32) - 256;
}
#endif

void temp_init(void)
{
    uint8_t rx[8] = {0};
    uint8_t max31865_init_cmd[8] = {0x80, 0xd3, 0x00, 0x00, 0xff, 0xfe, 0x00, 0x01};

#ifdef VERSION_D2
    //max31865оƬ�����Զ���ӦSPI�Ĵ������ʣ����Ե�һ��ͨ����������ͨ�����ʡ�
    HAL_SPI_TransmitReceive(&hspi3, max31865_init_cmd, rx, sizeof(rx), 10);
    
    max31865_1st_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi3, max31865_init_cmd, rx, sizeof(rx), 10);
    max31865_1st_spi_cs_high();
    
    max31865_2nd_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi3, max31865_init_cmd, rx, sizeof(rx), 10);
    max31865_2nd_spi_cs_high();
#else
    //max31865оƬ�����Զ���ӦSPI�Ĵ������ʣ����Ե�һ��ͨ����������ͨ�����ʡ�
    HAL_SPI_TransmitReceive(&hspi2, max31865_init_cmd, rx, sizeof(rx), 10);
    
    max31865_1st_spi_cs_low();
    HAL_SPI_TransmitReceive(&hspi2, max31865_init_cmd, rx, sizeof(rx), 10);
    max31865_1st_spi_cs_high();
#endif
}

void temp_task(void)
{
    static uint32_t period = 0;
    if(millis() - period >= 500)
    {
        period = millis();
        
#ifdef VERSION_D2
        Temp.CabinetTemp1ST = lm95071_1st_get_temp();
        Temp.CabinetTemp2ND = lm95071_2nd_get_temp();
        Temp.BatTemp1ST = max31865_1st_get_temp();
        Temp.BatTemp2ND = max31865_2nd_get_temp();
#else
        Temp.CabinetTemp1ST = cabinet_get_temp();
        Temp.BatTemp1ST = max31865_1st_get_temp();
#endif
    }
}

float temp_battery(void)
{
#ifdef VERSION_D2
    return (Temp.BatTemp1ST + Temp.BatTemp2ND) / 2;
#else
    return Temp.BatTemp1ST;
#endif
}

float temp_cabinet(void)
{
#ifdef VERSION_D2
    return (Temp.CabinetTemp1ST +  Temp.CabinetTemp2ND) / 2;
#else
    return Temp.CabinetTemp1ST;
#endif
}