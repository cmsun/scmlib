#ifndef _CONFIG_H_
#define _CONFIG_H_

#define ROBOT_VERSION_D3                        1

#define CLOCK_WISE                              (1)
#define COUNTER_CLOCK_WISE                      (-1)

#ifdef VERSION_D2
#define LEFT_SERVO_WISE                         CLOCK_WISE
#define RIGHT_SERVO_WISE                        CLOCK_WISE
#else
#define LEFT_SERVO_WISE                         COUNTER_CLOCK_WISE
#define RIGHT_SERVO_WISE                        CLOCK_WISE
#endif

#define USE_RADAR_SENSOR                        1

#define BATTERY_CHARGE_LOW_TEMPERATURE_BORDER   -15
#define BATTERY_CHARGE_HIGH_TEMPERATURE_BORDER  55

#endif