#ifndef _COMMUNICATION_H_
#define _COMMUNICATION_H_

#include <stdint.h>
#include "parameter.h"

#define FRAME_HEAD 0x20
#define FRAME_TAIL 0x88

#define FRAME_TYPE_COMMAND      0x21    //命令帧
#define FRAME_TYPE_PARAM        0x31    //参数设置帧
#define FRAME_TYPE_0X41         0x41    //未使用
#define FRAME_TYPE_0X51         0x51    //未使用
#define FRAME_TYPE_0x61         0x61    //未使用
#define FRAME_TYPE_UPDATE_CMD   0x71    //固件升级，命令帧类型
#define FRAME_TYPE_UPDATE_DATA  0x7A    //固件升级，数据帧类型
#define FRAME_TYPE_0x81         0x81    //未使用
#define FRAME_TYPE_HEART_BEAT   0x91    //心跳帧

#pragma pack(1)

typedef struct {
    uint8_t head;                                                           //帧头
    uint8_t type;                                                           //帧类型
    uint16_t length;                                                        //帧长度
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint8_t motionCmd;
    int8_t linearVelocity;
    int8_t angularVelocity;
    uint8_t brushCtl;
    uint8_t motionMethon;
    uint32_t sectorNum; 
    uint8_t reserve[6];
    uint8_t checksum;                                                       //校验值
    uint8_t tail;
} Frame_Command_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint8_t buildDate[4];
    uint8_t robotState;
    int8_t linearVelocity;
    int8_t angularVelocity;
    uint8_t brushState;
    uint8_t motionMethon;
    uint32_t faultFlag;
    uint32_t curMileage;
    uint32_t curCleanTime;
    uint16_t batteryVol;
    uint8_t dropLimitState;
    uint16_t reserve;
    uint8_t checksum;
    uint8_t tail;
} Frame_Command_Ack;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint8_t rw_raduction_ratio;
    uint32_t raduction_ratio;       //电机减速比
    uint8_t rw_brush_speed;
    uint16_t brush_speed_low;       //毛刷低档速度
    uint16_t brush_speed_high;      //毛刷高档速度
    uint8_t rw_servo_param;
    uint8_t servo_number;           //0:毛刷伺服 1:左行走伺服 2:右行走伺服
    uint16_t servo_param_addr;      //电机参数地址
    uint16_t servo_param_value;     //电机参数值
    uint8_t rw_sensor_mask;
    uint32_t sensor_mask;           //屏蔽传感器
    uint8_t rw_force_charge;
    uint8_t force_charge;           //强行充电
    uint8_t rw_over_current;
    uint32_t over_current1;         //过流保护值1，单位: mA
    uint32_t over_current2;         //过流保护值1，单位: mA
    uint32_t over_current3;         //过流保护值1，单位: mA
    uint8_t rw_liner_block;
    uint32_t linear_block;          //机器受阻，直线偏差，单位：厘米
    uint8_t rw_angle_block;
    uint32_t angle_block;           //机器受阻，角度偏差，单位：度
    uint8_t rw_battery_capacity;
    uint32_t battery_capacity;      //电池容量，单位：Ah
    uint8_t rw_homeward_soc;
    uint8_t howeward_soc;           //机器人返航电量
    uint32_t lowpower_voltage;      //触发低电量返航的电压，单位：伏。符点数乘以100取整数部分。
    uint8_t lowpower_trigger_time;  //触发低电量返航的时间，单位：秒
//    uint8_t rw_robot_id;
//    uint8_t robot_id[ROBOT_ID_LENGTH]; //设置机器人ID
    uint8_t reserve[8];
    uint8_t checkSum;
    uint8_t tail;
} Frame_Param_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint8_t buildDate[4];
    uint8_t rw_raduction_ratio;
    uint32_t raduction_ratio;       //电机减速比
    uint8_t rw_brush_speed;
    uint16_t brush_speed_low;       //毛刷低档速度
    uint16_t brush_speed_high;      //毛刷高档速度
    uint8_t rw_servo_param;
    uint8_t servo_number;           //0:毛刷伺服 1:左行走伺服 2:右行走伺服
    uint16_t servo_param_addr;      //电机参数地址
    uint16_t servo_param_value;     //电机参数值
    uint8_t rw_sensor_mask;
    uint32_t sensor_mask;           //屏蔽传感器
    uint8_t rw_force_charge;
    uint8_t force_charge;           //强行充电
    uint8_t rw_over_current;
    uint32_t over_current1;         //过流保护值
    uint32_t over_current2;         //过流保护值
    uint32_t over_current3;         //过流保护值
    uint8_t rw_liner_block;
    uint32_t linear_block;          //机器受阻，直线偏差
    uint8_t rw_angle_block;
    uint32_t angle_block;           //机器受阻，角度偏差
    uint8_t rw_battery_capacity;
    uint32_t battery_capacity;      //电池容量，单位：Ah
    uint8_t rw_homeward_soc;
    uint8_t homeward_soc;           //机器人返航电量
    uint32_t lowpower_voltage;      //触发低电量返航的电压，单位：伏。符点数乘以100取整数部分。
    uint8_t lowpower_trigger_time;  //触发低电量返航的时间，单位：秒
//    uint8_t rw_robot_id;
//    uint8_t robot_id[ROBOT_ID_LENGTH]; //设置机器人ID
    uint8_t reserve[8];
    uint8_t checkSum;
    uint8_t tail;
} Frame_Param_Ack;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint16_t year;
    uint8_t month;
    uint8_t day;
    uint8_t time[3];
    uint8_t deveice;
    uint8_t reserve[16];
    uint8_t checkSum;
    uint8_t tail;
} Frame_HeartBeat_Req;

typedef struct {
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[ROBOT_ID_LENGTH];
    uint8_t buildDate[4];
    uint8_t controlMethod;
    uint8_t taskStatus;
    uint32_t warningFlag;
    uint8_t dropSersor;
    uint8_t radarSersor;
    uint16_t radarLeftFront;
    uint16_t radarLeftRear;
    uint16_t radarRightFront;
    uint16_t radarRightRear;
    uint32_t magnaticGuider;
    uint64_t longtitude;
    uint64_t lattitude;
    uint16_t azimuth;
    int8_t linearVelocity;
    int8_t angleVelocity;
    uint8_t brushState;
    uint32_t currentMileage;
    uint32_t currentCleanTime;
    uint16_t batteryVoltage;
    uint8_t batteryStatus;    //电池电量
    int16_t batteryTemp;
    int16_t cabinetTemp;
    int16_t temperature;
    uint16_t windVelocity;
    uint8_t weather;
    uint64_t totalMileage;
    uint64_t totalCleanTime;
    uint16_t disChargeCurrent;
    uint16_t chargeCurrent;
    uint64_t timestamp;
    uint32_t random;
    uint8_t satInView;    
    uint8_t satInUse;
    uint8_t isTaskBreak;
    uint8_t posValid;
    uint8_t dirValid;
    uint8_t mapName[8];
	uint32_t cruiseTotal;
	uint32_t cruiseIndex;
    uint8_t leftDrvErrCode;
    uint8_t rightDrvErrCode;
    uint8_t leftDrvStaCode;
    uint8_t rightDrvStaCode;
    uint32_t errorFlag;
    uint8_t onSectorType;
    uint8_t version[3];
    uint8_t rtkQualitySta;
    uint32_t sensor_mask;
    uint8_t camera_power_state;
    uint8_t reserve[6];
    uint8_t checkSum;
    uint8_t tail;
} Frame_HeartBeat_Ack;

#pragma pack()

void com_init(void);
void com_task(void);

#endif
