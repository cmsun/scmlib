#include "task.h"
#include "fatfs.h"
#include "w25qxx.h"
#include "watchdog.h"
#include "led.h"
#include "temperature.h"
#include "RTK.h"
#include "pwrctrl.h"
#include "parameter.h"
#include "communication.h"
#include "uart_utility.h"
#include "battery.h"
#include "motion.h"
#include "statemachine.h"
#include "sensor.h"
#include "modbusdevs.h"
#include "map.h"
#include "log.h"
#include "safety.h"

/* SDIO时钟分频系数必须为2或者以上，否则SD卡经常读写出错 */
/* fatfs需要动态分配内存，所以程序的堆大小至少大于0x1000，否则无法正常使用fatfs。cJSON需要至少0x3000的堆空间，否则程序会跑飞。 */
/* fatfs 的 _FS_LOCK 变量限定了同时打开文件的数量。json2map.c文件中要打开大量文件，所以要把_FS_LOCK的值改成10。 */

void task_init(void)
{
    FRESULT res;
    char work[W25Q64_SECTOR_SIZE] = {0};
    
    res = f_mount(&SDFatFS, "0:", 1);
    if(res != FR_OK)
    {
        Error.SdCard = 1;
    }
    
    res = f_mount(&USERFatFS, "1:", 1);
    if(res == FR_NO_FILESYSTEM)
    {
        //W25Q16的扇区太少，不能格式化成FAT32
        res = f_mkfs("1:", FM_FAT, 0, work, sizeof(work));
        if(res != FR_OK)
        {
            Error.Eeprom = 1;
        }
    }
    
    led_init();
    param_init();
    temp_init();
    //rtk_init();
    pwr_init();
    uart_init();
    com_init();
    battery_init();
    motion_init();
    state_init();
    sensor_init();
    map_init();
    modbusdevs_init();
    log_init();
    //watchdog_init();
}

void task_loop(void)
{
    watchdog_task();
    led_blink_task(LED_2, 10, 0.2f);
    temp_task();
    rtk_task();
    pwr_task();
    com_task();
    battery_task();
    motion_task();
    state_task();
    sensor_task();
    modbusdevs_task();
    record_task();
    log_task();
    //map_test_task();
}