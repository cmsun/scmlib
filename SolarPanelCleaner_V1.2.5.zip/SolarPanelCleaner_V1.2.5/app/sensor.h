#ifndef _SENSOR_H_
#define _SENSOR_H_

#include <stdbool.h>
#include "main.h"

typedef enum
{
    SENSOR_ON = GPIO_PIN_RESET,
    SENSOR_OFF = GPIO_PIN_SET,
} SENSOR_STATE;

void sensor_init(void);
void sensor_task(void);
uint8_t sensor_get_bits(void);
SENSOR_STATE sensor_left_front(void);
SENSOR_STATE sensor_left_rear(void);
SENSOR_STATE sensor_right_front(void);
SENSOR_STATE sensor_right_rear(void);
SENSOR_STATE sensor_park(void);

#endif