#ifndef _CAMERA_H_
#define _CAMERA_H_

#include <stdint.h>
#include <stdbool.h>

#define STEP_MOTOR_STEP_DEGREES 1.8     //步进电机的步距：degrees/Pulse
#define STEP_MOTOR_PULSE_REV    1000    //步进电机的细分
#define STEP_MOTOR_ACCELE_RATE  200     //相机转动时的加速度：rpm/S^2

typedef enum 
{
    STEP_MOTOR_STOP = 0,
    STEP_MOTOR_RUN,
} STEP_MOTOR_CMD;

typedef struct 
{
    STEP_MOTOR_CMD cmd;
    uint32_t cmd_timeout;
    double rpm_set;    //步进电机的目标转速
    double rpm_cur;    //步进电机的当前转速
    bool camera_power_state;
} StepMotor_TypeDef;

void step_motor_init(void);
void step_motor_run(int16_t rpm);
void step_motor_stop(void);
void step_motor_task(void);

//-------------------------------------------------------------------------------

#define SERVO_VEL                       5       //舵机旋转速度
#define SERVO_SYSTEM_LIMIT_MIN          2420    //舵机旋转最小角度对应该的定时器CCR寄存器的值
#define SERVO_SYSTEM_LIMIT_MAX          4600    //舵机旋转最大角度对应的定时器CCR寄存器的值
#define CAMERA_HORIZON_SHUTDOWN_POINT   2545    //相机关机时水平方向的停止位置
#define CAMERA_VERTICAL_SHUTDOWN_POINT  3190    //相机关机时垂直方向的停止位置
#define CAMERA_HORIZON_STARTUP_POINT    3900    //相机开机时水平方向的起始位置
#define CAMERA_VERTICAL_STARTUP_POINT   3390    //相机开机时垂直方向的起始位置
#define CAMERA_VERTICAL_LIMIT_MIN       3190    //相机垂直方向的软件限位
#define CAMERA_VERTICAL_LIMIT_MAX       3706    //相机垂直方向的软件限位

typedef enum
{
    CAMERA_POWER_ON = 0,
    CAMERA_POWER_OFF, 
    CAMERA_MOVE_STOP,
    CAMERA_MOVE_LEFT,
    CAMERA_MOVE_RIGHT,
    CAMERA_MOVE_UP,
    CAMERA_MOVE_DOWN
} CAMERA_CMD;

typedef struct 
{
    bool pwr_state;
    CAMERA_CMD cmd;
    uint16_t vel;
    uint16_t horizon_ccr;
    uint16_t vertical_ccr;
}Camera_TypeDef;

void camera_init(void);
void camera_set_cmd(CAMERA_CMD cmd);
bool camera_pwr_state(void);
void camera_task(void);

#endif