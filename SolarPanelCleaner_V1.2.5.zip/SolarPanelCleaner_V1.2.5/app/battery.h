#ifndef _BATTERY_H_
#define _BATTERY_H_

#include "main.h"

void battery_init(void);
void battery_task(void);
float battery_voltage(void);
float battery_charge_current(void);
float battery_discharge_current(void);
float battery_soc(void);
void battery_enable_charge(void);
void battery_disable_charge(void);
void battery_calibrate(void);
#ifdef VERSION_D3
float cabinet_adc_voltage(void);
#endif

#endif
