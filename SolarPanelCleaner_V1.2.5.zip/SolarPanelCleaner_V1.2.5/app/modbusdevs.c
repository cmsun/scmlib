#include <string.h>
#include "modbusdevs.h"
#include "utility.h"
#include "uart_utility.h"
#include "parameter.h"
#include "pwrctrl.h"
#include "safety.h"
#include "statemachine.h"
#include "config.h"
#include "usart.h"

#define STATION_CODE_NONE       0
#define STATION_CODE_MAGNETIC   1
#define STATION_CODE_BRUSH      2
#define STATION_CODE_BATTERY    3
#define STATION_CODE_RADAR      4

#define MODBUSDEVS_TASK_PERIOD  1       //5mSec周期
#define PERIOD_MAGNETIC         100     //AGV磁导航传感器每隔100ms通信一次
#define PERIOD_BRUSH            500     //毛刷驱动器100ms通信一次
#define PERIOD_BATTERY          1000    //电池BMS每隔1秒通信一次
#define PERIOD_RADAR            5       //超声波传感器每隔5ms通信一次
//串口空闲中断的有效时间为一个字符，而modbus的数据边界为3.5个字符的传输时间。
//所以收到某个设备的回复帧后要间隔一段时间才能与下个设备通信，否则上个设备的
//回复帧与当前主站的问询帧会在下个设备的接收缓存里粘成一个modbus数据帧。
#define RELEASE_DELAY           2       
#define COMMUNICATION_TIMEOUT   50      //50ms接收不到数据计算一次通信失败

ModbusDevices_TypeDef ModbusDevs = {
    .station_code = STATION_CODE_NONE,
    
    .magnetic.cmd = {0x01, 0x03, 0x00, 0x08, 0x00, 0x01, 0x05, 0xC8},
    
    .brush.cmd.enable = {0x02, 0x06, 0x01, 0x1A, 0x00, 0x01, 0x68, 0x02},     //毛刷驱动器使能：282寄存器写1
    .brush.cmd.disable = {0x02, 0x06, 0x01, 0x1A, 0x00, 0x00, 0xA9, 0xC2},    //毛刷驱动器失能：282寄存器写0
    .brush.cmd.setrpm = {0x02, 0x06, 0x01, 0x44, 0xF7, 0x68, 0x00, 0x00},     //毛刷驱动器给速度：324寄存器写转速值(－3000到3000)
    .brush.cmd.stop = {0x02, 0x06, 0x01, 0x44, 0x00, 0x00, 0xC8, 0x10},       //毛刷驱动器减速停止：324寄存器写转速值为0
    .brush.cmd.readregs = {0x02, 0x03, 0x00, 0xC8, 0x00, 0x19, 0x05, 0xCD},   //毛刷驱动器读状态：从200寄存器开始读25个字节
    .brush.ctrl = BRUSH_CTRL_NONE,
    
    .battery.cmd = {0x03, 0x03, 0x00, 0x12, 0x00, 0x17, 0xA4, 0x23},
    .battery.info.SOC = 100,
    
    .radar.cmd = {0x04, 0x03, 0x00, 0x00, 0x00, 0x04, 0x44, 0x5C},
};

//要在发送完成中断中把RS485改成接收模式，否则不能接收数据。
static inline void modbusdevs_send(uint8_t *data, uint16_t len)
{
    ModbusDevs.wait_ack = true;
    ModbusDevs.ack_timeout = millis();
    brush_rs485_tx_enable();
    uart_send_dma(hBrush, data, len);
}

//初始化通信
void modbusdevs_init(void)
{
#if !USE_RADAR_SENSOR
    LL_USART_InitTypeDef USART_InitStruct = {0};
    
    LL_USART_DeInit(USART6);
    
    USART_InitStruct.BaudRate = 9600;
    USART_InitStruct.DataWidth = LL_USART_DATAWIDTH_8B;
    USART_InitStruct.StopBits = LL_USART_STOPBITS_1;
    USART_InitStruct.Parity = LL_USART_PARITY_NONE;
    USART_InitStruct.TransferDirection = LL_USART_DIRECTION_TX_RX;
    USART_InitStruct.HardwareFlowControl = LL_USART_HWCONTROL_NONE;
    USART_InitStruct.OverSampling = LL_USART_OVERSAMPLING_16;
    LL_USART_Init(USART6, &USART_InitStruct);
    LL_USART_ConfigAsyncMode(USART6);
    LL_USART_Enable(USART6);
#endif
}

//通信失败，设置安全标志位
static void modbusdevs_communication_fialed(uint8_t station)
{
    if(station == STATION_CODE_MAGNETIC)
    {
        if(++ModbusDevs.magnetic.failed_cnt == 3)
        {
            ModbusDevs.magnetic.failed_cnt = 0;
            if(RobotParam.sensor_mask.bit.magnetic == 0)
            {
                Error.MagneticSensorOffline = 1;
            }
        }
    }
    else if(station == STATION_CODE_BRUSH)
    {
        if(++ModbusDevs.brush.failed_cnt == 3)
        {
            ModbusDevs.brush.failed_cnt = 0;
            Warning.BrushDriverPmip = 1;
            
            ModbusDevs.brush.regs_update = false;
            ModbusDevs.brush.ctrl = BRUSH_CTRL_NONE; //毛刷通信失败则清除毛刷控制指令
            memset(&ModbusDevs.brush.regs, 0, sizeof(BrushRegisters_TypeDef));
        }
    }
    else if(station == STATION_CODE_BATTERY)
    {
        if(++ModbusDevs.battery.failed_cnt == 3)
        {
            ModbusDevs.battery.failed_cnt = 0;
            Error.BatteryBmsOffline = 1;
        }
    }
    else if(station == STATION_CODE_RADAR)
    {
        if(++ModbusDevs.radar.failed_cnt == 3)
        {
            ModbusDevs.radar.failed_cnt = 0;
            ModbusDevs.radar.state.left_front    = SENSOR_ON;
            ModbusDevs.radar.state.right_front   = SENSOR_ON;
            ModbusDevs.radar.state.left_rear     = SENSOR_ON;
            ModbusDevs.radar.state.right_rear    = SENSOR_ON;
        }
    }
}

//磁传感器数据处理
static void magnetic_sensor_data_process(uint8_t *data, uint16_t len)
{
    ModbusDevs.magnetic.info = data[3];
}

//发送MODBUS指令，控制毛刷
static void brush_manage(void)
{
    BrushRegisters_TypeDef *regs;
    
    if(ModbusDevs.brush.ctrl == BRUSH_CTRL_NONE || ModbusDevs.brush.regs_update == false)
    {
        modbusdevs_send((uint8_t *)ModbusDevs.brush.cmd.readregs, MODBUS_CMD_LENGTH);
    }
    else
    {
        ModbusDevs.brush.regs_update = false;
        regs = &ModbusDevs.brush.regs;
        if(ModbusDevs.brush.ctrl == BRUSH_CTRL_STOP)
        {
            if(regs->P220 != 0)                                                         //速度不为0则减速
            {
                modbusdevs_send((uint8_t *)ModbusDevs.brush.cmd.stop, MODBUS_CMD_LENGTH);
            }
            else if(regs->P200 == 3)                                                    //如果是使能状态则失能伺服器
            {
                modbusdevs_send((uint8_t *)ModbusDevs.brush.cmd.disable, MODBUS_CMD_LENGTH);
            }
        }
        else if(ModbusDevs.brush.ctrl == BRUSH_CTRL_RUN)
        {
            if(regs->P200 == 4)                                                         //伺服准备好但是未使能
            {
                modbusdevs_send((uint8_t *)ModbusDevs.brush.cmd.enable, MODBUS_CMD_LENGTH);
            }
            else if(regs->P200 == 3 && ((uint16_t)ModbusDevs.brush.rpm != regs->P220))  //伺服已经使能但是没有速度
            {
                modbusdevs_send((uint8_t *)ModbusDevs.brush.cmd.setrpm, MODBUS_CMD_LENGTH);
            }
        }
    }
}

static void brush_data_process(uint8_t *data, uint16_t len)
{
    uint16_t *regs;
    
    //如果是读寄存器指令则处理数据，其它指令不处理
    if(data[1] == 0x03)
    {
        ModbusDevs.brush.regs_update = true;
        
        memcpy(&ModbusDevs.brush.regs, data+3, data[2]);
        regs = (uint16_t *)&ModbusDevs.brush.regs;
        for(int i = 0; i < data[2]/2; ++i)
        {
            regs[i] = ntohs(regs[i]);
        }
        
        if(ModbusDevs.brush.ctrl == BRUSH_CTRL_STOP 
            && ModbusDevs.brush.regs.P200 != 3
            && ModbusDevs.brush.regs.P220 == 0)
        {
            ModbusDevs.brush.ctrl = BRUSH_CTRL_NONE;
        }
        else if(ModbusDevs.brush.ctrl == BRUSH_CTRL_RUN 
            && ModbusDevs.brush.regs.P200 == 3
            && ModbusDevs.brush.regs.P220 != 0)
        {
            //ModbusDevs.brush.ctrl.cmd = BRUSH_CMD_NONE;
        }
        
        if(ModbusDevs.brush.regs.P202 != 0)
        {
            ModbusDevs.brush.ctrl = BRUSH_CTRL_NONE;
            Warning.BrushDriverAlam = 1;
        }
    }
}

//电池管理系统数据处理
static void battery_data_process(uint8_t *data, uint16_t len)
{
    BatteryBMSInfoRaw_TypeDef info;
    memcpy((void *)&info, data+3, sizeof(info));
    ModbusDevs.battery.info.voltage = ntohs(info.voltage) * 10;
    ModbusDevs.battery.info.current = (int16_t)ntohs(info.current) * 10;
    ModbusDevs.battery.info.remain_power = ntohs(info.remain_power) * 10;
    ModbusDevs.battery.info.temprature1 = (ntohs(info.temprature1) - 2731) / 10;
    ModbusDevs.battery.info.temprature2 = (ntohs(info.temprature2) - 2731) / 10;
    ModbusDevs.battery.info.capacity = ntohs(info.capacity) * 10;
    ModbusDevs.battery.info.SOC = ntohs(info.SOC);
    for(int i = 0; i < sizeof(info.cells_voltage)/sizeof(info.cells_voltage[0]); ++i)
    {
        ModbusDevs.battery.info.cells_voltage[i] = ntohs(info.cells_voltage[i]);
    }
}

static void radar_data_process(uint8_t *data, uint16_t len)
{
    int16_t left_front, right_front, left_rear, right_rear, *temp;
    
    temp = (int16_t *)(data + 3);
    left_front  = ntohs(*temp);
    temp = (int16_t *)(data + 5);
    right_front  = ntohs(*temp);
    temp = (int16_t *)(data + 7);
    left_rear  = ntohs(*temp);
    temp = (int16_t *)(data + 9);
    right_rear  = ntohs(*temp);
    
    ModbusDevs.radar.distance[0] = left_front;
    ModbusDevs.radar.distance[1] = right_front;
    ModbusDevs.radar.distance[2] = left_rear;
    ModbusDevs.radar.distance[3] = right_rear;
    
#ifdef VERSION_D2
    ModbusDevs.radar.state.left_front    = (left_front  >= 30 && left_front  <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.right_front   = (right_front >= 30 && right_front <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.left_rear     = (left_rear   >= 30 && left_rear   <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.right_rear    = (right_rear  >= 30 && right_rear  <= 150) ? SENSOR_OFF : SENSOR_ON;
#else
    ModbusDevs.radar.state.left_front    = (left_front  >= 30 && left_front  <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.right_front   = (right_front >= 30 && right_front <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.left_rear     = (left_rear   >= 30 && left_rear   <= 150) ? SENSOR_OFF : SENSOR_ON;
    ModbusDevs.radar.state.right_rear    = (right_rear  >= 30 && right_rear  <= 150) ? SENSOR_OFF : SENSOR_ON;
#endif
}

void modbusdevs_task(void)
{
    uint8_t data[64];
    uint16_t len = 0;
    static uint32_t period = 0;

    if(millis() - period >= MODBUSDEVS_TASK_PERIOD)
    {
        period = millis();
        
        //计算AGV磁导航传感器的通信周期
        if(ModbusDevs.station_code != STATION_CODE_MAGNETIC)
        {
            if(RobotParam.sensor_mask.bit.magnetic == 0 && millis() - ModbusDevs.magnetic.period >= PERIOD_MAGNETIC)
            {
                ModbusDevs.magnetic.period = millis();
                if(state_task_state() == STATE_IN_GARAGE)
                {
                    ModbusDevs.magnetic.active = true;
                }
                else
                {
                    ModbusDevs.magnetic.info = 0;
                }
            }
        }
        else
        {
            ModbusDevs.magnetic.period = millis();
        }
        
        //计算毛刷控制器的通信周期
        if(ModbusDevs.station_code != STATION_CODE_BRUSH)
        {
            if(pwr_motion_state() == POWER_STATE_ON
                && millis() - ModbusDevs.brush.period >= PERIOD_BRUSH)
            {
                ModbusDevs.brush.period = millis();
                ModbusDevs.brush.active = true;
            }
        }
        else
        {
            ModbusDevs.brush.period = millis();
        }
        
        //计算电池BMS的通信周期
#if 0
        if(ModbusDevs.station_code != STATION_CODE_BATTERY)
        {
            if(millis() - ModbusDevs.battery.period >= PERIOD_BATTERY)
            {
                ModbusDevs.battery.period = millis();
                ModbusDevs.battery.active = true;
            }
        }
        else
        {
            ModbusDevs.battery.period = millis();
        }
#endif
        
        //计算超声波传感器的通信周期
        if(ModbusDevs.station_code != STATION_CODE_RADAR)
        {
            if(millis() - ModbusDevs.radar.period >= PERIOD_RADAR)
            {
                ModbusDevs.radar.period = millis();
                ModbusDevs.radar.active = true;
            }
        }
        else
        {
            ModbusDevs.radar.period = millis();
        }
        
        //MODBUS上位机发送问旬帧
        if(ModbusDevs.wait_ack)
        {
            if(millis() - ModbusDevs.ack_timeout >= COMMUNICATION_TIMEOUT)
            {
                //通信超时，可以立刻重发或者与下个设备通信
                ModbusDevs.wait_ack = false;
                ModbusDevs.bus_release_delay = millis() - RELEASE_DELAY;
                modbusdevs_communication_fialed(ModbusDevs.station_code);
                ModbusDevs.station_code = STATION_CODE_NONE;
            }
        }
        else
        {
            if(millis() - ModbusDevs.bus_release_delay >= RELEASE_DELAY)
            {
                if(ModbusDevs.radar.active)
                {
                    ModbusDevs.radar.active = false;
                    ModbusDevs.station_code = STATION_CODE_RADAR;
                    modbusdevs_send((uint8_t *)ModbusDevs.radar.cmd, MODBUS_CMD_LENGTH);
                }
                else if(ModbusDevs.magnetic.active)
                {
                    ModbusDevs.magnetic.active = false;
                    ModbusDevs.station_code = STATION_CODE_MAGNETIC;
                    modbusdevs_send((uint8_t *)ModbusDevs.magnetic.cmd, MODBUS_CMD_LENGTH);
                }
                else if(ModbusDevs.brush.active)
                {
                    ModbusDevs.brush.active = false;
                    ModbusDevs.station_code = STATION_CODE_BRUSH;
                    brush_manage();  
                }
                else if(ModbusDevs.battery.active)
                {
                    ModbusDevs.battery.active = false;
                    ModbusDevs.station_code = STATION_CODE_BATTERY;
                    modbusdevs_send((uint8_t *)ModbusDevs.battery.cmd, MODBUS_CMD_LENGTH);
                }
            }
        }
        
        //接收数据
        if(uart_rx_complete(hBrush))
        {
            len = uart_read(hBrush, data, count(data));
            if(len >= 5 && checksum_crc16(data, len) == 0)
            {
                if(ModbusDevs.station_code == STATION_CODE_MAGNETIC)
                {
                    magnetic_sensor_data_process(data, len);
                    ModbusDevs.magnetic.failed_cnt = 0;
                }
                else if(ModbusDevs.station_code == STATION_CODE_BRUSH)
                {
                    brush_data_process(data, len);
                    ModbusDevs.brush.failed_cnt = 0;
                }
                else if(ModbusDevs.station_code == STATION_CODE_BATTERY)
                {
                    battery_data_process(data, len);
                    ModbusDevs.battery.failed_cnt = 0;
                }
                else if(ModbusDevs.station_code == STATION_CODE_RADAR)
                {
                    radar_data_process(data, len);
                    ModbusDevs.radar.failed_cnt = 0;
                }
            }
            else
            {
                modbusdevs_communication_fialed(ModbusDevs.station_code);
            }
            
            //接收到数据，不管数据是否正确都要等待释放总线后才能与下个设备通信
            ModbusDevs.wait_ack = false;
            ModbusDevs.bus_release_delay = millis();
            ModbusDevs.station_code = STATION_CODE_NONE;
        }
    }
}

uint8_t magnetic_info(void)
{
    return ~ModbusDevs.magnetic.info;    //实际值取反，有效为1，无效为0
}

void brush_set_rpm(int16_t rpm)
{
    uint16_t crc;
    ModbusDevs.brush.ctrl = BRUSH_CTRL_RUN;
    if(ModbusDevs.brush.rpm != rpm)
    {
        ModbusDevs.brush.rpm = rpm;
        ModbusDevs.brush.cmd.setrpm[4] = rpm >> 8;
        ModbusDevs.brush.cmd.setrpm[5] = rpm & 0x0f;
        crc = checksum_crc16(ModbusDevs.brush.cmd.setrpm, MODBUS_CMD_LENGTH-2);
        ModbusDevs.brush.cmd.setrpm[MODBUS_CMD_LENGTH-2] = crc >> 8;
        ModbusDevs.brush.cmd.setrpm[MODBUS_CMD_LENGTH-1] = crc & 0xff;
    }
}

void brush_stop(void)
{
    ModbusDevs.brush.ctrl = BRUSH_CTRL_STOP;
}

bool brush_is_running(void)
{
    return ModbusDevs.brush.regs.P220 != 0;
}

void battery_info(BatteryBMSInfo_TypeDef *info)
{
    memcpy(info, &ModbusDevs.battery.info, sizeof(ModbusDevs.battery.info));
}

SENSOR_STATE radar_left_front(void) { return ModbusDevs.radar.state.left_front; }
SENSOR_STATE radar_left_rear(void) { return ModbusDevs.radar.state.left_rear; }
SENSOR_STATE radar_right_front(void) { return ModbusDevs.radar.state.right_front; }
SENSOR_STATE radar_right_rear(void) { return ModbusDevs.radar.state.right_rear; }
