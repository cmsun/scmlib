#include <math.h>
#include <string.h>
#include "statemachine.h"
#include "main.h"
#include "motion.h"
#include "sensor.h"
#include "pwrctrl.h"
#include "static_dlinklist.h"
#include "map.h"
#include "utility.h"
#include "RTK.h"
#include "motion.h"
#include "navigation.h"
#include "battery.h"
#include "safety.h"
#include "modbusdevs.h"
#include "parameter.h"
#include "rtc.h"
#include "temperature.h"
#include "config.h"

#define STATE_TASK_PERIOD 20

RobotStateMachine_TypeDef StateMachine = {0};

void state_init(void)
{
    navigation_init();
    
    StateMachine.methon = METHON_MANUAL;
    StateMachine.state = STATE_STANDBY_STOP;
    StateMachine.state_backup = STATE_STANDBY_STOP;
    StateMachine.task_period = millis();
}

static void rtk_check(uint8_t validate)
{
    static uint32_t rtk_invalid_time = 0;
    
    if(validate != 0)
    {
        if(validate & GPGGA_VALIDATE_MASK)
        {
            Warning.RunForbiddenByPos = 1;
        }
        
        if(validate & GPHDT_VALIDATE_MASK)
        {
            Warning.RunForbiddenByAmuzith = 1;
        }
            
        if(millis() - rtk_invalid_time > 10*60*1000)
        {
            rtk_invalid_time = millis();
            pwr_rtk_cmd(POWER_CMD_RESET);
        }
    }
    else
    {
        Warning.RunForbiddenByPos = 0;
        Warning.RunForbiddenByAmuzith = 0;
        rtk_invalid_time = millis();
    }
}

//����0�����䴫�������쳣
//����1�����䴫����������Ҫ��ͣ
//����-1�����䴫����������Ҫ��ͣ
static int drop_check(void)
{
    int res = 0;
    
    //ͬ�ഫ����һ�𴥷�
    if((sensor_left_front() == SENSOR_ON && sensor_left_rear() == SENSOR_ON)
        || (sensor_right_front() == SENSOR_ON && sensor_right_rear() == SENSOR_ON))
    {
        Error.DropSensorsFault = 1;
        res = -1;
    }
    //�ԽǴ�����һ�𴥷�
    else if((sensor_left_front() == SENSOR_ON && sensor_right_rear() == SENSOR_ON)
        || (sensor_right_front() == SENSOR_ON && sensor_left_rear() == SENSOR_ON))
    {
        Error.DropSensorsFault = 1;
        res = -1;
    }
    //ǰ���������������ٶ�Ϊ�������н��ٶ�
    else if((sensor_left_front() == SENSOR_ON || sensor_right_front() == SENSOR_ON)
        && (round(motion_linear_velocity()) > 0 || round(motion_angular_velocity()) != 0))
    {
        res = 1;
        //����̼ƺ�RTK�ж�ֹͣ����
    }
    //�󴫸����������ٶ�Ϊ�������н��ٶ�
    else if((sensor_left_rear() == SENSOR_ON || sensor_right_rear() == SENSOR_ON)
        && (round(motion_linear_velocity()) < 0 || round(motion_angular_velocity()) != 0))
    {
        res = 1;
        //����̼ƺ�RTK�ж�ֹͣ����
    }
    else
    {
        //��¼RTK��λ
    }
    
    return res;
}

void record_task(void)
{
    uint32_t time;
    float mileage;
    static uint32_t period = 0, last_tick = 0;
    RTC_DateTypeDef date;
    
    if(millis() - period > 100)
    {
        period = millis();
        
        if(StateMachine.methon == METHON_ATUO 
            && StateMachine.state == STATE_CRUISE 
            && round(motion_linear_velocity()) != 0)
        {
            time = millis() - last_tick;                            //��λ����
            mileage = (time/60000.0f) * motion_linear_velocity();   //��λ��
            
            if(mileage > 0)                                         //����ʱ�������
            {
                BpkParam->param.dayly_mileage += mileage;           //��λ��
            }
            BpkParam->param.dayly_work_time += time/1000.0f;        //��λ��
            BpkParam->param.mileage_records += mileage;             //��λ��
            BpkParam->param.work_time_records += time/1000.0f;      //��λ��
            
            last_tick = millis();
        }
        else
        {
            last_tick = millis();
        }
        
        HAL_RTC_GetDate(&hrtc, &date, 0);
        if(BpkParam->param.date != date.Date)
        {            
            BpkParam->param.date = date.Date;
            BpkParam->param.dayly_mileage = 0;
            BpkParam->param.dayly_work_time = 0;
        }
    }
}

static void battery_charge_control(ROBOT_STATE_ENUM state, GPS_Point_TypeDef *position)
{
    static uint32_t period;
    NavigateBlock_TypeDef block;
    
    if(state > STATE_PAUSE_STOP)
    {
        battery_disable_charge();
        Warning.StopButNotTrigSwitch = 0;
        Warning.ChargeForbiddenByTemp = 0;
    }
    else
    {
        if(RobotParam.force_charge)
        {
            battery_enable_charge();
            Warning.StopButNotTrigSwitch = 0;
            Warning.ChargeForbiddenByTemp = 0;
        }
        else
        {
            if(sensor_park() == SENSOR_ON)
            {
                Warning.StopButNotTrigSwitch = 0;
                if(temp_battery() < BATTERY_CHARGE_LOW_TEMPERATURE_BORDER 
                    || temp_battery() > BATTERY_CHARGE_HIGH_TEMPERATURE_BORDER)
                {
                    Warning.ChargeForbiddenByTemp = 1;
                }
                else
                {
                    battery_enable_charge();
                    Warning.ChargeForbiddenByTemp = 0;
                }
            }
            else
            {
                if(millis() - period >= 5000)
                {
                    period = millis();
                    
                    if(map_get_local_block(position, &block) >= 0
                        && block.block_type == GARAGE)
                    {
                        Warning.StopButNotTrigSwitch = 1;
                    }
                }
            }
        }
    }
}

static ROBOT_STATE_ENUM manual_standby_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_STANDBY_STOP;
    
    if(sensor_park() == SENSOR_ON || RobotParam.force_charge)
    {
        battery_enable_charge();
    }
    else
    {
        battery_disable_charge();
    }
    
    if(round(motion_linear_velocity()) == 0
        && round(motion_angular_velocity()) == 0
        && brush_is_running() == false)
    {
        pwr_motion_cmd(POWER_CMD_OFF);
    }
	else
	{
        brush_stop();
        motion_disable();
	}
    
    if(StateMachine.control.methon != METHON_CMD_NONE)
    {
        StateMachine.methon = (ROBOT_METHON_ENUM)(StateMachine.control.methon - 1);
        StateMachine.control.methon = METHON_CMD_NONE;
    }
    
    if(StateMachine.control.cmd == CMD_START)
    {
        state = STATE_CRUISE;
    }
    else if(StateMachine.control.cmd == CMD_CLARM)
    {
        safety_clear();
    }
    StateMachine.control.cmd = CMD_NONE;
           
    return state;
}

static ROBOT_STATE_ENUM manual_cruise(void)
{
    ROBOT_STATE_ENUM state = STATE_CRUISE;
    
    battery_disable_charge();
    
    drop_check();
    
    if(pwr_motion_state() != POWER_STATE_ON)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }
	
	if(StateMachine.control.brush_cmd == BRUSH_CMD_ENABLE)
    {
        brush_set_rpm(RobotParam.brush_speed_high);
    }
    else if(StateMachine.control.brush_cmd == BRUSH_CMD_DISABLE)
    {
        brush_stop();
    }
    
    if(StateMachine.control.master == MANUAL_VELOCITY_MASTER_APP)
    {
        if(StateMachine.control.app_online)
        {
            motion_set_velocity(StateMachine.control.linear_vel, StateMachine.control.angluar_vel);
        }
        else
        {
            motion_set_velocity(0, 0);
            StateMachine.control.master = MANUAL_VELOCITY_MASTER_NONE;
        }
    }
    else if(StateMachine.control.master == MANUAL_VELOCITY_MASTER_SERVER)
    {
        if(StateMachine.control.server_online)
        {
            motion_set_velocity(StateMachine.control.linear_vel, StateMachine.control.angluar_vel);
        }
        else
        {
            motion_set_velocity(0, 0);
            StateMachine.control.master = MANUAL_VELOCITY_MASTER_NONE;
        }
    }
    else
    {
        motion_set_velocity(0, 0);
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    if(StateMachine.control.cmd ==  CMD_PAUSE)
    {
        state = STATE_STANDBY_STOP;
    }
    else if(StateMachine.control.cmd == CMD_CLARM)
    {
        safety_clear();
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

static ROBOT_STATE_ENUM manual_emergency_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_EMERGENCY_STOP;
    
    if(sensor_park() == SENSOR_ON || RobotParam.force_charge)
    {
        battery_enable_charge();
    }
    else
    {
        battery_disable_charge();
    }
    
    pwr_motion_cmd(POWER_CMD_OFF);
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    if(StateMachine.control.cmd ==  CMD_CLARM)
    {
        safety_clear();
        state = STATE_STANDBY_STOP;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    brush_stop();
    
    return state;
}

void manual_state_task(void)
{
    ROBOT_STATE_ENUM state;
    
    if(millis() - StateMachine.task_period >= STATE_TASK_PERIOD)
    {
        StateMachine.task_period = millis();
        
        switch((int)StateMachine.state)
        {
            case STATE_STANDBY_STOP:
                state = manual_standby_stop();
                break;
            case STATE_CRUISE:
                state = manual_cruise();
                break;
            case STATE_EMERGENCY_STOP:
                state = manual_emergency_stop();
                break;
            default:
                state = manual_emergency_stop();
                break;
        }
        
        if(Error.DropSensorsFault
            || Error.LeftDriverConnect
            || Error.LeftDriverAlam
            || Error.RightDriverConnect
            || Error.RightDriverAlam)
        {
            StateMachine.state = STATE_EMERGENCY_STOP;
        }
        else
        {
            StateMachine.state = state;
        }
    }
}

ROBOT_STATE_ENUM auto_standby_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_STANDBY_STOP;
    NavigateBlock_TypeDef block;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
        
    if(round(motion_linear_velocity()) == 0
        && round(motion_angular_velocity()) == 0
        && brush_is_running() == false)
    {
        pwr_motion_cmd(POWER_CMD_OFF);
    }
    else
    {
        brush_stop();
        motion_disable();
    }
    
    if(StateMachine.control.methon != METHON_CMD_NONE)
    {
        StateMachine.methon = (ROBOT_METHON_ENUM)(StateMachine.control.methon - 1);
        StateMachine.control.methon = METHON_CMD_NONE;
    }
    
    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:                   
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                if(block.block_type == GARAGE)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_OUT_GARAGE;
                }
                else if(block.block_type == SOLAR_PANEL)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_CRUISE;
                }
                else
                {
                    Error.FindLine = 1;
                }
            }
            break;
        case CMD_PAUSE:
            break;
        case CMD_END:
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                if(block.block_type == SOLAR_PANEL || block.block_type == BRIDGE)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_HOMEWARD;
                }
            }
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                dllist_clear(&NavDLList);
                if(block.block_type == GARAGE)
                {
                    state = STATE_OUT_GARAGE;
                }
                else
                {
                    if(!dllist_empty(&NavDLList)
                        && ((NavigatePoint_TypeDef *)dllist_front(&NavDLList, NULL))->block_num != block.block_num)
                    {
                        dllist_clear(&NavDLList);
                    }
                    state = STATE_RESUME;
                }
            }
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_charge_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_CHARGE_STOP;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    
    if(round(motion_linear_velocity()) == 0
        && round(motion_angular_velocity()) == 0
        && brush_is_running() == false)
    {
        pwr_motion_cmd(POWER_CMD_OFF);
    }
    else
    {
        brush_stop();
        motion_disable();
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_emergency_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_STANDBY_STOP;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    
    pwr_motion_cmd(POWER_CMD_OFF);
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            state = STATE_STANDBY_STOP;
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_pause_stop(void)
{
    ROBOT_STATE_ENUM state = STATE_PAUSE_STOP;
    NavigateBlock_TypeDef block;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
	
	if(round(motion_linear_velocity()) == 0
        && round(motion_angular_velocity()) == 0
        && brush_is_running() == false)
    {
        pwr_motion_cmd(POWER_CMD_OFF);
    }
    else
    {
        brush_stop();
        motion_disable();
    }
    
    if(StateMachine.control.methon != METHON_CMD_NONE)
    {
        StateMachine.methon = (ROBOT_METHON_ENUM)(StateMachine.control.methon - 1);
        StateMachine.control.methon = METHON_CMD_NONE;
    }
    
    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                if(block.block_type == GARAGE)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_OUT_GARAGE;
                }
                else if(block.block_type == SOLAR_PANEL)
                {
                    state = STATE_CRUISE;
                }
                else
                {
                    Error.FindLine = 1;
                }
            }
            break;
        case CMD_PAUSE:
            break;
        case CMD_END:
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                if(block.block_type == SOLAR_PANEL || block.block_type == BRIDGE)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_HOMEWARD;
                }
            }
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            if(StateMachine.state_backup > STATE_PAUSE_STOP)
            {
                state = StateMachine.state_backup;
            }
            else
            {
                if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
                {
                    dllist_clear(&NavDLList);
                    if(block.block_type == GARAGE)
                    {
                        state = STATE_OUT_GARAGE;
                    }
                    else
                    {
                        if(!dllist_empty(&NavDLList)
                            && ((NavigatePoint_TypeDef *)dllist_front(&NavDLList, NULL))->block_num != block.block_num)
                        {
                            dllist_clear(&NavDLList);
                        }
                        state = STATE_RESUME;
                    }
                }
            }
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_out_garage(void)
{
    ROBOT_STATE_ENUM state = STATE_OUT_GARAGE;
    NavigateBlock_TypeDef block;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    int drop_state;
    
    if(pwr_motion_state() == POWER_STATE_OFF)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }

    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    drop_state = drop_check();
    if(drop_state == 0)
    {
        if(rtk_validate == 0)
        {
            if(navigation_out_garage(&position, azimuth) != 0)
            {
                state = STATE_CRUISE;
            }
        }
        else
        {
            brush_stop();
            motion_set_velocity(0, 0);
        }
    }
    else if(drop_state > 0)
    {
		brush_stop();
        motion_set_velocity(0, 0);
    }
    else if(drop_state < 0)
    {
        Error.DropSensorsFault = 1;
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            if(rtk_validate == 0 && map_get_local_block(&position, &block) >= 0)
            {
                if(block.block_type == GARAGE)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_IN_GARAGE;
                }
                else if(block.block_type == SOLAR_PANEL)
                {
                    dllist_clear(&NavDLList);
                    state = STATE_HOMEWARD;
                }
            }
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_in_garage(void)
{
    ROBOT_STATE_ENUM state = STATE_IN_GARAGE;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    int drop_state;
    
    if(pwr_motion_state() == POWER_STATE_OFF)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }

    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    drop_state = drop_check();
    if(drop_state == 0)
    {
        if(rtk_validate == 0)
        {
            if(navigation_in_garage(&position, azimuth) != 0 || sensor_park() == SENSOR_ON)
            {
                state = STATE_STANDBY_STOP;
            }
        }
        else
        {
            brush_stop();
            motion_set_velocity(0, 0);
        }
    }
    else if(drop_state > 0)
    {
		brush_stop();
        motion_set_velocity(0, 0);
    }
    else if(drop_state < 0)
    {
        Error.DropSensorsFault = 1;
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_homeward(void)
{
    ROBOT_STATE_ENUM state = STATE_HOMEWARD;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    int drop_state;
    
    if(pwr_motion_state() == POWER_STATE_OFF)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }

    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    drop_state = drop_check();
    if(drop_state == 0)
    {
        if(rtk_validate == 0)
        {
            if(navigation_homing(&position, azimuth) != 0)
            {
                state = STATE_IN_GARAGE;
            }
        }
        else
        {
            brush_stop();
            motion_set_velocity(0, 0);
        }
    }
    else if(drop_state > 0)
    {
		brush_stop();
        motion_set_velocity(0, 0);
    }
    else if(drop_state < 0)
    {
        Error.DropSensorsFault = 1;
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_cruise(void)
{
    ROBOT_STATE_ENUM state = STATE_CRUISE;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    int drop_state;
    
    if(pwr_motion_state() == POWER_STATE_OFF)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }
    pwr_motion_cmd(POWER_CMD_ON);

    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    drop_state = drop_check();
    if(drop_state == 0)
    {
        if(rtk_validate == 0)
        {
            if(navigation_cruise(&position, azimuth) != 0)
            {
                state = STATE_HOMEWARD;
            }
        }
        else
        {
            brush_stop();
            motion_set_velocity(0, 0);
        }
    }
    else if(drop_state > 0)
    {
		brush_stop();
        motion_set_velocity(0, 0);
    }
    else if(drop_state < 0)
    {
        Error.DropSensorsFault = 1;
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

ROBOT_STATE_ENUM auto_resume(void)
{
    ROBOT_STATE_ENUM state = STATE_RESUME;
    GPS_Point_TypeDef position;
    double azimuth;
    uint8_t rtk_validate;
    int drop_state;
    
    if(pwr_motion_state() == POWER_STATE_OFF)
    {
        pwr_motion_cmd(POWER_CMD_ON);
    }

    rtk_validate = rtk_info(&position, &azimuth);
    rtk_check(rtk_validate);
    battery_charge_control(state, &position);
    
    drop_state = drop_check();
    if(drop_state == 0)
    {
        if(rtk_validate == 0)
        {
            if(navigation_resume(&StateMachine.resume, &position, azimuth) != 0)
            {
                state = STATE_CRUISE;
            }
        }
        else
        {
            brush_stop();
            motion_set_velocity(0, 0);
        }
    }
    else if(drop_state > 0)
    {
		brush_stop();
        motion_set_velocity(0, 0);
    }
    else if(drop_state < 0)
    {
        Error.DropSensorsFault = 1;
    }
    
    StateMachine.control.methon = METHON_CMD_NONE;
    
    switch((int)StateMachine.control.cmd)
    {
        case CMD_START:
            break;
        case CMD_PAUSE:
            state = STATE_PAUSE_STOP;
            break;
        case CMD_END:
            break;
        case CMD_CLARM:
            safety_clear();
            break;
        case CMD_RESUME:
            break;
        case CMD_CLRESUME:
            break;
        case CMD_FINDSECTOR:
            break;
        default:
            break;
    }
    StateMachine.control.cmd = CMD_NONE;
    
    return state;
}

void auto_state_task(void)
{
    ROBOT_STATE_ENUM state;
    
    if(millis() - StateMachine.task_period >= STATE_TASK_PERIOD)
    {
        StateMachine.task_period = millis();
        
        switch((int)StateMachine.state)
        {
            case STATE_STANDBY_STOP:
                state = auto_standby_stop();
                break;
            case STATE_CHARGE_STOP:
                state = auto_charge_stop();
                break;
            case STATE_EMERGENCY_STOP:
                state = auto_emergency_stop();
                break;
            case STATE_PAUSE_STOP:
                state = auto_pause_stop();
                break;
            case STATE_OUT_GARAGE:
                state = auto_out_garage();
                break;
            case STATE_IN_GARAGE:
                state = auto_in_garage();
                break;
            case STATE_HOMEWARD:
                state = auto_homeward();
                break;
            case STATE_CRUISE:
                state = auto_cruise();
                break;
            case STATE_RESUME:
                state = auto_resume();
                break;
            default:
                state = STATE_EMERGENCY_STOP;
                break;
        }
        
        if(error() != 0)
        {
            if(state > STATE_PAUSE_STOP)
            {
                StateMachine.state_backup = state;
            }
            StateMachine.state = STATE_EMERGENCY_STOP;
        }
        else
        {
            StateMachine.state = state;
        }
    }
}

void state_task(void)
{
    if(StateMachine.methon == METHON_MANUAL)
    {
        manual_state_task();
    }
    else
    {
        auto_state_task();
    }
}

ROBOT_METHON_ENUM state_methon(void)
{
    return StateMachine.methon;
}

ROBOT_STATE_ENUM state_task_state(void)
{
    return StateMachine.state;
}

