#include <stdio.h>
#include <string.h>
#include "uart_utility.h"
#include "communication.h"
#include "utility.h"

#define UART1_RX_BUFF_LENGTH 256
#define UART1_TX_BUFF_LENGTH 1
#define UART2_RX_BUFF_LENGTH 64
#define UART2_TX_BUFF_LENGTH 64
#define UART3_RX_BUFF_LENGTH 256
#define UART3_TX_BUFF_LENGTH 256
#define UART4_RX_BUFF_LENGTH 4096
#define UART4_TX_BUFF_LENGTH 256
#define UART6_RX_BUFF_LENGTH 64
#define UART6_TX_BUFF_LENGTH 64

#pragma pack(1)
typedef struct rtk_dllist_node
{
    DLLNodeBase base;
    uint8_t data[UART1_RX_BUFF_LENGTH-1];
} RTKDLLNode;
    
typedef struct wifi_dllist_node
{
    DLLNodeBase base;
    uint8_t data[UART3_RX_BUFF_LENGTH-1];
} WifiDLLNode;
#pragma pack()

//RTK
RTKDLLNode RTKNodePool[10] = {0};
DLinkList RTKDLLink;
uint8_t uart1rxbuff[UART1_RX_BUFF_LENGTH] = {0};
__attribute__((section(".ARM.__at_0x20000000"))) uint8_t uart1txbuff[UART1_TX_BUFF_LENGTH] = {0}; //DMA只能访问IRAM1内存空间
UartDataStruct_TypeDef UART1DataStruct = {
    .UARTx = (USART_TypeDef *)USART1,
    .DMAx = DMA2,
    .DMA_stream_x = LL_DMA_STREAM_7,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart1rxbuff),
    .RX_TIMEOUT = 4,
    .rx_buff = uart1rxbuff,
    .rx_count = 0,
    .rx_complete = false,
    .rx_timeout = 0,
    .TX_BUFF_SIZE = sizeof(uart1txbuff),
    .tx_buff = uart1txbuff,
    .tx_count = 0,
    .tx_index = 0,
};

//SERVO
uint8_t uart2rxbuff[UART2_RX_BUFF_LENGTH] = {0};
__attribute__((section(".ARM.__at_0x20000000"))) uint8_t uart2txbuff[UART2_TX_BUFF_LENGTH] = {0}; //DMA只能访问IRAM1内存空间
UartDataStruct_TypeDef UART2DataStruct = {
    .UARTx = (USART_TypeDef *)USART2,
    .DMAx = DMA1,
    .DMA_stream_x = LL_DMA_STREAM_6,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart2rxbuff),
    .RX_TIMEOUT = 4,
    .rx_buff = uart2rxbuff,
    .rx_count = 0,
    .rx_complete = false,
    .rx_timeout = 0,
    .TX_BUFF_SIZE = sizeof(uart2txbuff),
    .tx_buff = uart2txbuff,
    .tx_count = 0,
    .tx_index = 0,
};

//WIFI
WifiDLLNode WifiNodePool[10] = {0};
DLinkList WifiDLLink;
uint8_t uart3rxbuff[UART3_RX_BUFF_LENGTH] = {0};
__attribute__((section(".ARM.__at_0x20000000"))) uint8_t uart3txbuff[UART3_TX_BUFF_LENGTH] = {0}; //DMA只能访问IRAM1内存空间
UartDataStruct_TypeDef UART3DataStruct = {
    .UARTx = (USART_TypeDef *)USART3,
    .DMAx = DMA1,
    .DMA_stream_x = LL_DMA_STREAM_3,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart3rxbuff),
    .RX_TIMEOUT = 4,
    .rx_buff = uart3rxbuff,
    .rx_count = 0,
    .rx_complete = false,
    .rx_timeout = 0,
    .TX_BUFF_SIZE = sizeof(uart3txbuff),
    .tx_buff = uart3txbuff,
    .tx_count = 0,
    .tx_index = 0,
};

//4G
uint8_t uart4rxbuff[UART4_RX_BUFF_LENGTH] = {0};
__attribute__((section(".ARM.__at_0x20000000"))) uint8_t uart4txbuff[UART4_TX_BUFF_LENGTH] = {0}; //DMA只能访问IRAM1内存空间
UartDataStruct_TypeDef UART4DataStruct = {
    .UARTx = (USART_TypeDef *)UART4,
    .DMAx = DMA1,
    .DMA_stream_x = LL_DMA_STREAM_4,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart4rxbuff),
    .RX_TIMEOUT = 4,
    .rx_buff = uart4rxbuff,
    .rx_count = 0,
    .rx_complete = false,
    .rx_timeout = 0,
    .TX_BUFF_SIZE = sizeof(uart4txbuff),
    .tx_buff = uart4txbuff,
    .tx_count = 0,
    .tx_index = 0,
};

//BRUSH
uint8_t uart6rxbuff[UART6_RX_BUFF_LENGTH] = {0};
__attribute__((section(".ARM.__at_0x20000000"))) uint8_t uart6txbuff[UART6_TX_BUFF_LENGTH] = {0}; //DMA只能访问IRAM1内存空间
UartDataStruct_TypeDef UART6DataStruct = {
    .UARTx = (USART_TypeDef *)USART6,
    .DMAx = DMA2,
    .DMA_stream_x = LL_DMA_STREAM_6,
    .busy = false,
    .RX_BUFF_SIZE = sizeof(uart6rxbuff),
    .RX_TIMEOUT = 4,
    .rx_buff = uart6rxbuff,
    .rx_count = 0,
    .rx_complete = false,
    .rx_timeout = 0,
    .TX_BUFF_SIZE = sizeof(uart6txbuff),
    .tx_buff = uart6txbuff,
    .tx_count = 0,
    .tx_index = 0,
};

UartDataStruct_TypeDef *hRTK    = &UART1DataStruct;
UartDataStruct_TypeDef *hServo  = &UART2DataStruct;
UartDataStruct_TypeDef *hWIFI   = &UART3DataStruct;
UartDataStruct_TypeDef *h4G     = &UART4DataStruct;
UartDataStruct_TypeDef *hBrush  = &UART6DataStruct;

void uart_init(void)
{
    LL_USART_EnableIT_RXNE(hRTK->UARTx);
    LL_USART_EnableIT_RXNE(hServo->UARTx);
    LL_USART_EnableIT_RXNE(hWIFI->UARTx);
    LL_USART_EnableIT_RXNE(h4G->UARTx);
    LL_USART_EnableIT_RXNE(hBrush->UARTx);
    
    LL_USART_EnableIT_IDLE(hRTK->UARTx);
    LL_USART_EnableIT_IDLE(hServo->UARTx);
    LL_USART_EnableIT_IDLE(hWIFI->UARTx);
    LL_USART_EnableIT_IDLE(h4G->UARTx);
    LL_USART_EnableIT_IDLE(hBrush->UARTx);
    
    LL_USART_EnableIT_TC(hRTK->UARTx);
    LL_USART_EnableIT_TC(hServo->UARTx);
    LL_USART_EnableIT_TC(hWIFI->UARTx);
    LL_USART_EnableIT_TC(h4G->UARTx);
    LL_USART_EnableIT_TC(hBrush->UARTx);
    
    LL_DMA_EnableIT_TC(hRTK->DMAx, hRTK->DMA_stream_x);
    LL_DMA_EnableIT_TC(hServo->DMAx, hServo->DMA_stream_x);
    LL_DMA_EnableIT_TC(hWIFI->DMAx, hWIFI->DMA_stream_x);
    LL_DMA_EnableIT_TC(h4G->DMAx, h4G->DMA_stream_x);
    LL_DMA_EnableIT_TC(hBrush->DMAx, hBrush->DMA_stream_x);
    
    dllist_init(&RTKDLLink, &RTKNodePool, sizeof(RTKNodePool), count(RTKNodePool));
    dllist_init(&WifiDLLink, &WifiNodePool, sizeof(WifiNodePool), count(WifiNodePool));
}

void uart_receive(UartDataStruct_TypeDef *uds, uint8_t byte)
{
    if(!uds->rx_complete)
    {
        if(uds->rx_count < uds->RX_BUFF_SIZE)
        {
            uds->rx_buff[uds->rx_count++] = byte;
            uds->rx_timeout = millis();
        }
    }
}

/* 当使用串口接收空闲中断后就不需要用这个函数来检查一帧数据是否接收完毕 */
void uart_rx_timeout_loop_check(UartDataStruct_TypeDef *uds)
{
    if(!uds->rx_complete && uds->rx_count > 0 && millis() - uds->rx_timeout >= uds->RX_TIMEOUT)
    {
        uds->rx_complete = true;
    }
}

bool uart_rx_complete(UartDataStruct_TypeDef *uds)
{
    return uds->rx_complete;
}

uint8_t *uart_rx_data(UartDataStruct_TypeDef *uds)
{
    return uds->rx_complete ? uds->rx_buff : NULL;
}

uint16_t uart_rx_data_len(UartDataStruct_TypeDef *uds)
{  
    return uds->rx_complete ? uds->rx_count : 0;
}

void uart_rx_clear(UartDataStruct_TypeDef *uds)
{
    uds->rx_count = 0;
    uds->rx_complete = false;
    LL_USART_EnableIT_RXNE(uds->UARTx);
    LL_USART_EnableIT_IDLE(uds->UARTx);
}

//不建议使用这个函数读取数据，因为单片机内存少，没有必要复制一份数据后再处理。
//读数据的方式应该为：uart_rx_complete()来判断是否有数据，然后用uart_rx_data()
//来读取数据所在内存，再用uart_rx_data_len()来读取数据大小。数据处理完后调用
//uart_rx_clear()来清除接收缓存的数据，否则不会接收新数据。
uint16_t uart_read(UartDataStruct_TypeDef *uds, uint8_t *buff, uint16_t size)
{
    uint16_t cnt = 0;
    if(uart_rx_complete(uds))
    {
        cnt = uart_rx_data_len(uds);
        cnt = min(cnt, size);
        memcpy(buff, uart_rx_data(uds), cnt);
        uart_rx_clear(uds);
    }
    return cnt;
}

void uart_send_poll(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len)
{
    uint32_t tick;
    for(uint16_t i = 0; i < len; ++i)
    {
        LL_USART_TransmitData8(uds->UARTx, data[i]);
        tick = millis();
        while(!LL_USART_IsActiveFlag_TC(uds->UARTx) && millis() - tick < 5)
            ;
    }
}

void uart_send_dma(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len)
{
    if(!uds->busy)
    {
        uds->busy = true;
        len = min(len, uds->TX_BUFF_SIZE);
        memcpy(uds->tx_buff, data, len);
        LL_DMA_SetMemoryAddress(uds->DMAx, uds->DMA_stream_x, (uint32_t)uds->tx_buff);
        LL_DMA_SetPeriphAddress(uds->DMAx, uds->DMA_stream_x, (uint32_t)&uds->UARTx->DR);
        LL_DMA_SetDataLength(uds->DMAx, uds->DMA_stream_x, len);
        LL_DMA_EnableStream(uds->DMAx, uds->DMA_stream_x);
        LL_USART_EnableDMAReq_TX(uds->UARTx);
    }
}

void uart_send_it(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len)
{
    if(!uds->busy)
    {
        uds->busy = true;
        len = min(len, uds->TX_BUFF_SIZE);
        memcpy(uds->tx_buff, data, len);
        uds->tx_count = len;
        uds->tx_index = 0;
        LL_USART_EnableIT_TXE(uds->UARTx);
    }
}

//当485在接收数据时不能发送数据，否则接收到的数据就不完整。
//当使用DMA发送数据时必须等待发送完成才能再发送一下次数据。
bool uart_busy(UartDataStruct_TypeDef *uds)
{
    return uds->busy;
}

bool com_format_check(uint8_t *frame, uint16_t len)
{
    bool result = false;
    uint8_t checksum_msg, checksum_calc;
    
    if(len > 16 && frame[0] == FRAME_HEAD && frame[len-1] == FRAME_TAIL)
    {
        checksum_msg = frame[len-2];
        checksum_calc = checksum_xor(frame, len-2);
        result = (checksum_msg == checksum_calc);
    }
    return result;
}

bool rtk_format_check(const char *frame, uint16_t len)
{
    bool result = false;
    uint8_t checksum_msg, checksum_calc = 0;
    
    if(len > 6 && *frame == '$')
    {
        if(sscanf(frame + (len-5), "*%hhx\r\n", &checksum_msg) == 1)
        {
            for(int i = 1; i < len-5; ++i)
            {
                checksum_calc ^= frame[i];
            }
            result = (checksum_msg == checksum_calc);
        }
    }
    return result;
}
