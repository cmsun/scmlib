#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include "map.h"
#include "cJSON.h"
#include "update.h"
#include "watchdog.h"
#include "utility.h"
#include "led.h"
#include "geometry.h"

#define MAP_DEBUG                   1

#define DIR_MAP                     "map"
#define DIR_ROUTER                  "router"
#define DIR_GARAGE                  "gara_"

#define NAME_ROBOT_MAP              "robotmap.dat"
#define NAME_TEMP_MAP               "tempmap.dat"

#define NAME_BLOCK                  "Block.csv"    //��������ݵ��ļ���
#define NAME_CRUISE                 "Cruise.csv"   //����Ѳ�����ݵ��ļ���
#define NAME_OUTGARAGE              "OutGara.csv"  //����������ݵ��ļ���
#define NAME_INGARAGE               "InGara.csv"   //����������ݵ��ļ���
#define NAME_HOMEWARD               "Homeward.csv" //���淵�����ݵ��ļ���

#define KEY_map_feature             "mf"    //��ͼ����
#define KEY_json_data_type          "ndt"   //������������
#define KEY_navigation_points_count "npc"	//���������
#define KEY_navigation_data_details "ndd"	//������������
#define KEY_block_number            "bn"	//����
#define KEY_block_type              "bt"	//������
#define KEY_point_number            "pn"    //����
#define KEY_longitude               "lon"	//����
#define KEY_latitude                "lat"	//γ��
#define KEY_speed                   "sp"    //�ٶ�
#define KEY_brush_speed             "bs"    //ëˢ�ٶ�
#define KEY_garage_number           "gn"	//������
#define KEY_garage_data_type        "gdt"	//������������

//JSON��ͼ�����������ͣ�"ndt"�ؼ���ȡֵ��Χ
typedef enum {
	JSON_DATA_BLOCK  = 0,    //������
	JSON_DATA_CRUISE = 1,    //Ѳ������
	JSON_DATA_GARAGE = 2     //�������ݣ��������������ݡ�������ݡ���������
} JSON_DATA_TYPE;

//JSON��ͼ�����������ͣ�"gdt"�ؼ���ȡֵ��Χ
typedef enum {
	JSON_GARAGE_OUT      = 0,   //��������
	JSON_GARAGE_IN       = 1,   //�������
	JSON_GARAGE_HOMEWARD = 2    //�������ݡ������������ʹ��ڵ���2ʱ�����Ƿ����ߣ���ͬ���ֱ����ǲ�ͬ�����ߡ�
} JSON_GARAGE_TYPE;

#define BLOCK_MAX   2000
typedef struct
{
    uint16_t cruise_line_prev_block;
    uint32_t cruise_addr[BLOCK_MAX];
    uint16_t cruise_total[BLOCK_MAX];
    
    uint16_t homeward_line_start_block;
    uint16_t homeward_line_prev_block;
    uint32_t homeward_addr[BLOCK_MAX];
    uint16_t homeward_total[BLOCK_MAX];
    
    uint16_t parent_block_num[BLOCK_MAX];
} BlockInfoBuff_TypeDef;

RobotMap_TypeDef RobotMap = {0};
RobotMap_TypeDef TempMap = {0};

static bool newmap_create_file(const char *name)
{
    FRESULT res;
    UINT br;
    
    memset(&TempMap, 0, sizeof(RobotMap_TypeDef));
    memcpy(TempMap.head.name, name, sizeof(TempMap.head.name));
    res = f_open(&TempMap.hmap, NAME_TEMP_MAP, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
    if(res == FR_OK)
    {
        res = f_write(&TempMap.hmap, &TempMap.head, sizeof(MapHead_TypeDef), &br);
    }
    return res == FR_OK && br == sizeof(MapHead_TypeDef);
}

static bool newmap_write_block(NavigateBlock_TypeDef *b)
{
    FRESULT res;
    UINT br;
    TempMap.head.block_total++;
    b->checksum = checksum_crc16((uint8_t *)b, sizeof(NavigateBlock_TypeDef)-2);
    res = f_write(&TempMap.hmap, b, sizeof(NavigateBlock_TypeDef), &br); 
    return res == FR_OK && br == sizeof(NavigateBlock_TypeDef);
}

static bool newmap_write_cruise(NavigatePoint_TypeDef *p)
{
    FRESULT res;
    UINT br;
    TempMap.head.cruise_total++;
    p->checksum = checksum_crc16((uint8_t *)p, sizeof(NavigatePoint_TypeDef)-2);
    res = f_write(&TempMap.hmap, p, sizeof(NavigatePoint_TypeDef), &br); 
    return res == FR_OK && br == sizeof(NavigatePoint_TypeDef);
}

static bool newmap_write_garage(NavigatePoint_TypeDef *p)
{
    FRESULT res;
    UINT br = 0;
    
    TempMap.head.garage_cnt = max(TempMap.head.garage_cnt, p->garage_num+1);
    
    p->checksum = checksum_crc16((uint8_t *)p, sizeof(NavigatePoint_TypeDef)-2);
    res = f_write(&TempMap.hmap, p, sizeof(NavigatePoint_TypeDef), &br);

    return res == FR_OK && br == sizeof(NavigatePoint_TypeDef);
}

//cJSON��json�ļ��Ľ�����Ҫ�ϴ�Ķѿռ䣬����heap��СӦ������5K�������json�ļ��Ľ����������

static int newmap_parse_json_block(FIL *fp, cJSON *root)
{
	cJSON *array, *member, *item;
	int elementTotal, size;
	double lon[4], lat[4];
    UINT btw, bw;
	char buff[256];
    NavigateBlock_TypeDef b = {.parent_num = -1};

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if(item == NULL)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }
	elementTotal = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if(array == NULL)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	size = cJSON_GetArraySize(array);
	if(size != elementTotal)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	member = cJSON_GetArrayItem(array, 0);
	if(member == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	item = cJSON_GetObjectItem(member, KEY_block_number);
	if(item == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }
	b.block_num = item->valueint;

	item = cJSON_GetObjectItem(member, KEY_block_type);
	if(item == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }
	b.block_type = (BLOCK_TYPE_ENUM)item->valueint;

	for(int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		lon[i] = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		lat[i] = item->valuedouble;
	}
    
    b.rect.p1.lat = lat[0];
    b.rect.p1.lon = lon[0];
    b.rect.p2.lat = lat[1];
    b.rect.p2.lon = lon[1];
    b.rect.p3.lat = lat[2];
    b.rect.p3.lon = lon[2];
    b.rect.p4.lat = lat[3];
    b.rect.p4.lon = lon[3];
    if(newmap_write_block(&b) == false)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_STORAGE_ERR;
    }

#if MAP_DEBUG
    if(f_tell(fp) == 0)
    {
        btw = snprintf(buff, sizeof(buff), "BlockNum, BlockType, Lat0, Lon0, Lat1, Lon1, Lat2, Lon2, Lat3, Lon3\r\n");
        if(f_write(fp, buff, btw, &bw) != FR_OK)
        {
            errdebug(errlocal());
            return UPDATE_REPLY_STORAGE_ERR;
        }
    }
    
    btw = snprintf(buff, sizeof(buff), "%u,%u,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f,%.13f\r\n",
            b.block_num, b.block_type, lat[0], lon[0], lat[1], lon[1], lat[2], lon[2], lat[3], lon[3]);
    if(f_write(fp, buff, btw, &bw) != FR_OK)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_STORAGE_ERR;
    }
#endif

	return 0;
}

static int newmap_parse_json_cruise(FIL *fp, cJSON *root, BlockInfoBuff_TypeDef *bi)
{
    cJSON *item, *array, *member;
    int elementTotal, size;
    NavigatePoint_TypeDef p = {0};
    UINT btw, bw;

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if(item == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }
	elementTotal = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if(array == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	size = cJSON_GetArraySize(array);
	if(size != elementTotal) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	for(int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_block_number);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.block_num = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_block_type);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.block_type = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_point_number);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.point_num = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.pos.lon = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.pos.lat = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_speed);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.linear_speed = item->valueint;
        
        item = cJSON_GetObjectItem(member, KEY_brush_speed);
        if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
        p.brush_gear = item->valueint;
        
        if(p.block_num < count(bi->cruise_total))
        {
            //bi->cruise_total[p.block_num] += 1;
            if(p.block_num != bi->cruise_line_prev_block && bi->cruise_addr[p.block_num] == 0)
            {
                bi->cruise_line_prev_block = p.block_num;
                bi->cruise_addr[p.block_num] = f_tell(&TempMap.hmap); 
            }
        }
        
        p.navigate_type = NAVIGATE_CRUISE;
        if(newmap_write_cruise(&p) != true)
        {
            errdebug(errlocal());
            return UPDATE_REPLY_STORAGE_ERR;
        }

#if MAP_DEBUG
        char buff[256];
        
        if(f_tell(fp) == 0)
        {
            btw = snprintf(buff, sizeof(buff), "NavigateType,PointNum,BlockNum,BlockType,Lat,Lon,LinearSpeed,BrushGear\r\n");
            if(f_write(fp, buff, btw, &bw) != FR_OK)
            {
                errdebug(errlocal());
                return UPDATE_REPLY_STORAGE_ERR;
            }
        }
        
        btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%u,%.13f,%.13f,%d,%d\r\n",
            p.navigate_type, p.point_num, p.block_num, p.block_type, p.pos.lat, p.pos.lon, p.linear_speed, p.brush_gear);
        if(f_write(fp, buff, btw, &bw) != FR_OK)
        {
            errdebug(errlocal());
            return UPDATE_REPLY_STORAGE_ERR;
        }
#endif
	}

	return 0;
}

static int newmap_parse_json_garage(FIL *fp, cJSON *root, BlockInfoBuff_TypeDef *bi)
{
    cJSON *item, *array, *member;
	int elementTotal, size;
    NavigatePoint_TypeDef p = {0};
    UINT btw, bw;

	item = cJSON_GetObjectItem(root, KEY_navigation_points_count);
	if(item == NULL) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }
	elementTotal = item->valueint;

	array = cJSON_GetObjectItem(root, KEY_navigation_data_details);
	if (array == NULL)
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	size = cJSON_GetArraySize(array);
	if(size != elementTotal) 
    {
        errdebug(errlocal());
        return UPDATE_REPLY_JSON_ERR;
    }

	for(int i = 0; i < size; ++i)
	{
		member = cJSON_GetArrayItem(array, i);

		item = cJSON_GetObjectItem(member, KEY_block_number);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.block_num = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_block_type);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.block_type = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_point_number);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.point_num = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_longitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.pos.lon = item->valuedouble;

		item = cJSON_GetObjectItem(member, KEY_latitude);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.pos.lat = item->valuedouble;
        
        item = cJSON_GetObjectItem(member, KEY_speed);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
        p.linear_speed = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_garage_number);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.garage_num = item->valueint;

		item = cJSON_GetObjectItem(member, KEY_garage_data_type);
		if(item == NULL) 
        {
            errdebug(errlocal());
            return UPDATE_REPLY_JSON_ERR;
        }
		p.navigate_type = (NAVIGATE_TYPE_ENUM)item->valueint;
        
        if(p.block_num < count(bi->homeward_total))
        {
            if(p.point_num == 0)
            {
                bi->homeward_line_prev_block = p.block_num;
                
                if(bi->homeward_addr[p.block_num] == 0)
                {
                    bi->homeward_line_start_block = p.block_num;
                    bi->homeward_addr[p.block_num] = f_tell(&TempMap.hmap);
                }
            }
            else
            {
                if(p.block_num != bi->homeward_line_prev_block)
                {
                    bi->parent_block_num[bi->homeward_line_prev_block] = p.block_num; 
                    bi->homeward_line_prev_block = p.block_num;
                }
            }
            bi->homeward_total[bi->homeward_line_start_block] += 1;
        }
        
        p.homeward_line_num = bi->homeward_line_start_block;
        if(newmap_write_garage(&p) != true)
        {
            errdebug(errlocal());
            return UPDATE_REPLY_STORAGE_ERR;
        }
        
#if MAP_DEBUG
        
        char buff[256], name[32];
        FIL *hFile = NULL;
        static int prev_garage_num = -1; 
        
		if (p.garage_num != prev_garage_num)
		{
			prev_garage_num = p.garage_num;
			snprintf(name, sizeof(name), "%s/%s%d", DIR_ROUTER, DIR_GARAGE, p.garage_num);
			f_mkdir(name);

            f_close(&fp[0]);
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, p.garage_num, NAME_OUTGARAGE);
            f_open(&fp[0], name, FA_CREATE_ALWAYS|FA_WRITE);
            
            f_close(&fp[1]);
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, p.garage_num, NAME_INGARAGE);
            f_open(&fp[1], name, FA_CREATE_ALWAYS|FA_WRITE);
            
            f_close(&fp[2]);
            snprintf(name, sizeof(name), "%s/%s%d/%s", DIR_ROUTER, DIR_GARAGE, p.garage_num, NAME_HOMEWARD);
            f_open(&fp[2], name, FA_CREATE_ALWAYS|FA_WRITE);
		}
        
        if(p.navigate_type == NAVIGATE_OUT)
        {
            hFile = &fp[0];
        }
        else if(p.navigate_type == NAVIGATE_IN)
        {
            hFile = &fp[1];
        }
        else  if(p.navigate_type >= NAVIGATE_HOMEWARD)
        {
            hFile = &fp[2];
        }
        
        if(f_tell(hFile) == 0)
        {
            btw = snprintf(buff, sizeof(buff), "NavigateType,PointNum,BlockNum,BlockType,Lat,Lon,LinearSpeed,BrushGear,GarageNum,HomewardLineNum\r\n");
            if(f_write(hFile, buff, btw, &bw) != FR_OK)
            {
                prev_garage_num = -1;
                errdebug(errlocal());
                return UPDATE_REPLY_STORAGE_ERR;
            }
        }
        
        btw = snprintf(buff, sizeof(buff), "%u,%u,%u,%u,%.13f,%.13f,%d,%u,%u,%u\r\n",
            p.navigate_type, p.point_num, p.block_num, p.block_type, p.pos.lat, p.pos.lon, p.linear_speed, 0, p.garage_num, p.homeward_line_num);
        if(f_write(hFile, buff, btw, &bw) != FR_OK)
        {
            prev_garage_num = -1;
            errdebug(errlocal());
            return UPDATE_REPLY_STORAGE_ERR;
        }
#endif
	}

	return 0;
}

static bool map_modify_block(RobotMap_TypeDef *map, int index, NavigateBlock_TypeDef *b)
{
    FRESULT res = FR_OK;
    UINT bw;
    
    b->checksum = checksum_crc16((uint8_t *)b, sizeof(NavigateBlock_TypeDef)-2);
    res |= f_lseek(&map->hmap, map->head.block_addr + sizeof(NavigateBlock_TypeDef)*index);
    res |= f_write(&map->hmap, b, sizeof(NavigateBlock_TypeDef), &bw);
    return res == FR_OK && bw == sizeof(NavigateBlock_TypeDef);
}

static bool newmap_update_finish(BlockInfoBuff_TypeDef *info)
{ 
    UINT br;
    NavigateBlock_TypeDef block, children;
    NavigatePoint_TypeDef point, end_point;
    const uint32_t SIZE = sizeof(NavigatePoint_TypeDef);
    uint32_t block_num, prev_block_num, first_point_addr, end_point_addr;
    
    for(int i = 0; i < count(info->homeward_addr); ++i)
    {
        if(info->homeward_addr[i] != 0)
        {
            block_num = i;
            prev_block_num = i;
            first_point_addr = info->homeward_addr[block_num];
            end_point_addr = first_point_addr + SIZE*(info->homeward_total[block_num]-1);
            f_lseek(&TempMap.hmap, end_point_addr);
            f_read(&TempMap.hmap, &end_point, SIZE, &br);
            f_lseek(&TempMap.hmap, first_point_addr);
            for(int j = 0; j < info->homeward_total[block_num]; ++j)
            {
                f_read(&TempMap.hmap, &point, SIZE, &br);
                if(point.block_num != prev_block_num)
                {
                    prev_block_num = point.block_num;
                    if(info->homeward_addr[point.block_num] == 0    //�����ͼ�黹û�з����ߵ�ַ
                        || point.block_num != end_point.block_num)  //�����ͼ���Ѿ������������ߵĵ�ַ�����ǵ�ǰ�������ӳ�����һ���飬˵����ǰ�����߲ŵ������ͼ��ķ�����
                    {
                        info->homeward_addr[point.block_num] = first_point_addr + SIZE*j;
                        info->homeward_total[point.block_num] = info->homeward_total[block_num] - j;
                    }
                }
            }
        }
    }
    
    TempMap.head.block_addr = sizeof(MapHead_TypeDef);
    TempMap.head.cruise_addr = TempMap.head.block_addr + sizeof(NavigateBlock_TypeDef)*TempMap.head.block_total;
    for(int i = 0; i < TempMap.head.block_total; ++i)
    {
        if(map_read_block(&TempMap, i, &block, 1))
        {
            block.cruise_addr = info->cruise_addr[i];
            block.cruise_total = info->cruise_total[i];
            block.homeward_addr = info->homeward_addr[i];
            block.homeward_total = info->homeward_total[i];
            block.parent_num = info->parent_block_num[i];
            
            if(block.block_type == GARAGE)
            {
                if(map_read_block_homeward(&TempMap, &block, 1, &point, 1))
                {
                    for(int j = 0; j < TempMap.head.block_total; ++j)
                    {
                        if(map_read_block(&TempMap, j, &children, 1)
                            && children.block_type == SOLAR_PANEL
                            && gps_rectangle_contain(&children.rect, &point.pos))
                        {
                            info->parent_block_num[children.block_num] = block.block_num;
                        }
                    }
                }
                else
                {
                    return false;
                }
            }
            
            if(map_modify_block(&TempMap, i, &block) != true)
            {
                return false;
            }
        }
        else
        {
            return false;
        }
    }
    
    f_rewind(&TempMap.hmap);
    if(f_write(&TempMap.hmap, &TempMap.head, sizeof(MapHead_TypeDef), &br) == FR_OK)
    {
        f_close(&RobotMap.hmap);
        f_close(&TempMap.hmap);
        f_unlink(NAME_ROBOT_MAP);   //ɾ���Ѿ����ڵ��ļ��������޷���������ͬ���ļ�   
        if((f_rename(NAME_TEMP_MAP, NAME_ROBOT_MAP)) == FR_OK)
        {
            map_init();
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

int map_json_convert_binary (const char *json)
{
	char buff[2048], name[32];
	cJSON *root, *item, *timestamp;
	int result = 0, json_data_type;
	FIL hJson, hBlock, hCruise, hGarage[3];
    FRESULT res = FR_OK;
    BlockInfoBuff_TypeDef blockinfo = {0};
    
    led_off(LED_0);
    led_off(LED_2);
    led_on(LED_1);
    
    snprintf(name, sizeof(name), "%s/%s", DIR_MAP, json);
	res |= f_open(&hJson, name, FA_OPEN_EXISTING|FA_READ);
#if MAP_DEBUG
    f_deldir(DIR_ROUTER);
	res = f_mkdir(DIR_ROUTER);
	snprintf(name, sizeof(name), "%s/%s", DIR_ROUTER, NAME_BLOCK);
	res |= f_open(&hBlock, name, FA_CREATE_ALWAYS|FA_WRITE);
	snprintf(name, sizeof(name), "%s/%s", DIR_ROUTER, NAME_CRUISE);
	res |= f_open(&hCruise, name, FA_CREATE_ALWAYS|FA_WRITE);
#endif
    
    if(newmap_create_file(json) == false)
    {
        errdebug(errlocal());
        result = UPDATE_REPLY_STORAGE_ERR;
        goto out;
    }
    
    for(uint32_t i = 0; i < count(blockinfo.parent_block_num); ++i)
    {
        blockinfo.parent_block_num[i] = -1;
    }
	
    while(!f_eof(&hJson))
	{
		watchdog_feed();
		
        f_gets(buff, sizeof(buff), &hJson);
		root = cJSON_Parse(buff);
		if(root != NULL)
		{
            if((item = cJSON_GetObjectItem(root, KEY_json_data_type)) != NULL)
			{
				json_data_type = item->valueint;
				if(json_data_type == JSON_DATA_BLOCK)
                {
                    result = newmap_parse_json_block(&hBlock, root);
                }
                else if(json_data_type == JSON_DATA_CRUISE)
                {
                    result = newmap_parse_json_cruise(&hCruise, root, &blockinfo);
                }
                else if(json_data_type == JSON_DATA_GARAGE)
                {
                    result = newmap_parse_json_garage(hGarage, root, &blockinfo);
                }
			}
            else if((item = cJSON_GetObjectItem(root, KEY_map_feature)) != NULL)
            {                
                if((timestamp = cJSON_GetArrayItem(item, 0)) != NULL)
                {
                    TempMap.head.timestamp = atoll(timestamp->valuestring);
                }
                else
                {
                    result = UPDATE_REPLY_JSON_ERR;
                }
            }
            
			cJSON_Delete(root);
            
            if(result != 0)
            {
                goto out;
            }
		}
		else
		{
            errdebug(errlocal());
            result = UPDATE_REPLY_JSON_ERR;
		}
	}
    
    if(newmap_update_finish(&blockinfo) != true)
    {
        errdebug(errlocal());
        result = UPDATE_REPLY_STORAGE_ERR;
    }

out:
    led_off(LED_1);
	f_close(&hJson);
#if MAP_DEBUG
	f_close(&hBlock);
    f_close(&hCruise);
	f_close(&hGarage[0]);
    f_close(&hGarage[1]);
    f_close(&hGarage[2]);
#endif

	return result;
}

void map_init(void)
{
    UINT br;
    
    if(f_open(&RobotMap.hmap, NAME_ROBOT_MAP, FA_OPEN_EXISTING|FA_READ|FA_WRITE) == FR_OK)
    {
        if(f_read(&RobotMap.hmap, &RobotMap.head, sizeof(MapHead_TypeDef), &br) == FR_OK
            && br == sizeof(MapHead_TypeDef))
        {
            RobotMap.valid = true;
        }
        else
        {
            RobotMap.valid = false;
        }
    }
    else
    {
        RobotMap.valid = false;
    }
}

int map_read_block(RobotMap_TypeDef *map, int index, NavigateBlock_TypeDef *b, int cnt)
{
    FRESULT res = FR_OK;
    int read_cnt = 0;
    UINT bw;
    
    cnt = (index+cnt > map->head.block_total ? map->head.block_total-index : cnt);
    res |= f_lseek(&map->hmap, map->head.block_addr + sizeof(NavigateBlock_TypeDef)*index);
    res |= f_read(&map->hmap, b, sizeof(NavigateBlock_TypeDef)*cnt, &bw);
    if(res == FR_OK)
    {
        cnt = bw / sizeof(NavigateBlock_TypeDef);
        for(int i = 0; i < cnt; ++i)
        {
            if(b[i].block_num == index + i
                && b[i].checksum == checksum_crc16((uint8_t *)(b+i), sizeof(NavigateBlock_TypeDef)-2))
            {
                read_cnt++;
            }
            else
            {
                read_cnt = 0;
                break;
            }
        }
    }
    
    return read_cnt;
}

int map_read_cruise(RobotMap_TypeDef *map, int index, NavigatePoint_TypeDef *p, int cnt)
{
    FRESULT res = FR_OK;
    int read_cnt = 0;
    UINT bw;
    
    cnt = (index+cnt > map->head.cruise_total ? map->head.cruise_total-index : cnt);
    res |= f_lseek(&map->hmap, map->head.cruise_addr + sizeof(NavigatePoint_TypeDef)*index);
    res |= f_read(&map->hmap, p, sizeof(NavigatePoint_TypeDef)*cnt, &bw);
    if(res == FR_OK)
    {
        cnt = bw / sizeof(NavigatePoint_TypeDef);
        for(int i = 0; i < cnt; ++i)
        {
            if(p[i].point_num == index + i
                && p[i].checksum == checksum_crc16((uint8_t *)&p[i], sizeof(NavigatePoint_TypeDef)-2))
            {
                read_cnt++;
            }
            else
            {
                read_cnt = 0;
                break;
            }
        }
    }
    
    return read_cnt;
}

int map_read_block_cruise(RobotMap_TypeDef *map, int block_num, int index, NavigatePoint_TypeDef *p, int cnt)
{
    FRESULT res = FR_OK;
    int read_cnt = 0;
    UINT bw;
    NavigateBlock_TypeDef block = {0};
    
    if(map_read_block(map, block_num, &block, 1) && block.cruise_addr != 0)
    {
        cnt = (index+cnt > map->head.cruise_total ? map->head.cruise_total-index : cnt);
        res |= f_lseek(&map->hmap, block.cruise_addr + sizeof(NavigatePoint_TypeDef)*index);
        res |= f_read(&map->hmap, p, sizeof(NavigatePoint_TypeDef)*cnt, &bw);
        if(res == FR_OK)
        {
            cnt = bw / sizeof(NavigatePoint_TypeDef);
            for(int i = 0; i < cnt; ++i)
            {
                if(p[i].point_num == index + i
                    && p[i].checksum == checksum_crc16((uint8_t *)&p[i], sizeof(NavigatePoint_TypeDef)-2))
                {
                    read_cnt++;
                }
                else
                {
                    read_cnt = 0;
                    break;
                }
            }
        }
    }

    return read_cnt;
}

int map_read_homeward(RobotMap_TypeDef *map, int block_num, int index, NavigatePoint_TypeDef *p, int cnt)
{
    FRESULT res = FR_OK;
    int read_cnt = 0;
    UINT bw;
    NavigateBlock_TypeDef block = {0};
    
    if(map_read_block(map, block_num, &block, 1) && block.homeward_addr != 0)
    {
        cnt = (index+cnt > block.homeward_total ? block.homeward_total-index : cnt);
        res |= f_lseek(&map->hmap, block.homeward_addr + sizeof(NavigatePoint_TypeDef)*index);
        res |= f_read(&map->hmap, p, sizeof(NavigatePoint_TypeDef)*cnt, &bw);
        if(res == FR_OK)
        {
            cnt = bw / sizeof(NavigatePoint_TypeDef);
            index = p[0].point_num;
            for(int i = 0; i < cnt; ++i)
            {
                if(/*p[i].point_num == index + i
                    &&*/ p[i].checksum == checksum_crc16((uint8_t *)&p[i], sizeof(NavigatePoint_TypeDef)-2))
                {
                    read_cnt++;
                }
                else
                {
                    read_cnt = 0;
                    break;
                }
            }
        }
    }

    return read_cnt;
}

int map_read_block_homeward(RobotMap_TypeDef *map, NavigateBlock_TypeDef *block, int index, NavigatePoint_TypeDef *p, int cnt)
{
    FRESULT res = FR_OK;
    int read_cnt = 0;
    UINT bw;
    
    if(block->homeward_addr != 0)
    {
        cnt = (index+cnt > block->homeward_total ? block->homeward_total-index : cnt);
        res |= f_lseek(&map->hmap, block->homeward_addr + sizeof(NavigatePoint_TypeDef)*index);
        res |= f_read(&map->hmap, p, sizeof(NavigatePoint_TypeDef)*cnt, &bw);
        if(res == FR_OK)
        {
            cnt = bw / sizeof(NavigatePoint_TypeDef);
            index = p[0].point_num;
            for(int i = 0; i < cnt; ++i)
            {
                if(/*p[i].point_num == index + i
                    &&*/ p[i].checksum == checksum_crc16((uint8_t *)&p[i], sizeof(NavigatePoint_TypeDef)-2))
                {
                    read_cnt++;
                }
                else
                {
                    read_cnt = 0;
                    break;
                }
            }
        }
    }

    return read_cnt;
}

//����ֵ�������ȡʧ�ܷ���-1�������ȡ�ɹ����ؿ����(0��n)
int map_get_local_block(const GPS_Point_TypeDef *point, NavigateBlock_TypeDef *block)
{
    int block_num = -1;
    int index = 0, cnt;
    NavigateBlock_TypeDef blockarr[50];
    
    do{
        cnt = map_read_block(&RobotMap, index, blockarr, count(blockarr));
        index += cnt;
        for(int i = 0; i < cnt; ++i)
        {
            if(gps_rectangle_contain(&(blockarr[i].rect), point))
            {
                memcpy(block, blockarr+i, sizeof(NavigateBlock_TypeDef));
                block_num = blockarr[i].block_num;
                break;
            }
        }
    }while(cnt == count(blockarr));
    
    return block_num;
}
