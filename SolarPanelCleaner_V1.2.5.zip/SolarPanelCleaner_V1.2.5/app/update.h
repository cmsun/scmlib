/*
********************************************************************************
*                              COPYRIGHT NOTICE
*                             Copyright (c) 2016
*                             All rights reserved
*
*  @fileName       : mod_update.h
*  @author         : scm 351721714@qq.com
*  @create         : 2019/01/27 10:24:26
********************************************************************************
*/
#ifndef _UPDATE_H
#define _UPDATE_H

#include <stdint.h>
#include "uart_utility.h"

#define UPDATE_FRAME_HEAD       0x20    //帧头
#define UPDATE_FRAME_TAIL       0x88    //帧尾
#define UPDATE_FRAME_CMD        0x71    //命令帧类型
#define UPDATE_FRAME_DATA       0x7A    //数据帧类型
#define UPDATE_FRAME_SELECT_MAP 0x7E    //地图选择帧

//通信错误定义
typedef enum {
    UPDATE_REPLY_READY = 1,          //接收方做好准备，发送方可以发送数据
    UPDATE_REPLY_COMPLETE = 2,       //接收传输完成
    UPDATE_REPLY_ROBOT_RUNNING = 3,  //机器人正在运行，不能操作
    UPDATE_REPLY_STORAGE_ERR = 4,    //存储器错误
    UPDATE_REPLY_FRAME_ERR = 5,      //通信帧格式错误
    UPDATE_REPLY_COMMAND_ERR = 6,    //不存在的传输指令
    UPDATE_REPLY_SEQUENCE_ERR = 7,   //传输顺序错误
    UPDATE_REPLY_MD5_ERR = 8,        //MD5校验错误
    UPDATE_REPLY_JSON_ERR = 9,       //地图JSON文件格式错误
} UPDATE_REPLY_STATE;

typedef enum {
	UPDATE_STATE_IDLE,                  //没有在传输文件，可以上传心跳
	UPDATE_STATE_BUSY,                  //输文件中，不可以上传心跳
	UPDATE_STATE_COMPLETE,              //文件传输完成，等待复位升级
} UPDATE_STATE;

typedef uint16_t (* UPDATE_SEND_FUNC)(uint8_t *, uint16_t); //文件传输所使用的通信端口的发送函数

#pragma pack(1)

typedef struct Update_Cmd_Req
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
    uint8_t command;
    uint32_t firmwareSize;
    uint8_t fileType;
    uint8_t reserve[3];
    uint8_t checkSum;
    uint8_t tail;
} Update_Cmd_Req;

typedef struct Update_Cmd_Ack
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
    uint8_t buildDate[4];
	uint8_t command;
    uint8_t acknowledge;
    uint8_t fileType;
    uint8_t reserve[3];
    uint8_t checkSum;
    uint8_t tail;
} Update_Cmd_Ack;

typedef struct Update_Transmit_Req
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
    uint8_t dataType;
    uint16_t sendCnt;
    uint32_t firmwareOffset;
    uint8_t data;
} Update_Transmit_Req;

typedef struct Update_Transmit_Ack
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
    uint8_t buildDate[4];
	uint8_t dataType;
    uint8_t acknowledge;
    uint32_t nextOffset;
    uint8_t fileType;
    uint8_t reserve[3];
    uint8_t checkSum;
    uint8_t tail;
} Update_Transmit_Ack;

typedef struct Update_MapSelect_Req
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
	uint8_t fileNameLen;
    int8_t fileName;
} Update_MapSelect_Req;

typedef struct Update_MapSelect_Ack
{
    uint8_t head;
    uint8_t type;
    uint16_t length;
    uint8_t serial;
    uint8_t ID[9];
    uint8_t buildDate[4];
	uint8_t acknowledge;
    uint8_t reserve[4];
    uint8_t checkSum;
    uint8_t tail;
} Update_MapSelect_Ack;

#pragma pack()

void update_cmd_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds);
void update_transmit_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds);
void update_map_select_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds);
void update_timeout_loop_check(void);
UPDATE_STATE update_state(void);

#endif /* end of include guard: _UPDATE_H */
