#ifndef _LED_H_
#define _LED_H_

#include <stdint.h>

typedef enum {
    LED_0,
    LED_1,
    LED_2
} LED_ENUM;

void led_init(void);
void led_on(LED_ENUM led);
void led_off(LED_ENUM led);
void led_toggle(LED_ENUM led);
void led_blink_task(LED_ENUM led, uint8_t Hz, float duty);

#endif