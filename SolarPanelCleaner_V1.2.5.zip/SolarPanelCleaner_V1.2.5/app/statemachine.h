#ifndef _STATEMACHINE_H_
#define _STATEMACHINE_H_

#include <stdint.h>
#include <stdbool.h>
#include "map.h"

typedef enum
{
    METHON_CMD_NONE = 0,
    METHON_CMD_MANUAL,
    METHON_CMD_AUTO
} METHON_CMD_ENUM;

typedef enum
{
    CMD_NONE = 0,
	CMD_START,
    CMD_PAUSE,
    CMD_END,
	CMD_CLARM,
	CMD_RESUME,
	CMD_CLRESUME,
    CMD_FINDSECTOR
} STATE_CMD_ENUM;

typedef enum
{
    BRUSH_CMD_NONE = 0,
    BRUSH_CMD_DISABLE,
    BRUSH_CMD_ENABLE
} BRUSH_CMD_ENUM;;

typedef enum
{
    MANUAL_VELOCITY_MASTER_NONE,
    MANUAL_VELOCITY_MASTER_APP,     //�ֶ�����ʱ���ֻ�APP��ȡ�ٶȣ����ٶȲ�Ϊ0
    MANUAL_VELOCITY_MASTER_SERVER,  //�ֶ�����ʱ�ӷ�������ȡ�ٶȣ����ٶȲ�Ϊ0
} MANUAL_VELOCITY_MASTER;

typedef enum
{
    METHON_MANUAL,
    METHON_ATUO
} ROBOT_METHON_ENUM;

typedef enum
{
	STATE_STANDBY_STOP = 0,
	STATE_CHARGE_STOP,
	STATE_EMERGENCY_STOP,
	STATE_PAUSE_STOP,
	STATE_OUT_GARAGE,
	STATE_IN_GARAGE,
	STATE_HOMEWARD,
	STATE_CRUISE,
	STATE_RESUME,
    STATE_NONE,
} ROBOT_STATE_ENUM;

typedef struct
{
    METHON_CMD_ENUM methon;
    STATE_CMD_ENUM cmd;
    MANUAL_VELOCITY_MASTER master;
    bool app_online;
    bool server_online;
    float linear_vel;               //UNIT: m/min
    float angluar_vel;              //UNIT: rad/min
    BRUSH_CMD_ENUM brush_cmd;       //�ֶ�ģʽ��ëˢ����ָ��
} RobotController_TypeDef;

typedef struct
{
    uint32_t task_period;
    ROBOT_METHON_ENUM methon;
    ROBOT_STATE_ENUM state;
    ROBOT_STATE_ENUM state_backup;
    RobotController_TypeDef control;
    NavigatePoint_TypeDef resume;
} RobotStateMachine_TypeDef;

void state_init(void);
void state_task(void);
void record_task(void);
ROBOT_METHON_ENUM state_methon(void);
ROBOT_STATE_ENUM state_task_state(void);

#endif