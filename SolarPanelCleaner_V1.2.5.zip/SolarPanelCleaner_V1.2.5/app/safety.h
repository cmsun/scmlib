#ifndef _MOD_SAFETY_H_
#define _MOD_SAFETY_H_

#include <stdint.h>

typedef struct
{    
    uint32_t OneBatTempSensorErr:1;		//0
    uint32_t OneCabTempSensorErr:1;
    uint32_t BatTempAbnormal:1;
    uint32_t CabTempAbnormal:1;

    uint32_t RunForbiddenByAmuzith:1;	//4
    uint32_t RunForbiddenByTemp:1;
    uint32_t RunForbiddenByBatCap:1;
    uint32_t RunForbiddenByPos:1;

    uint32_t BatteryVolLow:1; 			//8
    uint32_t BatteryCapLow:1;
    uint32_t CellularAbnormal:1;
    uint32_t DropSensorsWarn:1;

    uint32_t StopButNotTrigSwitch:1;    //12
    uint32_t ChargingNoCurrent:1;
    uint32_t ChargeForbiddenByTemp:1;
    uint32_t BrushOutOfCtl:1;
    
    uint32_t BrushDriverPmip:1;      	//16
    uint32_t BrushDriverAlam:1;
    uint32_t OutGarageWrongAmuzith:1;
    uint32_t RtkErrorToReboot:1;
    
    uint32_t ImuNeedCorrect:1;          //20
    uint32_t DriverNotReady:1;
    uint32_t RollToEdge:1;
    uint32_t CruiseToEdge:1;

    uint32_t RtkAntDisConnect:1;        //24
    uint32_t Warning_25:1;
    uint32_t Warning_26:1;
    uint32_t ImuValueFault:1;
    
    uint32_t AzimuthDisConnnect:1;      //28
    uint32_t AzimuthValue:1;
    uint32_t AzimuthChange:1;
    uint32_t AzimuthChangeInSecond:1;  
} Warning_TypeDef;

typedef struct 
{    
    uint32_t SdCard:1;                  //0
    uint32_t Eeprom:1;
    uint32_t Mpu6515Err:1;              
    uint32_t Hmc5843Err:1;

    uint32_t RtkConnectFailed:1;        //4
    uint32_t MagnetNaviFault:1;
    uint32_t RunHoldBack:1;
    uint32_t PosOnNoneResumeLine:1;

    uint32_t CoordInfo:1;               //8
    uint32_t GetSectorType:1;
    uint32_t PosSearchGarage:1;
    uint32_t FindLine:1;

    uint32_t BatTempSensor:1;           //12
    uint32_t CabTempSensor:1;
    uint32_t RollDrift:1;
    uint32_t DropSensorsFault:1;

    uint32_t LeftDriverConnect:1;       //16
    uint32_t LeftDriverControl:1;    
    uint32_t LeftDriverPmip:1;
    uint32_t LeftDriverAlam:1;          
    
    uint32_t RightDriverConnect:1;      //20
    uint32_t RightDriverControl:1;
    uint32_t RightDriverPmip:1;
    uint32_t RightDriverAlam:1;
    
    uint32_t MagneticSensorOffline:1;   //24
    uint32_t SampleBoardOffline:1;
    uint32_t BatteryBmsOffline:1;
    uint32_t BrushDriverOffline:1;
    
    uint32_t RtkPositionFault:1;        //28
    uint32_t RtkAzimuthFault:1;
    uint32_t InGarageNoTrig:1;
    uint32_t InGarageShift:1; 
} Error_TypeDef;

extern Warning_TypeDef Warning;
extern Error_TypeDef   Error;

static inline uint32_t warning(void)
{
    return *(uint32_t *)&Warning;
}

static inline uint32_t error(void)
{
    return *(uint32_t *)&Error;
}

static inline void safety_clear(void)
{
    *(uint32_t *)&Warning = 0;
    *(uint32_t *)&Error = 0;
}

#endif
