#include "main.h"
#include "iwdg.h"
#include "utility.h"
#include "watchdog.h"

void watchdog_init(void)
{
    MX_IWDG_Init();
}

void watchdog_feed(void)
{
    LL_GPIO_TogglePin(WDI_GPIO_Port, WDI_Pin);
    HAL_IWDG_Refresh(&hiwdg);
}

void watchdog_task(void)
{
    static uint32_t period = 0;
    if(millis() - period >= 100)
    {
        period = millis();
        watchdog_feed();
    }
}