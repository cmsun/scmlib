#ifndef _PWRCTRL_H_
#define _PWRCTRL_H_

#include <stdint.h>
#include "main.h"

typedef enum
{
    POWER_STATE_OFF,
    POWER_STATE_ON,
    POWER_STATE_WAIT,
} PowerState;

typedef enum
{
    POWER_CMD_NONE,
    POWER_CMD_OFF,
    POWER_CMD_ON,
    POWER_CMD_RESET,
} PowerCmd;

typedef struct
{
    PowerState state;
    PowerCmd cmd;
    uint32_t waittime;
    GPIO_TypeDef *port;
    uint16_t pin;
} PowerControl_TypeDef;

void pwr_init(void);
void pwr_task(void);
void pwr_wifi_cmd(PowerCmd cmd);
void pwr_4g_cmd(PowerCmd cmd);
void pwr_rtk_cmd(PowerCmd cmd);
void pwr_motion_cmd(PowerCmd cmd);
PowerState pwr_wifi_state(void);
PowerState pwr_4g_state(void);
PowerState pwr_rtk_state(void);
PowerState pwr_motion_state(void);

#endif