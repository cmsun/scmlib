#include "sensor.h"
#include "utility.h"
#include "parameter.h"
#include "config.h"
#include "modbusdevs.h"
    
typedef struct
{
    GPIO_TypeDef *port;
    uint32_t pin;
    SENSOR_STATE state;
    uint32_t delay;
} SensorUnit_TypeDef;

SensorUnit_TypeDef SensorLeftFront;
SensorUnit_TypeDef SensorLeftRear;
SensorUnit_TypeDef SensorRightFront;
SensorUnit_TypeDef SensorRightRear;
SensorUnit_TypeDef SensorPark;

void sensor_init(void)
{
    SensorLeftFront.port = APEXIN0_GPIO_Port;
    SensorLeftFront.pin = APEXIN0_Pin;
    SensorLeftFront.state = SENSOR_OFF;
    SensorLeftFront.delay = millis();
    
    SensorLeftRear.port = APEXIN2_GPIO_Port;
    SensorLeftRear.pin = APEXIN2_Pin;
    SensorLeftRear.state = SENSOR_OFF;
    SensorLeftRear.delay = millis();
    
    SensorRightFront.port = APEXIN1_GPIO_Port;
    SensorRightFront.pin = APEXIN1_Pin;
    SensorRightFront.state = SENSOR_OFF;
    SensorRightFront.delay = millis();
    
    SensorRightRear.port = APEXIN3_GPIO_Port;
    SensorRightRear.pin = APEXIN3_Pin;
    SensorRightRear.state = SENSOR_OFF;
    SensorRightRear.delay = millis();
    
#ifdef VERSION_D2
    SensorPark.port = APEXIN7_GPIO_Port;
    SensorPark.pin = APEXIN7_Pin;
#else
    SensorPark.port = APEXIN4_GPIO_Port;
    SensorPark.pin = APEXIN4_Pin;
#endif
    SensorPark.state = SENSOR_OFF;
    SensorPark.delay = millis();
}

static void sensor_judge_state(SensorUnit_TypeDef *sensor)
{
    if(sensor->state != (SENSOR_STATE)HAL_GPIO_ReadPin(sensor->port, sensor->pin))
    {
        if(millis() - sensor->delay >= 5)
        {
            sensor->state = (SENSOR_STATE)HAL_GPIO_ReadPin(sensor->port, sensor->pin);
        }
    }
    else
    {
        sensor->delay = millis();
    }
}

void sensor_task(void)
{
    static uint32_t period = 0;
    
    if(millis() - period >= 1)
    {
        period = millis();
        
        sensor_judge_state(&SensorLeftFront);
        sensor_judge_state(&SensorLeftRear);
        sensor_judge_state(&SensorRightFront);
        sensor_judge_state(&SensorRightRear);
        sensor_judge_state(&SensorPark);
    }
}

uint8_t sensor_get_bits(void)
{
    uint8_t res = 0;
    
#if USE_RADAR_SENSOR
    if(radar_left_front() == SENSOR_ON)
        res |= 1<<0;
    if(radar_right_front() == SENSOR_ON)
        res |= 1<<1;
    if(radar_left_rear() == SENSOR_ON)
        res |= 1<<2;
    if(radar_right_rear() == SENSOR_ON)
        res |= 1<<3;
    if(SensorPark.state == SENSOR_ON)
        res |= 1<<4;
#else
    if(SensorLeftFront.state == SENSOR_ON)
        res |= 1<<0;
    if(SensorRightFront.state == SENSOR_ON)
        res |= 1<<1;
    if(SensorLeftRear.state == SENSOR_ON)
        res |= 1<<2;
    if(SensorRightRear.state == SENSOR_ON)
        res |= 1<<3;
    if(SensorPark.state == SENSOR_ON)
        res |= 1<<4;
#endif
    
    return res;
}

#if USE_RADAR_SENSOR
SENSOR_STATE sensor_left_front(void) { return RobotParam.sensor_mask.bit.limit_left_front ? SENSOR_OFF : radar_left_front(); }
SENSOR_STATE sensor_left_rear(void) { return RobotParam.sensor_mask.bit.limit_left_rear ? SENSOR_OFF : radar_left_rear(); }
SENSOR_STATE sensor_right_front(void) { return RobotParam.sensor_mask.bit.limit_right_front ? SENSOR_OFF : radar_right_front(); }
SENSOR_STATE sensor_right_rear(void) { return RobotParam.sensor_mask.bit.limit_right_rear ? SENSOR_OFF : radar_right_rear(); }
#else
SENSOR_STATE sensor_left_front(void) { return RobotParam.sensor_mask.bit.limit_left_front ? SENSOR_OFF : SensorLeftFront.state; }
SENSOR_STATE sensor_left_rear(void) { return RobotParam.sensor_mask.bit.limit_left_rear ? SENSOR_OFF : SensorLeftRear.state; }
SENSOR_STATE sensor_right_front(void) { return RobotParam.sensor_mask.bit.limit_right_front ? SENSOR_OFF : SensorRightFront.state; }
SENSOR_STATE sensor_right_rear(void) { return RobotParam.sensor_mask.bit.limit_right_rear ? SENSOR_OFF : SensorRightRear.state; }
#endif
SENSOR_STATE sensor_park(void) { return SensorPark.state; }