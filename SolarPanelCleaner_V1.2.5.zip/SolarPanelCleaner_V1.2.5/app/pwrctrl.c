#include "pwrctrl.h"
#include "main.h"
#include "gpio.h"
#include "utility.h"

PowerControl_TypeDef PwrCtrlWifi = {.port = WIFI_PWR_CTRL_GPIO_Port, .pin = WIFI_PWR_CTRL_Pin};
PowerControl_TypeDef PwrCtrl4G = {.port = Cellular_PWR_CTRL_GPIO_Port, .pin = Cellular_PWR_CTRL_Pin};
PowerControl_TypeDef PwrCtrlRTK = {.port = RTK_PWR_CTRL_GPIO_Port, .pin = RTK_PWR_CTRL_Pin};
PowerControl_TypeDef PwrCtrlMotion = {.port = APEXOUT0_GPIO_Port, .pin = APEXOUT0_Pin};

void pwr_init(void)
{
    pwr_wifi_cmd(POWER_CMD_ON);
    pwr_4g_cmd(POWER_CMD_ON);
    pwr_rtk_cmd(POWER_CMD_ON);
    pwr_motion_cmd(POWER_CMD_OFF);
}

void pwr_wifi_cmd(PowerCmd cmd)
{
    PwrCtrlWifi.cmd = cmd;
}

void pwr_4g_cmd(PowerCmd cmd)
{
    PwrCtrl4G.cmd = cmd;
}

void pwr_rtk_cmd(PowerCmd cmd)
{
    PwrCtrlRTK.cmd = cmd;
}

void pwr_motion_cmd(PowerCmd cmd)
{
    PwrCtrlMotion.cmd = cmd;
}

PowerState pwr_wifi_state(void)
{
    return PwrCtrlWifi.state;
}

PowerState pwr_4g_state(void)
{
    return PwrCtrl4G.state;
}

PowerState pwr_rtk_state(void)
{
    return PwrCtrlRTK.state;
}

PowerState pwr_motion_state(void)
{
    return PwrCtrlMotion.state;
}

static void pwr_cmd_process(PowerControl_TypeDef *dev, uint32_t delay2on, uint32_t reset_delay)
{
    if(dev->cmd == POWER_CMD_OFF)
    {
        dev->cmd = POWER_CMD_NONE;
        dev->state = POWER_STATE_OFF;
        LL_GPIO_ResetOutputPin(dev->port, dev->pin);
    }
    else if(dev->cmd == POWER_CMD_ON)
    {
        if(dev->state == POWER_STATE_OFF)
        {
            dev->state = POWER_STATE_WAIT;
            dev->waittime = millis();
            LL_GPIO_SetOutputPin(dev->port, dev->pin);
        }
        else if(dev->state == POWER_STATE_WAIT)
        {
            if(millis() - dev->waittime >= delay2on)
            {
                dev->cmd = POWER_CMD_NONE;
                dev->state = POWER_STATE_ON;
            }
        }
    }
    else if(dev->cmd == POWER_CMD_RESET)
    {
        if(dev->state == POWER_STATE_OFF)
        {
            dev->cmd = POWER_CMD_ON;
        }
        else if(dev->state == POWER_STATE_ON)
        {
            dev->state = POWER_STATE_WAIT;
            dev->waittime = millis();
            LL_GPIO_ResetOutputPin(dev->port, dev->pin);
        }
        else if(dev->state == POWER_STATE_WAIT)
        {
            if(millis() - dev->waittime >= reset_delay)
            {
                dev->cmd = POWER_CMD_ON;
                dev->state = POWER_STATE_OFF;
            }
        }
    }
}

void pwr_task(void)
{
    pwr_cmd_process(&PwrCtrlWifi, 2000, 2000);
    pwr_cmd_process(&PwrCtrl4G, 2000, 2000);
    pwr_cmd_process(&PwrCtrlRTK, 10000, 2000);
    pwr_cmd_process(&PwrCtrlMotion, 2000, 2000);
}