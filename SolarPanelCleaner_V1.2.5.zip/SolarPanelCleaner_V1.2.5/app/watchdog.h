#ifndef _WATCHDOG_H_
#define _WATCHDOG_H_

void watchdog_init(void);
void watchdog_feed(void);
void watchdog_task(void);

#endif