#ifndef __UART_UTILITY_H
#define __UART_UTILITY_H

#include <stdint.h>
#include <stdbool.h>
#include "main.h"
#include "static_dlinklist.h"

extern DLinkList RTKDLLink;
extern DLinkList WifiDLLink;

typedef struct UartDataStruct_TypeDef{
    USART_TypeDef *UARTx;
    DMA_TypeDef *DMAx;
    uint32_t DMA_stream_x;
    bool busy;
    //UART数据接收相关属性和方法
    const uint16_t RX_BUFF_SIZE;
    const uint32_t RX_TIMEOUT;
    uint8_t *rx_buff;
    uint16_t rx_count;
    uint32_t rx_timeout;
    __IO bool rx_complete;
    //UART数据发送相关属性和方法
    const uint16_t TX_BUFF_SIZE;
    uint8_t *tx_buff;
    uint16_t tx_count;
    uint16_t tx_index;
} UartDataStruct_TypeDef;

extern UartDataStruct_TypeDef *hRTK;
extern UartDataStruct_TypeDef *hServo;
extern UartDataStruct_TypeDef *hWIFI;
extern UartDataStruct_TypeDef *h4G;
extern UartDataStruct_TypeDef *hBrush;

void uart_init(void);
void uart_receive(UartDataStruct_TypeDef *uds, uint8_t byte);
void uart_rx_timeout_loop_check(UartDataStruct_TypeDef *uds);
bool uart_rx_complete(UartDataStruct_TypeDef *uds);
uint8_t *uart_rx_data(UartDataStruct_TypeDef *uds);
uint16_t uart_rx_data_len(UartDataStruct_TypeDef *uds);
void uart_rx_clear(UartDataStruct_TypeDef *uds);
uint16_t uart_read(UartDataStruct_TypeDef *uds, uint8_t *buff, uint16_t size);
void uart_send_poll(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len);
void uart_send_dma(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len);
void uart_send_it(UartDataStruct_TypeDef *uds, uint8_t *data, uint16_t len);
bool uart_busy(UartDataStruct_TypeDef *uds);
bool com_format_check(uint8_t *frame, uint16_t len);
bool rtk_format_check(const char *frame, uint16_t len);
static inline void servo_rs485_rx_enable(void){ LL_GPIO_ResetOutputPin(SERVO_RS485_DE_GPIO_Port, SERVO_RS485_DE_Pin); }
static inline void servo_rs485_tx_enable(void){ LL_GPIO_SetOutputPin(SERVO_RS485_DE_GPIO_Port, SERVO_RS485_DE_Pin); }
static inline void brush_rs485_rx_enable(void){ LL_GPIO_ResetOutputPin(BRUSH_RS485_DE_GPIO_Port, BRUSH_RS485_DE_Pin); }
static inline void brush_rs485_tx_enable(void){ LL_GPIO_SetOutputPin(BRUSH_RS485_DE_GPIO_Port, BRUSH_RS485_DE_Pin); }

#endif
