#include <stdint.h>
#include <string.h>
#include "geometry.h"
#include "utility.h"
#include "pid.h"
#include "motion.h"
#include "map.h"
#include "rtk.h"
#include "static_dlinklist.h"
#include "navigation.h"
#include "safety.h"
#include "modbusdevs.h"
#include "Parameter.h"

DLinkList NavDLList = {0};
NavigateDLLNode NavNodePool[500] = {0};

void navigation_init(void)
{
    dllist_init(&NavDLList, &NavNodePool, sizeof(NavNodePool), count(NavNodePool));
}

//from��������ǰλ�õ�GPS����
//to��������Ŀ��λ�õĵ�����
//azimuth�������ĵ�ǰ����ǣ������жϻ����ǻ�����ǰ�����Ǻ������ַ�ʽ�ܸ��쵽��Ŀ��㡣
//startup�����ɵĵ�����
static void generate_startup_point(const GPS_Point_TypeDef *from, const NavigatePoint_TypeDef *to, double azimuth, NavigatePoint_TypeDef *startup)
{
    Vector_TypeDef ft, aid;
    double theta;
    
    memcpy(startup, to, sizeof(NavigatePoint_TypeDef));
    startup->point_num = -1;
    startup->pos.lat = from->lat;
    startup->pos.lon = from->lon;
    startup->brush_gear = 0;
    
    gps_vector_generate(from, &to->pos, &ft);
    get_azimuth_identity_vector(azimuth, &aid);
    theta = vector_angle(&ft, &aid);
    if(theta > 90)
    {
        startup->linear_speed = copysign(to->linear_speed, -1);
    }
}

static inline void navigation_brush_control(int gear)
{
    int16_t brush_speed = 0;
    
    if(gear == 1)
    {
        brush_speed = RobotParam.brush_speed_low;
    }
    else if(gear == 2)
    {
        brush_speed =  RobotParam.brush_speed_high;
    }

    brush_set_rpm(brush_speed);
}

//��aΪ����������·�ߵ���ʼ�㣬��bΪ����������·�ߵ���㣬��cΪ�����˵�ǰλ�ã���c���߶�ab�ϵ�ͶӰΪ��d��
//�������Ѿ������߶�ab��������true��û�����߶�ab����ֵΪfalse;
typedef enum
{
    NAVIGATION_STAGE_1,
    NAVIGATION_STAGE_2,
    NAVIGATION_STAGE_3
} NavigationStage_TypeDef;
NavigationStage_TypeDef NaviStage = NAVIGATION_STAGE_2;

PID_TypeDef Stage1AnglePID = {.Kp = 1.f, .Ki = 0.1f, .Kd = 0, .output_min = -45.f, .output_max = 45.f};
PID_TypeDef Stage2AnglePID = {.Kp = 2.f, .Ki = 0.2f, .Kd = 0, .output_min = -45.f, .output_max = 45.f};
PID_TypeDef Stage3AnglePID = {.Kp = 0.5f, .Ki = 0.05f, .Kd = 0, .output_min = -25.f, .output_max = 25.f};
PID_TypeDef Stage3DistancePID = {.Kp = 10.f, .Ki = 1.f, .Kd = 0, .output_min = -25.f, .output_max = 25.f};

NavigationStage_TypeDef navegation_stage1(NavigatePoint_TypeDef *a, NavigatePoint_TypeDef *b, GPS_Point_TypeDef *c, double azimuth)
{
    NavigationStage_TypeDef stage = NAVIGATION_STAGE_1;
    Vector_TypeDef ab, ac, cd, aid; //aid: azimuth identity vector �����˺����ϵĵ�λ����
    NavigatePoint_TypeDef startup;
    double distance, theta;
    float linear_vel = 0, angular_vel = 0;
    
    gps_vector_generate(&a->pos, &b->pos, &ab);
    gps_vector_generate(&a->pos, c, &ac);
    gps_get_vertical_vector(&a->pos, &b->pos, c, &cd);
    if(b->linear_speed < 0)
    {
        azimuth = azimuth_move(azimuth, 180);
    }
    get_azimuth_identity_vector(azimuth, &aid);
    
    distance = vector_len(&cd);
    
    if(distance < 0.01)
    {
        stage = NAVIGATION_STAGE_2;
        pid_reset(&Stage1AnglePID);
    }
    else if(distance > 0.5 && vector_angle(&ab, &ac) > 100)
    {
        generate_startup_point(c, a, azimuth, &startup);
        a->linear_speed = startup.linear_speed;
        dllist_push_front(&NavDLList, &startup, sizeof(NavigatePoint_TypeDef));
    }
    else
    {
        theta = copysign(vector_angle(&cd, &aid), vector_cross(&cd, &aid));
        angular_vel = pid_compute(&Stage1AnglePID, 0, theta);
        linear_vel = fabs(theta) > 15 ? 0 : b->linear_speed;
        motion_set_velocity(linear_vel, angular_vel);
    }
    
    return stage;
}

NavigationStage_TypeDef navegation_stage2(NavigatePoint_TypeDef *a, NavigatePoint_TypeDef *b, GPS_Point_TypeDef *c, double azimuth)
{
    NavigationStage_TypeDef stage = NAVIGATION_STAGE_2;
    Vector_TypeDef ab, ac, cd, aid, ab_adjust; //aid: azimuth identity vector �����˺����ϵĵ�λ����
    double distance, theta, azimuth_ab, angle_ab_aid;
    float linear_vel = 0, angular_vel = 0;
    static bool slip = false;
    
    gps_vector_generate(&a->pos, &b->pos, &ab);
    gps_vector_generate(&a->pos, c, &ac);
    gps_get_vertical_vector(&a->pos, &b->pos, c, &cd);
    if(b->linear_speed < 0)
    {
        azimuth = azimuth_move(azimuth, 180);
    }
    get_azimuth_identity_vector(azimuth, &aid);
    
    distance = vector_len(&cd);
    azimuth_ab = vector_azimuth(&ab);
    azimuth_ab = azimuth_move(azimuth_ab, vector_cross(&ac, &ab)*(25 + 35*(distance/0.25)));
    get_azimuth_identity_vector(azimuth_ab, &ab_adjust);
    theta = copysign(vector_angle(&ab_adjust, &aid), vector_cross(&ab_adjust, &aid));
    angular_vel = pid_compute(&Stage2AnglePID, 0, theta);
    
    if(distance > 0.3)
    {
        stage = NAVIGATION_STAGE_1;
        pid_reset(&Stage2AnglePID);
    }
    else if(distance < 0.02 && vector_angle(&ab, &aid) < 10)
    {
        stage = NAVIGATION_STAGE_3;
        pid_reset(&Stage2AnglePID);
    }
    else
    {
#if 0
        if(slip)
        {
            angular_vel = 0;
            
            if(distance < 0.02)
            {
                slip = false;
            }
            else
            {
                if(vector_cross(&ab, &ac) * vector_cross(&ab, &aid) < 0)
                {
                    linear_vel = copysign(7, b->linear_speed);
                }
                else
                {
                    linear_vel = copysign(7, -1 * b->linear_speed);
                }
            }
        }
        else
        {
            angle_ab_aid = vector_angle(&ab, &aid);
            if(distance > 0.05f && angle_ab_aid > 60 && angle_ab_aid < 120)
            {
                slip = true;
            }
            else
            {
                if(vector_angle(&ab_adjust, &aid) < 15)
                {
                    linear_vel = b->linear_speed;
                }
            }
        }
#else
        angle_ab_aid = vector_angle(&ab, &aid);
        if(angle_ab_aid > 60 && angle_ab_aid < 120 && distance > 0.03)
        {
            angular_vel = 0;
            
            if(vector_cross(&ab, &ac) * vector_cross(&ab, &aid) < 0)
            {
                linear_vel = copysign(7, b->linear_speed);
            }
            else
            {
                linear_vel = copysign(7, -1 * b->linear_speed);
            }
        }
        else
        {
            if(vector_angle(&ab_adjust, &aid) < 10)
            {
                linear_vel = b->linear_speed;
            }
        }
#endif
        
        motion_set_velocity(linear_vel, angular_vel);
    }
    
    return stage;
}

NavigationStage_TypeDef navegation_stage3(NavigatePoint_TypeDef *a, NavigatePoint_TypeDef *b, GPS_Point_TypeDef *c, double azimuth)
{
    NavigationStage_TypeDef stage = NAVIGATION_STAGE_3;
    Vector_TypeDef ab, ac, cd, aid; //aid: azimuth identity vector �����˺����ϵĵ�λ����
    double distance, theta, k;
    float angular_vel = 0;
    
    gps_vector_generate(&a->pos, &b->pos, &ab);
    gps_vector_generate(&a->pos, c, &ac);
    gps_get_vertical_vector(&a->pos, &b->pos, c, &cd);
    if(b->linear_speed < 0)
    {
        azimuth = azimuth_move(azimuth, 180);
    }
    get_azimuth_identity_vector(azimuth, &aid);
    
    distance = vector_len(&cd);
    if(distance > 0.02 || vector_angle(&ab, &aid) > 10)
    {
        stage = NAVIGATION_STAGE_2;
        pid_reset(&Stage3AnglePID);
        pid_reset(&Stage3DistancePID);
    }
    else
    {
        distance = copysign(distance, vector_cross(&ab, &ac));
        theta = copysign(vector_angle(&ab, &aid), vector_cross(&ab, &aid));
        k = distance / 0.02;
        angular_vel = (k * pid_compute(&Stage3DistancePID, 0, distance)) + ((1 - k) * pid_compute(&Stage3AnglePID, 0, theta));
        motion_set_velocity(b->linear_speed, angular_vel);
    }
    
    return stage;
}

bool navigation(NavigatePoint_TypeDef *a, NavigatePoint_TypeDef *b, GPS_Point_TypeDef *c, double azimuth)
{
    Vector_TypeDef ba, bc, cd;
    bool is_travel_end = false;

    gps_vector_generate(&b->pos, &a->pos, &ba);
    gps_vector_generate(&b->pos, c, &bc);
    gps_get_vertical_vector(&a->pos, &b->pos, c, &cd);
    
    if(vector_len(&bc) < 0.01 || vector_dot(&ba, &bc) <= 0)
    {
        //ba������bc�����ļн�Ϊֱ�ǻ��߶۽ǣ�˵���������Ѿ�����ab�����߶Ρ�
        is_travel_end = true;
    }
    else
    {
        switch(NaviStage)
        {
            case NAVIGATION_STAGE_1:
                NaviStage = navegation_stage1(a, b, c ,azimuth);
                break;
            case NAVIGATION_STAGE_2:
                NaviStage = navegation_stage2(a, b, c ,azimuth);
                break;
            case NAVIGATION_STAGE_3:
                NaviStage = navegation_stage3(a, b, c ,azimuth);
                break;
            default:
                NaviStage = navegation_stage3(a, b, c ,azimuth);    
        }
    }

    return is_travel_end;
}

static int block_read_homeward_line(int block_num, NAVIGATE_TYPE_ENUM type)
{
    NavigateBlock_TypeDef block;
    NavigatePoint_TypeDef points[100]; 
    
    int cnt, index = 0;
    
    if(map_read_block(&RobotMap, block_num, &block, 1))
    {
        do{
            cnt = map_read_homeward(&RobotMap, block_num, index, points, count(points));
            index += cnt;
            for(int i = 0; i < cnt; ++i)
            {
                if(points[i].navigate_type == type)
                {
                    dllist_push_back(&NavDLList, points+i, sizeof(NavigatePoint_TypeDef));
                    if(dllist_full(&NavDLList))
                    {
                        Error.FindLine = 1;
                    }
                }
            }
        }while(cnt > 0 && index < block.homeward_total && !dllist_full(&NavDLList));
    }
    else
    {
        Error.FindLine = 1;
    }
    
    return dllist_length(&NavDLList);
}

int navigation_out_garage(GPS_Point_TypeDef *position, double direction)
{
    NavigatePoint_TypeDef *a, *b;
    NavigateBlock_TypeDef block;
    int block_num = -1, result = 0;
    
    if(dllist_empty(&NavDLList))
    {
        if(round(motion_linear_velocity()) != 0 || round(motion_angular_velocity()) != 0)
        {
            motion_set_velocity(0, 0);
        }
        else
        {
            if((block_num = map_get_local_block(position, &block)) >= 0)
            {
                if(block.block_type == GARAGE)
                {
                    block_read_homeward_line(block_num, NAVIGATE_OUT);
                    if(dllist_length(&NavDLList) < 2)
                    {
                        Error.FindLine = 1;
                    }
                }
                else
                {
                    Error.FindLine = 1;
                }
            }
            else
            {
                Error.FindLine = 1;
            }
        }
    }
    else
    {
        if(dllist_length(&NavDLList) >= 2)
        {
            a = dllist_front(&NavDLList, NULL);
            b = dllist_at(&NavDLList, 1, NULL);

			navigation_brush_control(b->brush_gear);
			
            if(navigation(a, b, position, direction) == true)
            {
                dllist_pop_front(&NavDLList);
            }
        }
        else
        {
            dllist_clear(&NavDLList);
            result = 1;
        }
    }
    
    return result;
}

int navigation_cruise(GPS_Point_TypeDef *position, double direction)
{
    NavigatePoint_TypeDef *a, *b, *back, points[100], startup;
    NavigateBlock_TypeDef block;
	Vector_TypeDef ab, aid;
    int block_num = -1, cnt = 0, result = 0;
    
    if(dllist_empty(&NavDLList))
    {
        if(round(motion_linear_velocity()) != 0 || round(motion_angular_velocity()) != 0)
        {
            motion_set_velocity(0, 0);
        }
        else
        {
            if((block_num = map_get_local_block(position, &block)) >= 0)
            {
                if(block.block_type == SOLAR_PANEL || block.block_type == BRIDGE)
                {
                    cnt = map_read_block_cruise(&RobotMap, block_num, 0, points, count(points));
                    for(int i = 0; i < cnt; ++i)
                    {
                        dllist_push_back(&NavDLList, points+i, sizeof(NavigatePoint_TypeDef));
                    }
                    
                    if(dllist_length(&NavDLList) >= 2)
                    {
                        if(block.block_type == SOLAR_PANEL)
                        {
                            a = dllist_front(&NavDLList, NULL);
                            generate_startup_point(position, a, direction, &startup);
                            a->linear_speed = startup.linear_speed;
                            dllist_push_front(&NavDLList, &startup, sizeof(NavigatePoint_TypeDef));
                        }
                        else if(block.block_type == BRIDGE)
                        {
                            a = dllist_front(&NavDLList, NULL);
                            b = dllist_at(&NavDLList, 1, NULL);
                            gps_vector_generate(&a->pos, &b->pos, &ab);
                            get_azimuth_identity_vector(direction, &aid);
                            if(vector_angle(&ab, &aid) > 15 || gps_distance_to_line(position, &a->pos, &b->pos) > 0.15)
                            {
                                dllist_clear(&NavDLList);
                                Error.FindLine = 1;
                            }
                        }
                    }
                    else
                    {
                        Error.FindLine = 1;
                    }
                }
                else
                {
                    Error.FindLine = 1;
                }
            }
            else
            {
                Error.FindLine = 1;
            }
        }
    }
    else
    {
        if(dllist_length(&NavDLList) >= 2)
        {
            a = dllist_front(&NavDLList, NULL);
            b = dllist_at(&NavDLList, 1, NULL);
			
			navigation_brush_control(b->brush_gear);
			
            if(navigation(a, b, position, direction) == true)
            {
                dllist_pop_front(&NavDLList);
            }
        }
        else if(dllist_length(&NavDLList) == 1)
        {
            back = dllist_back(&NavDLList, NULL);
            if(back->point_num == RobotMap.head.cruise_total - 1)
            {
                dllist_clear(&NavDLList);
                result = 1;
            }
            else
            {
                Error.FindLine = 1;
            }
        }
        
        if(!dllist_full(&NavDLList))
        {
            back = dllist_back(&NavDLList, NULL);
            if(back->point_num < RobotMap.head.cruise_total)
            {
                cnt = map_read_cruise(&RobotMap, back->point_num + 1, points, count(points));
                for(int i = 0; i < cnt; ++i)
                {
                    dllist_push_back(&NavDLList, points+i, sizeof(NavigatePoint_TypeDef));
                }
            }
        }
    }
    
    return result;
}

int navigation_homing(GPS_Point_TypeDef *position, double direction)
{
    NavigatePoint_TypeDef *a, *b;
    NavigateBlock_TypeDef local, parent;
    int local_block_num = -1, result = 0;
    
    if(dllist_empty(&NavDLList))
    {
        if(round(motion_linear_velocity()) != 0 || round(motion_angular_velocity()) != 0)
        {
            motion_set_velocity(0, 0);
        }
        else
        {
            if((local_block_num = map_get_local_block(position, &local)) >= 0)
            {
                if(map_read_block(&RobotMap, local.parent_num, &parent, 1))
                {
                    if(parent.block_type == GARAGE)
                    {
                        result = 1;
                    }
                    else
                    {
                        block_read_homeward_line(local_block_num, NAVIGATE_HOMEWARD);
                    }
                }
            }
            else
            {
                Error.FindLine = 1;
            }
        }
    }
    else
    {
        if(dllist_length(&NavDLList) >= 2)
        {
            a = dllist_front(&NavDLList, NULL);
            b = dllist_at(&NavDLList, 1, NULL);
			
			navigation_brush_control(b->brush_gear);
			
            if(navigation(a, b, position, direction) == true)
            {
                dllist_pop_front(&NavDLList);
            }
        }
        else
        {
            dllist_clear(&NavDLList);
        }
    }
    
    return result;
}

int navigation_in_garage(GPS_Point_TypeDef *position, double direction)
{
    NavigatePoint_TypeDef *a, *b, startup;
    NavigateBlock_TypeDef local, parent;
    int result = 0;
    
    if(dllist_empty(&NavDLList))
    {
        if(round(motion_linear_velocity()) != 0 || round(motion_angular_velocity()) != 0)
        {
            motion_set_velocity(0, 0);
        }
        else
        {
            if(map_get_local_block(position, &local) < 0                                //��ȡ��ǰ��
                || map_read_block(&RobotMap, local.parent_num, &parent, 1) == 0         //��ȡ����
                || parent.block_type != GARAGE                                          //������鲻��ͣ��λ
                || block_read_homeward_line(parent.block_num, NAVIGATE_IN) < 2)   //�������ߵ���������
            {
                Error.FindLine = 1;
            }
            
            if(dllist_length(&NavDLList) >= 2)
            {
                generate_startup_point(position, a, direction, &startup);
                a->linear_speed = startup.linear_speed;
                dllist_push_front(&NavDLList, &startup, sizeof(NavigatePoint_TypeDef));
            }
            else
            {
                Error.FindLine = 1;
            }
        }
    }
    else
    {
        if(dllist_length(&NavDLList) >= 2)
        {
            a = dllist_front(&NavDLList, NULL);
            b = dllist_at(&NavDLList, 1, NULL);
            if(dllist_length(&NavDLList) == 2)
            {
                if(gps_two_points_distance(position, &(a->pos)) > 20)
                {
                    b->linear_speed = copysign(10, -1);
                }
                else
                {
                    b->linear_speed = copysign(5, -1);
                }
            }
			
			navigation_brush_control(b->brush_gear);
			
            if(navigation(a, b, position, direction) == true)
            {
                dllist_pop_front(&NavDLList);
            }
        }
        else
        {
            dllist_clear(&NavDLList);
            result = 1;
        }
    }
    
    return result;
}

static bool block_mumber_compare(int *block_num, NavigatePoint_TypeDef *point)
{
    return *block_num == point->block_num;
}

int navigation_resume(NavigatePoint_TypeDef *resume, GPS_Point_TypeDef *position, double direction)
{
    NavigatePoint_TypeDef *a, *b;
    NavigateBlock_TypeDef local;
    int local_block_num = -1, start_block_num = -1, result = 0;
    DLLIter min;
    
    if(dllist_empty(&NavDLList))
    {
        if(round(motion_linear_velocity()) != 0 || round(motion_angular_velocity()) != 0)
        {
            motion_set_velocity(0, 0);
        }
        else
        {            
            local_block_num = map_get_local_block(position, &local);
            start_block_num = resume->block_num;
            while(1)
            {
                block_read_homeward_line(start_block_num, NAVIGATE_HOMEWARD);
                if(dllist_length(&NavDLList) >= 2)
                {
                    if(((NavigatePoint_TypeDef *)dllist_front(&NavDLList, NULL))->block_num
                        == ((NavigatePoint_TypeDef *)dllist_back(&NavDLList, NULL))->block_num)
                    {
                        result = 1;
                        dllist_clear(&NavDLList);
                        break;
                    }
                    else
                    {
                        min = dllist_find_first(&NavDLList, (EqualFun)block_mumber_compare, &local_block_num);
                        if(min != dllist_end())
                        {
                            for(DLLIter iter = dllist_next(min);
                                iter != dllist_end() && ((NavigatePoint_TypeDef *)dllist_data(iter, NULL))->block_num == local_block_num;
                                iter = dllist_next(iter))
                            {
                                if(gps_two_points_distance(&resume->pos, dllist_data(iter, NULL)) 
                                    < gps_two_points_distance(&resume->pos, dllist_data(min, NULL)))
                                {
                                    min = iter;
                                }
                            }
                            dllist_iter_erase(&NavDLList, dllist_next(min), -1);
                        }
                        else
                        {
                            start_block_num = ((NavigatePoint_TypeDef *)dllist_back(&NavDLList, NULL))->block_num;
                            dllist_clear(&NavDLList);
                        }
                    }
                }
                else
                {
                    Error.FindLine = 1;
                }
            }
        }
    }
    else
    {
        if(dllist_length(&NavDLList) >= 2)
        {
            a = dllist_back(&NavDLList, NULL);
            b = dllist_at(&NavDLList, dllist_length(&NavDLList)-2, NULL);
			
			navigation_brush_control(b->brush_gear);
			
            if(navigation(a, b, position, direction) == true)
            {
                dllist_pop_back(&NavDLList);
            }
        }
        else
        {
            dllist_clear(&NavDLList);
        }
    }
    
    return result;
}