#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include "log.h"
#include "ff.h"
#include "rtc.h"
#include "statemachine.h"
#include "utility.h"
#include "safety.h"

#define LOG_DEBUG_PATH      "0:/debug"
#define LOG_DEBUG_SUFFIX    "log"
#define LOG_RTK_PATH        "0:/rtk"
#define LOG_RTK_SUFFIX      "csv"

static FIL hDebug;
static FIL hRTK;

static void log_delet_old_file(FIL *fp, const char *path, const char *suffix_);

static void log_init_(FIL *fp, const char *path, const char *suffix)
{
    FRESULT res;
    RTC_DateTypeDef date;
    char name[64] = {0};
    
    HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN);
    
    f_mkdir(path);
    snprintf(name, sizeof(name), "%s/%04u%02u%02u.%s", path, date.Year, date.Month, date.Date, suffix);
    res = f_open(fp, name, FA_OPEN_EXISTING|FA_READ|FA_WRITE);
    if(res == FR_OK)
    {
        f_lseek(fp, f_size(fp));
    }
    else
    {
        res = f_open(fp, name, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
        if(res != FR_OK)
        {
            Error.SdCard = 1;
        }
    }
    
    log_delet_old_file(fp, path, suffix);
}

static void log_manage(FIL *fp, const char *path, const char *suffix)
{
    RTC_DateTypeDef date;
    char name[64] = {0};
    FRESULT res;

    HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN);
    snprintf(name, sizeof(name), "%s/%04u%02u%02u.%s", path, date.Year, date.Month, date.Date, suffix);
    f_close(fp);
    res = f_open(fp, name, FA_OPEN_EXISTING|FA_READ|FA_WRITE);
    if(res == FR_OK)
    {
        f_lseek(fp, f_size(fp));
    }
    else
    {
        res = f_open(fp, name, FA_CREATE_ALWAYS|FA_READ|FA_WRITE);
        if(res == FR_OK)
        {
            log_delet_old_file(fp, path, suffix);
        }
        else
        {
            Error.SdCard = 1;
        }
    }
}

static int less(const void *a, const void *b)
{
    return *(uint32_t *)a < *(uint32_t *)b;
}

static void log_delet_old_file(FIL *fp, const char *path, const char *suffix_)
{
    FRESULT res;
    DIR   dir;     /* 文件夹对象 */ //36  bytes
    FILINFO fno;   /* 文件属性 */   //32  bytes
    
    const int save_cnt = 30;    //保留的文件数量
    int format_cnt = 0;         //sscanf格式化的数量
    char suffix[8] = {0}, name[64] = {0};
    uint32_t date, table[100] = {0}, cnt = 0;
    
    res = f_opendir(&dir, path);
    while(res == FR_OK && f_readdir(&dir, &fno) == FR_OK)
    {
        /* 若是"."或".."文件夹，跳过 */
        if(strlen(fno.fname) == 0)          break;      //若读到的文件名为空
        if(strcmp(fno.fname, ".") == 0)     continue;   //若读到的文件名为当前文件夹
        if(strcmp(fno.fname, "..") == 0)    continue;   //若读到的文件名为上一级文件夹
        
        format_cnt = sscanf(fno.fname, "%u\\.%3s", &date, suffix);
        if(cnt < count(table) && format_cnt == 2 && strcasecmp(suffix, suffix_) == 0)
        {
            table[cnt++] = date;
        }
    }
    f_closedir(&dir);
    
    if(cnt > save_cnt)
    {
        qsort(table, count(table), sizeof(table[0]), less);
        for(uint32_t i = save_cnt; i < cnt; ++i)
        {
            snprintf(name, sizeof(name), "%s/%08u.%s", path, table[i], suffix);
            f_unlink(name);
        }
    }
}

static int log_printf(FIL *fp, const char *fmt, va_list ap)
{
    RTC_DateTypeDef date;
    RTC_TimeTypeDef time;
    char buff[256] = {0};
    int len;
    
    vsnprintf(buff, sizeof(buff), fmt, ap);
    
    HAL_RTC_GetDate(&hrtc, &date, RTC_FORMAT_BIN);
    HAL_RTC_GetTime(&hrtc, &time, RTC_FORMAT_BIN);
    len = f_printf(fp, "%d/%d %d:%d:%d\r\n", date.Month, date.Date, time.Hours, time.Minutes, time.Seconds);
    len += f_puts(buff, fp);
    return len;
}

static void log_write(FIL *fp, const uint8_t *data, int len)
{
    UINT bw;
    f_write(fp, data, len, &bw);
}

void log_init(void)
{
    log_init_(&hDebug, LOG_DEBUG_PATH, LOG_DEBUG_SUFFIX);
    log_init_(&hRTK, LOG_RTK_PATH, LOG_RTK_SUFFIX);
}

void log_task(void)
{
    static uint32_t period = 0;
    if(millis() - period >= 1*60*1000)
    {
        period = millis();
        if(state_task_state() <= STATE_PAUSE_STOP)
        {
            log_manage(&hDebug, LOG_DEBUG_PATH, LOG_DEBUG_SUFFIX);
            log_manage(&hRTK, LOG_RTK_PATH, LOG_RTK_SUFFIX);
        }
    }
}

void log_debug_write(const uint8_t *data, uint16_t len)
{
    log_write(&hDebug, data, len);
}

void log_debug_printf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    log_printf(&hDebug, fmt, ap);
    va_end(ap);
}

void log_rtk_write(const uint8_t *data, uint16_t len)
{
    log_write(&hRTK, data, len);
}

void log_rtk_printf(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    log_printf(&hRTK, fmt, ap);
    va_end(ap);
}