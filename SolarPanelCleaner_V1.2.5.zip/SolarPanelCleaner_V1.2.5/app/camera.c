#include "camera.h"
#include "utility.h"

#if 0
StepMotor_TypeDef StepMotor = {0};

void step_motor_init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);    //TIM14时钟使能    
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);   //使能PORTF时钟	
	
	GPIO_PinAFConfig(GPIOD, GPIO_PinSource12, GPIO_AF_TIM4);//GPIOD12复用为定时器4
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;              //GPIOD12
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;            //复用功能
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;      //速度100MHz
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;          //推挽复用输出
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;            //上拉
	GPIO_Init(GPIOD,&GPIO_InitStructure);                   //初始化PD12
	  
	TIM_TimeBaseStructure.TIM_Prescaler = (84-1);           //定时器分频。APB1时钟频率为84M，84分频后供给时钟，则时钟计数频率为1M
	TIM_TimeBaseStructure.TIM_CounterMode =TIM_CounterMode_Up;//向上计数模式
	TIM_TimeBaseStructure.TIM_Period = (1000-1);            //自动重装载值。
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseInit(TIM4,&TIM_TimeBaseStructure);          //初始化定时器4
	
	//初始化TIM4 Channel1 PWM模式	 
	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;       //选择定时器模式:TIM脉冲宽度调制模式2
 	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;//比较输出使能
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;//输出极性:TIM输出比较极性低
	TIM_OC1Init(TIM4, &TIM_OCInitStructure);                //根据TIM4指定的参数初始化外设TIM4OC1
	TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);       //使能TIM14在CCR1上的预装载寄存器
    
    TIM_ARRPreloadConfig(TIM4, ENABLE);                     //ARPE使能 
}

static void step_motor_set_rpm(double rpm)
{
    double psc, arr, dps, dpp, freq;
    
    StepMotor.rpm_cur = rpm;
    GPIOx_setExtOutSingle(EXT_OUT4, rpm > 0 ? BIT_RESET : BIT_SET);

    dps = fabs(rpm) * 360 / 60;                 //degrees per second
    dpp = (double)360 / STEP_MOTOR_PULSE_REV;   //degrees per pulse
    freq = dps / dpp;                           //pwm frequncy
    if(freq >= 1)
    {
        if(freq <= 600)
            psc = 1400;
        else if(freq <= 1200)
            psc = 700;
        else if(freq <= 2400)
            psc = 350;
        else if(freq <= 4800)
            psc = 175;
        else if(freq <= 10E3)
            psc = 84;
        else if(freq <= 20E3)
            psc = 42;
        else if(freq <= 40E3)
            psc = 21;
        else //if(hz <= 840E3)
            psc = 1;
        arr = 84000000 / freq / psc;
        
        TIM_PrescalerConfig(TIM4, psc-1, TIM_PSCReloadMode_Immediate);
        TIM_SetAutoreload(TIM4, arr-1);
        TIM_SetCompare1(TIM4, arr/2-1);
        TIM_Cmd(TIM4, ENABLE);
    }
    else
    {
        StepMotor.cmd = STEP_MOTOR_STOP;
        TIM_Cmd(TIM4, DISABLE);
    }
}

static double step_motor_get_rpm(void)
{
    return StepMotor.rpm_cur;
}

void step_motor_run(int16_t rpm)
{
    StepMotor.cmd = STEP_MOTOR_RUN;
    StepMotor.rpm_set = range(rpm, -3000, 3000);
}

void step_motor_stop(void)
{
    StepMotor.cmd = STEP_MOTOR_STOP;
    StepMotor.rpm_set = 0;
    StepMotor.rpm_cur = 0;
    TIM_Cmd(TIM4, DISABLE);
}

void step_motor_task(void)
{
    double direction;
    static uint32_t interval;
    double acc, seconds, rpm_cur, rpm_change;
    
    if(StepMotor.cmd == STEP_MOTOR_RUN)
    {
        rpm_cur = step_motor_get_rpm();
        if(fabs(StepMotor.rpm_set - rpm_cur) >= 0.000001f)
        {
            direction = copysign(1, rpm_cur) * copysign(1, StepMotor.rpm_set);  //计算两个速度的方向，用copysign防止溢出
            if(direction > 0)                                                   //当前速度和目标速度同向
            {
                acc = copysign(STEP_MOTOR_ACCELE_RATE, StepMotor.rpm_set - rpm_cur);
            }
            else if(direction < 0)                                              //当前速度和目标速度反向
            {
                acc = copysign(STEP_MOTOR_ACCELE_RATE, StepMotor.rpm_set);
            }
            else
            {
                if(StepMotor.rpm_set == 0)
                    acc = copysign(STEP_MOTOR_ACCELE_RATE, -StepMotor.rpm_cur);
                else
                    acc = copysign(STEP_MOTOR_ACCELE_RATE, StepMotor.rpm_set);
            }
            
            seconds = (millis() - interval) / (double)1000;                     //每两次函数调用的时间间隔，单位秒
            rpm_change = acc * seconds;                                         //根据加速度计算rpm改变量
            rpm_cur += rpm_change;
            if((acc < 0 && rpm_cur < StepMotor.rpm_set) || (acc > 0 && rpm_cur > StepMotor.rpm_set))
            {
                rpm_cur = StepMotor.rpm_set;
            }
            step_motor_set_rpm(rpm_cur);
        }
        
        //电机点动
        if(millis() - StepMotor.cmd_timeout > 2000)
        {
            StepMotor.cmd_timeout = millis();
            StepMotor.rpm_set = 0;
        }
    }
    else
    {
        StepMotor.cmd_timeout = millis();
    }
    
    interval = millis();
}
#endif

//-------------------------------------------------------------------------------

Camera_TypeDef Camera = {
    .pwr_state = false,
    .cmd = CAMERA_MOVE_STOP,
    .vel = SERVO_VEL,
    .horizon_ccr = CAMERA_HORIZON_SHUTDOWN_POINT,
    .vertical_ccr = CAMERA_VERTICAL_SHUTDOWN_POINT,
};

void camera_init(void)
{
 #if 0
    TIM4->PSC = (84-1);     //定时器分频。APB1时钟频率为84M，84分频后供给时钟，则时钟计数频率为1M
    TIM4->ARR = (5000-1);   //自动重装载值。PWM频率为100Hz。
#endif
}

void camera_set_cmd(CAMERA_CMD cmd)
{
    Camera.cmd = cmd;
}

bool camera_pwr_state(void)
{
    return Camera.pwr_state;
}

void camera_task(void)
{
    if(Camera.cmd == CAMERA_POWER_ON)
    {
        if(Camera.horizon_ccr > CAMERA_HORIZON_STARTUP_POINT)
        {
            Camera.horizon_ccr -= Camera.vel * 3;
            if(Camera.horizon_ccr < CAMERA_HORIZON_STARTUP_POINT)
                Camera.horizon_ccr = CAMERA_HORIZON_STARTUP_POINT;
        }
        else if(Camera.horizon_ccr < CAMERA_HORIZON_STARTUP_POINT)
        {
            Camera.horizon_ccr += Camera.vel * 3;
            if(Camera.horizon_ccr > CAMERA_HORIZON_STARTUP_POINT)
                Camera.horizon_ccr = CAMERA_HORIZON_STARTUP_POINT;
        }
        
        if(Camera.vertical_ccr > CAMERA_VERTICAL_STARTUP_POINT)
        {
            Camera.vertical_ccr -= Camera.vel * 3;
            if(Camera.vertical_ccr < CAMERA_VERTICAL_STARTUP_POINT)
                Camera.vertical_ccr = CAMERA_VERTICAL_STARTUP_POINT;
        }
        else if(Camera.vertical_ccr < CAMERA_VERTICAL_STARTUP_POINT)
        {
            Camera.vertical_ccr += Camera.vel * 3;
            if(Camera.vertical_ccr > CAMERA_VERTICAL_STARTUP_POINT)
                Camera.vertical_ccr = CAMERA_VERTICAL_STARTUP_POINT;
        }
        
        if(Camera.horizon_ccr == CAMERA_HORIZON_STARTUP_POINT && Camera.vertical_ccr == CAMERA_VERTICAL_STARTUP_POINT)
        {
            Camera.pwr_state = true;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        
        TIM4->CR1 |= 0x01;                  //Enable TIM4
        TIM4->CCR1 = Camera.horizon_ccr;    //设置 PWM Channel1 占空比
        TIM4->CCR3 = Camera.vertical_ccr;   //设置 PWM Channel3 占空比
    }
    else if(Camera.cmd == CAMERA_POWER_OFF)
    {
        if(Camera.horizon_ccr > CAMERA_HORIZON_SHUTDOWN_POINT)
        {
            Camera.horizon_ccr -= Camera.vel * 3;
            if(Camera.horizon_ccr < CAMERA_HORIZON_SHUTDOWN_POINT)
                Camera.horizon_ccr = CAMERA_HORIZON_SHUTDOWN_POINT;
        }
        else if(Camera.horizon_ccr < CAMERA_HORIZON_SHUTDOWN_POINT)
        {
            Camera.horizon_ccr += Camera.vel * 3;
            if(Camera.horizon_ccr > CAMERA_HORIZON_SHUTDOWN_POINT)
                Camera.horizon_ccr = CAMERA_HORIZON_SHUTDOWN_POINT;
        }
        
        if(Camera.vertical_ccr > CAMERA_VERTICAL_SHUTDOWN_POINT)
        {
            Camera.vertical_ccr -= Camera.vel * 3;
            if(Camera.vertical_ccr < CAMERA_VERTICAL_SHUTDOWN_POINT)
                Camera.vertical_ccr = CAMERA_VERTICAL_SHUTDOWN_POINT;
        }
        else if(Camera.vertical_ccr < CAMERA_VERTICAL_SHUTDOWN_POINT)
        {
            Camera.vertical_ccr += Camera.vel * 3;
            if(Camera.vertical_ccr > CAMERA_VERTICAL_SHUTDOWN_POINT)
                Camera.vertical_ccr = CAMERA_VERTICAL_SHUTDOWN_POINT;
        }
        
        if(Camera.horizon_ccr == CAMERA_HORIZON_SHUTDOWN_POINT && Camera.vertical_ccr == CAMERA_VERTICAL_SHUTDOWN_POINT)
        {
            TIM4->CR1 &= ~0x01;             //Disable TIM4
            Camera.pwr_state = false;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        TIM4->CCR1 = Camera.horizon_ccr;    //设置 PWM Channel1 占空比
        TIM4->CCR3 = Camera.vertical_ccr;   //设置 PWM Channel1 占空比
    }
    else if(Camera.cmd == CAMERA_MOVE_LEFT)
    {
        Camera.horizon_ccr -= Camera.vel;
        if(Camera.horizon_ccr <= SERVO_SYSTEM_LIMIT_MIN)
        {
            Camera.horizon_ccr = SERVO_SYSTEM_LIMIT_MIN;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        TIM4->CCR1 = Camera.horizon_ccr;
    }
    else if(Camera.cmd == CAMERA_MOVE_RIGHT)
    {
        Camera.horizon_ccr += Camera.vel;
        if(Camera.horizon_ccr >= SERVO_SYSTEM_LIMIT_MAX)
        {
            Camera.horizon_ccr = SERVO_SYSTEM_LIMIT_MAX;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        TIM4->CCR1 = Camera.horizon_ccr;
    }
    else if(Camera.cmd == CAMERA_MOVE_UP)
    {
        Camera.vertical_ccr += Camera.vel;
        if(Camera.vertical_ccr >= SERVO_SYSTEM_LIMIT_MAX)
        {
            Camera.vertical_ccr = SERVO_SYSTEM_LIMIT_MAX;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        else if(Camera.vertical_ccr >= CAMERA_VERTICAL_LIMIT_MAX)
        {
            Camera.vertical_ccr = CAMERA_VERTICAL_LIMIT_MAX;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        TIM4->CCR3 = Camera.vertical_ccr;
    }
    else if(Camera.cmd == CAMERA_MOVE_DOWN)
    {
        Camera.vertical_ccr -= Camera.vel;
        if(Camera.vertical_ccr <= SERVO_SYSTEM_LIMIT_MIN)
        {
            Camera.vertical_ccr = SERVO_SYSTEM_LIMIT_MIN;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        else if(Camera.vertical_ccr <= CAMERA_VERTICAL_LIMIT_MIN)
        {
            Camera.vertical_ccr = CAMERA_VERTICAL_LIMIT_MIN;
            Camera.cmd = CAMERA_MOVE_STOP;
        }
        TIM4->CCR3 = Camera.vertical_ccr;
    }
    else
    {
        __NOP();
    }
}