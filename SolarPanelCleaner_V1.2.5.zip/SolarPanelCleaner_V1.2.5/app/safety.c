#include "safety.h"

Warning_TypeDef Warning;
Error_TypeDef   Error;