#ifndef _NAVIGATION_H_
#define _NAVIGATION_H_

#include <stdbool.h>
#include "geometry.h"
#include "static_dlinklist.h"
#include "map.h"

#pragma pack(1)
typedef struct navigate_dllist_node
{
    DLLNodeBase base;
    uint8_t data[sizeof(NavigatePoint_TypeDef)-1];
} NavigateDLLNode;
#pragma pack()

extern DLinkList NavDLList;

void navigation_init(void);
int navigation_out_garage(GPS_Point_TypeDef *position, double direction);
int navigation_cruise(GPS_Point_TypeDef *position, double direction);
int navigation_homing(GPS_Point_TypeDef *position, double direction);
int navigation_in_garage(GPS_Point_TypeDef *position, double direction);
int navigation_resume(NavigatePoint_TypeDef *resume, GPS_Point_TypeDef *position, double direction);

#endif