#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "communication.h"
#include "parameter.h"
#include "utility.h"
#include "uart_utility.h"
#include "update.h"
#include "pwrctrl.h"
#include "led.h"
#include "battery.h"
#include "temperature.h"
#include "statemachine.h"
#include "motion.h"
#include "camera.h"
#include "sensor.h"
#include "RTK.h"
#include "utility.h"
#include "map.h"
#include "modbusdevs.h"
#include "safety.h"

extern RobotStateMachine_TypeDef StateMachine;

struct
{
    uint32_t auto_send_period;
    uint32_t no_ack_cnt;
} CellularDataStruct;

void com_init(void)
{
    pwr_wifi_cmd(POWER_CMD_ON);
    pwr_4g_cmd(POWER_CMD_ON);
    CellularDataStruct.auto_send_period = 5000;
    CellularDataStruct.no_ack_cnt = 0;
}

void wifi_setup(void)
{
    #define WIFI_EXIT_MASK  (1<<0)
    #define WIFI_MODE_MASK  (1<<1)
    #define WIFI_SAP_MASK   (1<<2)
    #define WIFI_PAP_MASK   (1<<3)
    #define WIFI_START_MASK (1<<4)
    
    const char *exit  = "+++";
    const char *mode  = "AT+CWMODE_CUR=2\r\n";
    const char *sap   = "AT+CWSAP_CUR=\"%s-%02x%02x%02x%02x%02x%02x%02x%02x%02x\",\"12345678\",11,4,4\r\n";
    const char *pap   = "AT+CIPAP_CUR=\"192.168.3.20\"\r\n";
    const char *start = "AT+CIPSTART=\"UDP\",\"192.168.3.255\",9000,9000,0";
    //const char *transparent = "AT+SAVETRANSLINK=1,\"192.168.3.255\",9000,\"UDP\",9000\r\n";
    char buff[64] = {0};
    static uint32_t period = 0;
    static uint8_t status = {WIFI_EXIT_MASK | WIFI_MODE_MASK | WIFI_SAP_MASK | WIFI_PAP_MASK | WIFI_START_MASK};

    if(status)
    {
        if(millis() - period >= 500)
        {
            period = millis();
            
            if(status & WIFI_EXIT_MASK)
            {
                uart_send_dma(hWIFI, (uint8_t *)exit, strlen(exit));
            }
            else if(status & WIFI_MODE_MASK)
            {
                uart_send_dma(hWIFI, (uint8_t *)mode, strlen(mode));
            }
            else if(status & WIFI_SAP_MASK)
            {
                snprintf(buff, sizeof(buff), sap, RobotParam.robot_id[1] == 0x91 ? "D2" : "D3",
                                                  RobotParam.robot_id[0],
                                                  RobotParam.robot_id[1],
                                                  RobotParam.robot_id[2],
                                                  RobotParam.robot_id[3],
                                                  RobotParam.robot_id[4],
                                                  RobotParam.robot_id[5],
                                                  RobotParam.robot_id[6],
                                                  RobotParam.robot_id[7],
                                                  RobotParam.robot_id[8]);
                uart_send_dma(hWIFI, (uint8_t *)buff, strlen(buff));
            }
            else if(status & WIFI_PAP_MASK)
            {
                uart_send_dma(hWIFI, (uint8_t *)pap, strlen(pap));
            }
            else if(status & WIFI_START_MASK)
            {
                uart_send_dma(hWIFI, (uint8_t *)start, strlen(start));
            }
        }
        
        if(!dllist_empty(&WifiDLLink))
        {
            if(strcasecmp("+++", dllist_front(&WifiDLLink, NULL)) == 0 && (status & WIFI_EXIT_MASK))
            {
                status |= ~WIFI_EXIT_MASK;
            }
            else if(strcasecmp("OK\r\n", dllist_front(&WifiDLLink, NULL)) == 0)
            {
                if(status & WIFI_MODE_MASK)
                {
                    status |= ~WIFI_MODE_MASK;
                }
                else if(status & WIFI_SAP_MASK)
                {
                    status |= ~WIFI_SAP_MASK;
                }
                else if(status & WIFI_PAP_MASK)
                {
                    status |= ~WIFI_PAP_MASK;
                }
                else if(status & WIFI_START_MASK)
                {
                    status |= ~WIFI_START_MASK;
                }
            }
            LL_USART_DisableIT_IDLE(hWIFI->UARTx);
            dllist_clear(&WifiDLLink);
            LL_USART_EnableIT_IDLE(hWIFI->UARTx);
        }
    }
}

void cellular_setup(void)
{
    #define CELLULAR_MODE_MASK    (1<<0)
    #define CELLULAR_SOCKA_MASK   (1<<1)
    #define CELLULAR_SOCKASL_MASK (1<<2)
    #define CELLULAR_SOCKATO_MASK (1<<3)
    #define CELLULAR_UARTFT_MASK  (1<<4)
    
    const char *mode    = "adminAT+WKMOD=NET\r\n";
    const char *socka   = "adminAT+SOCKA=TCP,120.77.171.147,8011\r\n";
    const char *sockasl = "adminAT+SOCKASL=LONG\r\n";
    const char *sockato = "adminAT+SOCKATO=5\r\n";
    const char *uartft  = "adminAT+UARTFT=50\r\n";
    static uint32_t period = 0;
    static uint8_t status = { CELLULAR_MODE_MASK
                            | CELLULAR_SOCKA_MASK
                            | CELLULAR_SOCKASL_MASK
                            | CELLULAR_SOCKATO_MASK
                            | CELLULAR_UARTFT_MASK};
    
    if(status)
    {
        if(millis() - period > 500)
        {
            period = millis();
            
            if(status & CELLULAR_MODE_MASK)
            {
                uart_send_dma(h4G, (uint8_t *)mode, strlen(mode));
            }
            else if(status & CELLULAR_SOCKA_MASK)
            {
                uart_send_dma(h4G, (uint8_t *)socka, strlen(socka));
            }
            else if(status & CELLULAR_SOCKASL_MASK)
            {
                uart_send_dma(h4G, (uint8_t *)sockasl, strlen(sockasl));
            }
            else if(status & CELLULAR_SOCKATO_MASK)
            {
                uart_send_dma(h4G, (uint8_t *)sockato, strlen(sockato));
            }
            else if(status & CELLULAR_UARTFT_MASK)
            {
                uart_send_dma(h4G, (uint8_t *)uartft, strlen(uartft));
            }
        }
        
        if(!dllist_empty(&WifiDLLink))
        {
            if(strcasecmp("OK\r\n", dllist_front(&WifiDLLink, NULL)) == 0)
            {
                if(status & CELLULAR_MODE_MASK)
                {
                    status |= ~CELLULAR_MODE_MASK;
                }
                else if(status & CELLULAR_SOCKA_MASK)
                {
                    status |= ~CELLULAR_SOCKA_MASK;
                }
                else if(status & CELLULAR_SOCKASL_MASK)
                {
                    status |= ~CELLULAR_SOCKASL_MASK;
                }
                else if(status & CELLULAR_SOCKATO_MASK)
                {
                    status |= ~CELLULAR_SOCKATO_MASK;
                }
                else if(status & CELLULAR_UARTFT_MASK)
                {
                    status |= ~CELLULAR_UARTFT_MASK;
                }
            }
            
            LL_USART_DisableIT_IDLE(hWIFI->UARTx);
            dllist_clear(&WifiDLLink);
            LL_USART_EnableIT_IDLE(hWIFI->UARTx);
        }
    }
}

static void com_command_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds)
{
    Frame_Command_Req *req;
    Frame_Command_Ack ack;
    
    req = (Frame_Command_Req *)data;
    StateMachine.control.methon = (METHON_CMD_ENUM)req->motionMethon;
    StateMachine.control.cmd = (STATE_CMD_ENUM)req->motionCmd;
    StateMachine.control.linear_vel = req->linearVelocity;  //��λ: m/min
    StateMachine.control.angluar_vel = req->angularVelocity;//��λ: rad/min
    StateMachine.control.brush_cmd = (BRUSH_CMD_ENUM)req->brushCtl;
    if(req->linearVelocity != 0 || req->angularVelocity != 0)
    {
        if(uds == hWIFI)
        {
            StateMachine.control.master = MANUAL_VELOCITY_MASTER_APP;
        }
        else if(uds == h4G)
        {
            StateMachine.control.master = MANUAL_VELOCITY_MASTER_SERVER;
        }
    }
    
    ack.head = FRAME_HEAD;
    ack.type = req->type + 1;
    ack.length = htons(sizeof(ack));
    ack.serial = req->serial;
    memcpy(ack.ID, RobotParam.robot_id, ROBOT_ID_LENGTH);
    memcpy(ack.buildDate, RobotParam.build_date, BUILD_DATE_LENGTH);
	ack.robotState = StateMachine.state;
	ack.linearVelocity = (int8_t)motion_linear_velocity();
	ack.angularVelocity = (int8_t)motion_angular_velocity();
	ack.brushState = 0;
	ack.motionMethon = 0;
	ack.faultFlag = 0;
	ack.curMileage = 0;
	ack.curCleanTime = 0;
	ack.batteryVol = 0;
	ack.dropLimitState = 0;
	ack.reserve = 0;
    ack.checksum = checksum_xor((uint8_t *)&ack, sizeof(ack)-2);
    ack.tail = FRAME_TAIL;
    
    uart_send_dma(uds, (uint8_t *)&ack, sizeof(ack));
}

static void com_parmeter_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds)
{
    Frame_Param_Req *req;
    Frame_Param_Ack ack;
    bool change = false;
    
    req = (Frame_Param_Req *)data;

    if(req->rw_raduction_ratio)
    {
        change = true;
        RobotParam.raduction_ratio = (float)ntohl(req->raduction_ratio) / 100.0f;
    }
    if(req->rw_brush_speed)
    {
        change = true;
        RobotParam.brush_speed_low = ntohs(req->brush_speed_low);
        RobotParam.brush_speed_high = ntohs(req->brush_speed_high);
    }
    if(req->rw_servo_param)
    {
        
    }
    if(req->rw_sensor_mask)
    {
        //change = true;
        RobotParam.sensor_mask.value = ntohl(req->sensor_mask);
    }
    if(req->rw_force_charge)
    {
        change = true;
        RobotParam.force_charge = req->force_charge;
    }
    if(req->rw_over_current)
    {
        change = true;
        RobotParam.over_current1 = ntohl(req->over_current1);
        RobotParam.over_current2 = ntohl(req->over_current2);
        RobotParam.over_current3 = ntohl(req->over_current3);
    }
    if(req->rw_liner_block)
    {
        change = true;
        RobotParam.blocking_linear_biase = ntohl(req->linear_block);
    }
    if(req->rw_angle_block)
    {
        change = true;
        RobotParam.blocking_angle_biase = ntohl(req->angle_block);
    }
    if(req->rw_battery_capacity)
    {
        change = true;
        RobotParam.battery_capacity = ntohl(req->battery_capacity);
    }
    if(req->rw_homeward_soc)
    {
        change = true;
        RobotParam.homeward_soc = req->howeward_soc;
        RobotParam.lowpower_voltage = (float)ntohl(req->lowpower_voltage) / 100.0f;
        RobotParam.lowpower_trigger_time = req->lowpower_trigger_time;
    }
//    if(req->rw_robot_id)
//    {
//        change = true;
//        memcpy(&RobotParam.robot_id, req->robot_id, ROBOT_ID_LENGTH);
//    }
    
    if(change)
    {
        param_set_limit(&RobotParam);
        param_write(&RobotParam);
        param_read(&RobotParam);
        param_set_limit(&RobotParam);
        //���ٱ�������Ч
        motion_set_raduction_ratio(RobotParam.raduction_ratio);
    }
    
    ack.head = FRAME_HEAD;
    ack.type = FRAME_TYPE_PARAM + 1;
    ack.length = htons(sizeof(ack));
    ack.serial = req->serial;
    memcpy(ack.ID, RobotParam.robot_id, ROBOT_ID_LENGTH);
    memcpy(ack.buildDate, RobotParam.build_date, BUILD_DATE_LENGTH);
    ack.rw_raduction_ratio = req->rw_raduction_ratio;
    ack.raduction_ratio = htonl(RobotParam.raduction_ratio*100);
    ack.rw_brush_speed = req->rw_brush_speed;
    ack.brush_speed_low = htons(RobotParam.brush_speed_low);
    ack.brush_speed_high = htons(RobotParam.brush_speed_high);
    ack.rw_servo_param = req->rw_servo_param;
    ack.servo_number = htons(0);
    ack.servo_param_addr = htons(0);
    ack.servo_param_value = htons(0);
    ack.rw_sensor_mask = req->rw_sensor_mask;
    ack.sensor_mask =  htonl((uint32_t)RobotParam.sensor_mask.value);
    ack.rw_force_charge = req->rw_force_charge;
    ack.force_charge = RobotParam.force_charge;
    ack.rw_over_current = req->rw_over_current;
    ack.over_current1 = htonl(RobotParam.over_current1);
    ack.over_current2 = htonl(RobotParam.over_current2);
    ack.over_current3 = htonl(RobotParam.over_current3);
    ack.rw_liner_block = req->rw_liner_block;
    ack.linear_block = htonl(RobotParam.blocking_linear_biase);
    ack.rw_angle_block = req->rw_angle_block;
    ack.angle_block = htonl(RobotParam.blocking_angle_biase);
    ack.rw_battery_capacity = req->rw_battery_capacity;
    ack.battery_capacity = htonl(RobotParam.battery_capacity);
    ack.rw_homeward_soc = req->rw_homeward_soc;
    ack.homeward_soc = RobotParam.homeward_soc;
    ack.lowpower_voltage = htonl(RobotParam.lowpower_voltage*100);
    ack.lowpower_trigger_time = RobotParam.lowpower_trigger_time;
    ack.checkSum = checksum_xor((uint8_t *)&ack, sizeof(ack) - 2);
    ack.tail = FRAME_TAIL;

    uart_send_dma(uds, (uint8_t *)&ack, sizeof(ack));
}

static void com_heartbeat_send(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds)
{
    static uint8_t serial = 0;
    GPS_Point_TypeDef pos;
    double azimuth;
    
    rtk_info(&pos, &azimuth);
        
    Frame_HeartBeat_Ack frame;
    frame.head = FRAME_HEAD;
    frame.type = FRAME_TYPE_HEART_BEAT + 1;
    frame.length = htons(sizeof(frame));
    frame.serial = (data != NULL ? data[4] : serial++);
    memcpy(frame.ID, RobotParam.robot_id, ROBOT_ID_LENGTH);
    memcpy(frame.buildDate, RobotParam.build_date, BUILD_DATE_LENGTH);
    frame.controlMethod = state_methon();
    frame.taskStatus = state_task_state();
    frame.warningFlag = htonl(warning());
    frame.dropSersor = sensor_get_bits();
    frame.radarLeftFront = 0;
    frame.radarLeftRear = 0;
    frame.radarRightFront = 0;
    frame.radarRightRear = 0;
    frame.magnaticGuider = htonl(0);
    frame.longtitude = htonll(pos.lon*1E13);
    frame.lattitude = htonll(pos.lat*1E13);
    frame.azimuth = htons(azimuth*100);
    frame.linearVelocity = round(motion_linear_velocity());
    frame.angleVelocity = round(motion_angular_velocity());
    frame.brushState = brush_is_running();
    frame.currentMileage = htonl(BpkParam->param.dayly_mileage);
    frame.currentCleanTime = htonl(BpkParam->param.dayly_work_time);
    frame.batteryVoltage = htons(battery_voltage()*1000);
    frame.batteryStatus = battery_soc();
    frame.batteryTemp = htons(temp_battery()*100);
    frame.cabinetTemp = htons(temp_cabinet()*100);
    frame.temperature = 0;
    frame.windVelocity = 0;
    frame.weather = 0;
    frame.totalMileage = htonll(BpkParam->param.mileage_records);
    frame.totalCleanTime = htonll(BpkParam->param.work_time_records);
    frame.disChargeCurrent = htons(battery_discharge_current()*1000);
    frame.chargeCurrent = htons(battery_charge_current()*1000);
    frame.timestamp = htonll(RobotMap.head.timestamp);
    frame.random = 0;
    frame.satInView = rtk_satinuse();
    frame.satInUse = rtk_satinuse();
    frame.isTaskBreak = 0;
    frame.posValid = 0;
    frame.dirValid = 0;
    memcpy(frame.mapName, RobotMap.head.name, sizeof(RobotMap.head.name));
	frame.cruiseTotal = 0;
	frame.cruiseIndex = 0;
    frame.leftDrvErrCode = motion_left_errcode();
    frame.rightDrvErrCode = motion_right_errcode();
    frame.leftDrvStaCode = motion_left_state();
    frame.rightDrvStaCode = motion_right_state();
    frame.errorFlag = htonl(error());
    frame.onSectorType = 0;
    memcpy(frame.version, RobotParam.firmware_version, VERSION_LENGTH);
    frame.rtkQualitySta = rtk_sig();
    frame.sensor_mask = htonl(RobotParam.sensor_mask.value);
    frame.camera_power_state = camera_pwr_state();
    frame.checkSum = checksum_xor((uint8_t *)&frame, sizeof(frame) - 2);
    frame.tail = FRAME_TAIL;
    
    uart_send_dma(uds, (uint8_t *)&frame, sizeof(frame));
}

static void com_heartbeat_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds)
{
    Frame_HeartBeat_Req *frame;
    
    frame = (Frame_HeartBeat_Req *)data;
    
    if(frame->deveice == 1)
    {
        com_heartbeat_send(data, len, uds);
    }
    else
    {
        CellularDataStruct.no_ack_cnt = 0;
        Warning.CellularAbnormal = 0;
    }
}

static void com_process(uint8_t *data, uint16_t len, UartDataStruct_TypeDef *uds)
{
    switch(data[1])
    {
        case FRAME_TYPE_COMMAND:
            com_command_process(data, len, uds);
            break;
        case FRAME_TYPE_PARAM:
            com_parmeter_process(data, len, uds);
            break;
        case FRAME_TYPE_UPDATE_CMD:
            update_cmd_process(data, len, uds);
            break;
        case FRAME_TYPE_UPDATE_DATA:
            update_transmit_process(data, len, uds);
            break;
        case UPDATE_FRAME_SELECT_MAP:
            update_map_select_process(data, len, uds);
            break;
        case FRAME_TYPE_HEART_BEAT:
            com_heartbeat_process(data, len, uds);
            break;
        default:
            break;
    }
}

void com_task(void)
{
    uint8_t *data;
    int len;
    static uint32_t period = 0;
    static uint32_t wifi_offline_tick = 0;
    static uint32_t cellular_offline_tick = 0;
    static uint32_t auto_send_tick = 0;
    
    if(millis() - period >= 10)
    {
        period = millis();
        
        wifi_setup();
        cellular_setup();
        
        update_timeout_loop_check();
        
        if(!dllist_empty(&WifiDLLink))
        {
            led_on(LED_0);
            data = dllist_front(&WifiDLLink, &len);
            if(com_format_check(data, len))
            {
                com_process(data, len, hWIFI);
                StateMachine.control.app_online = true;
                wifi_offline_tick = millis();
            }
            LL_USART_DisableIT_IDLE(hWIFI->UARTx);
            dllist_pop_front(&WifiDLLink);
            LL_USART_EnableIT_IDLE(hWIFI->UARTx);
            led_off(LED_0);
        }
        
        if(uart_rx_complete(h4G))
        {
            led_on(LED_0);
            data = uart_rx_data(h4G);
            len = uart_rx_data_len(h4G);
            if(com_format_check(data, len))
            {
                com_process(data, len, h4G);
                StateMachine.control.server_online = true;
                cellular_offline_tick = millis();
            }
            uart_rx_clear(h4G);
            led_off(LED_0);
        }
        
        if(millis() - wifi_offline_tick >= 1000)
        {
            wifi_offline_tick = millis();
            StateMachine.control.app_online = false;
        }
        
        if(millis() - cellular_offline_tick >= 5000)
        {
            cellular_offline_tick = millis();
            StateMachine.control.server_online = false;
        }
        
        if(pwr_4g_state() == POWER_STATE_ON 
            && millis() - auto_send_tick >= CellularDataStruct.auto_send_period)
        {
            auto_send_tick = millis();
            com_heartbeat_send(NULL, 0, h4G);
            CellularDataStruct.no_ack_cnt++;
            
            //��������10֡����֡û�лظ�������Ϊ4Gͨ���ж�
            if(CellularDataStruct.no_ack_cnt > 10)
            {
                Warning.CellularAbnormal = 1;
            }
            
            //����5����û������֡�ظ���������4Gģ��
            if(CellularDataStruct.no_ack_cnt > (5*60*1000/CellularDataStruct.auto_send_period))
            {
                CellularDataStruct.no_ack_cnt = 0;
                pwr_4g_cmd(POWER_CMD_RESET);
            }
        }
    }
}
