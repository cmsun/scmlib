#ifndef _MOTION_H_
#define _MOTION_H_

#include <stdint.h>

void motion_init(void);
void motion_set_raduction_ratio(float ratio);
void motion_task(void);
void motion_enable(void);
void motion_disable(void);
void motion_set_velocity(float linear, float angluar);
void motion_fast_stop(void);
float motion_linear_velocity(void);
float motion_angular_velocity(void);
int16_t motion_left_state(void);
int16_t motion_right_state(void);
int16_t motion_left_errcode(void);
int16_t motion_right_errcode(void);
    
#endif