#ifndef _RTK_H_
#define _RTK_H_

#include <stdbool.h>
#include "map.h"

void rtk_init(void);
void rtk_task(void);
double rtk_lattitude_raw(void);
double rtk_longtitude_raw(void);
int rtk_sig(void);
int rtk_satinuse(void);
double rtk_azimuth(void);

#define GPGGA_VALIDATE_MASK (1<<0)
#define GPHDT_VALIDATE_MASK (1<<1)
uint8_t rtk_info(GPS_Point_TypeDef *coord, double *direct);

#endif