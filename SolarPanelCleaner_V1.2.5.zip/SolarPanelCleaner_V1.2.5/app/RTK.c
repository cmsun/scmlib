#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include "nmea/nmea.h"
#include "nmea/tok.h"
#include "RTK.h"
#include "mpuxxxx.h"
#include "uart_utility.h"
#include "pwrctrl.h"
#include "rtc.h"
#include "log.h"
#include "utility.h"
#include "safety.h"

#define RTK_TIMEOUT     1000
#define GPGGA_TIMEOUT   300
#define GPHDT_TIMEOUT   300
#define GPZDA_TIMEOUT   3000

#ifdef VERSION_D2
typedef struct
{
    Gyroscope gyro;
    Acceleration acc;
    EulerAngle eular;
    bool valid;
} MPU6515_TypeDef;

MPU6515_TypeDef MPU6515;
#endif

typedef struct{
    int year;       /**< Years since dc 0 */
    int mon;        /**< Months since January - [1,12] */
    int day;        /**< Day of the month - [1,31] */
    int hour;       /**< Hours since midnight - [0,23] */
    int min;        /**< Minutes after the hour - [0,59] */
    int sec;        /**< Seconds after the minute - [0,59] */
	int hsec;       /**< Seconds after the minute - [0,100] */
    int adj;        /**< local time dis hours - [0,24] */
} RTK_UTC_TypeDef;

typedef struct
{
    uint32_t rtk_timeout;   //RTK�ϵ���������Ժ�һ��ʱ����û���յ�������������ΪRTKͨ�Ŵ���
    
    uint8_t gpgga_cnt;      //GPGGA����50֡�̶������Ϊ��λ��Ч
    uint32_t gpgga_timeout; //GPGGA������֮֡�䳬��һ��ʱ����Ϊ��λ��Ч
    bool gpgga_validate;
    double lat;             //γ��
    double lon;             //����
    int sig;                //GPS��״̬��0δ��λ��1���㶨λ��2��ֶ�λ��3��ЧGPS��4�̶��⣻5����⣻6���ڹ���
    int satinuse;           //����������
    
    uint8_t gphdt_cnt;      //GPHDT����50֡��Ч֡����Ϊ������Ч
    uint32_t gphdt_timeout; //GPHDT������֮֡�䳬��һ��ʱ������Ϊ������Ч
    bool gphdt_validate;
    double azimuth;         //�����
    
    uint8_t gpzda_cnt;
    uint32_t gpzda_timeout;
    bool gpzda_validate;
    RTK_UTC_TypeDef utc;    //UTCʱ��

    uint8_t invalid;        //bit0:GPGGA invalid; bit1:GPHDT invalid
} RTK_TypeDef;

RTK_TypeDef RTK = {.gpgga_validate = false,
                   .gphdt_validate = false,
                   .gpzda_validate = false,
                   .utc.adj = 8, //�й���ʱ���Ƕ�����
                   .invalid = (GPGGA_VALIDATE_MASK | GPHDT_VALIDATE_MASK)};

void rtk_init(void)    
{
#ifdef VERSION_D2
    mpuxxxx_mpu_dmp_init();
#endif
}

static void rtk_gpgga_parse(char *data, uint16_t len)
{
    char *start, *end;
    nmeaGPGGA gpgga;
    nmeaINFO info;
    
    start = strstr((char *)data, "$GPGGA");
    if(start != NULL)
    {
        end = strstr((char *)start, "\r\n");
        if(end != NULL && rtk_format_check(start, end-start+2))
        {
            if(nmea_parse_GPGGA(start, end-start+2, &gpgga))
            {
                nmea_GPGGA2info(&gpgga, &info);
                RTK.lat = nmea_ndeg2degree(gpgga.lat);
                RTK.lon = nmea_ndeg2degree(gpgga.lon);
                RTK.sig = gpgga.sig;
                RTK.satinuse = gpgga.satinuse;
                //����50֡�̶�������Ϊ��λ��Ч
                if(gpgga.sig == 4)
                {
                    if(RTK.gpgga_cnt < 50)
                    {
                        RTK.gpgga_cnt++;
                    }
                    else
                    {
                        RTK.gpgga_validate = true;
                        RTK.invalid &= ~GPGGA_VALIDATE_MASK;
                    }
                    RTK.gpgga_timeout = millis();
                }
                else
                {
                    RTK.gpgga_cnt = 0;
                    RTK.gpgga_validate = false;
                    RTK.invalid |= GPGGA_VALIDATE_MASK;
                }
            }
            else
            {
                RTK.gpgga_cnt = 0;
                RTK.gpgga_validate = false;
                RTK.invalid |= GPGGA_VALIDATE_MASK;
            }
        }
        else
        {
            RTK.gpgga_cnt = 0;
            RTK.gpgga_validate = false;
            RTK.invalid |= GPGGA_VALIDATE_MASK;
        }
    }
}

static void rtk_gphdt_parse(char *data, uint16_t len)
{
    char *start, *end;
    double azimuth;
    
    start = strstr((char *)data, "$GPHDT");
    if(start != NULL)
    {
        end = strstr((char *)start, "\r\n");
        if(end != NULL && rtk_format_check(start, end-start+2))
        {
            if(sscanf(start, "$GPHDT,%lf,*\r\n", &azimuth) == 1)
            {
                RTK.azimuth = azimuth;
                if(RTK.gphdt_cnt < 50)
                {
                    RTK.gphdt_cnt++;
                }
                else
                {
                    RTK.gphdt_validate = true;
                    RTK.invalid &= ~GPHDT_VALIDATE_MASK;
                }
                RTK.gphdt_timeout = millis();
            }
            else
            {
                RTK.gphdt_cnt = 0;
                RTK.gphdt_validate = false;
                RTK.invalid |= GPHDT_VALIDATE_MASK;
            }
        }
        else
        {
            RTK.gphdt_cnt = 0;
            RTK.gphdt_validate = false;
            RTK.invalid |= GPHDT_VALIDATE_MASK;
        }
    }
}

static void rtk_gpzda_parse(char *data, uint16_t len)
{
    char *start, *end;
    RTC_DateTypeDef date;
    RTC_TimeTypeDef time;
    
    start = strstr((char *)data, "$GPZDA");
    if(start != NULL)
    {
        end = strstr((char *)start, "\r\n");
        if(end != NULL && rtk_format_check(start, end-start+2))
        {
            if(sscanf(start, "$GPZDA,%2d%2d%2d.%d,%d,%d,%d,*\r\n",
                &RTK.utc.hour, &RTK.utc.min, &RTK.utc.sec, &RTK.utc.hsec,
                &RTK.utc.day, &RTK.utc.mon, &RTK.utc.year/*, &RTK.utc.adj*/) == 7)
            {
                RTK.gpzda_validate = true;
                RTK.gpzda_timeout = millis();
                
                time.Hours = RTK.utc.hour + RTK.utc.adj;
                time.Minutes = RTK.utc.min;
                time.Seconds = RTK.utc.sec;
                HAL_RTC_SetTime(&hrtc, &time, RTC_FORMAT_BIN);
                
                date.Year = RTK.utc.year;
                date.Month = RTK.utc.mon;
                date.Date = RTK.utc.day;
                HAL_RTC_SetDate(&hrtc, &date, RTC_FORMAT_BIN);
            }
            else
            {
                RTK.gpzda_validate = false;
            }
        }
        else
        {
            RTK.gpzda_validate = false;
        }
    }
}

void rtk_task(void)
{
    char *data;
    int len;
    
#ifdef VERSION_D2
    mpuxxxx_dmp_get_scale_data(&MPU6515.gyro, &MPU6515.acc, (short *)&sensor);
    mpuxxxx_dmp_get_euler(&MPU6515.eular);
#endif
    
    if(!dllist_empty(&RTKDLLink))
    {
        RTK.rtk_timeout = millis();
        
        data = dllist_front(&RTKDLLink, &len);
        rtk_gpgga_parse(data, len);
        rtk_gphdt_parse(data, len);
        rtk_gpzda_parse(data, len);
        LL_USART_DisableIT_IDLE(hRTK->UARTx);
        dllist_pop_front(&RTKDLLink);
        LL_USART_EnableIT_IDLE(hRTK->UARTx);

        if(RTK.gpgga_validate && millis() - RTK.gpgga_timeout >= GPGGA_TIMEOUT)
        {
            RTK.gpgga_cnt = 0;
            RTK.gpgga_validate = false;
        }
        
        if(RTK.gphdt_validate && millis() - RTK.gphdt_timeout >= GPHDT_TIMEOUT)
        {
            RTK.gphdt_cnt = 0;
            RTK.gphdt_validate = false;
        }
        
        if(RTK.gpzda_validate && millis() - RTK.gpzda_timeout >= GPZDA_TIMEOUT)
        {
            RTK.gpzda_validate = false;
        }
        
        log_rtk_printf(data);
    }
    else
    {
        if(pwr_rtk_state() == POWER_STATE_ON && millis() - RTK.rtk_timeout >= RTK_TIMEOUT)
        {
            RTK.rtk_timeout = millis();
            Error.RtkConnectFailed = 1;
        }
    }
}

double rtk_lattitude_raw(void)
{
    return RTK.lat;
}

double rtk_longtitude_raw(void)
{
    return RTK.lon;
}

int rtk_sig(void)
{
    return RTK.sig;
}

int rtk_satinuse(void)
{
    return RTK.satinuse;
}

double rtk_azimuth(void)
{
    return RTK.azimuth;
}

uint8_t rtk_info(GPS_Point_TypeDef *coord, double *direct)
{
    nmeaPOS start, end;
    
    start.lat = degree2radian(RTK.lat);
    start.lon = degree2radian(RTK.lon);
    nmea_move_horz(&start, &end, RTK.azimuth, 0.0002);
    coord->lat = radian2degree(end.lat);
    coord->lon = radian2degree(end.lon);
    
    *direct = RTK.azimuth;
    
    return RTK.invalid;
}